#!/usr/bin/env python3
# PinClock launcher - compiled release (scripts/compile_pyc.py, v0.41.0).
# The app is pinclock_app.pyc next to this file. This stays plain .py:
# pinclock.service runs app.py by path, and the updater reads the version
# line below from this file's text - keep it in exactly this form.
PINCLOCK_VERSION = "v0.55.10"
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pinclock_app  # noqa: E402

if __name__ == "__main__":
    pinclock_app.main()
