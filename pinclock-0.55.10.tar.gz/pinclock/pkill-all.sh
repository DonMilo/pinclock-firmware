# else it was working around is gone.
for f in /tmp/pinclock-mpv-supervisor.pid /tmp/pinclock-cog-supervisor.pid /tmp/pinclock-cursor-loop.pid /tmp/pinclock-mpv-timestamp-loop.pid /tmp/pinclock-watchdog-loop.pid; do
    if [ -f "$f" ]; then
        kill "$(cat "$f")" 2>/dev/null
        rm -f "$f"
    fi
done

pkill labwc
pkill mpv
pkill cog
pkill swaybg
pkill -f "watchdog.py"
pkill -f "pinclock/app.py"

rm -f /tmp/mpvsocket /tmp/pinclock-playlist.m3u /tmp/pinclock-splash.pid
