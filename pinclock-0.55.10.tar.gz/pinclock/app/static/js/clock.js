

const WEEKDAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function getCurrentTime(format, showSeconds) {
    const now = new Date();
    let hour = now.getHours();
    let ampm = "";

    if (format === "12h") {
        ampm = hour < 12 ? "am" : "pm";
        hour = hour % 12;
        if (hour === 0) hour = 12;
    }

    const hh = String(hour).padStart(2, "0");
    const mm = String(now.getMinutes()).padStart(2, "0");
    const ss = String(now.getSeconds()).padStart(2, "0");

    const displayStr = showSeconds === false ? `${hh}:${mm}` : `${hh}:${mm}:${ss}`;
    const minuteKey = `${hh}:${mm}${ampm}`;

    return { displayStr, ampm, minuteKey, now };
}

function getDateString(now) {
    return `${WEEKDAYS[now.getDay()]}  ${MONTHS[now.getMonth()]} ${now.getDate()}`;
}
