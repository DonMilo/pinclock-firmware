
const SS_COLORS = {
    orange: [255, 140, 0],
    red: [255, 30, 16],
    blue: [64, 156, 255],
    green: [64, 255, 120],
    yellow: [255, 228, 20],
    purple: [186, 72, 255],
    cyan: [20, 232, 255],
};
const SS_COLOR_ORDER = ["orange", "red", "blue", "green", "yellow", "purple", "cyan"];
const SS_CORE_COLORS = {
    orange: [255, 210, 120],
    red: [255, 140, 110],
    blue: [170, 220, 255],
    green: [170, 255, 190],
    yellow: [255, 250, 190],
    purple: [226, 184, 255],
    cyan: [185, 250, 255],
};
let SS_CORE = 0.3;
const SS_PURE = [40, 60];
const SS_DEFAULT_COLOR = "orange";
let SS_UNLIT = "rgb(22,22,24)";
let SS_UNLIT14 = "rgb(17,17,19)";
const SS_PANEL = "rgb(6,6,7)";
const SS_PANEL_EDGE = "rgb(34,34,36)";

const SS_DIGIT_W = 0.56;
const SS_DIGIT_GAP = 0.2;
const SS_COLON_W = 0.24;
const SS_T7 = 0.15;
const SS_SMALL_SEC = 0.62;
const SS_AMPM_H = 0.5;
const SS_DATE_H = 0.48;
const SS_ALPHA_W = 0.68;
const SS_ALPHA_GAP = 0.24;
const SS_T14 = 0.15;
const SS_PAD_X = 0.3;
const SS_PAD_Y = 0.24;
const SS_LINE_GAP = 0.26;
const SS_STEP_PX = 128;

const SS_EXTRA14 = {
    "/": ["diagTopRight", "diagBottomLeft"],
    "'": ["vertTop"],
    "+": ["midLeft", "midRight", "vertTop", "vertBottom"],
    "*": ["diagTopLeft", "diagTopRight", "diagBottomLeft", "diagBottomRight", "vertTop", "vertBottom", "midLeft", "midRight"],
};

const SS_OVERRIDE14 = {
    "I": ["top", "bottom", "vertTop", "vertBottom"],
};

const SS_KX = [0.65, 2.5];
const SS_GLOW = 0.06;
const SS_FLASH_MS = [25, 45];
const SS_DIP_MS = 90;

const ssState = { canvas: null, key: null, flicker: null, nextFlickerMs: null, lastMs: -Infinity,
                  prevChars: null, dip: null };

function ssColor(name) {
    return SS_COLORS[name] || SS_COLORS[SS_DEFAULT_COLOR];
}

function ssBright(rgb, b, name) {
    b = Math.max(0, Math.min(2, b === undefined || b === null || isNaN(b) ? 1 : b));
    const pct = b * 50;
    let c = rgb.slice(), core = 0, glow = 0;
    if (pct < SS_PURE[0]) {
        const k = 0.3 + 0.7 * (pct / SS_PURE[0]);
        c = rgb.map((v) => Math.round(v * k));
    } else if (pct > SS_PURE[1]) {
        const t = Math.min(1, (pct - SS_PURE[1]) / (100 - SS_PURE[1]));
        core = t;
        glow = 3.2 * t;
    }
    return { rgb: c, glow, core, b, name };
}

function ssHits(f, idx, seg) {
    if (!f) return false;
    if (f.all) return true;
    if (f.cells) return f.cells.indexOf(idx) !== -1;
    if (f.cell !== idx) return false;
    if (f.part === undefined || f.part === null) return true;
    return ((f.part >>> seg) & 1) === 1;
}

function ssTimeParts(date, is24h, showSeconds, smallSeconds) {
    let h = date.getHours();
    if (!is24h) h = h % 12 || 12;
    const hh = String(h).padStart(2, "0");
    const mm = String(date.getMinutes()).padStart(2, "0");
    const cells = [{ ch: hh[0] }, { ch: hh[1] }, { ch: ":" }, { ch: mm[0] }, { ch: mm[1] }];
    if (showSeconds) {
        const ss = String(date.getSeconds()).padStart(2, "0");
        const small = smallSeconds !== false;
        cells.push({ ch: ":", small }, { ch: ss[0], small }, { ch: ss[1], small });
    }
    return cells;
}

function ssMeasure(cells, ampm, dateStr) {
    let timeW = 0;
    cells.forEach((c, i) => {
        const k = c.small ? SS_SMALL_SEC : 1;
        timeW += (c.ch === ":" ? SS_COLON_W : SS_DIGIT_W) * k;
        if (i < cells.length - 1) timeW += SS_DIGIT_GAP * (c.small ? SS_SMALL_SEC : 1);
    });
    const alphaW = (n, hgt) => n > 0 ? n * SS_ALPHA_W * hgt + (n - 1) * SS_ALPHA_GAP * hgt : 0;
    const ampmW = ampm ? SS_DIGIT_GAP * 1.4 + alphaW(2, SS_AMPM_H) : 0;
    const dateW = dateStr ? alphaW(Array.from(dateStr).length, SS_DATE_H) : 0;
    const lineW = Math.max(timeW + ampmW, dateW);
    return {
        w: lineW + SS_PAD_X * 2,
        h: 1 + (dateStr ? SS_LINE_GAP + SS_DATE_H : 0) + SS_PAD_Y * 2,
        timeW, ampmW, dateW,
    };
}

function ss7Geometry(x0, y0, w, h, t) {
    const g = t * 0.42;
    const L = x0 + t / 2, R = x0 + w - t / 2, T = y0 + t / 2, B = y0 + h - t / 2, M = y0 + h / 2;
    const seg = (ax, ay, bx, by) => segmentPoints(ax, ay, bx, by, t, g);
    return {
        a: seg(L, T, R, T), g: seg(L, M, R, M), d: seg(L, B, R, B),
        f: seg(L, T, L, M), b: seg(R, T, R, M), e: seg(L, M, L, B), c: seg(R, M, R, B),
    };
}

function ss14Geometry(x0, y0, w, h, t) {
    const g = t * 0.42;
    const L = x0 + t / 2, R = x0 + w - t / 2, T = y0 + t / 2, B = y0 + h - t / 2, M = y0 + h / 2, C = x0 + w / 2;
    const seg = (ax, ay, bx, by, th, mg) => segmentPoints(ax, ay, bx, by, th, mg);
    const ti = t * 0.85, gd = t * 1.15;
    return {
        top: seg(L, T, R, T, t, g), bottom: seg(L, B, R, B, t, g),
        topLeft: seg(L, T, L, M, t, g), bottomLeft: seg(L, M, L, B, t, g),
        topRight: seg(R, T, R, M, t, g), bottomRight: seg(R, M, R, B, t, g),
        midLeft: seg(L, M, C, M, t, g), midRight: seg(C, M, R, M, t, g),
        vertTop: seg(C, T, C, M, ti, g), vertBottom: seg(C, M, C, B, ti, g),
        diagTopLeft: seg(L, T, C, M, ti, gd), diagTopRight: seg(R, T, C, M, ti, gd),
        diagBottomLeft: seg(C, M, L, B, ti, gd), diagBottomRight: seg(C, M, R, B, ti, gd),
    };
}

function ssCorePath(ctx, pts, d) {
    const n = pts.length / 2;
    let cx = 0, cy = 0;
    for (let i = 0; i < pts.length; i += 2) { cx += pts[i]; cy += pts[i + 1]; }
    cx /= n; cy /= n;
    let best = -1, ax = 1, ay = 0;
    for (let i = 0; i < pts.length; i += 2) {
        for (let j = i + 2; j < pts.length; j += 2) {
            const dx = pts[j] - pts[i], dy = pts[j + 1] - pts[i + 1], l = dx * dx + dy * dy;
            if (l > best) { best = l; ax = dx; ay = dy; }
        }
    }
    const L = Math.hypot(ax, ay) || 1;
    const ux = ax / L, uy = ay / L, nx = -uy, ny = ux;
    for (let i = 0; i < pts.length; i += 2) {
        const rx = pts[i] - cx, ry = pts[i + 1] - cy;
        let a = rx * ux + ry * uy, p = rx * nx + ry * ny;
        p = Math.sign(p) * Math.max(0, Math.abs(p) - d);
        a = Math.sign(a) * Math.max(0, Math.abs(a) - d * 0.9);
        const x = cx + a * ux + p * nx, y = cy + a * uy + p * ny;
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.closePath();
}

function ssPolys(ctx, list) {
    ctx.beginPath();
    for (const pts of list) {
        ctx.moveTo(pts[0], pts[1]);
        for (let i = 2; i < pts.length; i += 2) ctx.lineTo(pts[i], pts[i + 1]);
        ctx.closePath();
    }
}

function ssRender(ctx, s, cells, ampm, dateStr, rgb, fx, kx, bright, panel) {
    kx = kx || 1;
    bright = bright || ssBright(rgb, 1);
    const tk = Math.min(1, kx);
    const m = ssMeasure(cells, ampm, dateStr);
    const W = m.w * s * kx, H = m.h * s;
    const pn = panel || {};
    const edge = pn.edge !== false;
    const r = pn.radius !== null && pn.radius !== undefined ? pn.radius : Math.max(2, 0.08 * s);
    const lw = edge ? Math.max(1, 0.035 * s) : 0;
    ctx.fillStyle = SS_PANEL;
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(lw / 2, lw / 2, W - lw, H - lw, r);
    else ctx.rect(lw / 2, lw / 2, W - lw, H - lw);
    ctx.fill();
    if (edge) {
        ctx.strokeStyle = SS_PANEL_EDGE;
        ctx.lineWidth = lw;
        ctx.stroke();
    }

    const lit = [], litT = [], half = [], dark = [], dark14 = [], dots = [];
    let tNow = 1;
    let idx = 0;
    const put = (on, pts, alpha14, seg) => {
        const hit = fx && ssHits(fx.target, idx, seg);
        if (on) {
            if (hit && fx.mode === "off") (alpha14 ? dark14 : dark).push(pts);
            else { lit.push(pts); litT.push(tNow); }
        }
        else (hit && fx.mode === "flash" ? half : (alpha14 ? dark14 : dark)).push(pts);
    };
    const lineW = Math.max(m.timeW + m.ampmW, m.dateW);
    let x = (SS_PAD_X + (lineW - m.timeW - m.ampmW) / 2) * s * kx;
    const y0 = SS_PAD_Y * s;
    cells.forEach((c) => {
        const k = c.small ? SS_SMALL_SEC : 1;
        const ch = c.ch;
        const hgt = s * k, top = y0 + s - hgt;
        if (ch === ":") {
            const cw = SS_COLON_W * hgt * kx, rad = SS_T7 * SS_DIGIT_W * hgt * 0.62 * tk;
            const on = !(fx && fx.mode === "off" && ssHits(fx.target, idx, 15));
            dots.push([x + cw / 2, top + hgt * 0.3, rad, on], [x + cw / 2, top + hgt * 0.7, rad, on]);
            x += cw + SS_DIGIT_GAP * hgt * kx;
            idx++;
            return;
        }
        const w = SS_DIGIT_W * hgt * kx;
        tNow = SS_T7 * SS_DIGIT_W * hgt * tk;
        const geo = ss7Geometry(x, top, w, hgt, tNow);
        const on = (typeof LED7_SEGMENTS !== "undefined" && LED7_SEGMENTS[ch]) || "";
        "abcdefg".split("").forEach((sg, i) => put(on.indexOf(sg) !== -1, geo[sg], false, i));
        x += w + SS_DIGIT_GAP * hgt * kx;
        idx++;
    });
    const alpha = (text, ax, ay, hgt) => {
        for (const rawCh of Array.from(text)) {
            const ch = rawCh.toUpperCase();
            const w = SS_ALPHA_W * hgt * kx, t = SS_T14 * SS_ALPHA_W * hgt * tk;
            tNow = t;
            const geo = ss14Geometry(ax, ay, w, hgt, t);
            const on = new Set(SS_OVERRIDE14[ch] || (typeof LED14_SEGMENTS !== "undefined" && LED14_SEGMENTS[ch]) || SS_EXTRA14[ch] || []);
            LED14_SEGMENT_NAMES.forEach((name, i) => put(on.has(name), geo[name], true, i));
            if (ch === "." || ch === ",") dots.push([ax + w * 0.92, ay + hgt * 0.95, t * 0.6, !(fx && fx.mode === "off" && ssHits(fx.target, idx, 15))]);
            ax += w + SS_ALPHA_GAP * hgt * kx;
            idx++;
        }
    };
    if (ampm) alpha(ampm, x + (SS_DIGIT_GAP * 1.4 - SS_DIGIT_GAP) * s * kx, y0, SS_AMPM_H * s);
    if (dateStr) alpha(dateStr, (SS_PAD_X + (lineW - m.dateW) / 2) * s * kx, y0 + (1 + SS_LINE_GAP) * s, SS_DATE_H * s);

    ctx.fillStyle = SS_UNLIT14;
    ssPolys(ctx, dark14);
    ctx.fill();
    ctx.fillStyle = SS_UNLIT;
    ssPolys(ctx, dark);
    ctx.fill();
    for (const d of dots) {
        if (d[3]) continue;
        ctx.beginPath();
        ctx.arc(d[0], d[1], d[2], 0, Math.PI * 2);
        ctx.fill();
    }
    if (half.length) {
        ctx.fillStyle = `rgb(${rgb.map((v) => Math.round(v * 0.45)).join(",")})`;
        ssPolys(ctx, half);
        ctx.fill();
    }
    const [cr, cg, cb] = bright.rgb;
    ctx.save();
    const glowOn = bright.glow > 0.02;
    ctx.shadowColor = glowOn ? `rgba(${cr},${cg},${cb},${Math.min(1, 0.6 + 0.25 * bright.glow).toFixed(2)})` : "transparent";
    ctx.shadowBlur = glowOn ? Math.max(1, SS_GLOW * s * bright.glow) : 0;
    ctx.fillStyle = `rgb(${cr},${cg},${cb})`;
    ssPolys(ctx, lit);
    ctx.fill();
    if (bright.glow > 1.4) {
        ctx.shadowBlur = Math.max(1, SS_GLOW * 2 * s * bright.glow);
        ctx.shadowColor = `rgba(${cr},${cg},${cb},0.55)`;
        ctx.fill();
    }
    ctx.shadowBlur = 0;
    ctx.shadowColor = "transparent";
    ctx.fill();
    ctx.shadowColor = glowOn ? `rgba(${cr},${cg},${cb},${Math.min(1, 0.6 + 0.25 * bright.glow).toFixed(2)})` : "transparent";
    ctx.shadowBlur = glowOn ? Math.max(1, SS_GLOW * s * bright.glow) : 0;
    for (const d of dots) {
        if (!d[3]) continue;
        ctx.beginPath();
        ctx.arc(d[0], d[1], d[2], 0, Math.PI * 2);
        ctx.fill();
    }
    ctx.shadowBlur = 0;
    ctx.shadowColor = "transparent";
    if (SS_CORE > 0 && bright.core > 0.02) {
        const core = (SS_CORE_COLORS[bright.name] || [255, 235, 200]).map((v, i) => Math.round(bright.rgb[i] + (v - bright.rgb[i]) * bright.core));
        ctx.fillStyle = `rgb(${core.join(",")})`;
        ctx.beginPath();
        lit.forEach((pts, i) => ssCorePath(ctx, pts, litT[i] * (1 - SS_CORE) / 2));
        for (const d of dots) {
            if (!d[3]) continue;
            ctx.moveTo(d[0] + d[2] * 0.45, d[1]);
            ctx.arc(d[0], d[1], d[2] * 0.45, 0, Math.PI * 2);
        }
        ctx.fill();
    }
    ctx.restore();
    return m;
}

function ssPlanFlicker(r1, r2, r3, r4, r5, nChars) {
    const n = Math.max(1, nChars || 1);
    let target;
    if (r4 < 0.2) target = { all: true };
    else if (r4 < 0.6) target = { cell: Math.floor(r5 * n) % n };
    else target = { cell: Math.floor(r5 * n) % n, part: Math.floor(r3 * 65536) };
    if (r1 < 0.75) {
        const a = 60 + Math.round(r2 * 90);
        if (r3 < 0.5) return [{ from: 0, to: a, mode: "off", target }];
        return [{ from: 0, to: a, mode: "off", target },
                { from: a + 70, to: a + 70 + Math.round(a * 0.7), mode: "off", target }];
    }
    return [{ from: 0, to: SS_FLASH_MS[0] + Math.round(r2 * (SS_FLASH_MS[1] - SS_FLASH_MS[0])), mode: "flash", target }];
}

function ssChanged(prev, cur) {
    if (!prev || prev.length !== cur.length) return [];
    const out = [];
    for (let i = 0; i < cur.length; i++) if (prev[i] !== cur[i] && cur[i] !== ":") out.push(i);
    return out;
}

function ssFlickerStep(now, enabled, maxMs, nChars) {
    if (ssState.dip) {
        if (now - ssState.dip.t0 < SS_DIP_MS) return { mode: "off", target: ssState.dip.target, id: "dip" + ssState.dip.t0 };
        ssState.dip = null;
    }
    if (!enabled) {
        ssState.flicker = null;
        ssState.nextFlickerMs = null;
        return null;
    }
    const maxGap = Math.max(1500, maxMs || 15000);
    if (ssState.nextFlickerMs === null || now - ssState.lastMs > 5000) {
        ssState.nextFlickerMs = now + 1000 + Math.random() * (maxGap - 1000);
        ssState.flicker = null;
    }
    if (!ssState.flicker && now >= ssState.nextFlickerMs) {
        ssState.flicker = { t0: now, steps: ssPlanFlicker(Math.random(), Math.random(), Math.random(),
                                                          Math.random(), Math.random(), nChars) };
        ssState.nextFlickerMs = now + 1000 + Math.random() * (maxGap - 1000);
    }
    const f = ssState.flicker;
    if (!f) return null;
    const e = now - f.t0;
    const last = f.steps[f.steps.length - 1].to;
    if (e > last) {
        ssState.flicker = null;
        return null;
    }
    const k = f.steps.findIndex((st) => e >= st.from && e < st.to);
    return k < 0 ? null : { mode: f.steps[k].mode, target: f.steps[k].target, id: f.t0 + ":" + k };
}

function ssWantsFrame(now) {
    if (now - ssState.lastMs > 2000) return false;
    return !!ssState.flicker || !!ssState.dip || (ssState.nextFlickerMs !== null && now >= ssState.nextFlickerMs);
}

function ssDrawDisplay(ctx, box, o) {
    const now = o.now !== undefined ? o.now : performance.now();
    const cells = ssTimeParts(o.date || new Date(), !!o.is24h, !!o.showSeconds, o.smallSeconds);
    const ampm = o.ampm ? String(o.ampm).toUpperCase() : "";
    const dateStr = o.dateStr ? String(o.dateStr).toUpperCase() : "";
    const m = ssMeasure(cells, ampm, dateStr);
    let s = Math.max(4, box.h / m.h);
    let kx = box.w / (m.w * s);
    if (kx < SS_KX[0]) { kx = SS_KX[0]; s = Math.max(4, box.w / (m.w * kx)); }
    else if (kx > SS_KX[1]) kx = SS_KX[1];
    const W = m.w * s * kx, H = m.h * s;
    const x = box.x + (box.w - W) / 2, y = box.y + (box.h - H) / 2;
    const rgb = ssColor(o.color);
    const bright = ssBright(rgb, o.brightness, SS_COLORS[o.color] ? o.color : SS_DEFAULT_COLOR);
    if (o.cache === false) {
        ctx.save();
        ctx.translate(x, y);
        ssRender(ctx, s, cells, ampm, dateStr, rgb, null, kx, bright, o);
        ctx.restore();
        return { x, y, w: W, h: H };
    }
    const chars = cells.map((c) => c.ch).concat(Array.from(ampm), Array.from(dateStr));
    if (o.dip) {
        const changed = ssChanged(ssState.prevChars, chars);
        if (changed.length) ssState.dip = { t0: now, target: changed.length === 1 ? { cell: changed[0] } : { cells: changed } };
    }
    ssState.prevChars = chars;
    const fx = ssFlickerStep(now, !!o.flicker, o.flickerMaxMs, chars.length);
    ssState.lastMs = now;
    const pad = Math.ceil(Math.max(0.1, SS_GLOW * 4.5 * bright.glow) * s);
    const cw = Math.ceil(W) + pad * 2, ch = Math.ceil(H) + pad * 2;
    const key = [cells.map((c) => c.ch + (c.small ? "s" : "")).join(""), ampm, dateStr, Math.round(s * 10),
                 Math.round(kx * 100), o.color, bright.rgb.join(","), bright.glow.toFixed(2), bright.core.toFixed(2), o.radius, o.edge, fx ? fx.id : ""].join("|");
    let cv = ssState.canvas;
    if (!cv || cv.width < cw || cv.height < ch) {
        cv = cv || document.createElement("canvas");
        cv.width = Math.max(cv.width || 0, Math.ceil(cw / SS_STEP_PX) * SS_STEP_PX);
        cv.height = Math.max(cv.height || 0, Math.ceil(ch / SS_STEP_PX) * SS_STEP_PX);
        ssState.canvas = cv;
        ssState.key = null;
    }
    if (ssState.key !== key) {
        const c = cv.getContext("2d");
        c.setTransform(1, 0, 0, 1, 0, 0);
        c.clearRect(0, 0, cv.width, cv.height);
        c.translate(pad, pad);
        ssRender(c, s, cells, ampm, dateStr, rgb, fx, kx, bright, o);
        ssState.key = key;
    }
    ctx.drawImage(cv, 0, 0, cw, ch, x - pad, y - pad, cw, ch);
    return { x, y, w: W, h: H };
}
