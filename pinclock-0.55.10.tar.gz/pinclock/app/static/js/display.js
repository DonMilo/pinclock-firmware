


const canvas = document.getElementById("display");
const ctx = canvas.getContext("2d", pinclockIsHighRes() ? { willReadFrequently: true } : undefined);

const MANUFACTURER_NAMES = {
    Capcom: "Capcom", DE: "Data East", Gtb: "Gottlieb",
    Sega: "Sega", Stn: "Stern", Wpc: "Williams",
    Mid: "Midway", Bly: "Bally",
    Ccm: "Chicago Coin", Gp: "Game Plan",
    Wms: "Williams",
    Zac: "Zaccaria", United: "United", Genco: "Genco",
    Sonic: "Sonic",
    Bly35: "Bally System 35",
};
const MANUFACTURER_NAMES_LOWER = {};
Object.keys(MANUFACTURER_NAMES).forEach(function (k) {
    MANUFACTURER_NAMES_LOWER[k.toLowerCase()] = MANUFACTURER_NAMES[k];
});
function splitWords(s) {
    return s
        .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
        .replace(/([A-Za-z])([0-9])/g, "$1 $2");
}
function tidyWords(s) {
    return splitWords(s.replace(/_+/g, " ")).replace(/\s+/g, " ").trim();
}
function finishName(raw) {
    const cut = raw.replace(/[\s_-]*\d+s$/i, "");
    const out = tidyWords(tidyWords(cut) ? cut : raw);
    return out.charAt(0).toUpperCase() + out.slice(1);
}
function decodeVideoName(filename) {
    const base = String(filename || "").replace(/\.[^.]+$/, "");
    const idx = base.indexOf("_");
    if (idx !== -1) {
        const mfgCode = base.slice(0, idx);
        const gameCode = base.slice(idx + 1);
        const mfgKey = mfgCode.toLowerCase();
        if (Object.prototype.hasOwnProperty.call(MANUFACTURER_NAMES_LOWER, mfgKey) && tidyWords(gameCode)) {
            return finishName(gameCode) + " (" + MANUFACTURER_NAMES_LOWER[mfgKey] + ")";
        }
        if (/^[A-Za-z]+$/.test(mfgCode) && tidyWords(gameCode)) {
            return finishName(gameCode) + " (" + mfgCode.charAt(0).toUpperCase() + mfgCode.slice(1) + ")";
        }
    }
    return finishName(base);
}

let _setupQhd = { asked: false, qhd: false };
function setupResolutionText() {
    if (!_setupQhd.asked) {
        _setupQhd.asked = true;
        fetch("/api/display/resolution").then((r) => r.json()).then((d) => {
            _setupQhd.qhd = !!(d && d.display && d.display.qhd === true);
            const el = document.getElementById("setup-overlay-version");
            if (el && systemStatus.version) el.textContent = "PinClock " + systemStatus.version + " \u00b7 " + setupResolutionText();
        }).catch(() => { _setupQhd.asked = false; });
    }
    const [w, h] = getScreenSize();
    return w + "x" + h + (_setupQhd.qhd ? " QHD" : "");
}

function getScreenSize() {
    return [window.innerWidth, window.innerHeight];
}

function resizeCanvas() {
    const [w, h] = getScreenSize();
    canvas.width = w;
    canvas.height = h;
}
window.addEventListener("resize", resizeCanvas);
resizeCanvas();

function ensureCanvasSize() {
    const [w, h] = getScreenSize();
    if (canvas.width !== w || canvas.height !== h) {
        canvas.width = w;
        canvas.height = h;
    }
}

let _lastReportedScreenSize = null;
async function reportScreenSize() {
    const [w, h] = getScreenSize();
    const key = `${w}x${h}`;
    if (key === _lastReportedScreenSize) return;
    try {
        await fetch("/api/system/screen-size", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ width: w, height: h }),
        });
        _lastReportedScreenSize = key;
    } catch (err) {
    }
}
reportScreenSize();
window.addEventListener("resize", reportScreenSize);
setInterval(reportScreenSize, 30000);

if (!window.PINCLOCK_DEFAULTS) {
    console.error("PinClock: window.PINCLOCK_DEFAULTS is missing - display.html didn't inject settings defaults; waiting for /api/settings.");
    window.PINCLOCK_DEFAULTS = {};
}
const DEFAULT_SETTINGS = window.PINCLOCK_DEFAULTS;

let settings = { ...DEFAULT_SETTINGS };

let sleepStatus = { asleep: false };

let tickerAnnouncementActive = false;
let tickerAnnouncementText = "";
let tickerAnnouncementStyle = null;
let tickerAnnouncementLoop = false;
let tickerAnnouncementStill = false;
let tickerAnnouncementUntil = 0;

function triggerTickerAnnouncement(text, style, loop, stillMs) {
    tickerAnnouncementText = text;
    tickerAnnouncementStyle = style || null;
    tickerAnnouncementActive = true;
    tickerAnnouncementLoop = !!loop;
    tickerAnnouncementStill = !loop && stillMs > 0;
    tickerAnnouncementUntil = tickerAnnouncementStill ? performance.now() + stillMs : 0;
    applyBarSettings();
}

const NOW_PLAYING_STILL_MS = 5000;

let nowPlayingName = "";
let nowPlayingUntil = 0;
const NOW_PLAYING_DURATION_MS = 4000;

function triggerNowPlayingBanner(name) {
    nowPlayingName = name;
    nowPlayingUntil = performance.now() + NOW_PLAYING_DURATION_MS;
    applyBarSettings();
    setTimeout(() => {
        if (performance.now() >= nowPlayingUntil) applyBarSettings();
    }, NOW_PLAYING_DURATION_MS + 50);
}

const EMPTY_PLAYLIST_TICKER_TEXT = "No videos in the playlist - showing the clock only. Add some from the app's Video tab.";
const SYSTEM_MESSAGE_TICKER_STYLE = () => ({
    ticker_color: "#ffffff",
    ticker_bg_enabled: true,
    ticker_bg_color: "#000000",
    ticker_bg_opacity: 80,
    ticker_border_enabled: false,
    ticker_direction: "rtl",
    ticker_speed: settings.ticker_speed || DEFAULT_SETTINGS.ticker_speed,
});


let systemStatus = { time_valid: false, playlist_empty: false, first_boot: true, first_boot_countdown_remaining: 0 };
let wasPlaylistEmpty = false;

function checkSystemStatusTransitions() {
    if (wifiStatus.hotspot_active) {
        wasPlaylistEmpty = systemStatus.playlist_empty;
        return;
    }

    if (systemStatus.playlist_empty && !wasPlaylistEmpty && !systemStatus.playlist_empty_by_choice) {
        triggerTickerAnnouncement(EMPTY_PLAYLIST_TICKER_TEXT, SYSTEM_MESSAGE_TICKER_STYLE());
    }
    wasPlaylistEmpty = systemStatus.playlist_empty;
}

let pageReloadScheduled = false;
function reloadIfServerUpdated() {
    const pageVer = window.PINCLOCK_PAGE_VERSION;
    const liveVer = systemStatus.version;
    if (pageReloadScheduled || !pageVer || !liveVer || pageVer === liveVer) return;
    pageReloadScheduled = true;
    console.log("[display] server is now " + liveVer + ", page is " + pageVer + " - reloading");
    setTimeout(() => location.reload(), 3000);
}

let emptyPlaylistLogoShown = false;
let reelBackgroundShown = false;
let reelBackgroundKey = null;

const emState = { video: null, startMs: null, lastTime: null, playing: false, plate: null, seed: 0,
                  plan: null, r: [0, 0, 0], rs: null, spun: false, step: 0 };
let emVideoStarts = 0;
function emActive() {
    return settings.fx_mode === "em" && !sleepStatus.asleep;
}
function emSource() {
    return settings.em_source === "backglasses" ? "backglasses" : "videos";
}
function emVideosActive() { return emActive() && emSource() === "videos" && settings.em_video_clips !== false; }
function emSlidesActive() { return emActive() && emSource() === "backglasses"; }
let _emSlideCache = { src: null, out: null };
const _emPick = { scene: undefined, anchor: null };
function emSlideSettings() {
    if (_emSlideCache.src === settings) return _emSlideCache.out;
    let out = null;
    try {
        reelThemeId(settings);
        const want = "scene:" + (settings.em_scene || "");
        const first = REEL_THEME_ORDER.find((id) => REEL_THEMES[id] && REEL_THEMES[id].scene);
        const pick = REEL_THEMES[want] && REEL_THEMES[want].scene ? want : first;
        const em = settings.em_scene || "";
        if (_emPick.scene !== undefined && em !== _emPick.scene && REEL_THEMES[want]) _emPick.anchor = { id: want, t: Date.now() };
        _emPick.scene = em;
        if (pick) out = Object.assign({}, settings, { clock_style: REEL_CLOCK_STYLE, reel_theme: pick, reel_theme_cycle: false, videos_enabled: false,
                                                      _cycle_anchor: _emPick.anchor });
    } catch (e) { out = null; }
    _emSlideCache = { src: settings, out };
    return out;
}

const SLIDE_CLIP_MAX_MS = 15 * 60 * 1000;
const SLIDE_CLIP_EARLY_MS = 250;
const slideClips = { map: {}, loaded: false };
const slide = { id: null, t0: 0, phase: "still", clipT0: 0, pending: false, picked: null, shown: false, clipName: null, outside: null };
let _slideOutCache = { src: null, id: null, out: null };
function slideClipsOn() { return emSlidesActive() && settings.em_slide_clips === true; }
function slideClipPlaying() { return slideClipsOn() && slide.phase === "clip"; }
function slideClipVisible() { return slideClipPlaying() && slide.shown; }
const SLIDE_VIDEO_ONLY_SHOWN = false;
function slideVideoOnly(id) {
    return SLIDE_VIDEO_ONLY_SHOWN && settings.em_slide_video_only === true && slideClipsOn() && !!id && !!slideClips.map[String(id).slice(6)];
}
function loadSlideClips(first) {
    fetch("/api/em-slides/clips").then((r) => r.json()).then((d) => {
        slideClips.map = (d && d.clips) || {};
        slideClips.loaded = true;
        if (first && d && d.playing) fetch("/api/em-slides/clip-stop", { method: "POST" }).catch(() => {});
    }).catch(() => {});
}
let _slideClipsKey = null;
function noteSlideScenes() {
    const key = JSON.stringify((settings.reel_scenes || []).map((p) => p && [p.id, p.name, !!p.hidden]));
    if (key !== _slideClipsKey) { const first = _slideClipsKey === null; _slideClipsKey = key; loadSlideClips(first); }
}
function slideOrder() {
    try { reelThemeId(settings); } catch (e) { return []; }
    const scenes = REEL_THEME_ORDER.filter((id) => REEL_THEMES[id] && REEL_THEMES[id].scene);
    const want = "scene:" + (settings.em_scene || "");
    const pick = scenes.indexOf(want) !== -1 ? want : scenes[0];
    if (!pick) return [];
    if (settings.reel_scene_cycle !== true) return [pick];
    const ticked = reelCycleOrder(settings).filter((id) => scenes.indexOf(id) !== -1);
    return ticked.length ? ticked : [pick];
}
function slideStillMs() {
    const c = Number(settings.reel_scene_cycle_seconds);
    return (isFinite(c) && c > 0 ? Math.max(REEL_CYCLE_SECONDS_MIN, Math.min(REEL_CYCLE_SECONDS_MAX, c)) : PINCLOCK_DEFAULTS.reel_scene_cycle_seconds) * 1000;
}
function slideGo(id, now) {
    slide.id = id; slide.t0 = now; slide.phase = "still"; slide.pending = false; slide.shown = false; slide.clipName = null;
    slide.clipEndAt = 0;
    slide.lastPoll = 0;
    try {
        const order = slideOrder();
        const next = REEL_THEMES[order[(order.indexOf(id) + 1) % order.length]];
        const sc = next && next.scene;
        if (sc) {
            reelPictureReady("/api/reel-scenes/" + sc.id + ".png?v=" + sc.v);
            if (sc.stretch === false && sc.bars !== false) reelPictureReady("/api/reel-scenes/" + sc.id + "-blur.jpg?v=" + sc.v);
        }
    } catch (e) {   }
}
function slideNext(now) {
    const order = slideOrder();
    if (!order.length) { slide.id = null; return; }
    if (order.length >= 3 && settings.reel_scene_random !== false) {
        slide.bag = (slide.bag || []).filter((id) => order.indexOf(id) !== -1 && id !== slide.id);
        if (!slide.bag.length) {
            slide.bag = order.filter((id) => id !== slide.id);
            for (let i = slide.bag.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                const t = slide.bag[i]; slide.bag[i] = slide.bag[j]; slide.bag[j] = t;
            }
        }
        slideGo(slide.bag.shift(), now);
        return;
    }
    const i = order.indexOf(slide.id);
    slideGo(order[(i + 1) % order.length], now);
}
function slideStartClip(id) {
    slide.pending = true;
    const asked = id;
    fetch("/api/em-slides/clip", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ scene: id.slice(6) }) })
        .then((r) => r.ok ? r.json() : null)
        .catch(() => null)
        .then((d) => {
            if (slide.id !== asked || !slide.pending) return;
            slide.pending = false;
            const now = performance.now();
            if (d && d.ok) { slide.phase = "clip"; slide.clipT0 = now; slide.shown = false; slide.clipName = d.name; slideWatchClip(asked); }
            else slideNext(now);
        });
}
const SLIDE_CLIP_START_WAIT_MS = 30000;
const SLIDE_CLIP_POLL_MS = 2000;
function slideWatchClip(id) {
    const until = performance.now() + SLIDE_CLIP_START_WAIT_MS;
    const look = () => {
        if (slide.id !== id || slide.phase !== "clip" || slide.shown) return;
        if (performance.now() > until) {
            fetch("/api/em-slides/clip-stop", { method: "POST" }).catch(() => {});
            slideNext(performance.now());
            return;
        }
        fetch("/api/status").then((r) => r.json()).then((st) => {
            if (st && st.video === slide.clipName && st.playing && typeof st.time === "number") {
                slide.shown = true;
                slide.clipT0 = performance.now();
                slideTimeClip(id);
            } else setTimeout(look, 400);
        }).catch(() => setTimeout(look, 600));
    };
    look();
}
function slideTimeClip(id) {
    fetch("/api/em-slides/clip-state").then((r) => r.json()).then((d) => {
        if (slide.id !== id || slide.phase !== "clip" || !d || d.name !== slide.clipName) return;
        if (typeof d.time !== "number" || typeof d.duration !== "number" || !(d.duration > 0)) return;
        const left = (d.duration - d.time) * 1000;
        slide.clipEndAt = performance.now() + left;
        if (left > 6000) setTimeout(() => slideTimeClip(id), left - 4000);
    }).catch(() => {});
}
function emSceneShow(p) {
    const id = String((p && p.id) || "");
    const want = "scene:" + id;
    if (!id || !REEL_THEMES[want]) return;
    _emPick.anchor = { id: want, t: Date.now() };
    _emSlideCache.src = null;
    if (emPreview.name) emPreviewEnd({ name: emPreview.name });
    if (slideClipsOn() && (settings.em_scene || "") === id) slide.picked = null;
}

const emPreview = { name: null, t0: 0, shown: false };
function emPreviewActive() { return !!emPreview.name; }
function emPreviewVisible() { return !!emPreview.name && emPreview.shown; }
function emPreviewStart(p) {
    emPreview.name = (p && p.name) || null; emPreview.t0 = performance.now(); emPreview.shown = false;
}
function emPreviewEnd(p) {
    if (!emPreview.name || (p && p.name && p.name !== emPreview.name)) return;
    emPreview.name = null; emPreview.shown = false;
    if (slide.id) { slide.pending = false; slideGo(slide.id, performance.now()); }
}
function drawEmPreviewMini(c, W, H) {
    const a = Math.min(1, (performance.now() - emPreview.t0) / REEL_EM_FADE_MS);
    const s = emMiniSettings();
    if (!emMini.rs) emMini.rs = reelFreshState();
    reelWithState(emMini.rs, () => drawReelClock(c, W, H, s, { alpha: a }));
    return s;
}
function slideClipEnded(p) {
    if (!p || p.reason === "replaced" || slide.phase !== "clip") return;
    if (slide.id && p.scene && slide.id !== "scene:" + p.scene) return;
    slideNext(performance.now());
}
function slideTick() {
    if (!slideClipsOn()) {
        if (slide.id) { slide.id = null; slide.phase = "still"; slide.pending = false; }
        return;
    }
    const now = performance.now();
    const order = slideOrder();
    if (!order.length) { slide.id = null; return; }
    const picked = settings.em_scene || "";
    if (picked !== slide.picked) {
        const wasClip = slide.phase === "clip" || slide.pending;
        slide.picked = picked;
        if (slide.id !== null || wasClip) {
            if (wasClip) fetch("/api/em-slides/clip-stop", { method: "POST" }).catch(() => {});
            const pid = "scene:" + picked;
            const ok = order.indexOf(pid) !== -1 || !!(REEL_THEMES[pid] && REEL_THEMES[pid].scene);
            slide.outside = ok && order.indexOf(pid) === -1 ? pid : null;
            slideGo(ok ? pid : order[0], now);
            return;
        }
    }
    if (!slide.id || (slide.phase === "still" && order.indexOf(slide.id) === -1 && slide.id !== slide.outside)) {
        const want = "scene:" + picked;
        slideGo(order.indexOf(want) !== -1 ? want : order[0], now);
        return;
    }
    if (slide.phase === "still" && !slide.pending && slideClips.loaded && now - slide.t0 >= (slideVideoOnly(slide.id) ? 0 : slideStillMs(slide.id))) {
        if (slideClips.map[slide.id.slice(6)]) slideStartClip(slide.id);
        else slideNext(now);
    } else if (slide.phase === "clip" && !slide.pending && now - (slide.lastPoll || 0) >= SLIDE_CLIP_POLL_MS) {
        slide.lastPoll = now;
        const id = slide.id, name = slide.clipName;
        fetch("/api/em-slides/clip-state").then((r) => r.json()).then((d) => {
            if (slide.id !== id || slide.phase !== "clip" || slide.clipName !== name) return;
            if (!d || d.name !== name) slideNext(performance.now());
        }).catch(() => {});
        if (slide.clipEndAt && now >= slide.clipEndAt - SLIDE_CLIP_EARLY_MS) {
            slideNext(now);
            fetch("/api/em-slides/clip-stop", { method: "POST" }).catch(() => {});
        }
    } else if (slide.phase === "clip" && slide.clipEndAt && now >= slide.clipEndAt - SLIDE_CLIP_EARLY_MS) {
        slideNext(now);
        fetch("/api/em-slides/clip-stop", { method: "POST" }).catch(() => {});
    } else if (slide.phase === "clip" && now - slide.clipT0 > SLIDE_CLIP_MAX_MS) {
        fetch("/api/em-slides/clip-stop", { method: "POST" }).catch(() => {});
        slideNext(now);
    }
}
function slideShowSettings() {
    const base = emSlideSettings();
    if (!base || !slideClipsOn() || !slide.id || !REEL_THEMES[slide.id]) return base;
    if (_slideOutCache.src === base && _slideOutCache.id === slide.id) return _slideOutCache.out;
    const out = Object.assign({}, base, { reel_theme: slide.id, reel_scene_cycle: false });
    _slideOutCache = { src: base, id: slide.id, out };
    return out;
}
function drawSlideClipMini(c, W, H) {
    const a = Math.min(1, (performance.now() - slide.clipT0) / REEL_EM_FADE_MS);
    let s = emMiniSettings();
    const t = slide.id && typeof REEL_THEMES !== "undefined" ? REEL_THEMES[slide.id] : null;
    const sc = t && t.scene;
    if (sc && typeof reelSceneIsSS === "function" && reelSceneIsSS(sc, settings)) {
        if (emMini.ssFor !== sc || emMini.ssSrc !== s) {
            emMini.ssFor = sc; emMini.ssSrc = s;
            emMini.ss = Object.assign({}, s, { _ss_scene: sc, reel_size_pct: EM_MINI_PCT });
        }
        s = emMini.ss;
    }
    if (!emMini.rs) emMini.rs = reelFreshState();
    reelWithState(emMini.rs, () => drawReelClock(c, W, H, s, { alpha: a }));
    return s;
}
function staticClockSettings() {
    const cs = getClockSettings();
    if (cs.clock_style !== REEL_CLOCK_STYLE) return cs;
    let theme = cs.reel_theme;
    const t = typeof REEL_THEMES !== "undefined" ? REEL_THEMES[theme] : null;
    if (t && t.scene) theme = t.sceneBase || PINCLOCK_DEFAULTS.reel_theme;
    const noPlateCycle = emVideosActive() && cs.reel_theme_cycle;
    if (!cs.reel_scene_cycle && theme === cs.reel_theme && !noPlateCycle) return cs;
    return Object.assign({}, cs, { reel_scene_cycle: false, reel_theme: theme, reel_theme_cycle: noPlateCycle ? false : cs.reel_theme_cycle });
}
function emNoteStatus(st) {
    if (!st) return;
    const video = st.video || null;
    if (emPreview.name) {
        if (!emPreview.shown && video === emPreview.name && st.playing) { emPreview.shown = true; emPreview.t0 = performance.now(); }
        return;
    }
    if (video && typeof fxSetStyleVideo === "function") fxSetStyleVideo(video);
    const t = typeof st.time === "number" && isFinite(st.time) ? st.time : null;
    const restarted = video && video === emState.video && t !== null && emState.lastTime !== null && t + 3 < emState.lastTime;
    if (video !== emState.video || restarted) {
        emState.video = video;
        emState.plate = null;
        emState.seed = Math.random();
        emState.r = [Math.random(), Math.random(), Math.random()];
        emState.plan = null;
        emState.rs = null;
        emState.spun = false;
        emState.startMs = null;
        emState.corner = null;
        if (video) emState.step = emVideoStarts++;
    }
    if (t !== null) {
        emState.startMs = performance.now() - t * 1000;
        emState.lastTime = t;
    }
    emState.playing = !!st.playing;
}
function emElapsedS() {
    if (emState.startMs === null) return 0;
    return emState.playing ? (performance.now() - emState.startMs) / 1000 : (emState.lastTime || 0);
}
let _emSettingsCache = { src: null, plate: null, out: null };
function emRotateCorner() {
    const s = settings || {};
    const ms = Math.max(1, s.position_rotate_interval || DEFAULT_SETTINGS.position_rotate_interval) * 1000;
    return ROTATE_CORNERS[Math.floor((performance.now() - rotateStartTime) / ms) % ROTATE_CORNERS.length];
}
let _emPlateCache = { src: null, step: -1, plate: null };
function emClockSettings() {
    if (!emState.video) return null;
    if (_emPlateCache.src !== settings || _emPlateCache.step !== emState.step || !REEL_THEMES[_emPlateCache.plate]) {
        _emPlateCache = { src: settings, step: emState.step, plate: reelEmVideoPlate(settings, emState.step) };
    }
    emState.plate = _emPlateCache.plate;
    if (!emState.plate) return null;
    if (!emState.corner) emState.corner = emRotateCorner();
    if (_emSettingsCache.src !== settings || _emSettingsCache.plate !== emState.plate || _emSettingsCache.corner !== emState.corner) {
        _emSettingsCache = { src: settings, plate: emState.plate, corner: emState.corner,
            out: reelEmSettings(settings, emState.plate, emState.corner) };
    }
    return _emSettingsCache.out;
}
const REEL_EM_VIDEO_PLAN = { enter: "grow", hold: "still", exit: "fade", side: 1 };
function emPlan() {
    if (!emState.plan) emState.plan = Object.assign({}, REEL_EM_VIDEO_PLAN);
    emState.plan.showS = reelEmShowS(settings);
    return emState.plan;
}
function drawEmEffect(c, W, H) {
    const s = emClockSettings();
    if (!s) return null;
    const e = emElapsedS(), plan = emPlan();
    if (!reelEmShowing(plan, e)) return null;
    if (!emState.rs) emState.rs = reelFreshState();
    const lay = emState.rs.layout;
    const m = reelEmMotion(plan, e, W, H, lay ? lay.w : 0, lay ? lay.h : 0);
    if (m.a <= 0) return null;
    if (!emState.rs.lastBox) {
        reelWithState(emState.rs, () => drawReelClock(c, W, H, s, { alpha: 0 }));
    }
    const box = emState.rs.lastBox;
    const cx = box ? box.x + box.w / 2 : W / 2, cy = box ? box.y + box.h / 2 : H / 2;
    c.save();
    c.translate(cx + m.dx, cy + m.dy);
    if (m.s !== 1) c.scale(m.s, m.s);
    c.translate(-cx, -cy);
    try {
        reelWithState(emState.rs, () => {
            drawReelClock(c, W, H, s, { alpha: m.a });
            if (plan.enter === "spin" && !emState.spun && reelState.layout && e < 2) {
                emState.spun = reelEmStartSpin(performance.now());
            }
        });
    } finally {
        c.restore();
    }
    return { s, plan, e };
}
const EM_MINI_PCT = 15;
const EM_MINI_PCT_REELS = 24;
const EM_MINI_POSITION = "top-right";
const emMini = { rs: null, src: null, s: null };
let emMiniDrawn = null;
function emMiniSettings() {
    if (emMini.src !== settings) {
        emMini.src = settings;
        emMini.s = Object.assign({}, settings, {
            clock_style: REEL_CLOCK_STYLE, reel_theme: "bare", reel_theme_cycle: false, reel_scene_cycle: false,
            reel_size_pct: EM_MINI_PCT_REELS, clock_position: EM_MINI_POSITION, position_rotate: false,
            show_seconds: false, show_ampm: false, show_date: false,
            reel_random_flicker: false, reel_lamp_dip: false, reel_hour_flourish: "off", videos_enabled: true,
        });
    }
    return emMini.s;
}
function drawEmMini(c, W, H) {
    if (!emState.video) return null;
    const showS = reelEmShowS(settings);
    const e = emElapsedS();
    if (e < showS) return null;
    const a = Math.min(1, ((e - showS) * 1000) / REEL_EM_FADE_MS);
    const s = emMiniSettings();
    if (!emMini.rs) emMini.rs = reelFreshState();
    reelWithState(emMini.rs, () => drawReelClock(c, W, H, s, { alpha: a }));
    return s;
}

function emFrameInterval() {
    if (emMiniDrawn && emMini.rs) {
        const fading = emPreviewVisible()
            ? performance.now() - emPreview.t0 < REEL_EM_FADE_MS + 100
            : slideClipVisible()
            ? performance.now() - slide.clipT0 < REEL_EM_FADE_MS + 100
            : emElapsedS() - reelEmShowS(settings) < REEL_EM_FADE_MS / 1000 + 0.1;
        if (fading || reelWithState(emMini.rs, () => isReelAnimating(emMiniDrawn))) return FX_FRAME_INTERVAL_MS;
    }
    if (!emDrawn) return null;
    const rate = reelEmFrameRate(emDrawn.plan, emElapsedS());
    let rolling = false;
    if (emState.rs) rolling = reelWithState(emState.rs, () => isReelAnimating(emDrawn.s));
    if (rate === "fast" || rolling) return FX_FRAME_INTERVAL_MS;
    if (rate === "slow") return 100;
    return null;
}

let reelBackgroundPending = false;
const _reelPictures = new Map();
const REEL_PICTURES_KEEP = 8;
function reelPictureReady(url) {
    const have = _reelPictures.get(url);
    if (have) return have !== "loading";
    _reelPictures.set(url, "loading");
    while (_reelPictures.size > REEL_PICTURES_KEEP) _reelPictures.delete(_reelPictures.keys().next().value);
    let im = new Image();
    const done = (state) => {
        if (_reelPictures.get(url) === "loading") _reelPictures.set(url, state);
        if (im) { im.onload = im.onerror = null; im = null; }
    };
    im.onload = () => done("ok");
    im.onerror = () => done("error");
    im.src = url;
    setTimeout(() => done("error"), 4000);
    return false;
}
function updateReelBackground() {
    const el = document.getElementById("reel-background");
    if (!el) return false;
    let scene = null;
    try {
        const slides = emSlidesActive() && !slideClipVisible() && !slideVideoOnly(slide.id) && !emPreviewVisible() ? slideShowSettings() : null;
        scene = !sleepStatus.asleep && slides && typeof reelCurrentScene === "function" ? reelCurrentScene(slides) : null;
    } catch (e) { scene = null; }
    const bars = !!scene && scene.stretch === false && scene.bars !== false;
    const key = scene ? scene.id + "@" + scene.v + "|" + (scene.stretch !== false) + "|" + bars : null;
    reelBackgroundPending = false;
    if (key !== reelBackgroundKey && scene) {
        const urls = ["/api/reel-scenes/" + scene.id + ".png?v=" + scene.v];
        if (bars) urls.push("/api/reel-scenes/" + scene.id + "-blur.jpg?v=" + scene.v);
        if (!urls.every(reelPictureReady)) {
            reelBackgroundPending = true;
            return !!reelBackgroundShown;
        }
    }
    if (key !== reelBackgroundKey) {
        reelBackgroundKey = key;
        if (scene) {
            const pic = 'url("/api/reel-scenes/' + scene.id + '.png?v=' + scene.v + '")';
            el.style.backgroundImage = bars ? pic + ', url("/api/reel-scenes/' + scene.id + '-blur.jpg?v=' + scene.v + '")' : pic;
            el.style.backgroundSize = scene.stretch === false ? (bars ? "contain, cover" : "contain") : "100% 100%";
            el.style.backgroundPosition = "center";
            el.style.backgroundRepeat = "no-repeat";
        }
        el.style.display = scene ? "block" : "none";
    }
    reelBackgroundShown = scene ? scene.id : false;
    try {
        reelVideoStandIn = !sleepStatus.asleep && emSlidesActive() && slideVideoOnly(slide.id) ? String(slide.id).slice(6) : false;
    } catch (e) { reelVideoStandIn = false; }
    return !!scene;
}

function updateEmptyPlaylistLogo() {
    const el = document.getElementById("empty-playlist-logo");
    if (!el) return;
    const bgShown = updateReelBackground();
    const noVideo = emPreviewVisible() ? false
        : emVideosActive() ? !emState.video
        : emSlidesActive() ? !slideClipVisible()
        : !!systemStatus.playlist_empty || settings.videos_enabled === false;
    const show = noVideo && !!settings.empty_playlist_logo && !sleepStatus.asleep && !bgShown;
    if (show && !emptyPlaylistLogoShown) {
        el.style.backgroundImage = 'url("/api/splash.png?t=' + Date.now() + '")';
    }
    if (show !== emptyPlaylistLogoShown) {
        el.style.display = show ? "block" : "none";
        emptyPlaylistLogoShown = show;
    }
}

async function loadSystemStatus() {
    try {
        const res = await fetch("/api/system/status");
        systemStatus = await res.json();
    } catch (err) {
    }
    checkSystemStatusTransitions();
    applyBarSettings();
    updateSetupOverlay();
    updateEmptyPlaylistLogo();
    reloadIfServerUpdated();
}
loadSystemStatus();
fetch("/api/status").then((r) => r.json()).then(emNoteStatus).catch(() => {});
function loadFxStyles() {
    fetch("/api/fx-styles").then((r) => r.json()).then((d) => fxSetStyles(d)).catch(() => {});
}
loadFxStyles();

let connectedOverlayVisibleUntil = 0;
const reminderStartedAt = Date.now();
const MIN_HOTSPOT_QR_SECONDS = 5;
let wifiStatus = { connected: false, hotspot_active: false, remembered_ssid: "", hostname_url: "", hotspot_ssid: "" };
let wasConnected = false;
const FIRST_LOAD_THIS_BOOT = window.PINCLOCK_FIRST_LOAD_THIS_BOOT !== false;
let wifiBaselineTaken = false;

const LAST_CONNECT_OK_SHOW_MS = 5 * 60 * 1000;
const LAST_CONNECT_FAIL_SHOW_MS = 10 * 60 * 1000;
let lastConnectShowUntil = 0;

function noteLastConnect(lc) {
    if (!lc) { lastConnectShowUntil = 0; return; }
    const finishedAt = Date.now() - (lc.seconds_ago || 0) * 1000;
    lastConnectShowUntil = finishedAt + (lc.ok ? LAST_CONNECT_OK_SHOW_MS : LAST_CONNECT_FAIL_SHOW_MS);
}

function lastConnectOverlayActive() {
    const lc = wifiStatus.last_connect;
    if (!lc || lc.settings_opened || Date.now() >= lastConnectShowUntil) return false;
    return lc.ok ? !!wifiStatus.connected : !!wifiStatus.hotspot_active;
}

function wifiActivityText(a) {
    if (!a) return null;
    const q = (s) => "\u201c" + (s || "") + "\u201d";
    if (a.kind === "connecting") {
        return { main: "Connecting to " + q(a.ssid) + "\u2026",
                 sub: "The setup hotspot is off while the clock tries, so your phone may drop off it. The result will show here." };
    }
    if (a.kind === "scanning") {
        return { main: "Looking for saved WiFi networks\u2026",
                 sub: "The setup hotspot is paused for a moment." };
    }
    if (a.kind === "trying") {
        const of = (a.total || 0) > 1 ? " (" + a.index + " of " + a.total + ")" : "";
        return { main: "Trying saved network " + q(a.ssid) + of + "\u2026",
                 sub: a.source === "phone"
                     ? "That didn\u2019t work, so the clock is going back to a network it knows."
                     : "The setup hotspot is paused while the clock tries." };
    }
    if (a.kind === "hotspot") {
        return { main: "Turning the setup hotspot back on\u2026", sub: "" };
    }
    return null;
}

let firstBootQrShownSent = false;
function noteFirstBootQrShown() {
    if (firstBootQrShownSent) return;
    firstBootQrShownSent = true;
    fetch("/api/system/first-boot-qr-shown", { method: "POST" }).catch(() => { firstBootQrShownSent = false; });
}

let activityHoldsOverlay = false;

async function loadWifiStatus() {
    let fresh = false;
    try {
        const res = await fetch("/api/wifi/status");
        wifiStatus = await res.json();
        noteLastConnect(wifiStatus.last_connect);
        fresh = true;
    } catch (err) {
    }
    if (fresh) checkWifiTransition();
    updateSetupOverlay();
}
loadWifiStatus();
setInterval(loadWifiStatus, 30000);

async function loadSleepStatus() {
    try {
        const res = await fetch("/api/system/sleep-status");
        sleepStatus = await res.json();
    } catch (err) {
    }
    applyBarSettings();
    updateSetupOverlay();
    updateEmptyPlaylistLogo();
}
loadSleepStatus();

async function loadCurrentMessage() {
    try {
        const res = await fetch("/api/messages/current");
        const r = await res.json();
        if (r && r.current) msgStart(r.current);
    } catch (err) {
    }
}
loadCurrentMessage();

function checkWifiTransition() {
    if (!wifiBaselineTaken) {
        wifiBaselineTaken = true;
        if (!FIRST_LOAD_THIS_BOOT) {
            wasConnected = wifiStatus.connected;
            return;
        }
    }
    if (wifiStatus.connected && !wasConnected) {
        connectedOverlayVisibleUntil = Date.now() + (settings.boot_qr_duration || DEFAULT_SETTINGS.boot_qr_duration) * 1000;
    }
    wasConnected = wifiStatus.connected;
}

function formatFirstBootCountdown(seconds) {
    const minutes = Math.ceil(seconds / 60);
    if (minutes <= 1) return "Demo mode will start in less than a minute";
    return `Demo mode will start in ${minutes} minutes`;
}

let setupOverlayVisible = false;
function setSetupOverlayVisible(visible) {
    if (visible === setupOverlayVisible) return;
    setupOverlayVisible = visible;
    applyBarSettings();
}

const QR_PANEL_PHYSICAL_W_MM = 354.82;
const QR_PANEL_PHYSICAL_H_MM = 99.97;

function updateQrAspectRatio() {
    const [w, h] = getScreenSize();
    if (!w || !h) return;
    const distortion = (QR_PANEL_PHYSICAL_W_MM * h) / (QR_PANEL_PHYSICAL_H_MM * w);
    document.documentElement.style.setProperty("--qr-aspect-ratio", (1 / distortion).toFixed(4));
}

function updateSetupOverlay() {
    updateFirstBootCountdown();
    updateQrAspectRatio();

    const overlay = document.getElementById("setup-overlay");
    if (sleepStatus.asleep) {
        overlay.style.display = "none";
        setSetupOverlayVisible(false);
        return;
    }
    const wifiKnown = wifiStatus.connected || wifiStatus.remembered_ssid || wifiStatus.hotspot_active;
    const activity = wifiStatus.activity || null;
    if (!activity) {
        activityHoldsOverlay = false;
    } else if (!activityHoldsOverlay && (activity.source === "phone" || setupOverlayVisible)) {
        activityHoldsOverlay = true;
    }
    const activityText = wifiActivityText(activity);
    const showLastConnect = lastConnectOverlayActive() || (activityHoldsOverlay && !!activityText);

    if (showLastConnect) {
    } else if (systemStatus.control_page_loaded || !wifiKnown) {
        overlay.style.display = "none";
        setSetupOverlayVisible(false);
        return;
    }

    if (showLastConnect) {
    } else if (wifiStatus.connected && systemStatus.first_boot) {
        if ((systemStatus.first_boot_countdown_remaining || 0) <= 0) {
            overlay.style.display = "none";
            setSetupOverlayVisible(false);
            return;
        }
    } else if (wifiStatus.connected) {
        if (!settings.show_boot_qr || Date.now() >= connectedOverlayVisibleUntil) {
            overlay.style.display = "none";
            setSetupOverlayVisible(false);
            return;
        }
    } else if (systemStatus.first_boot) {
        if ((systemStatus.first_boot_countdown_remaining || 0) <= 0) {
            overlay.style.display = "none";
            setSetupOverlayVisible(false);
            return;
        }
    } else if (wifiStatus.hotspot_active && !FIRST_LOAD_THIS_BOOT) {
        overlay.style.display = "none";
        setSetupOverlayVisible(false);
        return;
    } else if (wifiStatus.hotspot_active) {
        var hotspotQrSeconds = Math.max(MIN_HOTSPOT_QR_SECONDS, settings.boot_qr_duration || DEFAULT_SETTINGS.boot_qr_duration);
        if (Date.now() >= reminderStartedAt + hotspotQrSeconds * 1000) {
            overlay.style.display = "none";
            setSetupOverlayVisible(false);
            return;
        }
    } else if (!settings.show_boot_qr || !FIRST_LOAD_THIS_BOOT) {
        overlay.style.display = "none";
        setSetupOverlayVisible(false);
        return;
    } else if (Date.now() >= reminderStartedAt + (settings.boot_qr_duration || DEFAULT_SETTINGS.boot_qr_duration) * 1000) {
        overlay.style.display = "none";
        setSetupOverlayVisible(false);
        return;
    }

    if (systemStatus.first_boot) noteFirstBootQrShown();

    const qr1 = document.getElementById("setup-qr-1");
    const qr2Block = document.getElementById("setup-qr-2-block");
    const qr1Label = document.getElementById("setup-qr-1-label");
    const qr1Number = document.getElementById("setup-qr-1-number");
    const qr2Number = document.getElementById("setup-qr-2-number");
    const qr2Suburl = document.getElementById("setup-qr-2-suburl");
    const text = document.getElementById("setup-overlay-text");
    const ssidEl = document.getElementById("setup-overlay-ssid");
    const ipEl = document.getElementById("setup-overlay-ip");
    const versionEl = document.getElementById("setup-overlay-version");
    if (versionEl) versionEl.textContent = systemStatus.version ? ("PinClock " + systemStatus.version + " \u00b7 " + setupResolutionText()) : "";
    const activityEl = document.getElementById("setup-overlay-activity");
    if (activityEl) {
        activityEl.textContent = activityText ? activityText.main : "";
        activityEl.style.display = activityText ? "block" : "none";
    }

    if (wifiStatus.connected) {
        document.getElementById("setup-qr-1-block").style.display = "none";
        if (wifiStatus.ip) {
            qr2Block.style.display = "flex";
            document.getElementById("setup-qr-2").src = "/api/qr/settings-ip.png";
            document.getElementById("setup-qr-2-label").textContent = "Scan for settings";
            qr2Number.style.display = "none";
        } else {
            qr2Block.style.display = "none";
        }
        qr2Suburl.textContent = "";
        ssidEl.textContent = "Connected to: " + (wifiStatus.ssid || "");
        text.textContent = wifiStatus.hostname_url || "";
        ipEl.textContent = wifiStatus.ip ? ("IP: " + wifiStatus.ip) : "";
        overlay.style.display = "flex";
        setSetupOverlayVisible(true);
    } else {
        const hotspotName = wifiStatus.hotspot_ssid || "PinClock-Setup";
        qr1.src = "/api/qr/wifi-join.png";
        qr1Label.textContent = "Scan to join WiFi \u201c" + hotspotName + "\u201d";
        qr1Number.textContent = "1";
        qr1Number.style.display = "block";
        qr2Block.style.display = "flex";
        document.getElementById("setup-qr-2").src = "/static/img/control-url-qr.png";
        document.getElementById("setup-qr-2-label").textContent = "Scan to open settings";
        qr2Suburl.textContent = "or go to 10.42.0.1:5000/control";
        qr2Number.textContent = "2";
        qr2Number.style.display = "block";
        ssidEl.textContent = "Hotspot: " + hotspotName + (activityText && !wifiStatus.hotspot_active ? " (paused)" : "");
        ipEl.textContent = "";
        const lc = wifiStatus.last_connect;
        const retry = wifiStatus.auto_retry;
        if (activityText) {
            text.textContent = activityText.sub;
        } else if (lastConnectOverlayActive() && lc && !lc.ok) {
            text.textContent = "Couldn\u2019t join \u201c" + lc.ssid + "\u201d: " + (lc.reason || "connection failed.") +
                " On your phone, join \u201c" + hotspotName + "\u201d (1), then open settings (2) to try again.";
        } else if (retry && retry.saved && retry.saved.length && wifiStatus.hotspot_active) {
            const names = retry.saved.slice(0, 3).map((n) => "\u201c" + n + "\u201d").join(", ") +
                (retry.saved.length > 3 ? " and " + (retry.saved.length - 3) + " more" : "");
            let when = "";
            if (retry.waiting_for_client) when = " It will try again once nobody is using this hotspot.";
            else if (retry.next_try_in_min) when = " Trying again in about " + retry.next_try_in_min +
                (retry.next_try_in_min === 1 ? " minute." : " minutes.");
            text.textContent = "Can\u2019t reach saved WiFi " + names + "." + when +
                " To set up WiFi now, join \u201c" + hotspotName + "\u201d (1), then open settings (2).";
        } else {
            text.textContent = "Open settings to set time, change clock style, and configure WiFi for firmware updates and to add new videos.";
        }
        overlay.style.display = "flex";
        setSetupOverlayVisible(true);
    }
}

function updateFirstBootCountdown() {
    const el = document.getElementById("setup-overlay-countdown");
    if (!el) return;

    const remaining = systemStatus.first_boot_countdown_remaining || 0;
    const stillInFirstBootWindow = systemStatus.first_boot && setupOverlayVisible;
    if (sleepStatus.asleep || !stillInFirstBootWindow || remaining <= 0) {
        el.style.display = "none";
        el.textContent = "";
        return;
    }

    el.textContent = formatFirstBootCountdown(remaining);
    el.style.display = "block";
}
setInterval(updateSetupOverlay, 5000);

const DEMO_MODE_PREFIX = "PinClock 2.0 Demo Mode";
function unregisteredTickerText() {
    const parts = [];
    for (const key of ["mac_lock", "display_license"]) {
        const v = systemStatus && systemStatus[key];
        if (v && typeof v.ticker === "string" && v.ticker) parts.push(v.ticker);
    }
    return parts.length ? DEMO_MODE_PREFIX + "   \u2022   " + parts.join("   \u2022   ") : "";
}

let _demoTickerBottom = -1;
function updateDemoTickerPosition() {
    const track = document.getElementById("ticker-track");
    if (!track) return;
    let bottom = 0;
    if (unregisteredTickerText() && !sleepStatus.asleep) {
        const h = track.offsetHeight;
        const n = h > 0 ? Math.floor((window.innerHeight - h) / h) : 0;
        if (n > 0) {
            const idx = Math.floor(Date.now() / 60000) % (2 * n);
            bottom = (idx <= n ? idx : 2 * n - idx) * h;
        }
    }
    if (bottom !== _demoTickerBottom) {
        _demoTickerBottom = bottom;
        track.style.bottom = bottom + "px";
    }
}
setInterval(updateDemoTickerPosition, 5000);

function getEffectiveBarSettings() {
    if (sleepStatus.asleep) {
        return { ...settings, title_enabled: false, ticker_enabled: false };
    }

    const unreg = unregisteredTickerText();
    if (unreg) {
        return { ...settings, ...SYSTEM_MESSAGE_TICKER_STYLE(), ticker_enabled: true, ticker_text: unreg };
    }

    let base = settings;

    if (setupOverlayVisible) {
        return { ...base, ticker_enabled: false };
    }

    if (tickerAnnouncementActive) {
        return {
            ...base,
            ...(tickerAnnouncementStyle || {}),
            ticker_enabled: true,
            ticker_text: tickerAnnouncementText,
        };
    }
    if (settings.show_now_playing && nowPlayingName && performance.now() < nowPlayingUntil) {
        return { ...base, title_enabled: true, title_text: nowPlayingName };
    }
    return base;
}

async function loadSettings() {
    try {
        const res = await fetch("/api/settings");
        settings = { ...DEFAULT_SETTINGS, ...(await res.json()) };
    } catch (err) {
    }
    noteSlideScenes();
    applyBarSettings();
    updateSetupOverlay();
    updateEmptyPlaylistLogo();
    ensureTtFontLoaded(settings.tt_font_id);
    ensureTtFontLoaded(settings.fx_font_id);
}
loadSettings();

if (window.io) {
    const socket = io();
    socket.on("settings_updated", (s) => {
        settings = { ...DEFAULT_SETTINGS, ...s };
        noteSlideScenes();
        applyBarSettings();
        updateSetupOverlay();
        updateEmptyPlaylistLogo();
        ensureTtFontLoaded(settings.tt_font_id);
        ensureTtFontLoaded(settings.fx_font_id);
    });
    socket.on("system_status", (s) => {
        systemStatus = s;
        checkSystemStatusTransitions();
        applyBarSettings();
        updateSetupOverlay();
        updateEmptyPlaylistLogo();
        reloadIfServerUpdated();
    });
    socket.on("wifi_status", (w) => {
        wifiStatus = { ...wifiStatus, ...w };
        if ("last_connect" in w) noteLastConnect(w.last_connect);
        checkWifiTransition();
        applyBarSettings();
        updateSetupOverlay();
    });
    socket.on("sleep_status", (s) => {
        sleepStatus = s;
        applyBarSettings();
        updateSetupOverlay();
        updateEmptyPlaylistLogo();
    });
    socket.on("message_show", (p) => msgStart(p));
    socket.on("message_end", (p) => msgEnd(p));
    socket.on("message_current", (r) => {
        if (r && r.current) msgStart(r.current); else msgEnd(null);
    });
    socket.on("status_update", (st) => emNoteStatus(st));
    socket.on("em_slide_clip_end", (p) => slideClipEnded(p));
    socket.on("em_preview", (p) => emPreviewStart(p));
    socket.on("em_scene_show", (p) => emSceneShow(p));
    socket.on("em_preview_end", (p) => emPreviewEnd(p));
    socket.on("em_videos_updated", () => loadSlideClips(false));
    socket.on("fx_styles_updated", (d) => fxSetStyles(d));
    socket.on("connect", () => loadFxStyles());
    socket.on("connect", () => {
        fetch("/api/em-videos/preview").then((r) => r.json()).then((d) => {
            if (d && d.name) { if (emPreview.name !== d.name) emPreviewStart(d); }
            else if (emPreview.name) emPreviewEnd({ name: emPreview.name });
        }).catch(() => {});
    });
    socket.on("video_changed", (v) => {
        if (!settings.show_now_playing) return;
        if (settings.fx_mode === "em") return;
        const name = decodeVideoName(v.name);
        if (settings.ticker_enabled) {
            triggerNowPlayingBanner(name);
        } else {
            triggerTickerAnnouncement(name, null, settings.now_playing_loop, NOW_PLAYING_STILL_MS);
        }
    });
}

function applyBarSettings() {
    if (unregisteredTickerText() && tickerAnnouncementActive) {
        tickerAnnouncementActive = false;
        tickerAnnouncementText = "";
        tickerAnnouncementStyle = null;
        tickerAnnouncementLoop = false;
        tickerAnnouncementStill = false;
        tickerAnnouncementUntil = 0;
    }
    const effective = getEffectiveBarSettings();
    updateTitleBar(effective);
    const tickerOpts = tickerAnnouncementActive
        ? (tickerAnnouncementLoop
            ? undefined
            : {
                once: true,
                still: tickerAnnouncementStill,
                until: tickerAnnouncementUntil,
                onComplete: () => {
                    tickerAnnouncementActive = false;
                    tickerAnnouncementText = "";
                    tickerAnnouncementStyle = null;
                    tickerAnnouncementLoop = false;
                    tickerAnnouncementStill = false;
                    tickerAnnouncementUntil = 0;
                    applyBarSettings();
                },
            })
        : undefined;
    updateTicker(effective, tickerOpts);
    updateDemoTickerPosition();
}

window.addEventListener("resize", () => scheduleBarsResize(applyBarSettings));

const rotateStartTime = performance.now();

function getClockSettings() {
    let s = settings;
    if (s.position_rotate) {
        const intervalMs = Math.max(1, s.position_rotate_interval || DEFAULT_SETTINGS.position_rotate_interval) * 1000;
        const elapsed = performance.now() - rotateStartTime;
        const idx = Math.floor(elapsed / intervalMs) % ROTATE_CORNERS.length;
        s = { ...s, clock_position: ROTATE_CORNERS[idx] };
    }
    return s;
}

function getEffectiveSettings() {
    let s = getClockSettings();
    const barEff = getEffectiveBarSettings();
    if (barEff.title_enabled !== s.title_enabled || barEff.ticker_enabled !== s.ticker_enabled) {
        s = { ...s, title_enabled: barEff.title_enabled, ticker_enabled: barEff.ticker_enabled };
    }
    return s;
}

const CLOCK_REVEAL_DURATION_S = 8;
const clockCycleStartTime = performance.now();

function isClockVisible(s) {
    const mode = s.clock_display_mode || DEFAULT_SETTINGS.clock_display_mode;
    if (mode === "never") return false;
    if (mode !== "interval") return true;
    const periodS = Math.max(CLOCK_REVEAL_DURATION_S + 1, s.clock_display_interval || DEFAULT_SETTINGS.clock_display_interval);
    const elapsedS = (performance.now() - clockCycleStartTime) / 1000;
    const phase = elapsedS % periodS;
    return phase < CLOCK_REVEAL_DURATION_S;
}

let emDrawn = null;
let staticDrawnSettings = null;
function drawFrame() {
    ensureCanvasSize();
    const W = canvas.width;
    const H = canvas.height;
    ctx.clearRect(0, 0, W, H);

    if (sleepStatus.asleep) {
        ctx.fillStyle = "#000000";
        ctx.fillRect(0, 0, W, H);
        return;
    }

    if (emSlidesActive() && !emPreviewActive()) slideTick();
    updateEmptyPlaylistLogo();

    const emVideos = emVideosActive(), emSlides = emSlidesActive();
    const slideClip = emSlides && slideClipVisible();
    if (emPreviewVisible()) {
        emDrawn = null; staticDrawnSettings = null;
        emMiniDrawn = drawEmPreviewMini(ctx, W, H);
        drawMessage(ctx, W, H, getBarInsets(getEffectiveSettings()));
        const br = settings.brightness !== undefined ? settings.brightness : DEFAULT_SETTINGS.brightness;
        if (br < 100) { ctx.fillStyle = `rgba(0,0,0,${(100 - br) / 100})`; ctx.fillRect(0, 0, W, H); }
        return;
    }
    if (((emSlides && !slideClip) || (!emVideos && !emSlides && settings.videos_enabled === false)) && !emptyPlaylistLogoShown && !reelBackgroundShown) {
        ctx.fillStyle = "#000000";
        ctx.fillRect(0, 0, W, H);
    }

    const effSettings = getEffectiveSettings();
    emDrawn = null;
    emMiniDrawn = null;
    staticDrawnSettings = null;
    const slides = emSlides && !slideClip ? slideShowSettings() : null;
    if (slideClip && slideVideoOnly(slide.id)) {
        staticDrawnSettings = slideShowSettings();
        drawReelClock(ctx, W, H, staticDrawnSettings);
    } else if (slideClip) {
        emMiniDrawn = drawSlideClipMini(ctx, W, H);
    } else if (slides && reelBackgroundPending) {
    } else if (slides) {
        drawReelClock(ctx, W, H, slides);
        staticDrawnSettings = slides;
    } else {
        if (emVideos) emDrawn = drawEmEffect(ctx, W, H);
        if (emVideos) emMiniDrawn = drawEmMini(ctx, W, H);
        const emVideoOn = emVideos && !!emState.video;
        if (!emDrawn && !emVideoOn && isClockVisible(settings)) {
            staticDrawnSettings = staticClockSettings();
            renderClockFrame(ctx, W, H, staticDrawnSettings);
        }
    }

    drawFxClock(ctx, W, H, settings);

    drawMessage(ctx, W, H, getBarInsets(effSettings));

    const brightness = settings.brightness !== undefined ? settings.brightness : DEFAULT_SETTINGS.brightness;
    if (brightness < 100) {
        ctx.fillStyle = `rgba(0,0,0,${(100 - brightness) / 100})`;
        ctx.fillRect(0, 0, W, H);
    }

    drawDebugOverlay();
    if (settings.show_fps || debugForced) drawFpsCounter();
}

let fpsFrames = 0;
let fpsLastTime = performance.now();
let fpsValue = 0;

let debugForced = false;
let lastStatus = { video: null, width: null, height: null, cpu_percent: null, cpu_temp_c: null };

async function pollDebugStatus() {
    if (!(settings.show_fps || debugForced)) return;
    try {
        const res = await fetch("/api/status");
        const data = await res.json();
        lastStatus = {
            video: data.video || "(no video)",
            width: data.width || null,
            height: data.height || null,
            cpu_percent: data.cpu_percent,
            cpu_temp_c: data.cpu_temp_c,
        };
    } catch (err) {
        lastStatus = { video: "mpv: unreachable", width: null, height: null, cpu_percent: null, cpu_temp_c: null };
    }
}
setInterval(pollDebugStatus, 500);

let lastRestartCounts = { mpv: 0, cog: 0, flask: null, uptime: null, thermal_throttle_count: 0 };

async function pollRestartCounts() {
    if (!(settings.show_fps || debugForced)) return;
    try {
        const res = await fetch("/api/debug/restart-counts");
        const data = await res.json();
        lastRestartCounts = { mpv: data.mpv, cog: data.cog, flask: data.flask, uptime: data.uptime, thermal_throttle_count: data.thermal_throttle_count };
    } catch (err) {
    }
}
pollRestartCounts();
setInterval(pollRestartCounts, 10000);

function drawFpsCounter() {
    const resText = lastStatus.width && lastStatus.height
        ? `${lastStatus.width}x${lastStatus.height}`
        : "unknown res";
    const eff = getEffectiveSettings();
    const cpuText = lastStatus.cpu_percent != null ? `${lastStatus.cpu_percent}%` : "--";
    const tempText = lastStatus.cpu_temp_c != null ? `${lastStatus.cpu_temp_c}\u00b0C` : "--";
    const deviceName = wifiStatus.hotspot_ssid || "PinClock";
    const ipText = wifiStatus.ip || (wifiStatus.hotspot_active ? "10.42.0.1 (hotspot)" : "no IP");
    const flaskRestartsText = lastRestartCounts.flask === null || lastRestartCounts.flask === undefined ? "?" : lastRestartCounts.flask;
    const lines = [
        `PinClock ${systemStatus.version || ""}`,
        `${deviceName}  (${ipText})`,
        `${fpsValue} fps`,
        `cpu: ${cpuText}  temp: ${tempText}`,
        lastStatus.video || "(no video)",
        `video: ${resText}`,
        `canvas: ${canvas.width}x${canvas.height} (screen: ${getScreenSize().join("x")})`,
        `clock pos: ${eff.clock_position}`,
        `restarts - mpv: ${lastRestartCounts.mpv}  cog: ${lastRestartCounts.cog}  app: ${flaskRestartsText}`,
        `uptime: ${lastRestartCounts.uptime || "?"}`,
        `thermal throttle events: ${lastRestartCounts.thermal_throttle_count || 0}`,
    ];
    if (systemStatus.sfx_thermal_throttled) {
        lines.push("SFX PAUSED - running hot");
    }

    ctx.save();
    ctx.font = "16px monospace";
    ctx.fillStyle = "#3cff78";
    ctx.textAlign = "left";
    ctx.textBaseline = "top";

    const pad = 6;
    const lineHeight = 20;
    const boxW = Math.max(...lines.map((l) => ctx.measureText(l).width)) + pad * 2;
    const boxH = lines.length * lineHeight + pad * 2;
    ctx.fillStyle = "rgba(0,0,0,0.5)";
    ctx.fillRect(4, 4, boxW, boxH);

    ctx.fillStyle = "#3cff78";
    lines.forEach((line, i) => {
        ctx.fillText(line, 4 + pad, 4 + pad + i * lineHeight);
    });
    ctx.restore();
}

const TARGET_FPS = 4;
const FRAME_INTERVAL_MS = 1000 / TARGET_FPS;
const FX_TARGET_FPS = 20;
const FX_FRAME_INTERVAL_MS = 1000 / FX_TARGET_FPS;
let lastDrawTime = 0;

function render() {
    const now = performance.now();

    reportRenderHeartbeat(now);

    fpsFrames++;
    if (now - fpsLastTime >= 1000) {
        fpsValue = fpsFrames;
        fpsFrames = 0;
        fpsLastTime = now;
    }

    try {
        const animating = isFxAnimating(settings);
        const reelsRolling = !sleepStatus.asleep && !!staticDrawnSettings && isReelAnimating(staticDrawnSettings);
        const emInterval = sleepStatus.asleep ? null : emFrameInterval();
        let interval = reelsRolling ? FX_FRAME_INTERVAL_MS
            : animating ? fxFrameIntervalMs()
            : (msgWantsFast() ? MSG_FAST_FRAME_MS : FRAME_INTERVAL_MS);
        if (emInterval !== null) interval = Math.min(interval, emInterval);
        const dueForFrame = now - lastDrawTime >= interval;
        if (dueForFrame) {
            lastDrawTime = now;
            drawFrame();
        }
    } catch (err) {
        reportRenderError(err);
    }

    requestAnimationFrame(render);
}

let lastHeartbeatReportTime = -Infinity;
const RENDER_HEARTBEAT_MIN_INTERVAL_MS = 15000;

function reportRenderHeartbeat(now) {
    if (now - lastHeartbeatReportTime < RENDER_HEARTBEAT_MIN_INTERVAL_MS) return;
    lastHeartbeatReportTime = now;
    fetch("/api/debug/render-heartbeat", { method: "POST" }).catch(() => {});
}

let lastRenderErrorReportTime = -Infinity;
const RENDER_ERROR_REPORT_MIN_INTERVAL_MS = 30000;

function reportRenderError(err) {
    console.error("render() error:", err);
    const now = performance.now();
    if (now - lastRenderErrorReportTime < RENDER_ERROR_REPORT_MIN_INTERVAL_MS) return;
    lastRenderErrorReportTime = now;
    fetch("/api/debug/render-error", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            message: String(err && err.message || err),
            stack: err && err.stack ? String(err.stack) : null,
            fxEffect: (typeof fxState !== "undefined" && fxState.effect) || null,
            fxFont: (typeof fxState !== "undefined" && fxState.fontId) || null,
        }),
    }).catch(() => {});
}


let debugOverlayText = "";
let debugOverlayUntil = 0;

function showDebugOverlay(text, durationMs = 2000) {
    debugOverlayText = text;
    debugOverlayUntil = performance.now() + durationMs;
}

function drawDebugOverlay() {
    if (!debugOverlayText || performance.now() > debugOverlayUntil) return;

    ctx.save();
    ctx.font = "24px monospace";
    ctx.textAlign = "center";
    ctx.textBaseline = "bottom";

    const x = canvas.width / 2;
    const y = canvas.height - 24;

    ctx.lineWidth = 4;
    ctx.strokeStyle = "#000000";
    ctx.strokeText(debugOverlayText, x, y);

    ctx.fillStyle = "#00ff66";
    ctx.fillText(debugOverlayText, x, y);
    ctx.restore();
}

let isPaused = false;

async function mpvTransport(cmd) {
    try {
        await fetch("/api/transport", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ cmd }),
        });
        if (cmd === "play") isPaused = false;
        if (cmd === "pause") isPaused = true;
        pollDebugStatus();
    } catch (err) {
        showDebugOverlay("mpv: unreachable");
    }
}

document.addEventListener("keydown", (e) => {
    switch (e.key) {
        case "F8":
            debugForced = !debugForced;
            if (debugForced) pollDebugStatus();
            break;
        case "ArrowRight":
            mpvTransport("next");
            break;
        case "ArrowLeft":
            mpvTransport("prev");
            break;
        case " ":
            mpvTransport(isPaused ? "play" : "pause");
            e.preventDefault();
            break;
    }
});

render();
