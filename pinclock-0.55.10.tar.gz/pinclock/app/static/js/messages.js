

const MSG_EFFECTS = [
    { id: "show", label: "Show", hint: "Appears all at once, holds, then disappears." },
    { id: "fade", label: "Fade", hint: "Fades in, holds, then fades out." },
    { id: "line_by_line", label: "Line by line", hint: "Each line appears in turn and stays." },
    { id: "one_at_a_time", label: "One line at a time", hint: "Each line fades in and out on its own - drawn bigger, since only one line is on screen." },
    { id: "typewriter", label: "Typewriter", hint: "Types out one letter at a time." },
    { id: "word_by_word", label: "Word by word", hint: "Adds one word at a time." },
    { id: "blink", label: "Blink", hint: "Gently flashes the whole sign." },
    { id: "color_cycle", label: "Color cycle", hint: "Each line steps through the colors. Plain and Shadow fonts only - Color and 3D fonts keep their own colors." },
    { id: "rainbow", label: "Rainbow letters", hint: "Every letter a different color, shifting along. Plain and Shadow fonts only." },
    { id: "spotlight", label: "Spotlight", hint: "Lights up one line at a time while the others dim." },
    { id: "twinkle", label: "Twinkle", hint: "Small stars sparkle around the sign." },
    { id: "drop_in", label: "Drop in", hint: "Lines drop in from the top one after another and bounce into place, then fall away." },
    { id: "letter_drop", label: "Letter drop", hint: "Letters fall into place one at a time." },
    { id: "slide_in", label: "Slide in", hint: "Slides in from the right, holds, then slides out to the left." },
    { id: "scroll_up", label: "Scroll up", hint: "Rises up from the bottom, holds, then rises off the top." },
    { id: "scroll_across", label: "Scroll across", hint: "Moves across the screen from right to left in one pass." },
    { id: "drift", label: "Drift", hint: "Fades in, floats slowly around the screen while it's up, then fades out." },
    { id: "cycle", label: "Cycle", hint: "A different effect each time it shows, working through the whole list." },
];

const MSG_PALETTE = ["#ff0000", "#ff6600", "#ffff00", "#00ff00", "#00ffff", "#0066ff", "#ff00ff"];

const MSG_COLOR_SETS = [
    { id: "rainbow", label: "Rainbow (all colors)", colors: null },
    { id: "usa", label: "Red, white & blue", colors: ["#ff2a2a", "#ffffff", "#2f6bff"] },
    { id: "christmas", label: "Red & green", colors: ["#ff2a2a", "#00cc44"] },
    { id: "halloween", label: "Orange & purple", colors: ["#ff6600", "#9933ff"] },
    { id: "irish", label: "Greens & gold", colors: ["#00cc44", "#99ff66", "#ffcc00"] },
    { id: "valentine", label: "Pinks & red", colors: ["#ff3399", "#ff99cc", "#ff2a2a"] },
    { id: "gold", label: "Gold & white", colors: ["#ffcc00", "#ffffff"] },
    { id: "greenyellow", label: "Green & yellow", colors: ["#00cc44", "#ffcc00"] },
];

function msgPalette(msg) {
    return msg && Array.isArray(msg.colors) && msg.colors.length >= 2 ? msg.colors : MSG_PALETTE;
}

const MSG_SIZE_MAX_REF = 700;
const MSG_WIDTH_FILL = 0.92;
const MSG_HEIGHT_FILL = 0.88;
const MSG_LINE_PITCH = 1.15;
const MSG_FADE_MS = 1200;
const MSG_LINE_FADE_MS = 600;
const MSG_FAST_FRAME_MS = 100;
const MSG_FONT_WAIT_MAX_MS = 5000;
const MSG_BANNER_MAX_CHARS = 200;
const MSG_BANNER_SPEED_MIN = 1, MSG_BANNER_SPEED_MAX = 10, MSG_BANNER_SPEED_DEFAULT = 4;
const MSG_BANNER_SPEED_PRESETS = [
    { id: "slow", label: "Slow", value: 2 },
    { id: "medium", label: "Medium", value: 4 },
    { id: "fast", label: "Fast", value: 7 },
    { id: "fastest", label: "Fastest", value: 10 },
];
const MSG_BANNER_SPEED_LEGACY = { slow: 7, normal: 8, fast: 10 };
function msgBannerSpeed(msg) {
    const v = msg && msg.speed;
    if (MSG_BANNER_SPEED_LEGACY[v]) return MSG_BANNER_SPEED_LEGACY[v];
    const n = Math.round(Number(v));
    return n >= MSG_BANNER_SPEED_MIN && n <= MSG_BANNER_SPEED_MAX ? n : MSG_BANNER_SPEED_DEFAULT;
}
function msgBannerSpeedK(speed) {
    return 2.7 * Math.pow(0.3 / 2.7, (MSG_BANNER_SPEED_MAX - speed) / (MSG_BANNER_SPEED_MAX - MSG_BANNER_SPEED_MIN));
}
const MSG_BANNER_SIZE_MIN = 20, MSG_BANNER_SIZE_MAX = 100, MSG_BANNER_SIZE_DEFAULT = 100;
const MSG_BANNER_SIZE_PRESETS = [
    { id: "small", label: "Small", value: 30 },
    { id: "medium", label: "Medium", value: 50 },
    { id: "large", label: "Large", value: 75 },
    { id: "xlarge", label: "Extra Large", value: 100 },
];
function msgBannerSize(msg) {
    const n = Math.round(Number(msg && msg.banner_size));
    return n >= MSG_BANNER_SIZE_MIN && n <= MSG_BANNER_SIZE_MAX ? n : MSG_BANNER_SIZE_DEFAULT;
}
const MSG_BANNER_PIECE_FILL = 0.5;
const MSG_BANNER_SLOTS = 6;

function msgIsBanner(msg) { return !!msg && msg.kind === "banner"; }

const MSG_FONT_MISSING = {
    "broadcast_titling": "\"#$%'()*+-/<=>@[\\]^_`{|}~",
    "fotokerstkaart": "|",
    "frankens_steina": "#%",
    "goma_block": "&[]^{}~",
    "gradientico": "\"#$%&'()*+-/<=>@[\\]^_`{|}~",
    "kaliber_round": "*^_`{|}~",
    "liquid": "\"#%&'*/<=>@[\\]^_`{|}~",
    "passage_gradient": "#$%&()*+-/<=>@[\\]^_`{|}~",
    "rainbows": "^`|~",
    "thats_super": "`~",
    "wafer": "_`|"
};

function msgMissingChars(text, fontId) {
    const gaps = (fontId && fontId !== "system" && MSG_FONT_MISSING[fontId]) || "";
    const out = [];
    for (const ch of String(text || "")) {
        const code = ch.codePointAt(0);
        const bad = (code < 0x20 || code > 0x7e) || gaps.indexOf(ch) !== -1;
        if (bad && out.indexOf(ch) === -1) out.push(ch);
    }
    return out;
}

function msgClamp01(v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }

function msgRand(seed) {
    const x = Math.sin(seed * 127.1 + 311.7) * 43758.5453;
    return x - Math.floor(x);
}

const _msgMeasureCache = {};

function msgFontReady(fontId) {
    if (!fontId || fontId === "system" || !document.fonts) return true;
    try { return ttFontLoaded(fontId); } catch (e) { return true; }
}

function msgMeasure(ctx, lines, fontId) {
    const key = fontId + "\n" + lines.join("\n");
    if (_msgMeasureCache[key]) return _msgMeasureCache[key];
    ctx.save();
    ctx.font = ttFontStringPx(100, fontId);
    ctx.textBaseline = "alphabetic";
    let asc = 0, desc = 0;
    const widths = lines.map((line) => {
        const m = ctx.measureText(line);
        const a = typeof m.actualBoundingBoxAscent === "number" ? m.actualBoundingBoxAscent : 80;
        const d = typeof m.actualBoundingBoxDescent === "number" ? m.actualBoundingBoxDescent : 20;
        asc = Math.max(asc, a);
        desc = Math.max(desc, d);
        const inkW = typeof m.actualBoundingBoxRight === "number" ? m.actualBoundingBoxRight : 0;
        return Math.max(m.width, inkW);
    });
    const prefixes = lines.map((line) => {
        const pre = [0];
        for (let j = 1; j <= line.length; j++) pre.push(ctx.measureText(line.slice(0, j)).width);
        return pre;
    });
    ctx.restore();
    const result = { widths, asc: asc || 80, desc, prefixes };
    if (msgFontReady(fontId)) {
        if (Object.keys(_msgMeasureCache).length > 100) for (const k in _msgMeasureCache) delete _msgMeasureCache[k];
        _msgMeasureCache[key] = result;
    }
    return result;
}

function msgLayout(ctx, W, H, msg, insets, singleLine) {
    const lines = msg.lines || [];
    const n = singleLine ? 1 : lines.length;
    const meas = msgMeasure(ctx, lines, msg.font_id);
    const top = (insets && insets.top) || 0;
    const usableH = Math.max(20, H - top - ((insets && insets.bottom) || 0));
    const maxW = Math.max(1, ...meas.widths);
    const pitch = Math.max(MSG_LINE_PITCH * 100, (meas.asc + meas.desc) * 1.05);
    const blockH100 = (n - 1) * pitch + meas.asc + meas.desc;
    const zoom = typeof zoomFactor === "function" ? zoomFactor(H) : 1;
    const banner = msgIsBanner(msg);
    const maxRef = (!banner && msg.max_size) || MSG_SIZE_MAX_REF;
    const px = Math.max(8, Math.min(
        banner ? Infinity : 100 * (W * MSG_WIDTH_FILL) / maxW,
        100 * (usableH * MSG_HEIGHT_FILL) / blockH100,
        maxRef * zoom,
    ) * (banner ? msgBannerSize(msg) / 100 : 1));
    const k = px / 100;
    const blockH = blockH100 * k;
    const blockTop = top + (usableH - blockH) / 2;
    const items = lines.map((text, i) => {
        const w = meas.widths[i] * k;
        return {
            text, w,
            pre: (meas.prefixes && meas.prefixes[i] ? meas.prefixes[i] : [0]).map((v) => v * k),
            x: (W - w) / 2,
            baseline: blockTop + meas.asc * k + (singleLine ? 0 : i * pitch * k),
        };
    });
    return {
        px, asc: meas.asc * k, desc: meas.desc * k, items,
        block: { top: blockTop, bottom: blockTop + blockH, left: (W - maxW * k) / 2, right: (W + maxW * k) / 2 },
        usableTop: top, usableBottom: top + usableH,
    };
}

function msgBannerSeconds(ctx, W, H, msg, insets) {
    if (!msg || !msg.lines || !msg.lines.length) return 5;
    const lay = msgLayout(ctx, W, H, msg, insets, false);
    const travel = W + (lay.block.right - lay.block.left) + 20;
    return Math.max(5, Math.min(600, Math.ceil(travel / (msgBannerSpeedK(msgBannerSpeed(msg)) * lay.px))));
}

function msgBannerPieces(item, W) {
    const pre = item.pre, n = item.text.length;
    const target = Math.max(1, W * MSG_BANNER_PIECE_FILL);
    const out = [];
    let a = 0;
    while (a < n) {
        let b = a + 1;
        while (b < n && (pre[b + 1] !== undefined ? pre[b + 1] : item.w) - pre[a] <= target) b++;
        const end = b >= n ? item.w : pre[b];
        out.push({ a, b, x: pre[a], w: Math.max(1, end - pre[a]) });
        a = b;
    }
    return out;
}

function msgFrame(effect, t, D, msg, geo) {
    const lines = msg.lines || [];
    const n = lines.length || 1;
    const st = { env: 1, fast: false, stars: false, lines: lines.map(() => ({ alpha: 1, chars: null, color: msg.color, rainbow: -1, dx: 0, dy: 0, letters: null })) };
    const W = geo ? geo.W : 1000, H = geo ? geo.H : 1000;
    const lay = geo && geo.lay;
    const blk = lay ? lay.block : { top: 0, bottom: 0, left: 0, right: 0 };
    const easeIn = (p) => p * p * p;
    const easeOut = (p) => 1 - Math.pow(1 - p, 3);
    const bounce = typeof easeOutBounce === "function" ? easeOutBounce : easeOut;
    const MOVE_MS = Math.min(1000, D * 0.2);
    const fadeIn = () => { if (t < MSG_FADE_MS) { st.env = Math.min(st.env, t / MSG_FADE_MS); st.fast = true; } };
    const fadeOut = () => { if (t > D - MSG_FADE_MS) { st.env = Math.min(st.env, (D - t) / MSG_FADE_MS); st.fast = true; } };

    if (effect === "fade") {
        fadeIn(); fadeOut();
    } else if (effect === "line_by_line") {
        const step = Math.min(1500, Math.max(300, (D * 0.5) / n));
        st.lines.forEach((l, i) => {
            const since = t - i * step;
            l.alpha = msgClamp01(since / MSG_LINE_FADE_MS);
            if (since > 0 && since < MSG_LINE_FADE_MS) st.fast = true;
        });
        fadeOut();
    } else if (effect === "one_at_a_time") {
        const slot = D / n;
        const cur = Math.min(n - 1, Math.floor(t / slot));
        const local = t - cur * slot;
        const fade = Math.min(MSG_LINE_FADE_MS, slot / 3);
        st.lines.forEach((l, i) => { l.alpha = 0; });
        st.lines[cur].alpha = msgClamp01(Math.min(local / fade, (slot - local) / fade));
        if (local < fade || slot - local < fade) st.fast = true;
    } else if (effect === "typewriter" || effect === "word_by_word") {
        let shown;
        const total = lines.reduce((s, l) => s + l.length, 0);
        if (effect === "typewriter") {
            const typeMs = Math.max(1, Math.min(D * 0.6, total * 110));
            shown = Math.min(total, Math.ceil(total * t / typeMs));
        } else {
            const ends = [];
            let offset = 0;
            lines.forEach((l) => {
                const re = /\S+/g;
                let m;
                while ((m = re.exec(l))) ends.push(offset + m.index + m[0].length);
                offset += l.length;
            });
            const wordMs = Math.min(700, (D * 0.6) / Math.max(1, ends.length));
            const count = Math.min(ends.length, Math.floor(t / wordMs) + 1);
            shown = count ? ends[count - 1] : 0;
        }
        let offset = 0;
        st.lines.forEach((l, i) => {
            const len = lines[i].length;
            const c = Math.max(0, Math.min(len, shown - offset));
            l.chars = c >= len ? null : c;
            if (c === 0) l.alpha = 0;
            offset += len;
        });
        fadeOut();
    } else if (effect === "blink") {
        fadeIn(); fadeOut();
        const tt = t - MSG_FADE_MS;
        if (tt > 0 && t < D - MSG_FADE_MS && tt % 1400 >= 1000) st.env *= 0.15;
    } else if (effect === "color_cycle") {
        fadeIn(); fadeOut();
        const pal = msgPalette(msg);
        const base = Math.max(0, pal.indexOf(String(msg.color).toLowerCase()));
        const step = Math.floor(t / 1000);
        st.lines.forEach((l, i) => { l.color = pal[(base + step + i) % pal.length]; });
    } else if (effect === "rainbow") {
        fadeIn(); fadeOut();
        const step = Math.floor(t / 500);
        st.lines.forEach((l, i) => { l.rainbow = step + i * 2; l.palette = msgPalette(msg); });
    } else if (effect === "spotlight") {
        fadeIn(); fadeOut();
        const step = Math.floor(t / 900);
        if (n === 1) st.lines[0].alpha = step % 2 ? 0.55 : 1;
        else st.lines.forEach((l, i) => { l.alpha = i === step % n ? 1 : 0.3; });
    } else if (effect === "twinkle") {
        fadeIn(); fadeOut();
        st.stars = true;
    }
    else if (effect === "drop_in") {
        const step = Math.min(400, (D * 0.3) / n);
        st.lines.forEach((l, i) => {
            const p = msgClamp01((t - i * step) / MOVE_MS);
            if (p <= 0) { l.alpha = 0; return; }
            if (p < 1) st.fast = true;
            const from = lay ? -(lay.items[i].baseline + lay.desc + lay.px * 0.2) : -H;
            l.dy = from * (1 - bounce(p));
        });
        const out = msgClamp01((t - (D - MOVE_MS)) / MOVE_MS);
        if (out > 0) {
            st.fast = true;
            st.lines.forEach((l) => { l.dy += (H - blk.top + 10) * easeIn(out); });
        }
    } else if (effect === "letter_drop") {
        const total = lines.reduce((sum, l) => sum + l.length, 0) || 1;
        const fall = 450;
        const stagger = Math.min(110, Math.max(20, (D * 0.5 - fall) / total));
        let offset = 0;
        st.lines.forEach((l, i) => {
            const len = lines[i].length;
            const from = lay ? -(lay.items[i].baseline + lay.desc + lay.px * 0.2) : -H;
            const lastP = msgClamp01((t - (offset + len - 1) * stagger) / fall);
            if (lastP < 1) {
                l.letters = [];
                for (let j = 0; j < len; j++) {
                    const p = msgClamp01((t - (offset + j) * stagger) / fall);
                    if (p > 0 && p < 1) st.fast = true;
                    l.letters.push(p <= 0 ? null : { dy: from * (1 - easeOut(p)) });
                }
            }
            offset += len;
        });
        fadeOut();
    } else if (effect === "slide_in") {
        const pin = msgClamp01(t / MOVE_MS);
        const pout = msgClamp01((t - (D - MOVE_MS)) / MOVE_MS);
        const dx = pout > 0 ? -(blk.right + 10) * easeIn(pout) : (W - blk.left + 10) * (1 - easeOut(pin));
        if (pin < 1 || pout > 0) st.fast = true;
        st.lines.forEach((l) => { l.dx = dx; });
    } else if (effect === "scroll_up") {
        const pin = msgClamp01(t / MOVE_MS);
        const pout = msgClamp01((t - (D - MOVE_MS)) / MOVE_MS);
        const dy = pout > 0 ? -(blk.bottom + 10) * easeIn(pout) : (H - blk.top + 10) * (1 - easeOut(pin));
        if (pin < 1 || pout > 0) st.fast = true;
        st.lines.forEach((l) => { l.dy = dy; });
    } else if (effect === "scroll_across" || effect === "banner_drift") {
        const p = msgClamp01(t / D);
        const startDx = W - blk.left + 10, endDx = -(blk.right + 10);
        st.fast = true;
        const dy = effect === "banner_drift" ? msgDriftDy(t, H, blk) : 0;
        st.lines.forEach((l) => { l.dx = startDx + (endDx - startDx) * p; l.dy = dy; });
    } else if (effect === "drift") {
        fadeIn(); fadeOut();
        st.fast = true;
        const ts = t / 1000, ramp = Math.min(1, ts / 1.5);
        const roomX = Math.max(0, Math.min(blk.left, W - blk.right) - 16);
        const dx = Math.sin(2 * Math.PI * (ts / 11 + 0.25)) * roomX * 0.7 * ramp;
        const dy = msgDriftDy(t, H, blk) * ramp;
        st.lines.forEach((l) => { l.dx = dx; l.dy = dy; });
    }
    st.env = msgClamp01(st.env);
    return st;
}

function msgDriftDy(t, H, blk) {
    const roomY = Math.max(0, Math.min(blk.top, H - blk.bottom) - 16);
    return Math.sin(2 * Math.PI * (t / 1000) / 7) * roomY * 0.7;
}

const _msgSlots = [];
const _msgBannerSlots = [];

function msgNewSlot() {
    const canvas = document.createElement("canvas");
    const hiRes = typeof pinclockIsHighRes === "function" ? pinclockIsHighRes() : true;
    return { canvas, ctx: canvas.getContext("2d", hiRes ? { willReadFrequently: true } : undefined), key: null, w: 0, h: 0 };
}

function msgSlot(i) {
    if (!_msgSlots[i]) _msgSlots[i] = msgNewSlot();
    return _msgSlots[i];
}

function msgPrepareLine(i, item, lay, fontId, ls) {
    const text = ls.chars === null ? item.text : item.text.slice(0, ls.chars);
    const key = [text, ls.color, ls.rainbow, (ls.palette || []).join(","), lay.px, fontId, item.w].join("|");
    const slot = msgSlot(i);
    const pad = Math.ceil(lay.px * 0.2);
    if (slot.key === key) return { slot, pad };
    const w = Math.ceil(item.w + pad * 2);
    const h = Math.ceil(lay.asc + lay.desc + pad * 2);
    if (slot.canvas.width < w || slot.canvas.height < h) {
        slot.canvas.width = Math.max(slot.canvas.width, w);
        slot.canvas.height = Math.max(slot.canvas.height, h);
    }
    const c = slot.ctx;
    c.clearRect(0, 0, slot.canvas.width, slot.canvas.height);
    c.font = ttFontStringPx(lay.px, fontId);
    c.textBaseline = "alphabetic";
    c.textAlign = "left";
    const y = pad + lay.asc;
    if (ls.rainbow >= 0) {
        let ci = 0;
        for (let j = 0; j < text.length; j++) {
            const ch = text[j];
            if (ch === " ") continue;
            const pal = ls.palette || MSG_PALETTE;
            c.fillStyle = pal[(ls.rainbow + ci++) % pal.length];
            c.fillText(ch, pad + c.measureText(text.slice(0, j)).width, y);
        }
    } else {
        c.fillStyle = ls.color;
        c.fillText(text, pad, y);
    }
    slot.key = key;
    slot.w = w;
    slot.h = h;
    return { slot, pad };
}

function msgDrawBanner(ctx, W, lay, msg, ls, alpha) {
    const item = lay.items[0];
    if (!item) return;
    if (!lay.pieces) lay.pieces = msgBannerPieces(item, W);
    const pad = Math.ceil(lay.px * 0.2);
    const h = Math.ceil(lay.asc + lay.desc + pad * 2);
    const lineX = item.x + (ls.dx || 0);
    const y0 = Math.round(item.baseline - lay.asc - pad + (ls.dy || 0));
    ctx.save();
    ctx.globalAlpha = alpha;
    lay.pieces.forEach((pc, p) => {
        const sx = lineX + pc.x;
        if (sx + pc.w + pad < 0 || sx - pad > W) return;
        const si = p % MSG_BANNER_SLOTS;
        if (!_msgBannerSlots[si]) _msgBannerSlots[si] = msgNewSlot();
        const slot = _msgBannerSlots[si];
        const text = item.text.slice(pc.a, pc.b);
        const key = [p, text, ls.color, lay.px, msg.font_id, pc.w].join("|");
        const w = Math.ceil(pc.w + pad * 2);
        if (slot.key !== key) {
            if (slot.canvas.width < w || slot.canvas.height < h) {
                slot.canvas.width = Math.max(slot.canvas.width, w);
                slot.canvas.height = Math.max(slot.canvas.height, h);
            }
            const c = slot.ctx;
            c.clearRect(0, 0, slot.canvas.width, slot.canvas.height);
            c.font = ttFontStringPx(lay.px, msg.font_id);
            c.textBaseline = "alphabetic";
            c.textAlign = "left";
            c.fillStyle = ls.color;
            c.fillText(text, pad, pad + lay.asc);
            slot.key = key;
            slot.w = w;
            slot.h = h;
        }
        ctx.drawImage(slot.canvas, 0, 0, slot.w, slot.h, Math.round(sx - pad), y0, slot.w, slot.h);
    });
    ctx.restore();
}

function msgDrawStars(ctx, lay, seq, t, alpha, W) {
    const count = 16;
    const b = lay.block;
    const margin = lay.px * 0.15;
    ctx.save();
    ctx.fillStyle = "#fff6c8";
    for (let i = 0; i < count; i++) {
        let x = 0, y = 0, free = false;
        for (let tries = 0; tries < 24 && !free; tries++) {
            const s = seq * 97 + i * 13 + tries * 7;
            x = msgRand(s) * W;
            y = lay.usableTop + msgRand(s + 1) * (lay.usableBottom - lay.usableTop);
            free = x < b.left - margin || x > b.right + margin || y < b.top - margin || y > b.bottom + margin;
        }
        if (!free) continue;
        const phase = msgRand(seq * 31 + i) * Math.PI * 2;
        const a = alpha * (0.5 + 0.5 * Math.sin(t / 450 + phase));
        if (a <= 0.05) continue;
        const size = lay.px * (0.06 + 0.06 * msgRand(seq * 17 + i));
        const thin = Math.max(1, size * 0.18);
        ctx.globalAlpha = a;
        ctx.fillRect(x - size, y - thin / 2, size * 2, thin);
        ctx.fillRect(x - thin / 2, y - size, thin, size * 2);
        ctx.fillRect(x - size * 0.3, y - size * 0.3, size * 0.6, size * 0.6);
    }
    ctx.restore();
}

function msgDrawBackdrop(ctx, lay, W, opacityPct, alpha) {
    if (!opacityPct) return;
    const pad = lay.px * 0.25;
    const top = Math.max(lay.usableTop, lay.block.top - pad);
    const bottom = Math.min(lay.usableBottom, lay.block.bottom + pad);
    ctx.save();
    ctx.fillStyle = "rgba(0,0,0," + (opacityPct / 100) * alpha + ")";
    ctx.fillRect(0, top, W, bottom - top);
    ctx.restore();
}

const msgState = { current: null };

function msgStart(p) {
    if (!p || !p.message) { msgState.current = null; return; }
    if (msgState.current && msgState.current.seq === p.seq) return;
    const m = p.message;
    const c = {
        seq: p.seq, message: m,
        startPerf: performance.now() - (p.elapsed_ms || 0),
        durationMs: p.duration_ms || (m.duration || 15) * 1000,
        effect: msgIsBanner(m) ? (m.effect === "drift" && !p.throttled ? "banner_drift" : "scroll_across")
            : (p.throttled ? "show" : m.effect),
        throttled: !!p.throttled,
        fontReady: msgFontReady(m.font_id),
        fontWaitStart: performance.now(),
        layoutKey: null, layout: null,
    };
    msgState.current = c;
    if (!c.fontReady) {
        ensureTtFontLoaded(m.font_id).then(() => { c.fontReady = true; c.layoutKey = null; });
    }
}

function msgEnd(p) {
    if (!msgState.current) return;
    if (!p || p.seq === undefined || p.seq === msgState.current.seq) msgState.current = null;
}

function msgIsActive() {
    const c = msgState.current;
    if (!c) return false;
    if (performance.now() - c.startPerf >= c.durationMs) { msgState.current = null; return false; }
    return true;
}

function msgWantsFast() {
    if (!msgIsActive()) return false;
    const c = msgState.current;
    if (msgIsBanner(c.message) && c.throttled) return false;
    return msgFrame(c.effect, performance.now() - c.startPerf, c.durationMs, c.message).fast;
}

function drawMessage(ctx, W, H, insets) {
    if (!msgIsActive()) return;
    const c = msgState.current;
    const m = c.message;
    if (!c.fontReady && performance.now() - c.fontWaitStart < MSG_FONT_WAIT_MAX_MS) return;
    const singleLine = c.effect === "one_at_a_time";
    const key = [W, H, insets.top, insets.bottom, c.fontReady].join("|");
    if (key !== c.layoutKey) {
        c.layout = msgLayout(ctx, W, H, m, insets, singleLine);
        c.layoutKey = key;
    }
    const lay = c.layout;
    const t = performance.now() - c.startPerf;
    const st = msgFrame(c.effect, t, c.durationMs, m, { W, H, lay });
    if (st.env <= 0) return;

    msgDrawBackdrop(ctx, lay, W, m.backdrop, st.env);
    if (msgIsBanner(m)) { msgDrawBanner(ctx, W, lay, m, st.lines[0], st.env * st.lines[0].alpha); return; }
    if (st.stars) msgDrawStars(ctx, lay, c.seq, t, st.env, W);
    lay.items.forEach((item, i) => {
        const ls = st.lines[i];
        const a = ls.alpha * st.env;
        if (a <= 0 || ls.chars === 0) return;
        const { slot, pad } = msgPrepareLine(i, item, lay, m.font_id, ls);
        const x0 = Math.round(item.x - pad + (ls.dx || 0));
        const y0 = Math.round(item.baseline - lay.asc - pad + (ls.dy || 0));
        ctx.save();
        ctx.globalAlpha = a;
        if (ls.letters) {
            const pre = item.pre;
            ls.letters.forEach((lt, j) => {
                if (!lt || j + 1 >= pre.length) return;
                const sx = j === 0 ? 0 : pad + pre[j];
                const ex = j + 2 >= pre.length ? slot.w : pad + pre[j + 1];
                const sw = Math.max(1, Math.ceil(ex - sx));
                ctx.drawImage(slot.canvas, sx, 0, sw, slot.h, x0 + sx, Math.round(y0 + lt.dy), sw, slot.h);
            });
        } else {
            ctx.drawImage(slot.canvas, 0, 0, slot.w, slot.h, x0, y0, slot.w, slot.h);
        }
        ctx.restore();
    });
}

function msgDrawPreview(ctx, W, H, msg, insets) {
    if (!msg || !msg.lines || !msg.lines.length) return;
    const singleLine = msg.effect === "one_at_a_time";
    const lay = msgLayout(ctx, W, H, msg, insets, singleLine);
    msgDrawBackdrop(ctx, lay, W, msg.backdrop, 1);
    if (msgIsBanner(msg)) {
        const item = lay.items[0];
        ctx.save();
        ctx.font = ttFontStringPx(lay.px, msg.font_id);
        ctx.textBaseline = "alphabetic";
        ctx.textAlign = "left";
        ctx.fillStyle = msg.color;
        ctx.fillText(item.text, Math.round(W * 0.03), item.baseline);
        ctx.restore();
        return;
    }
    if (msg.effect === "twinkle") msgDrawStars(ctx, lay, 1, 900, 1, W);
    const items = singleLine ? lay.items.slice(0, 1) : lay.items;
    ctx.save();
    ctx.font = ttFontStringPx(lay.px, msg.font_id);
    ctx.textBaseline = "alphabetic";
    ctx.textAlign = "left";
    const pal = msgPalette(msg);
    items.forEach((item, i) => {
        if (msg.effect === "rainbow") {
            let ci = 0;
            for (let j = 0; j < item.text.length; j++) {
                if (item.text[j] === " ") continue;
                ctx.fillStyle = pal[(i * 2 + ci++) % pal.length];
                ctx.fillText(item.text[j], item.x + ctx.measureText(item.text.slice(0, j)).width, item.baseline);
            }
        } else {
            ctx.fillStyle = msg.effect === "color_cycle"
                ? pal[(Math.max(0, pal.indexOf(String(msg.color).toLowerCase())) + i) % pal.length]
                : msg.color;
            ctx.fillText(item.text, item.x, item.baseline);
        }
    });
    ctx.restore();
}
