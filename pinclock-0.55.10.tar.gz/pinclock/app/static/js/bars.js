

const BAR_HEIGHT_MULTIPLIER = 1.6;

function barHeight(fontSize) {
    return Math.round((fontSize || 0) * BAR_HEIGHT_MULTIPLIER);
}

function hexToRgbBars(hex) {
    const h = (hex || "#000000").replace("#", "");
    return [
        parseInt(h.substring(0, 2), 16) || 0,
        parseInt(h.substring(2, 4), 16) || 0,
        parseInt(h.substring(4, 6), 16) || 0,
    ];
}

function rgbaCss(hex, opacityPct) {
    const [r, g, b] = hexToRgbBars(hex);
    const a = Math.max(0, Math.min(100, opacityPct !== undefined ? opacityPct : 100)) / 100;
    return `rgba(${r},${g},${b},${a})`;
}

function getBarInsets(settings) {
    return {
        top: settings.title_enabled ? barHeight(settings.title_font_size) : 0,
        bottom: settings.ticker_enabled ? barHeight(settings.ticker_font_size) : 0,
    };
}

function updateTitleBar(settings) {
    const el = document.getElementById("titlebar");
    if (!el) return;

    if (!settings.title_enabled) {
        el.style.display = "none";
        return;
    }

    const h = barHeight(settings.title_font_size);
    el.style.display = "flex";
    el.style.height = h + "px";
    el.style.fontSize = (settings.title_font_size || PINCLOCK_DEFAULTS.title_font_size) + "px";
    el.style.color = settings.title_color || PINCLOCK_DEFAULTS.title_color;
    el.style.justifyContent =
        settings.title_align === "left" ? "flex-start" :
        settings.title_align === "right" ? "flex-end" : "center";
    el.style.padding = "0 16px";

    el.style.background = settings.title_bg_enabled
        ? rgbaCss(settings.title_bg_color, settings.title_bg_opacity)
        : "transparent";

    if (settings.title_border_enabled) {
        el.style.borderBottom = `${settings.title_border_width || PINCLOCK_DEFAULTS.title_border_width}px solid ${settings.title_border_color || PINCLOCK_DEFAULTS.title_border_color}`;
    } else {
        el.style.borderBottom = "none";
    }

    if (el.textContent !== settings.title_text) {
        el.textContent = settings.title_text || "";
    }
}

let _tickerSignature = null;
let _tickerStyleEl = null;

function tickerSignature(settings, trackWidth, opts) {
    return [
        settings.ticker_text,
        settings.ticker_font_size,
        settings.ticker_speed,
        settings.ticker_direction,
        trackWidth,
        (opts && opts.still) ? "still" : "scroll",
    ].join("|");
}

function updateTicker(settings, opts) {
    const track = document.getElementById("ticker-track");
    const content = document.getElementById("ticker-content");
    if (!track || !content) return;

    if (!settings.ticker_enabled) {
        track.style.display = "none";
        _tickerSignature = null;
        _clearTickerStillTimer();
        return;
    }

    const h = barHeight(settings.ticker_font_size);
    track.style.display = "block";
    track.style.height = h + "px";
    track.style.background = settings.ticker_bg_enabled
        ? rgbaCss(settings.ticker_bg_color, settings.ticker_bg_opacity)
        : "transparent";

    if (settings.ticker_border_enabled) {
        track.style.borderTop = `${settings.ticker_border_width || PINCLOCK_DEFAULTS.ticker_border_width}px solid ${settings.ticker_border_color || PINCLOCK_DEFAULTS.ticker_border_color}`;
    } else {
        track.style.borderTop = "none";
    }

    content.style.fontSize = (settings.ticker_font_size || PINCLOCK_DEFAULTS.ticker_font_size) + "px";
    content.style.color = settings.ticker_color || PINCLOCK_DEFAULTS.ticker_color;

    if (content.textContent !== settings.ticker_text) {
        content.textContent = settings.ticker_text || "";
    }

    const trackWidth = track.offsetWidth;
    const sig = tickerSignature(settings, trackWidth, opts);
    if (sig === _tickerSignature) return;
    _tickerSignature = sig;

    restartTickerAnimation(settings, track, content, trackWidth, opts);
}

let _tickerOnceHandler = null;

let _tickerStillTimer = null;
function _clearTickerStillTimer() {
    if (_tickerStillTimer) {
        clearTimeout(_tickerStillTimer);
        _tickerStillTimer = null;
    }
}

function restartTickerAnimation(settings, track, content, trackWidth, opts) {
    opts = opts || {};

    content.style.animation = "none";
    content.style.transform = "translateX(0)";

    const contentWidth = content.scrollWidth;
    const speed = Math.max(1, settings.ticker_speed || PINCLOCK_DEFAULTS.ticker_speed);
    const totalDistance = trackWidth + contentWidth;
    const durationSec = totalDistance / speed;

    const rtl = settings.ticker_direction !== "ltr";
    const startX = rtl ? trackWidth : -contentWidth;
    const endX = rtl ? -contentWidth : trackWidth;

    if (!_tickerStyleEl) {
        _tickerStyleEl = document.createElement("style");
        document.head.appendChild(_tickerStyleEl);
    }
    _tickerStyleEl.textContent = `
      @keyframes ticker-scroll {
        from { transform: translateX(${startX}px); }
        to   { transform: translateX(${endX}px); }
      }
    `;

    void content.offsetWidth;

    if (_tickerOnceHandler) {
        content.removeEventListener("animationend", _tickerOnceHandler);
        _tickerOnceHandler = null;
    }
    _clearTickerStillTimer();

    if (opts.still) {
        content.style.animation = "none";
        const x = Math.max(0, Math.round((trackWidth - contentWidth) / 2));
        content.style.transform = `translateX(${x}px)`;
        const wait = Math.max(0, (opts.until || 0) - performance.now());
        _tickerStillTimer = setTimeout(() => {
            _tickerStillTimer = null;
            if (opts.onComplete) opts.onComplete();
        }, wait);
        return;
    }

    if (opts.once) {
        content.style.animation = `ticker-scroll ${durationSec}s linear 1`;
        const handler = () => {
            content.removeEventListener("animationend", handler);
            _tickerOnceHandler = null;
            if (opts.onComplete) opts.onComplete();
        };
        _tickerOnceHandler = handler;
        content.addEventListener("animationend", handler);
    } else {
        content.style.animation = `ticker-scroll ${durationSec}s linear infinite`;
    }
}

let _barsResizeTimer = null;
function scheduleBarsResize(runUpdate) {
    clearTimeout(_barsResizeTimer);
    _barsResizeTimer = setTimeout(() => {
        _tickerSignature = null;
        runUpdate();
    }, 200);
}
