

function hexToRgb(hex) {
    const h = hex.replace("#", "");
    return [
        parseInt(h.substring(0, 2), 16),
        parseInt(h.substring(2, 4), 16),
        parseInt(h.substring(4, 6), 16),
    ];
}

function easeInOut(t) {
    return t * t * (3 - 2 * t);
}

const SIZE_PX = { small: 5, medium: 8, large: 12, xlarge: 20 };
const EFFECT_FRAMES = { slow: 60, medium: 36, fast: 18 };

const REFERENCE_CANVAS_H = 1080;
function zoomFactor(canvasH) {
    return Math.min(2.0, Math.max(0.35, (canvasH || REFERENCE_CANVAS_H) / REFERENCE_CANVAS_H));
}

function dotScale(clockSize, zoom) {
    return resolveSizePx(clockSize, SIZE_PX) * (zoom || 1);
}

function effectFrameCount(effectSpeed) {
    return EFFECT_FRAMES[effectSpeed] || EFFECT_FRAMES.medium;
}

const DMD_FONT_ROWS = { "5x7": 7 };

function dmdRowCount(fontStyle) {
    return DMD_FONT_ROWS[fontStyle] || DMD_FONT_ROWS["5x7"];
}

function dmdTextWidth(text, clockSize, dotGap, fontStyle, zoom) {
    const dot = dotScale(clockSize, zoom);
    const gap = (dotGap || 0) * (zoom || 1);
    const cell = dot + gap;
    const chars = Array.from(text);
    let total = 0;
    chars.forEach((ch, i) => {
        const glyph = dmdGlyph(ch, fontStyle);
        total += glyph[0].length * cell;
        if (i < chars.length - 1) total += cell;
    });
    return total;
}

function dmdTextHeight(clockSize, dotGap, fontStyle, zoom) {
    const dot = dotScale(clockSize, zoom);
    const gap = (dotGap || 0) * (zoom || 1);
    return dmdRowCount(fontStyle) * (dot + gap);
}

const CLOCK_SIZE_PRESET_FRAC = { small: 0.25, medium: 0.5, large: 0.75, xlarge: 1 };
const CLOCK_SIZE_FIT_FRAC = 0.92;
const TT_SIZE_PX = { small: 60, medium: 120, large: CLOCK_SIZE_REF_PX, xlarge: 220 };

function resolveSizePx(clockSize, table) {
    const ratio = clockSizeRatio(clockSize);
    return ratio !== null ? ratio * table.large : (table[clockSize] || table.large);
}


function drawDmdText(ctx, text, x0, y0, opts) {
    const dot = dotScale(opts.size, opts.zoom);
    const gap = (opts.gap || 0) * (opts.zoom || 1);
    const cell = dot + gap;
    const [r, g, b] = hexToRgb(opts.color);
    const dim = [r * 0.1, g * 0.1, b * 0.1];
    const glow = opts.glow;
    const alpha = opts.alpha !== undefined ? opts.alpha : 1;
    const rad = dot / 2;
    const fontStyle = opts.fontStyle || "5x7";

    const litDots = [];
    const dimDots = [];

    let xoff = x0;
    for (const ch of text) {
        const glyph = dmdGlyph(ch, fontStyle);
        const colsN = glyph[0].length;

        for (let rIdx = 0; rIdx < glyph.length; rIdx++) {
            const row = glyph[rIdx];
            for (let c = 0; c < row.length; c++) {
                const lit = row[c] === "1";
                const cx = xoff + c * cell + rad;
                const cy = y0 + rIdx * cell + rad;
                (lit ? litDots : dimDots).push(cx, cy);
            }
        }
        xoff += (colsN + 1) * cell;
    }

    function fillDots(dots, radius, color) {
        if (dots.length === 0) return;
        ctx.beginPath();
        for (let i = 0; i < dots.length; i += 2) {
            ctx.moveTo(dots[i] + radius, dots[i + 1]);
            ctx.arc(dots[i], dots[i + 1], radius, 0, Math.PI * 2);
        }
        ctx.fillStyle = color;
        ctx.fill();
    }

    if (glow) {
        const gCol = [Math.min(255, r * 1.4), Math.min(255, g * 1.4), Math.min(255, b * 1.4)];
        fillDots(litDots, rad + 3, `rgba(${gCol[0]},${gCol[1]},${gCol[2]},${alpha * 0.4})`);
    }
    fillDots(dimDots, rad, `rgba(${dim[0]},${dim[1]},${dim[2]},${alpha})`);
    fillDots(litDots, rad, `rgba(${r},${g},${b},${alpha})`);
}

const TT_FONTS = {
    system: { label: "Default", family: "'DejaVu Sans', Arial, sans-serif", weight: "bold" },
    asimovian: { label: "Asimovian", family: "'Asimovian'", weight: "normal" },
    caprasimo: { label: "Caprasimo", family: "'Caprasimo'", weight: "normal" },
    chango: { label: "Chango", family: "'Chango'", weight: "normal" },
    climate_crisis: { label: "Climate Crisis", family: "'Climate Crisis'", weight: "normal" },
    coiny: { label: "Coiny", family: "'Coiny'", weight: "normal" },
    faster_one: { label: "Faster One", family: "'Faster One'", weight: "normal" },
    jolly_lodger: { label: "Jolly Lodger", family: "'Jolly Lodger'", weight: "normal" },
    luckiest_guy: { label: "Luckiest Guy", family: "'Luckiest Guy'", weight: "normal" },
    monoton: { label: "Monoton", family: "'Monoton'", weight: "normal" },
    permanent_marker: { label: "Permanent Marker", family: "'Permanent Marker'", weight: "normal" },
    plaster: { label: "Plaster", family: "'Plaster'", weight: "normal" },
    press_start_2p: { label: "Press Start 2P", family: "'Press Start 2P'", weight: "normal" },
    ranchers: { label: "Ranchers", family: "'Ranchers'", weight: "normal" },
    revalia: { label: "Revalia", family: "'Revalia'", weight: "normal" },
    rubik_glitch: { label: "Rubik Glitch", family: "'Rubik Glitch'", weight: "normal" },
    sekuya: { label: "Sekuya", family: "'Sekuya'", weight: "normal" },
    tac_one: { label: "Tac One", family: "'Tac One'", weight: "normal" },
    unifraktur_cook: { label: "UnifrakturCook", family: "'UnifrakturCook'", weight: "bold" },
    wallpoet: { label: "Wallpoet", family: "'Wallpoet'", weight: "normal" },
    bungee_spice: { label: "Bungee Spice", family: "'Bungee Spice'", weight: "normal", color: true },
    honk: { label: "Honk", family: "'Honk'", weight: "normal", color: true },
    nabla: { label: "Nabla", family: "'Nabla'", weight: "normal", threeD: true },

    digitalts_lime: { label: "DigitaltS (Lime)", family: "'DigitaltS-Lime'", group: "digitalts", weight: "normal", threeD: true },
    digitalts_orange: { label: "DigitaltS (Orange)", family: "'DigitaltS-Orange'", group: "digitalts", weight: "normal", threeD: true },
    digitalts_plum: { label: "DigitaltS (Plum)", family: "'DigitaltS-Plum'", group: "digitalts", weight: "normal", threeD: true },

    digitalts_strawberry: { label: "DigitaltS (Strawberry)", family: "'DigitaltS-Strawberry'", weight: "normal", threeD: true, group: "digitalts" },
    broadcast_titling: { label: "Broadcast Titling", family: "'Broadcast Titling'", weight: "normal" },
    fotokerstkaart: { label: "Fotokerstkaart", family: "'Fotokerstkaart'", weight: "normal" },
    karnivore_digit: { label: "Karnivore Digit", family: "'Karnivore Digit'", weight: "normal" },
    passage_gradient: { label: "Passage Gradient", family: "'Passage Gradient'", weight: "normal" },
    wafer: { label: "Wafer", family: "'Wafer'", weight: "normal" },
    liquid: { label: "Liquid", family: "'Liquid 3D'", weight: "normal", threeD: true },
    orange_gummy: { label: "Orange Gummy", family: "'Orange Gummy 3D'", weight: "normal", threeD: true },
    coffee_town: { label: "Coffee Town", family: "'Coffee Town 3D'", weight: "normal", threeD: true },
    frankens_steina: { label: "Franken's SteinA", family: "'Frankens SteinA 3D'", weight: "normal", threeD: true },
    linolschrift: { label: "Linolschrift", family: "'Linolschrift 3D'", weight: "normal", threeD: true },
    matcha_world: { label: "Matcha World", family: "'Matcha World 3D'", weight: "normal", threeD: true },
    merkin_goo: { label: "Merkin Goo", family: "'Merkin Goo 3D'", weight: "normal", threeD: true },
    playgum: { label: "Playgum", family: "'Playgum 3D'", weight: "normal", threeD: true },
    thats_super: { label: "That's Super", family: "'Thats Super 3D'", weight: "normal", threeD: true },
    rainbows: { label: "Rainbows", family: "'Rainbows 01 Outline Thick'", weight: "normal", color: true },
    bungee_color: { label: "Bungee Color", family: "'Bungee Color Regular'", weight: "normal", color: true },
    arbutus: { label: "Sorkin Western", family: "'Sorkin Western Shadow'", weight: "normal", shadowFX: true },
    black_ops_one: { label: "Black Ops One", family: "'Black Ops One Shadow'", weight: "normal", shadowFX: true },
    caesar_dressing: { label: "Toga Party", family: "'Toga Party Shadow'", weight: "normal", shadowFX: true },
    creepster: { label: "Drip Scare", family: "'Drip Scare Shadow'", weight: "normal", shadowFX: true },
    matemasie: { label: "Matemasie", family: "'Matemasie Shadow'", weight: "normal", shadowFX: true },
    new_rocker: { label: "Rock Gothic", family: "'Rock Gothic Shadow'", weight: "normal", shadowFX: true },
    rubik_wet_paint: { label: "Rubik Wet Paint", family: "'Rubik Wet Paint Shadow'", weight: "normal", shadowFX: true },
    slackey: { label: "Slackey", family: "'Slackey Shadow'", weight: "normal", shadowFX: true },
    zen_dots: { label: "Zen Dots", family: "'Zen Dots Shadow'", weight: "normal", shadowFX: true },
    gradientico: { label: "Gradientico", family: "'Gradientico Shadow'", weight: "normal", shadowFX: true },
    zschusch_light: { label: "Zschusch Light", family: "'Zschusch Light Shadow'", weight: "normal", shadowFX: true },
    yay_holiday: { label: "Yay Holiday", family: "'Yay Holiday Shadow'", weight: "normal", shadowFX: true },
    supercomputer: { label: "Supercomputer", family: "'Supercomputer Shadow'", weight: "normal", shadowFX: true },
    goma_block: { label: "Goma Block", family: "'Goma Block Shadow'", weight: "normal", shadowFX: true },
    blackwood_castle: { label: "Blackwood Castle", family: "'Blackwood Castle Shadow'", weight: "normal", shadowFX: true },
    yeasty_flavors: { label: "Yeasty Flavors", family: "'Yeasty Flavors Shadow'", weight: "normal", shadowFX: true },
    freckle_face: { label: "Speckled", family: "'Speckled Shadow'", weight: "normal", shadowFX: true },
    henny_penny: { label: "Story Hen", family: "'Story Hen Shadow'", weight: "normal", shadowFX: true },
    santa_child: { label: "Santa Child", family: "'Santa Child Shadow'", weight: "normal", shadowFX: true },
    flavors: { label: "Soft Serve", family: "'Soft Serve Shadow'", weight: "normal", shadowFX: true },
    spicy_rice: { label: "Chili Bowl", family: "'Chili Bowl Shadow'", weight: "normal", shadowFX: true },
    sansita_one: { label: "Swing Bold", family: "'Swing Bold Shadow'", weight: "normal", shadowFX: true },
    amorlate: { label: "Amorlate", family: "'Amorlate Shadow'", weight: "normal", shadowFX: true },
    standing_room_only: { label: "Standing Room Only", family: "'Standing Room Only Shadow'", weight: "normal", shadowFX: true },
    kaliber_round: { label: "Kaliber Round", family: "'Kaliber Round Shadow'", weight: "normal", shadowFX: true },
    snowtop_caps: { label: "Snowtop Caps", family: "'Snowtop Caps Shadow'", weight: "normal", shadowFX: true },
    reel_barlow: { label: "Barlow Condensed", family: "'Barlow Condensed'", weight: "bold", reelOnly: true },
    dotimatrix_3: { label: "Dotimatrix 3", family: "'Dotimatrix 3'", weight: "normal" },
    dotimatrix_5: { label: "Dotimatrix 5", family: "'Dotimatrix 5'", weight: "normal" },
    dotimatrix_7: { label: "Dotimatrix 7", family: "'Dotimatrix 7'", weight: "normal" },
    ninepin_dmd: { label: "NinePin DMD", family: "'NinePin'", weight: "normal" },
    led_real: { label: "LED Real", family: "'LED Real'", weight: "normal" },
};

function ttFontDef(fontId) {
    return TT_FONTS[fontId] || TT_FONTS.system;
}

function ttFontIsThreeD(fontId) {
    return !!ttFontDef(fontId).threeD;
}

function ttFontIsColor(fontId) {
    return !!ttFontDef(fontId).color;
}

function ttFontIsShadowFX(fontId) {
    return !!ttFontDef(fontId).shadowFX;
}

function ttFontIsNormal(fontId) {
    const def = ttFontDef(fontId);
    return !def.color && !def.threeD;
}

function ensureTtFontLoaded(fontId) {
    const def = ttFontDef(fontId);
    if (fontId === "system" || !document.fonts) return Promise.resolve();
    return document.fonts.load(`${def.weight} 100px ${def.family}`).catch(() => {});
}

const _ttLoadedFamilies = {};
let _ttProbeCtx = null;
const TT_PROBE_TEXT = "0123456789:AMPamp";
function ttFontLoaded(fontId) {
    if (!fontId || fontId === "system" || typeof document === "undefined" || !document.fonts) return true;
    const def = ttFontDef(fontId);
    const key = def.weight + "|" + def.family;
    if (_ttLoadedFamilies[key]) return true;
    let loaded = false;
    try {
        if (!_ttProbeCtx) _ttProbeCtx = document.createElement("canvas").getContext("2d");
        const c = _ttProbeCtx;
        const w = (font) => { c.font = font; return c.measureText(TT_PROBE_TEXT).width; };
        for (const fb of ["monospace", "serif"]) {
            if (Math.abs(w(`${def.weight} 100px ${def.family}, ${fb}`) - w(`${def.weight} 100px ${fb}`)) > 0.5) { loaded = true; break; }
        }
    } catch (e) {   }
    if (!loaded) {
        const fam = String(def.family).replace(/["']/g, "").trim().toLowerCase();
        try {
            document.fonts.forEach((f) => {
                if (f.status === "loaded" && String(f.family).replace(/["']/g, "").trim().toLowerCase() === fam) loaded = true;
            });
        } catch (e) {   }
    }
    if (loaded) _ttLoadedFamilies[key] = true;
    return loaded;
}

const FX_FONT_WAIT_MAX_MS = 5000;

function fxFontReady(fontId) {
    if (fontId === FX_REEL_FONT_ID) return typeof reelFontReady === "function" ? reelFontReady() : true;
    return fontId === "system" || !document.fonts || !!fxState.readyFontIds[fontId];
}

function fxLoadFont(fontId) {
    if (fxFontReady(fontId)) return;
    if (fontId === FX_REEL_FONT_ID) return;
    if (ttFontLoaded(fontId)) {
        fxState.readyFontIds[fontId] = true;
        return;
    }
    ensureTtFontLoaded(fontId).then(() => { fxState.readyFontIds[fontId] = true; });
}

function ttFontString(clockSize, zoom, fontId) {
    const px = resolveSizePx(clockSize, TT_SIZE_PX) * (zoom || 1);
    return ttFontStringPx(px, fontId);
}

function ttFontStringPx(px, fontId) {
    const def = ttFontDef(fontId);
    return `${def.weight} ${px}px ${def.family}`;
}

function ttTextWidth(ctx, text, clockSize, zoom, fontId) {
    const px = resolveSizePx(clockSize, TT_SIZE_PX) * (zoom || 1);
    return ttTextWidthPx(ctx, text, px, fontId);
}

function ttTextWidthPx(ctx, text, px, fontId) {
    ctx.save();
    ctx.font = ttFontStringPx(px, fontId);
    const w = ctx.measureText(text).width;
    ctx.restore();
    return w;
}

function ttTextHeight(clockSize, zoom) {
    return resolveSizePx(clockSize, TT_SIZE_PX) * (zoom || 1);
}

const TT_INK_CACHE = {};
function ttInkBox(ctx, text, px, fontId) {
    const key = fontId + "|" + px + "|" + text;
    if (TT_INK_CACHE[key]) return TT_INK_CACHE[key];
    ctx.save();
    ctx.font = ttFontStringPx(px, fontId);
    ctx.textBaseline = "top";
    const m = ctx.measureText(text);
    ctx.restore();
    if (typeof m.actualBoundingBoxAscent !== "number" || typeof m.actualBoundingBoxDescent !== "number") return null;
    const box = { top: -m.actualBoundingBoxAscent, bottom: m.actualBoundingBoxDescent };
    if (!(box.bottom > box.top)) return null;
    let loaded = true;
    try { loaded = ttFontLoaded(fontId); } catch (e) {   }
    if (loaded) {
        if (Object.keys(TT_INK_CACHE).length > 300) for (const k in TT_INK_CACHE) delete TT_INK_CACHE[k];
        TT_INK_CACHE[key] = box;
    }
    return box;
}

const FX_SHADOW_OFFSET_SCALE = 0.07;
const FX_SHADOW_COLOR = "#000000";

function drawTtText(ctx, text, x0, y0, opts) {
    const fontId = opts.fontId || "system";
    const px = opts.fontPx || resolveSizePx(opts.size, TT_SIZE_PX) * (opts.zoom || 1);
    if (opts.shadow) {
        const offset = Math.max(1, Math.round(px * FX_SHADOW_OFFSET_SCALE));
        ctx.save();
        ctx.font = ttFontStringPx(px, fontId);
        ctx.fillStyle = hexWithAlpha(FX_SHADOW_COLOR, opts.alpha);
        ctx.textBaseline = "top";
        ctx.textAlign = "left";
        ctx.fillText(text, x0 + offset, y0 + offset);
        ctx.restore();
    }
    ctx.save();
    ctx.font = ttFontStringPx(px, fontId);
    const a = opts.alpha !== undefined ? opts.alpha : 1;
    ctx.globalAlpha = ctx.globalAlpha * a;
    ctx.fillStyle = hexWithAlpha(opts.color, 1);
    ctx.textBaseline = "top";
    ctx.textAlign = "left";
    ctx.fillText(text, x0, y0);
    ctx.restore();
}

function hexWithAlpha(hex, alpha) {
    const [r, g, b] = hexToRgb(hex);
    const a = alpha !== undefined ? alpha : 1;
    return `rgba(${r},${g},${b},${a})`;
}

const PLATE_PAD_X = 16;
const PLATE_PAD_Y = 10;

function drawClockBackground(ctx, x, y, w, h, settings, alpha, zoom, padYOverride) {
    if (!settings.bg_enabled && !settings.border_enabled) return;
    zoom = zoom || 1;

    const padX = PLATE_PAD_X * zoom;
    const padY = padYOverride !== undefined ? padYOverride : PLATE_PAD_Y * zoom;
    const bx = x - padX;
    const by = y - padY;
    const bw = w + padX * 2;
    const bh = h + padY * 2;
    const radius = 8 * zoom;

    ctx.save();
    ctx.beginPath();
    ctx.moveTo(bx + radius, by);
    ctx.arcTo(bx + bw, by, bx + bw, by + bh, radius);
    ctx.arcTo(bx + bw, by + bh, bx, by + bh, radius);
    ctx.arcTo(bx, by + bh, bx, by, radius);
    ctx.arcTo(bx, by, bx + bw, by, radius);
    ctx.closePath();

    if (settings.bg_enabled) {
        ctx.fillStyle = hexWithAlpha(settings.bg_color, alpha);
        ctx.fill();
    }
    if (settings.border_enabled) {
        ctx.lineWidth = settings.border_width || PINCLOCK_DEFAULTS.border_width;
        ctx.strokeStyle = hexWithAlpha(settings.border_color, alpha);
        ctx.stroke();
    }
    ctx.restore();
}

const CLOCK_POSITIONS = {
    "top-left": (W, H, bw, bh, padX, padY, topInset) => [padX, topInset + padY],
    "top-center": (W, H, bw, bh, padX, padY, topInset) => [(W - bw) / 2, topInset + padY],
    "top-right": (W, H, bw, bh, padX, padY, topInset) => [W - bw - padX, topInset + padY],
    "center": (W, H, bw, bh, padX, padY, topInset, bottomInset) =>
        [(W - bw) / 2, topInset + (H - topInset - bottomInset - bh) / 2],
    "bottom-left": (W, H, bw, bh, padX, padY, topInset, bottomInset) =>
        [padX, H - bottomInset - bh - padY],
    "bottom-center": (W, H, bw, bh, padX, padY, topInset, bottomInset) =>
        [(W - bw) / 2, H - bottomInset - bh - padY],
    "bottom-right": (W, H, bw, bh, padX, padY, topInset, bottomInset) =>
        [W - bw - padX, H - bottomInset - bh - padY],
};

const ROTATE_CORNERS = ["top-left", "top-right", "bottom-right", "bottom-left"];

const TT_AMPM_GAP_SCALE = 0.25;

function renderClockFrame(ctx, W, H, settings, opts) {
    opts = opts || {};
    if (settings.clock_style === "reels" && typeof drawReelClock === "function") {
        drawReelClock(ctx, W, H, settings, opts);
        return;
    }
    const alpha = opts.alpha !== undefined ? opts.alpha : 1;
    const xShift = opts.xShift || 0;
    const yShift = opts.yShift || 0;
    const isTt = settings.clock_style === "truetype";
    const isLed = !isTt && settings.dmd_font_style === "led";

    const zoom = zoomFactor(H);

    const { displayStr, ampm: rawAmpm } = getCurrentTime(settings.clock_format, settings.show_seconds);
    const ampm = settings.show_ampm === false ? "" : rawAmpm;
    const now = opts.now || new Date();
    const fullText = (isTt || isLed) ? displayStr : (displayStr + (ampm ? " " + ampm : ""));
    const mainTtPx = resolveSizePx(settings.clock_size, TT_SIZE_PX) * zoom;
    const ampmTtPx = Math.round(mainTtPx / 2);

    const ttAmpmGap = isTt && ampm ? ttTextWidthPx(ctx, ":", mainTtPx, settings.tt_font_id) * TT_AMPM_GAP_SCALE : 0;
    const ledAmpmGap = isLed && ampm ? ledGlyphWidth(":", led7CellMetrics(settings.clock_size, zoom)) : 0;

    const hasPlate = settings.bg_enabled || settings.border_enabled;
    const padX = hasPlate ? PLATE_PAD_X * zoom : 0;
    const padY = hasPlate ? (isTt ? Math.max(PLATE_PAD_Y * zoom, mainTtPx * 0.12) : PLATE_PAD_Y * zoom) : 0;

    const dmdFont = settings.dmd_font_style || PINCLOCK_DEFAULTS.dmd_font_style;

    const ttTimeW = isTt ? ttTextWidthPx(ctx, displayStr, mainTtPx, settings.tt_font_id) : 0;
    const ttAmpmW = isTt && ampm ? ttTextWidthPx(ctx, ampm, ampmTtPx, settings.tt_font_id) + ttAmpmGap : 0;

    const led7TimeW = isLed ? led7TextWidth(displayStr, settings.clock_size, settings.dot_gap, zoom) : 0;
    const ledAmpmLetterGap = isLed && ampm ? led14CellMetrics(settings.clock_size, zoom).w * LED14_LETTER_EXTRA_GAP_FRAC : 0;
    const led14AmpmW = isLed && ampm
        ? led14TextWidth(ampm, settings.clock_size, settings.dot_gap, zoom, ledAmpmLetterGap) + ledAmpmGap
        : 0;

    const cw = isTt
        ? ttTimeW + ttAmpmW
        : isLed
            ? led7TimeW + led14AmpmW
            : dmdTextWidth(fullText, settings.clock_size, settings.dot_gap, dmdFont, zoom);
    let ttInkTop = 0;
    let ttInkH = 0;
    if (isTt) {
        const tInk = ttInkBox(ctx, "0123456789:", mainTtPx, settings.tt_font_id);
        if (tInk) {
            let top = tInk.top, bottom = tInk.bottom;
            if (ampm) {
                const aInk = ttInkBox(ctx, ampm, ampmTtPx, settings.tt_font_id);
                const off = mainTtPx - ampmTtPx;
                if (aInk) { top = Math.min(top, off + aInk.top); bottom = Math.max(bottom, off + aInk.bottom); }
            }
            ttInkTop = top;
            ttInkH = bottom - top;
        }
    }
    const ch = isTt
        ? (ttInkH || ttTextHeight(settings.clock_size, zoom))
        : isLed
            ? led7TextHeight(settings.clock_size, zoom)
            : dmdTextHeight(settings.clock_size, settings.dot_gap, dmdFont, zoom);

    const DATE_GAP = isTt ? Math.max(10 * zoom, mainTtPx * 0.14) : 10 * zoom;
    let dateStr = null, dw = 0, dh = 0, dateInkTop = 0;
    if (settings.show_date) {
        dateStr = getDateString(now);
        dw = isTt
            ? ttTextWidth(ctx, dateStr, "small", zoom, settings.tt_font_id)
            : isLed
                ? led14TextWidth(dateStr, "small", settings.dot_gap, zoom)
                : dmdTextWidth(dateStr, "small", settings.dot_gap, dmdFont, zoom);
        const dInk = isTt ? ttInkBox(ctx, dateStr, resolveSizePx("small", TT_SIZE_PX) * zoom, settings.tt_font_id) : null;
        dateInkTop = dInk ? dInk.top : 0;
        dh = isTt
            ? (dInk ? dInk.bottom - dInk.top : ttTextHeight("small", zoom))
            : isLed
                ? led14TextHeight("small", zoom)
                : dmdTextHeight("small", settings.dot_gap, dmdFont, zoom);
    }
    const dateH = settings.show_date ? dh + DATE_GAP : 0;

    const bw = settings.show_date ? Math.max(cw, dw) : cw;
    const bh = ch + dateH;

    const insets = getBarInsets(settings);

    const posFn = CLOCK_POSITIONS[settings.clock_position] || CLOCK_POSITIONS["top-right"];
    let [boxX, boxY] = posFn(W, H, bw, bh, padX, padY, insets.top, insets.bottom);
    boxX += xShift;
    boxY += yShift;

    const x = boxX + (bw - cw) / 2;
    const y = boxY;

    let dx = 0, dy = 0;
    if (settings.show_date) {
        dx = boxX + (bw - dw) / 2;
        dy = y + ch + DATE_GAP;
    }

    const bgLeft = settings.show_date ? Math.min(x, dx) : x;
    const bgRight = settings.show_date ? Math.max(x + cw, dx + dw) : x + cw;
    const bgTop = y;
    const bgBottom = settings.show_date ? dy + dh : y + ch;
    drawClockBackground(ctx, bgLeft, bgTop, bgRight - bgLeft, bgBottom - bgTop, settings, alpha, zoom, padY);

    if (isTt) {
        const ty = y - ttInkTop;
        drawTtText(ctx, displayStr, x, ty, { color: settings.dot_color, alpha, fontPx: mainTtPx, fontId: settings.tt_font_id });
        if (ampm) {
            const ampmX = x + ttTimeW + ttAmpmGap;
            const ampmY = ty + (mainTtPx - ampmTtPx);
            drawTtText(ctx, ampm, ampmX, ampmY, { color: settings.dot_color, alpha, fontPx: ampmTtPx, fontId: settings.tt_font_id });
        }
        if (settings.show_date) {
            drawTtText(ctx, dateStr, dx, dy - dateInkTop, { color: settings.dot_color, size: "small", alpha: alpha * 0.7, zoom, fontId: settings.tt_font_id });
        }
    } else if (isLed) {
        drawLed7Text(ctx, displayStr, x, y, {
            color: settings.dot_color, glow: settings.dot_glow, gap: settings.dot_gap,
            size: settings.clock_size, alpha, zoom,
        });
        if (ampm) {
            const ampmX = x + led7TimeW + ledAmpmGap;
            drawLed14Text(ctx, ampm, ampmX, y, {
                color: settings.dot_color, glow: settings.dot_glow, gap: settings.dot_gap,
                size: settings.clock_size, alpha, zoom, extraGap: ledAmpmLetterGap,
            });
        }
        if (settings.show_date) {
            drawLed14Text(ctx, dateStr, dx, dy, {
                color: settings.dot_color, glow: settings.dot_glow, gap: settings.dot_gap,
                size: "small", alpha: alpha * 0.7, zoom,
            });
        }
    } else {
        const dotOpts = {
            color: settings.dot_color,
            glow: settings.dot_glow,
            gap: settings.dot_gap,
            size: settings.clock_size,
            alpha,
            fontStyle: dmdFont,
            zoom,
        };
        drawDmdText(ctx, fullText, x, y, dotOpts);
        if (settings.show_date) {
            drawDmdText(ctx, dateStr, dx, dy, { ...dotOpts, size: "small", alpha: alpha * 0.7 });
        }
    }
}

const FX_CLOCK_SIZE_MIN = 200;
const FX_CLOCK_SIZE_MAX = 700;
const FX_CLOCK_SAFETY_MARGIN = 0.92;

const FX_WIDEST_TIME = {};
function fxWidestTime(ctx, fontId, px) {
    if (FX_WIDEST_TIME[fontId]) return FX_WIDEST_TIME[fontId];
    const widest = (cands) => {
        let best = cands[0], bestW = -1;
        cands.forEach((c) => { const w = ttTextWidthPx(ctx, c, px, fontId); if (w > bestW) { bestW = w; best = c; } });
        return best;
    };
    const hours = [];
    for (let h = 1; h <= 12; h++) hours.push(String(h).padStart(2, "0"));
    const str = widest(hours) + ":" + widest("012345".split("")) + widest("0123456789".split(""));
    if (typeof fxFontReady !== "function" || fxFontReady(fontId)) FX_WIDEST_TIME[fontId] = str;
    return str;
}

function fxFitFontPx(ctx, W, zoom, fontId, requestedSize, showAmpm) {
    const cappedRequest = Math.min(requestedSize || PINCLOCK_DEFAULTS.fx_size, FX_CLOCK_SIZE_MAX);
    const basePx = cappedRequest * zoom;
    const ampmPx = Math.round(basePx / 2);
    let worstW = ttTextWidthPx(ctx, fxWidestTime(ctx, fontId, basePx), basePx, fontId);
    if (showAmpm) {
        const gap = ttTextWidthPx(ctx, ":", basePx, fontId) * TT_AMPM_GAP_SCALE;
        worstW += gap + ttTextWidthPx(ctx, "PM", ampmPx, fontId);
    }
    const available = W * FX_CLOCK_SAFETY_MARGIN;
    if (worstW <= available) return basePx;
    return Math.max(FX_CLOCK_SIZE_MIN * zoom, basePx * (available / worstW));
}

const FX_BOUNCE_TRAVEL_MS = 1500;
const FX_TRAVERSE_MS = 5000;
const FX_FADE_IN_MS = 800, FX_FADE_HOLD_MS = 2500, FX_FADE_OUT_MS = 800;
const FX_ZOOM_IN_MS = 1000, FX_ZOOM_HOLD_MS = 2000, FX_ZOOM_OUT_MS = 1000;
const FX_ZOOM_MIN_SCALE = 0.15;
const FX_PULSE_PERIOD_MS = 1500, FX_PULSE_CYCLES = 2;
const FX_PULSE_MIN_ALPHA = 0.35;
const FX_WOBBLE_PERIOD_MS = 250, FX_WOBBLE_DURATION_MS = 2000;
const FX_WOBBLE_AMPLITUDE_PX = 10;
const FX_DIGIT_STAGGER_MS = 500;
const FX_DIGIT_ITEM_DURATION_MS = 400;
const FX_DIGIT_ITEM_COUNT = 6;
const FX_DIGIT_MAIN_MS = (FX_DIGIT_ITEM_COUNT - 1) * FX_DIGIT_STAGGER_MS + FX_DIGIT_ITEM_DURATION_MS;
const FX_DIGIT_SLIDE_PX = 220;
const FX_DIGIT_DROP_PX = 220;
const FX_SLOT_SPIN_MS = 60;
const FX_SLOT_LAND_FRACTION = 0.85;
const FX_WAVE_AMPLITUDE_PX = 40;

const FX_DIGIT_EFFECTS = ["pop_digits", "scroll_digits", "drop_digits", "flip_digits", "slot_digits", "wave_digits", "converge_digits"];
const FX_EFFECT_LIST = ["static", "scroll", "drop", "diagonal", "bounce_lr", "bounce_td", "random_bounce", "fade", "zoom", "pulse", "wobble", "drift"].concat(FX_DIGIT_EFFECTS);

const FX_DRIFT_FADE_MS = 800, FX_DRIFT_GAP_MS = 1500, FX_DRIFT_MIN_MS = 3000, FX_DRIFT_MAX_MS = 15000;
const FX_DRIFT_FRAME_MS = 100;
function fxDriftMs(settings) {
    const iv = Math.max(1, Math.round((settings && settings.fx_interval_seconds) || PINCLOCK_DEFAULTS.fx_interval_seconds));
    return Math.max(FX_DRIFT_MIN_MS, Math.min(FX_DRIFT_MAX_MS, iv * 1000 - FX_DRIFT_GAP_MS));
}
function fxEffectMainMs(effect, settings) {
    if (effect === "drift") return fxDriftMs(settings);
    return (FX_EFFECT_DEFS[effect] || FX_EFFECT_DEFS.static).mainMs;
}
const FX_DRIFT_PERIOD_X_S = 17, FX_DRIFT_PERIOD_Y_S = 11, FX_DRIFT_REACH = 0.5, FX_DRIFT_RAMP_S = 2;
function fxDriftMotion(t, D, roomX, roomY, r1, r2) {
    const ts = Math.max(0, t) / 1000;
    const ramp = Math.min(1, ts / FX_DRIFT_RAMP_S);
    const a = Math.min(1, Math.max(0, t) / FX_DRIFT_FADE_MS, Math.max(0, D - t) / FX_DRIFT_FADE_MS);
    return {
        dx: Math.sin(2 * Math.PI * (ts / FX_DRIFT_PERIOD_X_S + r1)) * roomX * FX_DRIFT_REACH * ramp,
        dy: Math.sin(2 * Math.PI * (ts / FX_DRIFT_PERIOD_Y_S + r2)) * roomY * FX_DRIFT_REACH * ramp,
        a: Math.max(0, a),
    };
}

const FX_TEXT_PAD = 0.35;
const FX_TEXT_STEP_PX = 128;
const _fxTextBmp = { canvas: null, ctx: null, key: null, pad: 0, w: 0, h: 0 };
function fxTextBitmap(mainPx, ampmPx, displayStr, ampmStr, mainW, ampmGap, totalW, color, fontId, shadow) {
    const key = [displayStr, ampmStr, Math.round(mainPx), Math.round(ampmPx), Math.round(totalW), color, fontId,
        typeof fxFontReady === "function" ? fxFontReady(fontId) : true].join("|");
    const b = _fxTextBmp;
    if (b.key === key && b.canvas) return b;
    if (!b.canvas) {
        b.canvas = document.createElement("canvas");
        const hiRes = typeof pinclockIsHighRes === "function" ? pinclockIsHighRes() : true;
        b.ctx = b.canvas.getContext("2d", hiRes ? { willReadFrequently: true } : undefined);
    }
    const pad = Math.ceil(mainPx * FX_TEXT_PAD);
    const w = Math.ceil(totalW + pad * 2), h = Math.ceil(mainPx + pad * 2);
    const cw = Math.max(b.canvas.width, Math.ceil(w / FX_TEXT_STEP_PX) * FX_TEXT_STEP_PX);
    const ch = Math.max(b.canvas.height, Math.ceil(h / FX_TEXT_STEP_PX) * FX_TEXT_STEP_PX);
    if (b.canvas.width !== cw || b.canvas.height !== ch) {
        b.canvas.width = cw;
        b.canvas.height = ch;
    } else {
        b.ctx.setTransform(1, 0, 0, 1, 0, 0);
        b.ctx.clearRect(0, 0, Math.max(w, b.w), Math.max(h, b.h));
    }
    drawFxWholeClockAt(b.ctx, pad, pad, mainPx, ampmPx, displayStr, ampmStr, mainW, ampmGap, color, 1, fontId, shadow);
    b.key = key;
    b.pad = pad;
    b.w = w;
    b.h = h;
    return b;
}

const FX_LOW_CPU_EFFECTS = ["static", "fade", "pulse", "zoom"];
const FX_EFFECT_DEFS = {
    static: { mainMs: 2000, endsVisible: true },
    scroll: { mainMs: FX_TRAVERSE_MS, endsVisible: false },
    drop: { mainMs: FX_TRAVERSE_MS, endsVisible: false },
    diagonal: { mainMs: FX_TRAVERSE_MS, endsVisible: false },
    bounce_lr: { mainMs: FX_BOUNCE_TRAVEL_MS, endsVisible: true },
    bounce_td: { mainMs: FX_BOUNCE_TRAVEL_MS, endsVisible: true },
    random_bounce: { mainMs: FX_BOUNCE_TRAVEL_MS, endsVisible: true },
    fade: { mainMs: FX_FADE_IN_MS + FX_FADE_HOLD_MS + FX_FADE_OUT_MS, endsVisible: false },
    zoom: { mainMs: FX_ZOOM_IN_MS + FX_ZOOM_HOLD_MS + FX_ZOOM_OUT_MS, endsVisible: false },
    pulse: { mainMs: FX_PULSE_PERIOD_MS * FX_PULSE_CYCLES, endsVisible: true },
    wobble: { mainMs: FX_WOBBLE_DURATION_MS, endsVisible: true },
    drift: { mainMs: FX_DRIFT_MAX_MS, endsVisible: false },
};
FX_DIGIT_EFFECTS.forEach((name) => { FX_EFFECT_DEFS[name] = { mainMs: FX_DIGIT_MAIN_MS, endsVisible: true }; });


const FX_LINGER_MS = 1000;
const FX_DISAPPEAR_MS = 300;

const fxState = { active: false, effect: null, fontId: "system", startTime: 0, episodeSeed: 0, episodeCount: 0, lastTriggerSecond: -1, reducedMode: false,
    waitingForFont: false, waitStart: 0, readyFontIds: {}, nextFontId: null, nextFontKey: "", typeHistory: [],
    color: null,
    style: null,
    lastTriggerSlot: null, activeSince: 0, buildBonusMs: 0, lastEpisodeMs: null, lastUpdateMs: null };

const FX_ACTIVE_CAP_MS = 15000;
const FX_BUILD_BONUS_MAX_MS = 3000;
function FX_STALL_MS(intervalS) { return Math.max(60000, intervalS * 3000 + 20000); }

function fxRecovered(reason) {
    try {
        fetch("/api/debug/fx-log", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ font: "(recovered)", effect: reason, size: 0 }),
        }).catch(() => {});
    } catch (e) {   }
}

const FX_ALT_COLORS = ["#ff6600", "#ff0000", "#ffff00", "#00ff00", "#00ffff", "#0066ff", "#ff00ff"];

function fxColor(settings) {
    return fxState.color || settings.fx_color;
}

const FX_DEVICE_SALT = Math.random() * 1e6;

function fxEffectPool(settings, rule) {
    if (rule === undefined) rule = fxActiveRule(settings);
    if (rule && Array.isArray(rule.effects)) {
        const own = FX_EFFECT_LIST.filter((e) => rule.effects.indexOf(e) !== -1);
        if (own.length) return own;
    }
    const excluded = Array.isArray(settings.fx_effect_excluded) ? settings.fx_effect_excluded : [];
    const pool = FX_EFFECT_LIST.filter((e) => excluded.indexOf(e) === -1);
    return pool.length ? pool : FX_EFFECT_LIST;
}

function fxPickEffect(settings, episodeSeed) {
    const basePool = fxEffectPool(settings);
    const prevEffect = fxState.effect;
    const pool = basePool.filter((e) => e !== prevEffect);
    const finalPool = pool.length ? pool : basePool;
    return finalPool[Math.floor(fxPseudoRandom(episodeSeed + FX_DEVICE_SALT) * finalPool.length)];
}

const FX_REEL_FONT_ID = "reels_bank";
const FX_FONT_LIST = Object.keys(TT_FONTS).filter((id) => !TT_FONTS[id].signOnly && !TT_FONTS[id].reelOnly).concat([FX_REEL_FONT_ID]);

let fxStyles = null;
let fxStyleVideo = null;
const _fxRuleCache = { version: null, video: null, rule: null };

function fxSetStyles(data) {
    fxStyles = data && Array.isArray(data.videos) ? data : null;
}
function fxSetStyleVideo(name) {
    fxStyleVideo = name ? String(name) : null;
}

function fxGlobRegex(pattern) {
    const body = String(pattern).split("").map((ch) => {
        if (ch === "*") return ".*";
        if (ch === "?") return ".";
        return ch.replace(/[\\^$.|+()[\]{}]/g, "\\$&");
    }).join("");
    return new RegExp("^" + body + "$", "i");
}

function fxVideoRule(styles, video, decoded) {
    if (!styles || !Array.isArray(styles.videos) || !video) return null;
    const file = String(video).replace(/^.*[\\/]/, "").toLowerCase();
    const names = [file, file.replace(/\.[^.]+$/, "")];
    if (decoded) names.push(String(decoded).toLowerCase());
    const hit = (p) => names.some((n) => fxGlobRegex(p).test(n));
    for (const r of styles.videos) {
        const pats = Array.isArray(r.patterns) ? r.patterns : [];
        if (pats.some((p) => !/[*?]/.test(p) && hit(p))) return r;
    }
    for (const r of styles.videos) {
        const pats = Array.isArray(r.patterns) ? r.patterns : [];
        if (pats.some((p) => /[*?]/.test(p) && hit(p))) return r;
    }
    return null;
}

function fxActiveRule(settings) {
    if (!fxStyles || !fxStyleVideo) return null;
    if (settings && settings.fx_video_styles === false) return null;
    if (settings && settings.videos_enabled === false) return null;
    if (_fxRuleCache.version !== fxStyles.version || _fxRuleCache.video !== fxStyleVideo) {
        const decoded = typeof decodeVideoName === "function" ? decodeVideoName(fxStyleVideo) : null;
        _fxRuleCache.version = fxStyles.version;
        _fxRuleCache.video = fxStyleVideo;
        _fxRuleCache.rule = fxVideoRule(fxStyles, fxStyleVideo, decoded);
    }
    return _fxRuleCache.rule;
}

function fxFontTypes(fontId) {
    if (fontId === FX_REEL_FONT_ID) return ["reels"];
    const out = [];
    if (ttFontIsThreeD(fontId)) out.push("3d");
    if (ttFontIsColor(fontId)) out.push("color");
    if (ttFontIsShadowFX(fontId)) out.push("shadow");
    if (!out.length) out.push("normal");
    return out;
}

function fxFontPool(settings, rule) {
    let base = null;
    if (rule && Array.isArray(rule.fonts)) {
        base = FX_FONT_LIST.filter((id) => rule.fonts.indexOf(id) !== -1);
        if (!base.length) base = null;
    }
    if (!base) {
        const excluded = Array.isArray(settings.fx_font_excluded) ? settings.fx_font_excluded : [];
        const checked = FX_FONT_LIST.filter((id) => excluded.indexOf(id) === -1);
        base = checked.length ? checked : FX_FONT_LIST;
    }
    if (rule && Array.isArray(rule.fontTypes) && rule.fontTypes.length) {
        const ok = (id) => fxFontTypes(id).some((t) => rule.fontTypes.indexOf(t) !== -1);
        const narrowed = base.filter(ok);
        if (narrowed.length) return narrowed;
        const anyOfType = FX_FONT_LIST.filter(ok);
        if (anyOfType.length) return anyOfType;
    }
    return base;
}

function fxRuleColors(rule) {
    if (!rule || !rule.colors) return null;
    if (rule.colors === "any") return FX_ALT_COLORS;
    const list = Array.isArray(rule.colors) ? rule.colors.filter((c) => /^#[0-9a-f]{6}$/i.test(c)) : [];
    return list.length ? list : null;
}

function fxFontPrimaryType(fontId) {
    if (fontId === FX_REEL_FONT_ID) return "reels";
    if (ttFontIsThreeD(fontId)) return "3d";
    if (ttFontIsColor(fontId)) return "color";
    if (ttFontIsShadowFX(fontId)) return "shadow";
    return "normal";
}

function fxPickFont(settings, episodeSeed) {
    const typePool = fxFontPool(settings, fxActiveRule(settings));
    const prevFontId = fxState.fontId;
    const prevFont = TT_FONTS[prevFontId];
    const prevGroup = prevFont && prevFont.group;
    let pool = typePool.filter((id) => {
        if (id === prevFontId) return false;
        const def = TT_FONTS[id];
        if (prevGroup && def && def.group === prevGroup) return false;
        return true;
    });
    const hist = fxState.typeHistory;
    if (hist.length >= 2 && hist[hist.length - 1] === hist[hist.length - 2]) {
        const types = new Set(typePool.map(fxFontPrimaryType));
        if (types.size > 1) {
            const lastType = hist[hist.length - 1];
            const other = pool.filter((id) => fxFontPrimaryType(id) !== lastType);
            if (other.length) pool = other;
        }
    }
    const finalPool = pool.length ? pool : typePool;
    if (!finalPool.length) return "system";
    return finalPool[Math.floor(fxPseudoRandom(episodeSeed + FX_DEVICE_SALT) * finalPool.length)];
}

function fxUpdateState(settings) {
    const nowP = performance.now();
    if (fxState.lastUpdateMs === null || nowP - fxState.lastUpdateMs > 5000) fxState.lastEpisodeMs = nowP;
    fxState.lastUpdateMs = nowP;
    if (!settings.fx_enabled) { fxState.active = false; fxState.waitingForFont = false; fxState.lastEpisodeMs = nowP; return fxState; }
    if (typeof msgIsActive === "function" && msgIsActive()) {
        fxState.active = false;
        fxState.waitingForFont = false;
        fxState.lastEpisodeMs = nowP;
        return fxState;
    }
    const intervalS = Math.max(1, Math.round(settings.fx_interval_seconds || PINCLOCK_DEFAULTS.fx_interval_seconds));
    if (!fxState.active && nowP - fxState.lastEpisodeMs > FX_STALL_MS(intervalS)) {
        fxState.waitingForFont = false;
        fxState.lastTriggerSlot = null;
        fxState.lastEpisodeMs = nowP;
        fxRecovered("stall: no appearance for " + Math.round(FX_STALL_MS(intervalS) / 1000) + "s");
    }
    if (fxState.active) {
        const d = FX_EFFECT_DEFS[fxState.effect] || FX_EFFECT_DEFS.static;
        const planned = fxEffectMainMs(fxState.effect, settings) + (d.endsVisible ? FX_LINGER_MS + FX_DISAPPEAR_MS : 0);
        if (nowP - fxState.activeSince > planned + FX_ACTIVE_CAP_MS) {
            fxState.active = false;
            fxRecovered("appearance ran " + Math.round((nowP - fxState.activeSince) / 1000) + "s");
        }
    }
    if (fxState.waitingForFont) {
        if (fxFontReady(fxState.fontId) || performance.now() - fxState.waitStart > FX_FONT_WAIT_MAX_MS) {
            fxState.waitingForFont = false;
            fxState.startTime = performance.now();
            fxState.activeSince = fxState.startTime;
            fxState.buildBonusMs = 0;
            fxState.lastEpisodeMs = fxState.startTime;
            fxState.active = true;
        }
        return fxState;
    }
    if (!fxState.active) {
        const r = fxActiveRule(settings);
        const key = [JSON.stringify(settings.fx_font_excluded || []), fxState.episodeCount, r ? r.where + "@" + (fxStyles && fxStyles.version) : ""].join("|");
        if (key !== fxState.nextFontKey) {
            fxState.nextFontKey = key;
            fxState.nextFontId = fxPickFont(settings, fxState.episodeCount);
            fxLoadFont(fxState.nextFontId);
        }
    }
    const nowSec = Math.floor(Date.now() / 1000);
    const interval = Math.max(1, Math.round(settings.fx_interval_seconds || PINCLOCK_DEFAULTS.fx_interval_seconds));
    const thermalThrottled = typeof systemStatus !== "undefined" && !!systemStatus.sfx_thermal_throttled;
    const styleRule = fxActiveRule(settings);
    const lowCpuSelected = fxEffectPool(settings, styleRule).every((e) => FX_LOW_CPU_EFFECTS.indexOf(e) !== -1);
    const slot = Math.floor(nowSec / interval);
    const slotStart = slot * interval;
    if (fxState.lastTriggerSlot === null || slot < fxState.lastTriggerSlot) fxState.lastTriggerSlot = slot - 1;
    const missedStart = fxState.lastSecSeen !== undefined && fxState.lastSecSeen < slotStart && nowSec - slotStart <= 1;
    const inSlotStart = nowSec === slotStart || missedStart;
    fxState.lastSecSeen = nowSec;
    if (!fxState.active && !fxState.waitingForFont && slot > fxState.lastTriggerSlot && inSlotStart) {
        fxState.lastTriggerSlot = slot;
        fxState.lastTriggerSecond = nowSec;
        fxState.reducedMode = thermalThrottled || lowCpuSelected;
        const prevColor = fxState.color;
        try {
            fxState.effect = thermalThrottled ? "static" : fxPickEffect(settings, fxState.episodeCount);
            fxState.fontId = fxPickFont(settings, fxState.episodeCount);
        } catch (err) {
            fxState.effect = "static";
            fxState.fontId = "system";
            fxRecovered("pick failed: " + String(err && err.message || err).slice(0, 80));
        }
        fxLoadFont(fxState.fontId);
        if (fxState.fontId === FX_REEL_FONT_ID) fxState.effect = "static";
        fxState.typeHistory = fxState.typeHistory.concat(fxFontPrimaryType(fxState.fontId)).slice(-2);
        fxState.color = null;
        fxState.style = styleRule ? styleRule.label : null;
        const ruleColors = fxRuleColors(styleRule);
        if (ruleColors) {
            const shown = String(prevColor || settings.fx_color || "").toLowerCase();
            const choices = ruleColors.length > 1 ? ruleColors.filter((c) => c.toLowerCase() !== shown) : ruleColors;
            const list = choices.length ? choices : ruleColors;
            fxState.color = list[Math.floor(fxPseudoRandom(fxState.episodeCount + FX_DEVICE_SALT + 4) * list.length)];
        } else if (settings.fx_color_auto) {
            const shown = String(prevColor || settings.fx_color || "").toLowerCase();
            const choices = FX_ALT_COLORS.filter((c) => c !== shown);
            fxState.color = choices[Math.floor(fxPseudoRandom(fxState.episodeCount + FX_DEVICE_SALT + 4) * choices.length)];
        }
        fetch("/api/debug/fx-log", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ font: fxState.fontId, effect: fxState.effect, size: settings.fx_size,
                style: fxState.style || undefined, color: fxState.style ? fxColor(settings) : undefined }),
        }).catch(() => {});
        fxState.episodeSeed = fxState.episodeCount;
        fxState.episodeCount++;
        fxState.startTime = performance.now();
        fxState.activeSince = fxState.startTime;
        fxState.buildBonusMs = 0;
        fxState.lastEpisodeMs = fxState.startTime;
        if (fxFontReady(fxState.fontId)) {
            fxState.active = true;
        } else {
            fxState.waitingForFont = true;
            fxState.waitStart = performance.now();
        }
    }
    if (fxState.active) {
        const def = FX_EFFECT_DEFS[fxState.effect] || FX_EFFECT_DEFS.static;
        const totalMs = fxEffectMainMs(fxState.effect, settings) + (def.endsVisible ? FX_LINGER_MS + FX_DISAPPEAR_MS : 0);
        if (performance.now() - fxState.startTime >= totalMs) fxState.active = false;
    }
    return fxState;
}

function pinclockIsHighRes() {
    const area = window.innerWidth * window.innerHeight;
    return area === 0 || area > 640 * 480;
}

function isFxAnimating(settings) {
    const state = fxUpdateState(settings);
    return state.active && (!state.reducedMode || state.effect === "pulse") && !(state.effect === "static" && pinclockIsHighRes());
}

function fxFrameIntervalMs() {
    return fxState.effect === "drift" ? FX_DRIFT_FRAME_MS : FX_FRAME_INTERVAL_MS;
}

function easeOutBounce(t) {
    const n1 = 7.5625, d1 = 2.75;
    if (t < 1 / d1) return n1 * t * t;
    if (t < 2 / d1) { t -= 1.5 / d1; return n1 * t * t + 0.75; }
    if (t < 2.5 / d1) { t -= 2.25 / d1; return n1 * t * t + 0.9375; }
    t -= 2.625 / d1; return n1 * t * t + 0.984375;
}

function easeOutCubic(t) {
    const inv = 1 - t;
    return 1 - inv * inv * inv;
}

function fxPseudoRandom(seed) {
    const x = Math.sin(seed * 12.9898) * 43758.5453;
    return x - Math.floor(x);
}

function drawFxWholeClockAt(ctx, x0, y0, mainPx, ampmPx, displayStr, ampmStr, mainW, ampmGap, color, alpha, fontId, shadow) {
    drawTtText(ctx, displayStr, x0, y0, { color, alpha, fontPx: mainPx, fontId, shadow });
    if (ampmStr) {
        const ampmX = x0 + mainW + ampmGap;
        const ampmY = y0 + (mainPx - ampmPx);
        drawTtText(ctx, ampmStr, ampmX, ampmY, { color, alpha, fontPx: ampmPx, fontId, shadow });
    }
}

function drawFxWholeEffect(ctx, W, H, settings, effect, mainPx, ampmPx, zoom, elapsed, episodeSeed, globalAlpha, fontId, showAmpm) {
    const { displayStr, ampm } = getCurrentTime("12h", false);
    const ampmStr = showAmpm ? ampm.toUpperCase() : "";
    const shadow = false;

    const reelBank = fontId === FX_REEL_FONT_ID && typeof reelSfxBank === "function"
        ? reelSfxBank(ctx, W, H, settings, !!ampmStr, episodeSeed) : null;
    const boxH = reelBank ? reelBank.h : mainPx;

    const mainW = reelBank ? reelBank.w : ttTextWidthPx(ctx, displayStr, mainPx, fontId);
    const ampmGap = ampmStr && !reelBank ? ttTextWidthPx(ctx, ":", mainPx, fontId) * TT_AMPM_GAP_SCALE : 0;
    const ampmW = ampmStr && !reelBank ? ttTextWidthPx(ctx, ampmStr, ampmPx, fontId) : 0;
    const totalW = mainW + ampmGap + ampmW;
    const restX = (W - totalW) / 2;
    const restY = (H - boxH) / 2;

    let x0 = restX, y0 = restY, alpha = 1, scale = 1;

    if (effect === "scroll" || effect === "drop" || effect === "diagonal") {
        const phase = elapsed / FX_TRAVERSE_MS;
        if (effect === "scroll") {
            x0 = W - phase * (W + totalW);
        } else if (effect === "drop") {
            y0 = -boxH + phase * (H + boxH);
        } else {
            x0 = -totalW + phase * (W + totalW);
            y0 = -boxH + phase * (H + boxH);
        }
    } else if (effect === "bounce_lr") {
        const p = easeOutBounce(Math.min(1, elapsed / FX_BOUNCE_TRAVEL_MS));
        x0 = W * (1 - p);
    } else if (effect === "bounce_td") {
        const p = easeOutBounce(Math.min(1, elapsed / FX_BOUNCE_TRAVEL_MS));
        y0 = -boxH + p * (restY + boxH);
    } else if (effect === "random_bounce") {
        const p = easeOutBounce(Math.min(1, elapsed / FX_BOUNCE_TRAVEL_MS));
        const edges = ["left", "right", "top", "bottom"];
        const edge = edges[Math.floor(fxPseudoRandom(episodeSeed * 7 + 3 + FX_DEVICE_SALT) * edges.length)];
        if (edge === "left") x0 = W + p * (0 - W);
        else if (edge === "right") x0 = -totalW + p * ((W - totalW) - -totalW);
        else if (edge === "top") y0 = H + p * (0 - H);
        else y0 = -boxH + p * ((H - boxH) - -boxH);
    } else if (effect === "fade") {
        if (elapsed < FX_FADE_IN_MS) alpha = elapsed / FX_FADE_IN_MS;
        else if (elapsed < FX_FADE_IN_MS + FX_FADE_HOLD_MS) alpha = 1;
        else alpha = 1 - Math.min(1, (elapsed - FX_FADE_IN_MS - FX_FADE_HOLD_MS) / FX_FADE_OUT_MS);
    } else if (effect === "zoom") {
        if (elapsed < FX_ZOOM_IN_MS) {
            scale = FX_ZOOM_MIN_SCALE + easeOutCubic(elapsed / FX_ZOOM_IN_MS) * (1 - FX_ZOOM_MIN_SCALE);
        } else if (elapsed < FX_ZOOM_IN_MS + FX_ZOOM_HOLD_MS) {
            scale = 1;
        } else {
            const t = (elapsed - FX_ZOOM_IN_MS - FX_ZOOM_HOLD_MS) / FX_ZOOM_OUT_MS;
            scale = 1 - easeOutCubic(Math.min(1, t));
        }
    } else if (effect === "pulse") {
        const t = elapsed / FX_PULSE_PERIOD_MS;
        alpha = FX_PULSE_MIN_ALPHA + (1 - FX_PULSE_MIN_ALPHA) * (0.5 + 0.5 * Math.sin(t * 2 * Math.PI));
    } else if (effect === "drift") {
        const m = 16 * zoom;
        const roomX = Math.max(0, (W - totalW) / 2 - m), roomY = Math.max(0, (H - boxH) / 2 - m);
        const d = fxDriftMotion(elapsed, fxDriftMs(settings), roomX, roomY,
            fxPseudoRandom(episodeSeed * 5 + 11 + FX_DEVICE_SALT), fxPseudoRandom(episodeSeed * 3 + 17 + FX_DEVICE_SALT));
        x0 = restX + d.dx;
        y0 = restY + d.dy;
        alpha = d.a;
    } else if (effect === "wobble") {
        const t = elapsed / FX_WOBBLE_PERIOD_MS;
        x0 = restX + Math.sin(t * 2 * Math.PI) * FX_WOBBLE_AMPLITUDE_PX * zoom;
    }

    alpha *= globalAlpha;
    if (alpha <= 0) return;

    if (reelBank) {
        ctx.save();
        ctx.globalAlpha = alpha;
        if (scale !== 1) {
            ctx.translate(W / 2, H / 2);
            ctx.scale(scale, scale);
            ctx.translate(-W / 2, -H / 2);
        }
        ctx.drawImage(reelBank.canvas, Math.round(x0), Math.round(y0));
        ctx.restore();
        if (reelBank.buildMs > 0 && fxState.active && fxState.buildBonusMs < FX_BUILD_BONUS_MAX_MS) {
            const give = Math.min(reelBank.buildMs, FX_BUILD_BONUS_MAX_MS - fxState.buildBonusMs);
            fxState.buildBonusMs += give;
            fxState.startTime += give;
        }
    } else {
        const bmp = fxTextBitmap(mainPx, ampmPx, displayStr, ampmStr, mainW, ampmGap, totalW, fxColor(settings), fontId, shadow);
        ctx.save();
        ctx.globalAlpha = ctx.globalAlpha * alpha;
        if (scale !== 1) {
            ctx.translate(W / 2, H / 2);
            ctx.scale(scale, scale);
            ctx.translate(-W / 2, -H / 2);
        }
        ctx.drawImage(bmp.canvas, 0, 0, bmp.w, bmp.h, x0 - bmp.pad, y0 - bmp.pad, bmp.w, bmp.h);
        ctx.restore();
    }
}

function buildFxDigitItems(ctx, W, H, mainPx, ampmPx, displayStr, ampmStr, fontId) {
    const items = [];
    let cursor = 0;
    Array.from(displayStr).forEach((ch) => {
        const w = ttTextWidthPx(ctx, ch, mainPx, fontId);
        items.push({ text: ch, w, fontPx: mainPx, dy: 0, isMain: true });
        cursor += w;
    });
    let totalW = cursor;
    if (ampmStr) {
        const gap = ttTextWidthPx(ctx, ":", mainPx, fontId) * TT_AMPM_GAP_SCALE;
        const w = ttTextWidthPx(ctx, ampmStr, ampmPx, fontId);
        items.push({ text: ampmStr, w, fontPx: ampmPx, dy: mainPx - ampmPx, gapBefore: gap, isMain: false });
        totalW += gap + w;
    }
    const x0 = (W - totalW) / 2;
    const y0 = (H - mainPx) / 2;
    let x = x0;
    let digitIndex = 0;
    items.forEach((item) => {
        if (item.gapBefore) x += item.gapBefore;
        item.finalX = x;
        item.finalY = y0 + item.dy;
        if (item.isMain && item.text !== ":") item.digitIndex = digitIndex++;
        x += item.w;
    });
    return items;
}

const CONVERGE_EDGES = ["top", "bottom", "left", "right"];
function convergeEdgeFor(item) {
    if (!item.isMain || item.text === ":") return "fade";
    return CONVERGE_EDGES[item.digitIndex % CONVERGE_EDGES.length];
}

function drawFxDigitsEffect(ctx, W, H, settings, mode, mainPx, ampmPx, zoom, elapsed, globalAlpha, fontId, showAmpm) {
    const { displayStr, ampm } = getCurrentTime("12h", false);
    const ampmStr = showAmpm ? ampm.toUpperCase() : "";
    const items = buildFxDigitItems(ctx, W, H, mainPx, ampmPx, displayStr, ampmStr, fontId);

    items.forEach((item, i) => {
        const start = i * FX_DIGIT_STAGGER_MS;
        if (elapsed < start) return;
        const raw = Math.min(1, (elapsed - start) / FX_DIGIT_ITEM_DURATION_MS);
        const eased = easeOutCubic(raw);

        let x = item.finalX, y = item.finalY, alpha = 1, text = item.text, scaleY = 1;
        if (mode === "pop_digits") {
            alpha = eased;
        } else if (mode === "scroll_digits") {
            x = item.finalX + (1 - eased) * FX_DIGIT_SLIDE_PX * zoom;
        } else if (mode === "drop_digits") {
            y = item.finalY - (1 - eased) * FX_DIGIT_DROP_PX * zoom;
        } else if (mode === "flip_digits") {
            scaleY = Math.max(0.02, Math.sin(eased * Math.PI / 2));
        } else if (mode === "slot_digits") {
            if (/[0-9]/.test(item.text) && raw < FX_SLOT_LAND_FRACTION) {
                text = String(Math.floor(performance.now() / FX_SLOT_SPIN_MS) % 10);
            }
        } else if (mode === "wave_digits") {
            alpha = eased;
            y = item.finalY - Math.sin(eased * Math.PI) * FX_WAVE_AMPLITUDE_PX * zoom;
        } else if (mode === "converge_digits") {
            const edge = convergeEdgeFor(item);
            const remain = 1 - eased;
            if (edge === "top") y = item.finalY - FX_DIGIT_DROP_PX * zoom * remain;
            else if (edge === "bottom") y = item.finalY + FX_DIGIT_DROP_PX * zoom * remain;
            else if (edge === "left") x = item.finalX - FX_DIGIT_SLIDE_PX * zoom * remain;
            else if (edge === "right") x = item.finalX + FX_DIGIT_SLIDE_PX * zoom * remain;
            else alpha = eased;
        }
        alpha *= globalAlpha;
        if (alpha <= 0) return;

        if (scaleY !== 1) {
            const cx = item.finalX + item.w / 2;
            const cy = item.finalY + item.fontPx / 2;
            ctx.save();
            ctx.translate(cx, cy);
            ctx.scale(1, scaleY);
            ctx.translate(-cx, -cy);
            drawTtText(ctx, text, x, y, { color: fxColor(settings), alpha, fontPx: item.fontPx, fontId });
            ctx.restore();
        } else {
            drawTtText(ctx, text, x, y, { color: fxColor(settings), alpha, fontPx: item.fontPx, fontId });
        }
    });
}

function drawFxClock(ctx, W, H, settings) {
    const state = fxUpdateState(settings);
    if (!state.active) return;

    const def = FX_EFFECT_DEFS[state.effect] || FX_EFFECT_DEFS.static;
    const rawElapsed = performance.now() - state.startTime;
    const mainMs = fxEffectMainMs(state.effect, settings);
    const mainElapsed = Math.min(rawElapsed, mainMs);
    let globalAlpha = 1;
    if (rawElapsed > mainMs) {
        const sinceMain = rawElapsed - mainMs;
        if (sinceMain > FX_LINGER_MS) {
            globalAlpha = 1 - Math.min(1, (sinceMain - FX_LINGER_MS) / FX_DISAPPEAR_MS);
        }
    }
    if (globalAlpha <= 0) return;

    const zoom = zoomFactor(H);
    const showAmpm = !!settings.fx_show_ampm;
    const mainPx = fxFitFontPx(ctx, W, zoom, state.fontId, settings.fx_size, showAmpm);
    const ampmPx = Math.round(mainPx / 2);

    if (FX_DIGIT_EFFECTS.indexOf(state.effect) !== -1 && state.fontId !== FX_REEL_FONT_ID) {
        drawFxDigitsEffect(ctx, W, H, settings, state.effect, mainPx, ampmPx, zoom, mainElapsed, globalAlpha, state.fontId, showAmpm);
    } else {
        drawFxWholeEffect(ctx, W, H, settings, state.effect, mainPx, ampmPx, zoom, mainElapsed, state.episodeSeed, globalAlpha, state.fontId, showAmpm);
    }
}
