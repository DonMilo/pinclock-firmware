


const LED7_SEGMENTS = {
    " ": "",
    "0": "abcdef", "1": "bc", "2": "abdeg", "3": "abcdg", "4": "bcfg",
    "5": "acdfg", "6": "acdefg", "7": "abc", "8": "abcdefg", "9": "abcdfg",
    "-": "g",
};

const LED_NARROW = { ":": 0.34, ".": 0.34, ",": 0.34, " ": 0.55 };

const LED7_DIGIT_ASPECT = 0.58;
const LED7_THICKNESS_FRAC = 0.22;

const LED_HEIGHT_PX = { small: 46, medium: 92, large: 150, xlarge: 200 };

function ledDigitHeight(clockSize, zoom) {
    const ratio = clockSizeRatio(clockSize);
    const px = ratio !== null ? ratio * LED_HEIGHT_PX.large : (LED_HEIGHT_PX[clockSize] || LED_HEIGHT_PX.large);
    return px * (zoom || 1);
}

function led7CellMetrics(clockSize, zoom) {
    const h = ledDigitHeight(clockSize, zoom);
    const w = h * LED7_DIGIT_ASPECT;
    const t = w * LED7_THICKNESS_FRAC;
    return { h, w, t };
}

function ledGlyphWidth(ch, metrics) {
    const narrow = LED_NARROW[ch];
    return narrow !== undefined ? metrics.w * narrow : metrics.w;
}

function ledCellGap(dotGap, zoom, metrics, extra) {
    return (dotGap || 0) * (zoom || 1) + metrics.w * 0.16 + (extra || 0);
}

function led7TextWidth(text, clockSize, dotGap, zoom) {
    const metrics = led7CellMetrics(clockSize, zoom);
    const gap = ledCellGap(dotGap, zoom, metrics);
    const chars = Array.from(text);
    let total = 0;
    chars.forEach((ch, i) => {
        total += ledGlyphWidth(ch.toUpperCase(), metrics);
        if (i < chars.length - 1) total += gap;
    });
    return total;
}

function led7TextHeight(clockSize, zoom) {
    return led7CellMetrics(clockSize, zoom).h;
}

function hSegmentPoints(cx, cy, len, t) {
    const half = len / 2;
    const bevel = Math.min(t / 2, half);
    return [
        cx - half, cy,
        cx - half + bevel, cy - t / 2,
        cx + half - bevel, cy - t / 2,
        cx + half, cy,
        cx + half - bevel, cy + t / 2,
        cx - half + bevel, cy + t / 2,
    ];
}

function vSegmentPoints(cx, cy, len, t) {
    const half = len / 2;
    const bevel = Math.min(t / 2, half);
    return [
        cx, cy - half,
        cx + t / 2, cy - half + bevel,
        cx + t / 2, cy + half - bevel,
        cx, cy + half,
        cx - t / 2, cy + half - bevel,
        cx - t / 2, cy - half + bevel,
    ];
}

function led7SegmentGeometry(x0, y0, w, h, t) {
    const midY = y0 + h / 2;
    const hLen = w - t;
    const vLen = h / 2 - t * 1.4;
    const cx = x0 + w / 2;
    return {
        a: hSegmentPoints(cx, y0 + t / 2, hLen, t),
        g: hSegmentPoints(cx, midY, hLen, t),
        d: hSegmentPoints(cx, y0 + h - t / 2, hLen, t),
        f: vSegmentPoints(x0 + t / 2, y0 + t + vLen / 2, vLen, t),
        b: vSegmentPoints(x0 + w - t / 2, y0 + t + vLen / 2, vLen, t),
        e: vSegmentPoints(x0 + t / 2, midY + t * 0.4 + vLen / 2, vLen, t),
        c: vSegmentPoints(x0 + w - t / 2, midY + t * 0.4 + vLen / 2, vLen, t),
    };
}

function drawLed7Text(ctx, text, x0, y0, opts) {
    const zoom = opts.zoom || 1;
    const metrics = led7CellMetrics(opts.size, zoom);
    const gap = ledCellGap(opts.gap, zoom, metrics);
    const [r, g, b] = hexToRgb(opts.color);
    const dim = [r * 0.12, g * 0.12, b * 0.12];
    const alpha = opts.alpha !== undefined ? opts.alpha : 1;

    const litPolys = [];
    const dimPolys = [];
    const litDots = [];

    let xoff = x0;
    for (const rawCh of text) {
        const ch = rawCh.toUpperCase();
        const gw = ledGlyphWidth(ch, metrics);

        if (ch === ":" || ch === "." || ch === ",") {
            const dotR = metrics.t * 0.55;
            const cxDot = xoff + gw / 2;
            if (ch === ":") {
                litDots.push(cxDot, y0 + metrics.h * 0.32, dotR);
                litDots.push(cxDot, y0 + metrics.h * 0.68, dotR);
            } else if (ch === ".") {
                litDots.push(cxDot, y0 + metrics.h - dotR, dotR);
            }
            xoff += gw + gap;
            continue;
        }

        if (ch !== " ") {
            const lit = LED7_SEGMENTS[ch] || "";
            const geo = led7SegmentGeometry(xoff, y0, metrics.w, metrics.h, metrics.t);
            for (const seg of "abcdefg") {
                (lit.includes(seg) ? litPolys : dimPolys).push(geo[seg]);
            }
        }
        xoff += gw + gap;
    }

    _fillLedPolysAndDots(ctx, litPolys, dimPolys, litDots, r, g, b, dim, alpha, opts.glow, metrics.t, zoom);
}


const LED14_SEGMENTS = {
    " ": [],
    "0": ["top", "bottom", "topLeft", "topRight", "bottomLeft", "bottomRight"],
    "1": ["topRight", "bottomRight"],
    "2": ["top", "topRight", "midLeft", "midRight", "bottomLeft", "bottom"],
    "3": ["top", "topRight", "midLeft", "midRight", "bottomRight", "bottom"],
    "4": ["topLeft", "topRight", "midLeft", "midRight", "bottomRight"],
    "5": ["top", "topLeft", "midLeft", "midRight", "bottomRight", "bottom"],
    "6": ["top", "topLeft", "midLeft", "midRight", "bottomLeft", "bottomRight", "bottom"],
    "7": ["top", "topRight", "bottomRight"],
    "8": ["top", "bottom", "topLeft", "topRight", "bottomLeft", "bottomRight", "midLeft", "midRight"],
    "9": ["top", "topLeft", "topRight", "midLeft", "midRight", "bottomRight", "bottom"],
    "-": ["midLeft", "midRight"],

    "A": ["top", "topLeft", "topRight", "bottomLeft", "bottomRight", "midLeft", "midRight"],
    "B": ["top", "bottom", "topLeft", "topRight", "bottomLeft", "bottomRight", "midLeft", "midRight"],
    "C": ["top", "topLeft", "bottomLeft", "bottom"],
    "D": ["top", "bottom", "topRight", "bottomRight", "vertTop", "vertBottom"],
    "E": ["top", "bottom", "topLeft", "bottomLeft", "midLeft", "midRight"],
    "F": ["top", "topLeft", "bottomLeft", "midLeft", "midRight"],
    "G": ["top", "topLeft", "bottomLeft", "bottom", "bottomRight", "midRight"],
    "H": ["topLeft", "bottomLeft", "topRight", "bottomRight", "midLeft", "midRight"],
    "I": ["vertTop", "vertBottom"],
    "J": ["topRight", "bottomRight", "bottom", "bottomLeft"],
    "K": ["topLeft", "bottomLeft", "diagTopRight", "diagBottomRight"],
    "L": ["topLeft", "bottomLeft", "bottom"],
    "M": ["topLeft", "bottomLeft", "topRight", "bottomRight", "diagTopLeft", "diagTopRight"],
    "N": ["topLeft", "bottomLeft", "topRight", "bottomRight", "diagTopLeft", "diagBottomRight"],
    "O": ["top", "bottom", "topLeft", "topRight", "bottomLeft", "bottomRight"],
    "P": ["top", "topLeft", "topRight", "midLeft", "midRight", "bottomLeft"],
    "Q": ["top", "bottom", "topLeft", "topRight", "bottomLeft", "bottomRight", "diagBottomRight"],
    "R": ["top", "topLeft", "topRight", "midLeft", "midRight", "bottomLeft", "diagBottomRight"],
    "S": ["top", "topLeft", "midLeft", "midRight", "bottomRight", "bottom"],
    "T": ["top", "vertTop", "vertBottom"],
    "U": ["topLeft", "bottomLeft", "topRight", "bottomRight", "bottom"],
    "V": ["topLeft", "bottomLeft", "diagBottomLeft", "diagTopRight"],
    "W": ["topLeft", "bottomLeft", "topRight", "bottomRight", "diagBottomLeft", "diagBottomRight"],
    "X": ["diagTopLeft", "diagTopRight", "diagBottomLeft", "diagBottomRight"],
    "Y": ["diagTopLeft", "diagTopRight", "vertBottom"],
    "Z": ["top", "bottom", "diagTopRight", "diagBottomLeft"],
};

const LED14_DIGIT_ASPECT = 0.58;
const LED14_THICKNESS_FRAC = 0.16;

function led14CellMetrics(clockSize, zoom) {
    const h = ledDigitHeight(clockSize, zoom);
    const w = h * LED14_DIGIT_ASPECT;
    const t = w * LED14_THICKNESS_FRAC;
    return { h, w, t };
}

const LED14_LETTER_EXTRA_GAP_FRAC = 0.22;

function led14TextWidth(text, clockSize, dotGap, zoom, extraGap) {
    const metrics = led14CellMetrics(clockSize, zoom);
    const gap = ledCellGap(dotGap, zoom, metrics, extraGap);
    const chars = Array.from(text);
    let total = 0;
    chars.forEach((ch, i) => {
        total += ledGlyphWidth(ch.toUpperCase(), metrics);
        if (i < chars.length - 1) total += gap;
    });
    return total;
}

function led14TextHeight(clockSize, zoom) {
    return led14CellMetrics(clockSize, zoom).h;
}

function segmentPoints(x1, y1, x2, y2, t, margin) {
    const dx = x2 - x1, dy = y2 - y1;
    const fullLen = Math.hypot(dx, dy) || 1;
    const ux = dx / fullLen, uy = dy / fullLen;
    const px = -uy, py = ux;

    const len = Math.max(0, fullLen - margin * 2);
    const cx = (x1 + x2) / 2, cy = (y1 + y2) / 2;
    const half = len / 2;
    const bevel = Math.min(t / 2, half);

    return [
        cx - ux * half, cy - uy * half,
        cx - ux * (half - bevel) + px * t / 2, cy - uy * (half - bevel) + py * t / 2,
        cx + ux * (half - bevel) + px * t / 2, cy + uy * (half - bevel) + py * t / 2,
        cx + ux * half, cy + uy * half,
        cx + ux * (half - bevel) - px * t / 2, cy + uy * (half - bevel) - py * t / 2,
        cx - ux * (half - bevel) - px * t / 2, cy - uy * (half - bevel) - py * t / 2,
    ];
}

function led14SegmentGeometry(x0, y0, w, h, t) {
    const cx = x0 + w / 2, midY = y0 + h / 2;
    const TLc = [x0, y0], TRc = [x0 + w, y0];
    const BLc = [x0, y0 + h], BRc = [x0 + w, y0 + h];
    const TM = [cx, y0], BM = [cx, y0 + h];
    const LM = [x0, midY], RM = [x0 + w, midY];
    const C = [cx, midY];

    const outerMargin = t * 0.55;
    const centerMargin = t * 0.7;

    const seg = (p1, p2, margin) => segmentPoints(p1[0], p1[1], p2[0], p2[1], t, margin);

    return {
        top: seg(TLc, TRc, outerMargin),
        bottom: seg(BLc, BRc, outerMargin),
        topLeft: seg(TLc, LM, outerMargin),
        bottomLeft: seg(LM, BLc, outerMargin),
        topRight: seg(TRc, RM, outerMargin),
        bottomRight: seg(RM, BRc, outerMargin),
        midLeft: seg(LM, C, centerMargin),
        midRight: seg(C, RM, centerMargin),
        diagTopLeft: seg(TLc, C, centerMargin),
        diagTopRight: seg(TRc, C, centerMargin),
        diagBottomLeft: seg(C, BLc, centerMargin),
        diagBottomRight: seg(C, BRc, centerMargin),
        vertTop: seg(TM, C, centerMargin),
        vertBottom: seg(C, BM, centerMargin),
    };
}

const LED14_SEGMENT_NAMES = [
    "top", "bottom", "topLeft", "topRight", "bottomLeft", "bottomRight",
    "midLeft", "midRight", "diagTopLeft", "diagTopRight",
    "diagBottomLeft", "diagBottomRight", "vertTop", "vertBottom",
];

function drawLed14Text(ctx, text, x0, y0, opts) {
    const zoom = opts.zoom || 1;
    const metrics = led14CellMetrics(opts.size, zoom);
    const gap = ledCellGap(opts.gap, zoom, metrics, opts.extraGap);
    const [r, g, b] = hexToRgb(opts.color);
    const dim = [r * 0.12, g * 0.12, b * 0.12];
    const alpha = opts.alpha !== undefined ? opts.alpha : 1;

    const litPolys = [];
    const dimPolys = [];
    const litDots = [];

    let xoff = x0;
    for (const rawCh of text) {
        const ch = rawCh.toUpperCase();
        const gw = ledGlyphWidth(ch, metrics);

        if (ch === ":" || ch === "." || ch === ",") {
            const dotR = metrics.t * 0.6;
            const cxDot = xoff + gw / 2;
            if (ch === ":") {
                litDots.push(cxDot, y0 + metrics.h * 0.32, dotR);
                litDots.push(cxDot, y0 + metrics.h * 0.68, dotR);
            } else if (ch === ".") {
                litDots.push(cxDot, y0 + metrics.h - dotR, dotR);
            }
            xoff += gw + gap;
            continue;
        }

        if (ch !== " ") {
            const lit = new Set(LED14_SEGMENTS[ch] || []);
            const geo = led14SegmentGeometry(xoff, y0, metrics.w, metrics.h, metrics.t);
            for (const name of LED14_SEGMENT_NAMES) {
                (lit.has(name) ? litPolys : dimPolys).push(geo[name]);
            }
        }
        xoff += gw + gap;
    }

    _fillLedPolysAndDots(ctx, litPolys, dimPolys, litDots, r, g, b, dim, alpha, opts.glow, metrics.t, zoom);
}


const LED_GLOW_BLUR_PX = 6;

function _fillLedPolysAndDots(ctx, litPolys, dimPolys, litDots, r, g, b, dim, alpha, glow, zoomedThickness, zoom) {
    function fillPolys(polys, color) {
        if (polys.length === 0) return;
        ctx.beginPath();
        for (const pts of polys) {
            ctx.moveTo(pts[0], pts[1]);
            for (let i = 2; i < pts.length; i += 2) ctx.lineTo(pts[i], pts[i + 1]);
            ctx.closePath();
        }
        ctx.fillStyle = color;
        ctx.fill();
    }

    function fillDots(dots, color) {
        if (dots.length === 0) return;
        ctx.beginPath();
        for (let i = 0; i < dots.length; i += 3) {
            const cx = dots[i], cy = dots[i + 1], rad = dots[i + 2];
            ctx.moveTo(cx + rad, cy);
            ctx.arc(cx, cy, rad, 0, Math.PI * 2);
        }
        ctx.fillStyle = color;
        ctx.fill();
    }

    if (glow) {
        const gCol = [Math.min(255, r * 1.4), Math.min(255, g * 1.4), Math.min(255, b * 1.4)];
        ctx.save();
        ctx.shadowColor = `rgba(${gCol[0]},${gCol[1]},${gCol[2]},${alpha * 0.7})`;
        ctx.shadowBlur = Math.min(LED_GLOW_BLUR_PX * (zoom || 1), zoomedThickness * 0.5);
        fillPolys(litPolys, `rgba(${r},${g},${b},${alpha})`);
        fillDots(litDots, `rgba(${r},${g},${b},${alpha})`);
        ctx.restore();
    }

    fillPolys(dimPolys, `rgba(${dim[0]},${dim[1]},${dim[2]},${alpha})`);
    fillPolys(litPolys, `rgba(${r},${g},${b},${alpha})`);
    fillDots(litDots, `rgba(${r},${g},${b},${alpha})`);
}
