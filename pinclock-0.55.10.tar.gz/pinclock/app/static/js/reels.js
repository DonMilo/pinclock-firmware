

const REEL_CLOCK_STYLE = "reels";

const REEL_FONT_ID = "reel_barlow";

const REEL_DIRECTIONS = { up: 1, down: -1 };
const REEL_FLOURISHES = ["off", "stepper", "spin"];

function reelSetting(settings, key) {
    const v = settings ? settings[key] : undefined;
    if (v !== undefined && v !== null) return v;
    return typeof PINCLOCK_DEFAULTS !== "undefined" && PINCLOCK_DEFAULTS ? PINCLOCK_DEFAULTS[key] : undefined;
}

function reelSizePct(settings) {
    if (settings && settings.reel_size_pct === false) return null;
    const n = Number(reelSetting(settings, "reel_size_pct"));
    if (!isFinite(n) || n <= 0) return null;
    return Math.max(10, Math.min(110, n));
}

function reelOptions(settings) {
    const pct = (key) => {
        const n = Number(reelSetting(settings, key));
        return isFinite(n) ? Math.max(0, Math.min(100, n)) / 100 : 0;
    };
    const pick = (key, list) => {
        const v = reelSetting(settings, key);
        return list.indexOf(v) !== -1 ? v : list[0];
    };
    return {
        dir: REEL_DIRECTIONS[reelSetting(settings, "reel_roll_direction")] || REEL_DIRECTIONS.up,
        backlight: pct("reel_backlight") * 2,
        wear: pct("reel_wear"),
        dip: reelSetting(settings, "reel_lamp_dip") === true,
        flicker: reelSetting(settings, "reel_random_flicker") === true,
        flickerMaxMs: (() => {
            const n = Number(reelSetting(settings, "reel_random_flicker_max_seconds"));
            return (isFinite(n) ? Math.max(REEL_FLICKER_MAX_S_MIN, Math.min(REEL_FLICKER_MAX_S_MAX, n)) : REEL_FLICKER_MAX_S_MAX) * 1000;
        })(),
        flourish: pick("reel_hour_flourish", REEL_FLOURISHES),
        secStyle: pick("reel_seconds_style", REEL_SEC_STYLES),
        secLampMode: pick("reel_seconds_lamp_mode", REEL_SEC_LAMP_MODES),
        smallSeconds: reelSetting(settings, "reel_small_seconds") !== false,
    };
}

const REEL_SEC_STYLES = ["reels", "lamps"];
const REEL_SEC_LAMP_MODES = ["single", "fill"];
const REEL_SEC_LAMP_TEXT = ["00", "10", "20", "30", "40", "50"];
const REEL_SEC_LAMP_GAP = 0.07;
const REEL_SEC_LAMP_DX = 1.12;
const REEL_SEC_LAMP_TEXT_SCALE = 0.46;
const REEL_LAMPS_STEP_MS = 750;

function reelSecondsLampMask(sec, mode) {
    const g = Math.max(0, Math.min(5, Math.floor((Number(sec) || 0) / 10)));
    let out = "";
    for (let i = 0; i < 6; i++) out += (mode === "fill" ? i <= g : i === g) ? "1" : "0";
    return out;
}

function reelSecondsAsLamps(settings) {
    return settings.show_seconds !== false && reelSetting(settings, "reel_seconds_style") === "lamps";
}

const REEL_THEMES = {
    classic: {
        label: "Score Glass",
        plate: ["#2c2825", "#121110"],
        plateRims: [{ c: "rgba(255,255,255,0.13)", w: 0.008 }],
        deco: "none",
        recess: "#040404",
        windowRims: [],
        drum: "#f0e7d1",
        ink: "#17130f",
        colon: "#eadfc2",
        backlight: "rgba(255,190,100,0.20)",
        lampOnCenter: "#fff3c8",
        lampOnEdge: "#ffbe4d",
        lampOnGlow: "rgba(255,180,60,0.85)",
        lampOnText: "#4a2500",
        lampOff: "#2b2216",
        lampOffText: "#5a4a32",
        dateText: "#e6d9b8",
    },
    bare: {
        label: "Reels Only",
        frameless: true,
        plate: ["#2c2825", "#121110"],
        plateRims: [],
        deco: "none",
        recess: "#040404",
        windowRims: [{ c: "rgba(255,255,255,0.18)", w: 0.012 }],
        drum: "#f0e7d1",
        ink: "#17130f",
        colon: "#eadfc2",
        backlight: "rgba(255,190,100,0.20)",
        lampOnCenter: "#fff3c8",
        lampOnEdge: "#ffbe4d",
        lampOnGlow: "rgba(255,180,60,0.85)",
        lampOnText: "#4a2500",
        lampOff: "#2b2216",
        lampOffText: "#5a4a32",
        dateText: "#e6d9b8",
    },
    atomic: {
        label: "Atomic Saucer",
        plate: ["#dbe851", "#a9bb22"],
        plateRims: [{ c: "#c8202c", w: 0.075 }, { c: "#f7eccd", w: 0.018 }],
        deco: "marquee", decoColor: "#fff3c4",
        padX: 0.05, padY: 0.05,
        recess: "#151209",
        windowRims: [{ c: "#c8202c", w: 0.03 }],
        drum: "#f4ebd3",
        ink: "#1b120c",
        colon: "#c8202c",
        backlight: "rgba(255,210,120,0.20)",
        lampOnCenter: "#fff0a0",
        lampOnEdge: "#ff7a1a",
        lampOnGlow: "rgba(255,110,20,0.9)",
        lampOnText: "#5a1300",
        lampOff: "#8c9b22",
        lampOffText: "#5d6815",
        dateText: "#5a1010",
    },
    space: {
        label: "Space Race",
        plate: ["#123a9a", "#06123a"],
        plateRims: [{ c: "#e9eefc", w: 0.012 }],
        deco: "stars", decoColor: "#ffffff", decoColor2: "#ffe27a",
        recess: "#050505",
        windowRims: [{ c: "#d6232f", w: 0.026 }, { c: "#ffffff", w: 0.018 }],
        drum: "#f3efe2",
        ink: "#111111",
        colon: "#ffffff",
        backlight: "rgba(200,220,255,0.16)",
        lampOnCenter: "#fff6b8",
        lampOnEdge: "#f2b51c",
        lampOnGlow: "rgba(255,200,40,0.9)",
        lampOnText: "#7a1a00",
        lampOff: "#1b2f6b",
        lampOffText: "#5068a8",
        dateText: "#e8eefc",
    },
    mod: {
        label: "Go-Go Mod",
        plate: ["#2fd0cf", "#14979f"],
        plateRims: [{ c: "#111111", w: 0.03 }, { c: "#ff2d95", w: 0.022 }],
        deco: "modband", decoColor: "#ff2d95", decoColor2: "#ffe23a",
        padY: 0.06,
        recess: "#0b0b0b",
        windowRims: [{ c: "#111111", w: 0.014 }, { c: "#ffffff", w: 0.034 }],
        drum: "#fbf8ef",
        ink: "#111111",
        colon: "#111111",
        backlight: "rgba(255,230,240,0.14)",
        lampOnCenter: "#ffe1f0",
        lampOnEdge: "#ff2d95",
        lampOnGlow: "rgba(255,45,149,0.9)",
        lampOnText: "#4a0026",
        lampOff: "#11777e",
        lampOffText: "#0a4c52",
        dateText: "#0b2b2d",
    },
    chevron: {
        label: "Hi-Score Chevron",
        plate: ["#ffb347", "#ee7f22"],
        plateRims: [{ c: "#111111", w: 0.045 }],
        deco: "chevrons", decoColor: "#111111", decoColor2: "#fff3d6",
        padX: 0.5,
        recess: "#0a0a0a",
        windowRims: [{ c: "#111111", w: 0.03 }, { c: "#fff3d6", w: 0.012 }],
        drum: "#f6eedb",
        ink: "#1a0e05",
        colon: "#111111",
        backlight: "rgba(255,200,120,0.18)",
        lampOnCenter: "#fff4c2",
        lampOnEdge: "#ff3b2f",
        lampOnGlow: "rgba(255,50,30,0.9)",
        lampOnText: "#4a0000",
        lampOff: "#a6501a",
        lampOffText: "#6a2e08",
        dateText: "#241000",
    },
    lunar: {
        label: "Lunar Burst",
        plate: ["#ffffff", "#e8edf6"],
        plateRims: [{ c: "#1d3fb5", w: 0.03 }, { c: "#ffd400", w: 0.02 }, { c: "#1d3fb5", w: 0.012 }],
        deco: "burst", decoColor: "#ffd400", decoColor2: "#1d3fb5",
        padX: 0.16, padY: 0.16,
        recess: "#0a0a0a",
        windowRims: [{ c: "#1d3fb5", w: 0.02 }],
        drum: "#fbfbf8",
        ink: "#0a0a0a",
        colon: "#1d3fb5",
        backlight: "rgba(220,230,255,0.14)",
        lampOnCenter: "#fff7c0",
        lampOnEdge: "#ffd400",
        lampOnGlow: "rgba(255,200,0,0.9)",
        lampOnText: "#10208a",
        lampOff: "#d9dfeb",
        lampOffText: "#97a3c2",
        dateText: "#1d3fb5",
    },
    fiesta: {
        label: "Fiesta Tile",
        plate: ["#ff4fae", "#de1f7c"],
        plateRims: [{ c: "#1a1a1a", w: 0.03 }, { c: "#ffd23a", w: 0.018 }],
        deco: "tiles", decoColor: "#e8562c", decoColor2: "#8a2a10",
        padY: 0.17,
        recess: "#0b0b0b",
        windowRims: [{ c: "#111111", w: 0.016 }, { c: "#fff8e6", w: 0.03 }],
        drum: "#f6eedb",
        ink: "#1a0e05",
        colon: "#1a1a1a",
        backlight: "rgba(255,200,140,0.18)",
        lampOnCenter: "#fff4b0",
        lampOnEdge: "#ffb21a",
        lampOnGlow: "rgba(255,160,20,0.9)",
        lampOnText: "#5a1a00",
        lampOff: "#b81f6a",
        lampOffText: "#7d1448",
        dateText: "#2a0018",
    },
    rink: {
        label: "Rinkside",
        plate: ["#33b85e", "#168a3e"],
        plateRims: [{ c: "#ffffff", w: 0.02 }, { c: "#d6232f", w: 0.02 }],
        deco: "rink", decoColor: "#ffffff", decoColor2: "#d6232f",
        padX: 0.34,
        recess: "#0a0a0a",
        windowRims: [{ c: "#ffffff", w: 0.03 }],
        drum: "#f8f6ee",
        ink: "#111111",
        colon: "#ffffff",
        backlight: "rgba(230,245,255,0.14)",
        lampOnCenter: "#fff0f0",
        lampOnEdge: "#e8262f",
        lampOnGlow: "rgba(232,38,47,0.9)",
        lampOnText: "#3a0000",
        lampOff: "#146b32",
        lampOffText: "#0d4a22",
        dateText: "#ffffff",
    },
    velvet: {
        label: "Velvet & Gold",
        plate: ["#b3121f", "#3a0508"],
        plateRims: [{ c: "#d9a63a", w: 0.03 }, { c: "#1a0204", w: 0.012 }, { c: "#f2cf6b", w: 0.01 }],
        deco: "ornate", decoColor: "#e8bd55",
        padX: 0.12, padY: 0.06,
        recess: "#050505",
        windowRims: [{ c: "#e8bd55", w: 0.022 }],
        drum: "#f3ead2",
        ink: "#140c06",
        colon: "#e8bd55",
        backlight: "rgba(255,190,120,0.20)",
        lampOnCenter: "#fff2c0",
        lampOnEdge: "#e0a628",
        lampOnGlow: "rgba(230,170,40,0.9)",
        lampOnText: "#3a1500",
        lampOff: "#5a0b10",
        lampOffText: "#8a3a2a",
        dateText: "#f2cf6b",
    },
    swirl: {
        label: "Hypno Swirl",
        plate: ["#2340b8", "#13227a"],
        plateRims: [{ c: "#ffd400", w: 0.025 }, { c: "#d6232f", w: 0.018 }],
        deco: "swirl", decoColor: "#d6232f", decoColor3: "#ffd400",
        recess: "#050505",
        windowRims: [{ c: "#d6232f", w: 0.012 }, { c: "#ffd400", w: 0.024 }],
        drum: "#f7f3e6",
        ink: "#111111",
        colon: "#ffd400",
        backlight: "rgba(255,240,200,0.14)",
        lampOnCenter: "#fffbd0",
        lampOnEdge: "#ffd400",
        lampOnGlow: "rgba(255,212,0,0.9)",
        lampOnText: "#6a0d00",
        lampOff: "#22307a",
        lampOffText: "#5560a8",
        dateText: "#ffd400",
    },
    volcano: {
        label: "Volcano Dusk",
        plate: ["#6f2cc4", "#d63c98"],
        plateRims: [{ c: "#111111", w: 0.03 }, { c: "#b8f23a", w: 0.018 }],
        deco: "lava", decoColor: "#3a1450", decoColor2: "#ff6a1a",
        padY: 0.1,
        recess: "#0a0a0a",
        windowRims: [{ c: "#111111", w: 0.018 }, { c: "#ffffff", w: 0.03 }],
        drum: "#fbf8ef",
        ink: "#111111",
        colon: "#b8f23a",
        backlight: "rgba(255,220,240,0.14)",
        lampOnCenter: "#f6ffd0",
        lampOnEdge: "#9be21a",
        lampOnGlow: "rgba(155,226,26,0.9)",
        lampOnText: "#213a00",
        lampOff: "#5a2a8a",
        lampOffText: "#8a62b8",
        dateText: "#f6ffd0",
    },
    inferno: {
        label: "Inferno",
        plate: ["#13205a", "#05060f"],
        plateRims: [{ c: "#ff8a1a", w: 0.02 }, { c: "#2a0a00", w: 0.01 }],
        deco: "flames", decoColor: "#ff5a14", decoColor2: "#ffd23a",
        padY: 0.12,
        recess: "#050505",
        windowRims: [{ c: "#2b2b2b", w: 0.014 }, { c: "#f2e6c4", w: 0.026 }],
        drum: "#f4ead0",
        ink: "#140c06",
        colon: "#ffd23a",
        backlight: "rgba(255,190,110,0.20)",
        lampOnCenter: "#fff2b0",
        lampOnEdge: "#ff6a14",
        lampOnGlow: "rgba(255,106,20,0.9)",
        lampOnText: "#4a0f00",
        lampOff: "#1f2650",
        lampOffText: "#4c5690",
        dateText: "#ffd23a",
    },
    limeflame: {
        label: "Lime & Flame",
        plate: ["#e2ea3c", "#b7c916"],
        plateRims: [{ c: "#d8261f", w: 0.03 }, { c: "#ffffff", w: 0.014 }],
        deco: "flamedots", decoColor: "#e3241c", decoColor2: "#ff9a1a", decoColor3: "#2a6ad8",
        padY: 0.17,
        recess: "#0a0a0a",
        windowRims: [{ c: "#5a3a1a", w: 0.012 }, { c: "#ffffff", w: 0.034 }],
        drum: "#f6f1e2",
        ink: "#141008",
        colon: "#d8261f",
        backlight: "rgba(255,200,120,0.18)",
        lampOnCenter: "#ff9a7a",
        lampOnEdge: "#d8261f",
        lampOnGlow: "rgba(216,38,31,0.9)",
        lampOnText: "#fff35a",
        lampOff: "#a9b81a",
        lampOffText: "#7d8a10",
        dateText: "#7a0a0a",
    },
};
const REEL_THEME_ORDER = [
    "classic", "bare", "atomic", "space", "mod", "chevron", "lunar",
    "fiesta", "rink", "velvet", "swirl", "volcano", "inferno", "limeflame",
];
const REEL_DECOS = ["none", "stars", "marquee", "chevrons", "modband", "burst", "tiles", "rink", "ornate", "swirl", "lava", "flames", "flamedots"];

function reelThemeId(settings) {
    if (settings && Array.isArray(settings.reel_faceplates)) reelSyncImageThemes(settings.reel_faceplates);
    if (settings && Array.isArray(settings.reel_scenes)) reelSyncSceneThemes(settings.reel_scenes);
    const id = settings && settings.reel_theme;
    if (REEL_THEMES[id]) return id;
    const def = typeof PINCLOCK_DEFAULTS !== "undefined" && PINCLOCK_DEFAULTS ? PINCLOCK_DEFAULTS.reel_theme : null;
    return REEL_THEMES[def] ? def : REEL_THEME_ORDER[0];
}

const REEL_CYCLE_SECONDS_MIN = 20, REEL_CYCLE_SECONDS_MAX = 3600;
function reelActiveThemeId(settings, date) {
    const base = reelThemeId(settings);
    const kind = reelCycleKind(settings, base);
    if (!kind) return base;
    const secsOf = (key) => {
        const raw = Number(reelSetting(settings, key));
        return isFinite(raw) ? Math.max(REEL_CYCLE_SECONDS_MIN, Math.min(REEL_CYCLE_SECONDS_MAX, Math.round(raw))) : REEL_CYCLE_SECONDS_MAX;
    };
    const ticked = reelCycleOrder(settings);
    const plates = ticked.filter((id) => !REEL_THEMES[id].scene);
    const scenes = ticked.filter((id) => !!REEL_THEMES[id].scene);
    let seq;
    if (kind === "both" && plates.length && scenes.length) {
        seq = reelCycleSequence(plates, scenes, (id) => REEL_THEMES[id].label).map((id) => ({
            id, ms: secsOf(REEL_THEMES[id].scene ? "reel_scene_cycle_seconds" : "reel_theme_cycle_seconds") * 1000,
        }));
    } else {
        const scenesRun = kind === "scenes" || (kind === "both" && !plates.length);
        const list = scenesRun ? scenes : plates;
        const ms = secsOf(scenesRun ? "reel_scene_cycle_seconds" : "reel_theme_cycle_seconds") * 1000;
        seq = list.map((id) => ({ id, ms }));
    }
    const n = seq.length;
    if (!n) return base;
    const total = seq.reduce((a, x) => a + x.ms, 0);
    const random = n >= 3 && kind !== "both" && seq.every((x) => REEL_THEMES[x.id].scene) && reelSetting(settings, "reel_scene_random") !== false;
    let start = 0;
    const at = seq.findIndex((x) => x.id === base);
    for (let i = 0; i < Math.max(0, at); i++) start += seq[i].ms;
    const nowMs = (date || new Date()).getTime();
    const an = settings && settings._cycle_anchor;
    if (an && an.id && REEL_THEMES[an.id] && isFinite(an.t) && nowMs >= an.t) {
        let el = nowMs - an.t;
        let from = seq.findIndex((x) => x.id === an.id);
        if (from === -1 || random) {
            const ms0 = from === -1 ? secsOf(REEL_THEMES[an.id].scene ? "reel_scene_cycle_seconds" : "reel_theme_cycle_seconds") * 1000 : seq[from].ms;
            if (el < ms0) return an.id;
            el -= ms0;
            from = 0;
            if (random) return reelShuffleSlot(seq, Math.floor(el / seq[0].ms), reelHashId(an.id) ^ Math.floor(an.t), an.id);
        }
        el %= total;
        for (let k = 0; k < n; k++) {
            const x = seq[(from + k) % n];
            if (el < x.ms) return x.id;
            el -= x.ms;
        }
        return seq[from].id;
    }
    if (random) return reelShuffleSlot(seq, Math.floor(nowMs / seq[0].ms), reelHashId(base), null);
    let pos = ((nowMs + start) % total + total) % total;
    for (let i = 0; i < n; i++) {
        if (pos < seq[i].ms) return seq[i].id;
        pos -= seq[i].ms;
    }
    return seq[n - 1].id;
}

function reelRng(seed) {
    let a = seed >>> 0;
    return () => {
        a = (a + 0x6D2B79F5) >>> 0;
        let t = a;
        t = Math.imul(t ^ (t >>> 15), t | 1);
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}
function reelHashId(s) {
    let h = 2166136261;
    for (const ch of String(s || "")) h = Math.imul(h ^ ch.charCodeAt(0), 16777619);
    return h >>> 0;
}
function reelShufflePass(ids, seed, pass) {
    const out = ids.slice();
    const rnd = reelRng((seed ^ Math.imul(pass + 1, 0x9E3779B1)) >>> 0);
    for (let i = out.length - 1; i > 0; i--) {
        const j = Math.floor(rnd() * (i + 1));
        const t = out[i]; out[i] = out[j]; out[j] = t;
    }
    return out;
}
function reelShuffleSlot(seq, slot, seed, notFirst) {
    const ids = seq.map((x) => x.id), n = ids.length;
    const p = Math.floor(slot / n), i = ((slot % n) + n) % n;
    const order = reelShufflePass(ids, seed, p);
    const before = p === 0 && notFirst ? notFirst : (p !== 0 || !notFirst ? reelShufflePass(ids, seed, p - 1)[n - 1] : null);
    if (order[0] === before) { const t = order[0]; order[0] = order[1]; order[1] = t; }
    return order[i];
}
function reelCycleSequence(plates, scenes, label) {
    const key = (id) => String(label(id) || "").replace(/\s*\([^)]*\)\s*$/, "").toLowerCase().replace(/[^a-z0-9]+/g, "");
    const n = Math.max(plates.length, scenes.length);
    if (!plates.length || !scenes.length) return (plates.length ? plates : scenes).slice();
    const B = new Array(n).fill(null);
    const used = new Set();
    for (let k = 0; k < plates.length; k++) {
        const kk = key(plates[k]);
        if (!kk) continue;
        const s = scenes.find((id) => !used.has(id) && key(id) === kk);
        if (s) { B[k] = s; used.add(s); }
    }
    const fill = scenes.filter((id) => !used.has(id));
    let f = 0;
    for (let k = 0; k < n; k++) {
        if (B[k] !== null) continue;
        B[k] = f < fill.length ? fill[f] : scenes[(f - fill.length) % scenes.length];
        f++;
    }
    const out = [];
    for (let k = 0; k < n; k++) out.push(plates[k % plates.length], B[k]);
    return out;
}
const REEL_EM_SHOW_S = 27;
const REEL_EM_SHOW_MIN_S = 5, REEL_EM_SHOW_MAX_S = 60;
function reelEmShowS(planOrSettings) {
    const o = planOrSettings || {};
    const n = Number(o.showS !== undefined ? o.showS : reelSetting(o, "em_plate_seconds"));
    return isFinite(n) && n > 0 ? Math.max(REEL_EM_SHOW_MIN_S, Math.min(REEL_EM_SHOW_MAX_S, n)) : REEL_EM_SHOW_S;
}
const REEL_EM_FADE_MS = 600;
function reelEmKey(label) {
    return String(label || "").replace(/\s*\([^)]*\)\s*$/, "").toLowerCase().replace(/[^a-z]+/g, "");
}
function reelEmVideoKey(fileName) {
    const stem = String(fileName || "").replace(/^.*[\\/]/, "").replace(/\.[^.]+$/, "");
    return reelEmKey(reelDisplayName(stem) || stem);
}
function reelEmPlateFor(fileName, seed) {
    const plates = REEL_THEME_ORDER.filter((id) => REEL_THEMES[id] && !REEL_THEMES[id].scene && !REEL_THEMES[id].frameless);
    if (!plates.length) return null;
    const want = reelEmVideoKey(fileName);
    const rank = (id) => (id.indexOf(REEL_IMAGE_THEME_PREFIX) === 0 ? 0 : id.indexOf(REEL_SCENE_PLATE_PREFIX) === 0 ? 1 : 2);
    if (want) {
        const hits = plates.filter((id) => reelEmKey(REEL_THEMES[id].label) === want);
        if (hits.length) return hits.sort((a, b) => rank(a) - rank(b))[0];
    }
    const r = Number(seed);
    return plates[Math.min(plates.length - 1, Math.floor((isFinite(r) ? Math.abs(r) % 1 : 0) * plates.length))];
}
function reelEmVideoPlate(settings, step) {
    let pick = reelThemeId(settings);
    const t = REEL_THEMES[pick];
    if (t && t.scene) pick = t.sceneBase && REEL_THEMES[t.sceneBase] ? t.sceneBase : (REEL_THEMES.classic ? "classic" : null);
    if (!pick || !REEL_THEMES[pick]) pick = REEL_THEME_ORDER.find((id) => REEL_THEMES[id] && !REEL_THEMES[id].scene) || null;
    if (reelSetting(settings, "reel_theme_cycle") !== true) return pick;
    const plates = reelCycleOrder(settings).filter((id) => REEL_THEMES[id] && !REEL_THEMES[id].scene);
    if (!plates.length) return pick;
    const at = plates.indexOf(pick);
    const k = Math.max(0, Math.floor(Number(step) || 0));
    return plates[(((at < 0 ? 0 : at) + k) % plates.length + plates.length) % plates.length];
}
function reelEmAlpha(elapsedS, showS) {
    const e = Number(elapsedS);
    if (!isFinite(e) || e < 0) return 1;
    const show = isFinite(Number(showS)) && Number(showS) > 0 ? Number(showS) : REEL_EM_SHOW_S;
    const f = (e - show) * 1000 / REEL_EM_FADE_MS;
    return f <= 0 ? 1 : f >= 1 ? 0 : 1 - f;
}
const REEL_EM_ENTERS = ["slide_left", "slide_right", "drop", "grow", "spin", "fade"];
const REEL_EM_HOLDS = ["still", "tour", "drift"];
const REEL_EM_EXITS = ["fade", "slide_off", "drop_away"];
const REEL_EM_ENTER_MS = 1000;
const REEL_EM_EXIT_MS = 800;
const REEL_EM_TOUR_EVERY_S = 5;
const REEL_EM_TOUR_MOVE_MS = 800;
const REEL_EM_TOUR_STOPS = [[0, 0], [-1, -1], [1, -1], [1, 1], [-1, 1]];
function reelEmPick(list, excluded, r) {
    const ex = Array.isArray(excluded) ? excluded : [];
    const pool = list.filter((x) => ex.indexOf(x) === -1);
    const use = pool.length ? pool : [list[0]];
    return use[Math.min(use.length - 1, Math.floor((isFinite(r) ? Math.abs(r) % 1 : 0) * use.length))];
}
function reelEmPlan(settings, r1, r2, r3) {
    const g = (k) => reelSetting(settings, k);
    return {
        enter: reelEmPick(REEL_EM_ENTERS, g("em_fx_enter_excluded"), r1),
        hold: reelEmPick(REEL_EM_HOLDS, g("em_fx_hold_excluded"), r2),
        exit: reelEmPick(REEL_EM_EXITS, g("em_fx_exit_excluded"), r3),
        side: (Math.abs(r1 * 7919) % 1) < 0.5 ? -1 : 1,
    };
}
const _emEaseOut = (u) => 1 - Math.pow(1 - u, 3);
const _emEaseInOut = (u) => (u < 0.5 ? 4 * u * u * u : 1 - Math.pow(-2 * u + 2, 3) / 2);
function _emBounce(u) {
    const n = 7.5625, d = 2.75;
    if (u < 1 / d) return n * u * u;
    if (u < 2 / d) { u -= 1.5 / d; return n * u * u + 0.75; }
    if (u < 2.5 / d) { u -= 2.25 / d; return n * u * u + 0.9375; }
    u -= 2.625 / d; return n * u * u + 0.984375;
}
function _emBackOut(u) { const c = 1.70158; return 1 + (c + 1) * Math.pow(u - 1, 3) + c * Math.pow(u - 1, 2); }
function reelEmMotion(plan, e, W, H, w, h) {
    const out = { dx: 0, dy: 0, s: 1, a: 1 };
    if (!plan || !isFinite(e)) return out;
    if (e < 0) e = 0;
    const roomX = Math.max(0, (W - w) / 2 - 16), roomY = Math.max(0, (H - h) / 2 - 16);
    const SHOW = plan.showS ? reelEmShowS(plan) : REEL_EM_SHOW_S;
    const tHold = Math.min(e, SHOW);
    if (plan.hold === "tour") {
        const S = REEL_EM_TOUR_STOPS, k = Math.floor(tHold / REEL_EM_TOUR_EVERY_S);
        const into = (tHold - k * REEL_EM_TOUR_EVERY_S) * 1000;
        const at = S[k % S.length], prev = k === 0 ? at : S[(k - 1) % S.length];
        const m = _emEaseInOut(Math.min(1, into / REEL_EM_TOUR_MOVE_MS));
        out.dx = (prev[0] + (at[0] - prev[0]) * m) * roomX;
        out.dy = (prev[1] + (at[1] - prev[1]) * m) * roomY;
    } else if (plan.hold === "drift") {
        const ramp = Math.min(1, tHold / 3);
        out.dx = Math.sin((2 * Math.PI * tHold) / 17) * roomX * 0.5 * ramp;
        out.dy = Math.sin((2 * Math.PI * tHold) / 11) * roomY * 0.5 * ramp;
    }
    const ue = Math.min(1, (e * 1000) / REEL_EM_ENTER_MS);
    if (ue < 1) {
        if (plan.enter === "slide_left") out.dx += -(W + w) / 2 * (1 - _emEaseOut(ue));
        else if (plan.enter === "slide_right") out.dx += (W + w) / 2 * (1 - _emEaseOut(ue));
        else if (plan.enter === "drop") out.dy += -(H + h) / 2 * (1 - _emBounce(ue));
        else if (plan.enter === "grow") out.s = Math.max(0.02, _emBackOut(ue));
        else if (plan.enter === "fade") out.a = ue;
    }
    const tx = (e - SHOW) * 1000;
    if (tx > 0) {
        if (plan.exit === "fade") out.a *= Math.max(0, 1 - tx / REEL_EM_FADE_MS);
        else {
            const ux = Math.min(1, tx / REEL_EM_EXIT_MS);
            const k = ux * ux;
            if (plan.exit === "slide_off") out.dx += (plan.side || 1) * (W + w) / 2 * k;
            else out.dy += (H + h) / 2 * k;
            if (ux >= 1) out.a = 0;
        }
    }
    return out;
}
function reelEmShowing(plan, e) {
    const show = plan && plan.showS ? reelEmShowS(plan) : REEL_EM_SHOW_S;
    const end = show + ((plan && plan.exit !== "fade") ? REEL_EM_EXIT_MS : REEL_EM_FADE_MS) / 1000;
    return isFinite(e) && e < end;
}
function reelEmFrameRate(plan, e) {
    if (!plan || !reelEmShowing(plan, e)) return null;
    if (e * 1000 < REEL_EM_ENTER_MS + 100 && plan.enter !== "spin") return "fast";
    if (e >= (plan.showS ? reelEmShowS(plan) : REEL_EM_SHOW_S) - 0.05) return "fast";
    if (plan.hold === "tour" && e >= REEL_EM_TOUR_EVERY_S) {
        const into = (e % REEL_EM_TOUR_EVERY_S) * 1000;
        if (into < REEL_EM_TOUR_MOVE_MS + 100) return "fast";
    }
    if (plan.hold === "drift") return "slow";
    return null;
}
function reelEmStartSpin(now) {
    const lay = reelState.layout;
    if (!lay || !lay.reels) return false;
    let order = 0;
    for (let i = reelState.reels.length - 1; i >= 0; i--) {
        const st = reelState.reels[i], n = lay.reels[i].cycle.length;
        if (!st) continue;
        if (st.anim) { st.idx = reelMod(st.anim.from + st.anim.n, n); st.anim = null; }
        st.anim = { from: st.idx, n, t0: now + order * REEL_RIPPLE_MS, dur: REEL_SPIN_MS, mode: "spin", fired: 0 };
        order++;
    }
    let end = 0;
    reelState.reels.forEach((st) => { if (st && st.anim) end = Math.max(end, st.anim.t0 + st.anim.dur); });
    reelState.animEndMs = end;
    return true;
}

const REEL_EM_CLOCK_KEYS = [
    ["em_clock_format", "clock_format"], ["em_clock_show_date", "show_date"],
    ["em_clock_show_seconds", "show_seconds"], ["em_clock_show_ampm", "show_ampm"],
    ["em_reel_seconds_style", "reel_seconds_style"], ["em_reel_seconds_lamp_mode", "reel_seconds_lamp_mode"],
    ["em_reel_roll_direction", "reel_roll_direction"], ["em_reel_backlight", "reel_backlight"],
    ["em_reel_wear", "reel_wear"], ["em_reel_lamp_dip", "reel_lamp_dip"],
    ["em_reel_random_flicker", "reel_random_flicker"],
    ["em_reel_random_flicker_max_seconds", "reel_random_flicker_max_seconds"],
    ["em_reel_hour_flourish", "reel_hour_flourish"],
];
const REEL_EM_XL_PRESET = "em_xlarge";
const REEL_EM_XL_FRAC = 0.875;
const REEL_EM_SIZES = { small: "small", medium: "medium", large: "large", xlarge: REEL_EM_XL_PRESET };
function reelPresetFrac(preset) {
    if (preset === REEL_EM_XL_PRESET) return REEL_EM_XL_FRAC;
    return (typeof CLOCK_SIZE_PRESET_FRAC !== "undefined" && CLOCK_SIZE_PRESET_FRAC[preset]) || 0;
}

const REEL_STATIC_EM_PROFILE_KEYS = ["clock_size", "clock_size_preset", "show_date", "show_seconds", "show_ampm",
    "clock_position", "position_rotate"];
function reelStaticEmSettings(settings, emDefaults) {
    const s = settings || {};
    const live = s.clock_style === REEL_CLOCK_STYLE;
    const saved = !live && s.clock_profiles && typeof s.clock_profiles === "object" && s.clock_profiles.reels &&
        typeof s.clock_profiles.reels === "object" ? s.clock_profiles.reels : null;
    const d = emDefaults && typeof emDefaults === "object" ? emDefaults : {};
    const out = {};
    REEL_STATIC_EM_PROFILE_KEYS.forEach((k) => {
        let v = live ? s[k] : (saved && saved[k] !== undefined ? saved[k] : d[k]);
        if (v === undefined || v === null) v = s[k];
        out[k] = v;
    });
    const preset = out.clock_size_preset;
    if (preset !== "small" && preset !== "medium" && preset !== "large" && preset !== "xlarge") {
        const px = Number(out.clock_size);
        out.clock_size_preset = isFinite(px) && px > 0 ? "" : "medium";
    }
    return out;
}

function reelEmSettings(settings, plateId, rotCorner) {
    let own;
    const custom = reelSetting(settings, "em_clock_custom") === true;
    if (custom) {
        own = {};
        REEL_EM_CLOCK_KEYS.forEach((p) => {
            const v = reelSetting(settings, p[0]);
            if (v !== undefined && v !== null) own[p[1]] = v;
        });
        own.clock_size_preset = REEL_EM_SIZES[reelSetting(settings, "em_clock_size")] || "medium";
    } else {
        own = reelStaticEmSettings(settings, typeof PINCLOCK_EM_CLOCK_DEFAULTS !== "undefined" ? PINCLOCK_EM_CLOCK_DEFAULTS : null);
    }
    let pos = "center";
    if (!custom) {
        pos = own.position_rotate === true && typeof rotCorner === "string" ? rotCorner : own.clock_position;
        if (typeof CLOCK_POSITIONS !== "undefined" && !CLOCK_POSITIONS[pos]) pos = "center";
    }
    return Object.assign({}, settings, own, {
        clock_style: REEL_CLOCK_STYLE, reel_theme: plateId,
        clock_position: pos || "center", position_rotate: false,
        reel_theme_cycle: false, reel_scene_cycle: false, videos_enabled: true,
    });
}

function reelCycleKind(settings, base) {
    const p = reelSetting(settings, "reel_theme_cycle") === true;
    const sc = reelSetting(settings, "reel_scene_cycle") === true;
    if (p && sc) return "both";
    const b = base || reelThemeId(settings);
    const isScene = !!(REEL_THEMES[b] && REEL_THEMES[b].scene);
    if (isScene) return sc ? "scenes" : null;
    return p ? "plates" : null;
}
function reelCycleOrder(settings) {
    const ex = reelSetting(settings, "reel_cycle_excluded");
    let out = !Array.isArray(ex) || !ex.length ? REEL_THEME_ORDER : REEL_THEME_ORDER.filter((id) => ex.indexOf(id) === -1);
    const kind = settings && settings.em_scene_kind;
    if (kind === "em" || kind === "ss") {
        out = out.filter((id) => {
            const sc = REEL_THEMES[id] && REEL_THEMES[id].scene;
            return !sc || (typeof reelSceneIsSS === "function" && reelSceneIsSS(sc, settings)) === (kind === "ss");
        });
    }
    return out;
}

function reelDisplayName(raw) {
    const s = typeof raw === "string" ? raw.trim() : "";
    if (!s) return "";
    try {
        const fn = typeof decodeVideoName === "function" ? decodeVideoName : (typeof window !== "undefined" ? window.decodeVideoName : null);
        const out = typeof fn === "function" ? String(fn(s)).trim() : s;
        return (out || s).slice(0, 48);
    } catch (e) {
        return s.slice(0, 48);
    }
}

const REEL_FACEPLATE_URL = "/api/reel-faceplates/";
const REEL_IMAGE_THEME_PREFIX = "img:";
const REEL_IMAGE_PAD = 0.32;
const _reelImages = {};
let _reelImageListKey = "";

let _reelImageListRef = null;
function reelSyncImageThemes(list) {
    if (list === _reelImageListRef) return;
    _reelImageListRef = list;
    const clean = (Array.isArray(list) ? list : []).filter((p) => p && /^[0-9a-f]{8}$/.test(String(p.id)) && !p.hidden);
    const key = JSON.stringify(clean.map((p) => [p.id, p.v, p.name, p.mode, p.frame, p.colors, !!p.stock]));
    if (key === _reelImageListKey) return;
    _reelImageListKey = key;
    for (let i = REEL_THEME_ORDER.length - 1; i >= 0; i--) {
        if (String(REEL_THEME_ORDER[i]).indexOf(REEL_IMAGE_THEME_PREFIX) === 0) {
            delete REEL_THEMES[REEL_THEME_ORDER[i]];
            REEL_THEME_ORDER.splice(i, 1);
        }
    }
    clean.forEach((p, n) => {
        const id = REEL_IMAGE_THEME_PREFIX + p.id;
        const name = reelDisplayName(p.name) || "My image " + (n + 1);
        const asTheme = p.mode === "theme";
        REEL_THEMES[id] = Object.assign({}, REEL_THEMES.classic, { deco: "none" }, reelImageColors(p.colors, asTheme), {
            label: name, userId: p.id, userKind: p.stock ? "stockplate" : "faceplate",
        }, asTheme ? {} : { imageId: p.id, imageV: p.v, deco: "none", imageFrame: p.frame !== false });
        REEL_THEME_ORDER.push(id);
        if (!asTheme) reelThemeImage(REEL_THEMES[id]);
    });
}

const REEL_IMAGE_COLOR_KEYS = ["colon", "dateText", "lampOnCenter", "lampOnEdge", "lampOnGlow", "lampOnText", "lampOff", "lampOffText"];
const REEL_COLOR_RE = /^(#[0-9a-fA-F]{3}|#[0-9a-fA-F]{6}|rgba?\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*(,\s*(0|1|0?\.\d+|1\.0+)\s*)?\))$/;
function reelImageColors(colors, full) {
    const out = {};
    if (!colors || typeof colors !== "object") return out;
    const isColor = (v) => typeof v === "string" && REEL_COLOR_RE.test(v);
    const rims = (v) => Array.isArray(v) && v.length <= 3 &&
        v.every((r) => r && isColor(r.c) && Number(r.w) > 0 && Number(r.w) <= 0.1);
    REEL_IMAGE_COLOR_KEYS.concat(full ? ["recess"] : []).forEach((k) => { if (isColor(colors[k])) out[k] = colors[k]; });
    ["windowRims"].concat(full ? ["plateRims"] : []).forEach((k) => {
        if (rims(colors[k])) out[k] = colors[k].map((r) => ({ c: r.c, w: Number(r.w) }));
    });
    if (full && Array.isArray(colors.plate) && colors.plate.length === 2 && colors.plate.every(isColor)) out.plate = colors.plate.slice();
    if (full && REEL_DECOS.indexOf(colors.deco) !== -1) {
        out.deco = colors.deco;
        ["decoColor", "decoColor2", "decoColor3"].forEach((k) => { if (isColor(colors[k])) out[k] = colors[k]; });
        const py = Number(colors.padY);
        if (isFinite(py) && py >= 0 && py <= 0.3) out.padY = py;
    }
    return out;
}

function reelThemeImage(pal) {
    if (!pal || !pal.imageId || typeof Image === "undefined") return null;
    let e = _reelImages[pal.imageId];
    if (!e || e.v !== pal.imageV) {
        const img = new Image();
        e = _reelImages[pal.imageId] = { v: pal.imageV, img, ready: false };
        const entry = e;
        img.onload = () => {
            entry.ready = true;
            if (typeof reelOnImageLoaded === "function") { try { reelOnImageLoaded(); } catch (err) {   } }
        };
        img.onerror = () => { entry.ready = false; };
        img.src = REEL_FACEPLATE_URL + pal.imageId + ".png?v=" + pal.imageV;
    }
    return e.ready ? e.img : null;
}

const REEL_IMAGE_FRAME = 0.03;
function reelDrawImagePlate(c, lay, img, pal) {
    const w = lay.w, h = lay.h, rad = lay.radius;
    const iw = img.naturalWidth || img.width, ih = img.naturalHeight || img.height;
    if (!(iw > 0 && ih > 0)) return;
    if (pal && pal.imageFrame === false) {
        const s0 = Math.max(w / iw, h / ih);
        c.save();
        reelRoundRectPath(c, 0, 0, w, h, rad);
        c.clip();
        c.drawImage(img, (w - iw * s0) / 2, (h - ih * s0) / 2, iw * s0, ih * s0);
        c.restore();
        const lw0 = Math.max(1, Math.round(lay.Hw * 0.014));
        reelRoundRectPath(c, lw0 / 2, lw0 / 2, w - lw0, h - lw0, Math.max(0, rad - lw0 / 2));
        c.strokeStyle = "rgba(0,0,0,0.6)";
        c.lineWidth = lw0;
        c.stroke();
        return;
    }
    const fw = Math.max(3, Math.round(lay.Hw * REEL_IMAGE_FRAME));
    const irad = Math.max(1, rad - fw * 0.6);
    const ix = fw, iy = fw, iwid = w - fw * 2, ihgt = h - fw * 2;

    c.save();
    reelRoundRectPath(c, 0, 0, w, h, rad);
    const body = c.createLinearGradient(0, 0, 0, h);
    body.addColorStop(0, "#f2f4f6");
    body.addColorStop(0.18, "#aab2bb");
    body.addColorStop(0.5, "#5b636c");
    body.addColorStop(0.82, "#9aa2ab");
    body.addColorStop(1, "#3c4248");
    c.fillStyle = body;
    c.fill();
    c.beginPath();
    reelRoundRectSub(c, 0, 0, w, h, rad);
    reelRoundRectSub(c, ix, iy, iwid, ihgt, irad);
    c.clip("evenodd");
    const bevel = c.createLinearGradient(0, 0, w * 0.35, h * 1.1);
    bevel.addColorStop(0, "rgba(255,255,255,0.55)");
    bevel.addColorStop(0.45, "rgba(255,255,255,0)");
    bevel.addColorStop(1, "rgba(0,0,0,0.45)");
    c.fillStyle = bevel;
    c.fillRect(0, 0, w, h);
    c.lineWidth = Math.max(1, fw * 0.12);
    c.strokeStyle = "rgba(255,255,255,0.35)";
    reelRoundRectPath(c, fw * 0.45, fw * 0.45, w - fw * 0.9, h - fw * 0.9, Math.max(1, rad - fw * 0.3));
    c.stroke();
    c.restore();

    const sc = Math.max(iwid / iw, ihgt / ih);
    const dw = iw * sc, dh = ih * sc;
    c.save();
    reelRoundRectPath(c, ix, iy, iwid, ihgt, irad);
    c.clip();
    c.drawImage(img, ix + (iwid - dw) / 2, iy + (ihgt - dh) / 2, dw, dh);
    const sh = Math.max(2, fw * 0.55);
    const st = c.createLinearGradient(0, iy, 0, iy + sh);
    st.addColorStop(0, "rgba(0,0,0,0.55)");
    st.addColorStop(1, "rgba(0,0,0,0)");
    c.fillStyle = st;
    c.fillRect(ix, iy, iwid, sh);
    const sl = c.createLinearGradient(ix, 0, ix + sh, 0);
    sl.addColorStop(0, "rgba(0,0,0,0.45)");
    sl.addColorStop(1, "rgba(0,0,0,0)");
    c.fillStyle = sl;
    c.fillRect(ix, iy, sh, ihgt);
    c.restore();

    const lw = Math.max(1, Math.round(fw * 0.14));
    reelRoundRectPath(c, ix, iy, iwid, ihgt, irad);
    c.strokeStyle = "rgba(0,0,0,0.75)";
    c.lineWidth = lw;
    c.stroke();
    c.save();
    reelRoundRectPath(c, ix - lw, iy - lw, iwid + lw * 2, ihgt + lw * 2, irad + lw);
    const lip = c.createLinearGradient(ix, iy, ix + iwid * 0.3, iy + ihgt);
    lip.addColorStop(0, "rgba(0,0,0,0)");
    lip.addColorStop(0.6, "rgba(0,0,0,0)");
    lip.addColorStop(1, "rgba(255,255,255,0.7)");
    c.strokeStyle = lip;
    c.lineWidth = Math.max(1, lw * 0.8);
    c.stroke();
    c.restore();
    if (pal && pal.lampOnEdge) {
        reelRoundRectPath(c, ix - lw * 2.2, iy - lw * 2.2, iwid + lw * 4.4, ihgt + lw * 4.4, irad + lw * 2.2);
        c.strokeStyle = pal.lampOnEdge;
        c.lineWidth = Math.max(1, lw * 0.7);
        c.stroke();
    }
    reelRoundRectPath(c, 0.5, 0.5, w - 1, h - 1, rad);
    c.strokeStyle = "rgba(0,0,0,0.7)";
    c.lineWidth = 1;
    c.stroke();
}

function reelRoundRectSub(c, x, y, w, h, r) {
    r = Math.max(0, Math.min(r, w / 2, h / 2));
    c.moveTo(x + r, y);
    c.arcTo(x + w, y, x + w, y + h, r);
    c.arcTo(x + w, y + h, x, y + h, r);
    c.arcTo(x, y + h, x, y, r);
    c.arcTo(x, y, x + w, y, r);
    c.closePath();
}


const REEL_WINDOW_H_SCALE = 1.5;
const REEL_WINDOW_HALF_DEG = 32;
const REEL_PITCH_DEG = 36;
const REEL_GLYPH_FRAC = 0.7;
const REEL_SIDE_MARGIN_FRAC = 0.34;
const REEL_SEPARATOR = 0.055;
const REEL_RECESS_PAD = 0.045;
const REEL_COLON_GAP = 0.3;
const REEL_PLATE_PAD = 0.14;
const REEL_FRAMELESS_PAD = 0.06;
const REEL_SECONDS_WIDTH_SCALE = 0.72;
const REEL_LAMP_H = 0.4, REEL_LAMP_GAP = 0.09, REEL_LAMP_LEFT_GAP = 0.16;
const REEL_LAMP_TEXT = 0.62;
const REEL_LAMP_PAD_X = 0.2;
const REEL_DATE_PX = 0.27, REEL_DATE_GAP = 0.1;
const REEL_DATE_WORST = "Wednesday  Sep 30";


const REEL_STEP_MS = 260;
const REEL_TRAVEL_FRAC = 0.72;
const REEL_OVERSHOOT = 0.07;
const REEL_RIPPLE_MS = Math.round(REEL_STEP_MS * 0.6);
const REEL_STALE_MS = 1500;
const REEL_LIVE_SLICE_PX = 5, REEL_LIVE_SLICES_MIN = 8, REEL_LIVE_SLICES_MAX = 24;
const REEL_REST_SLICE_PX = 2, REEL_REST_SLICES_MIN = 16, REEL_REST_SLICES_MAX = 72;

const REEL_DEG = Math.PI / 180;

function reelStepCurve(t) {
    if (t <= 0) return 0;
    if (t >= 1) return 1;
    const peak = 1 + REEL_OVERSHOOT;
    if (t < REEL_TRAVEL_FRAC) {
        const u = t / REEL_TRAVEL_FRAC;
        const e = u < 0.5 ? 2 * u * u : 1 - Math.pow(-2 * u + 2, 2) / 2;
        return e * peak;
    }
    const v = (t - REEL_TRAVEL_FRAC) / (1 - REEL_TRAVEL_FRAC);
    const e = 1 - (1 - v) * (1 - v);
    return peak - REEL_OVERSHOOT * e;
}

function reelMod(n, m) {
    return ((n % m) + m) % m;
}


const REEL_CYCLE_0_9 = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];
const REEL_CYCLE_0_5 = ["0", "1", "2", "3", "4", "5"];
const REEL_CYCLES = {
    h12_tens: ["0", "1"],
    h12_ones: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "1", "2"],
    h24_tens: ["0", "1", "2"],
    h24_ones: Array.from({ length: 24 }, (_, i) => String(i % 10)),
    tens: REEL_CYCLE_0_5,
    ones: REEL_CYCLE_0_9,
};

function reelRoles(is24h, showSeconds) {
    const roles = is24h ? ["h24_tens", "h24_ones"] : ["h12_tens", "h12_ones"];
    roles.push("tens", "ones");
    if (showSeconds) roles.push("tens", "ones");
    return roles;
}

function reelTargetIndexes(date, is24h, showSeconds) {
    const h = date.getHours(), m = date.getMinutes(), s = date.getSeconds();
    const out = [];
    if (is24h) {
        out.push(Math.floor(h / 10), h);
    } else {
        const h12 = h % 12 || 12;
        out.push(h12 >= 10 ? 1 : 0, h12 - 1);
    }
    out.push(Math.floor(m / 10), m % 10);
    if (showSeconds) out.push(Math.floor(s / 10), s % 10);
    return out;
}

function reelPlanSteps(current, target, cycleLengths, snapAll) {
    const n = target.map((t, i) => {
        const c = current[i];
        if (c === undefined || c === null) return -1;
        return reelMod(t - c, cycleLengths[i]);
    });
    const jump = snapAll || n.some((k) => k < 0 || k > 1);
    return n.map((k) => (k === 0 ? "none" : jump ? "snap" : "step"));
}

function reelFaces(roles, indexes) {
    return roles.map((r, i) => REEL_CYCLES[r][reelMod(indexes[i], REEL_CYCLES[r].length)]).join("");
}


function reelNewCanvas() {
    const canvas = document.createElement("canvas");
    const hiRes = typeof pinclockIsHighRes === "function" ? pinclockIsHighRes() : true;
    return { canvas, ctx: canvas.getContext("2d", hiRes ? { willReadFrequently: true } : undefined), key: null };
}

function reelPrepCanvas(slot, w, h) {
    w = Math.max(1, Math.ceil(w));
    h = Math.max(1, Math.ceil(h));
    if (slot.canvas.width !== w || slot.canvas.height !== h) {
        slot.canvas.width = w;
        slot.canvas.height = h;
    } else {
        slot.ctx.setTransform(1, 0, 0, 1, 0, 0);
        slot.ctx.clearRect(0, 0, w, h);
    }
    return slot.ctx;
}

function reelRoundRectPath(c, x, y, w, h, r) {
    r = Math.max(0, Math.min(r, w / 2, h / 2));
    c.beginPath();
    c.moveTo(x + r, y);
    c.arcTo(x + w, y, x + w, y + h, r);
    c.arcTo(x + w, y + h, x, y + h, r);
    c.arcTo(x, y + h, x, y, r);
    c.arcTo(x, y, x + w, y, r);
    c.closePath();
}


let _reelFontLoadStarted = false;

let _reelFontLastLoadMs = -Infinity;
function reelFontReady() {
    if (!TT_FONTS[REEL_FONT_ID] || typeof document === "undefined" || !document.fonts) return true;
    if (ttFontLoaded(REEL_FONT_ID)) return true;
    const t = Date.now();
    if (!_reelFontLoadStarted || t - _reelFontLastLoadMs > 2000) {
        _reelFontLoadStarted = true;
        _reelFontLastLoadMs = t;
        ensureTtFontLoaded(REEL_FONT_ID);
    }
    return false;
}

const _reelFontMetricsCache = {};
function reelFontMetrics(ctx, fontReady) {
    const key = REEL_FONT_ID + "|" + fontReady;
    if (_reelFontMetricsCache[key]) return _reelFontMetricsCache[key];
    const ink = ttInkBox(ctx, "0123456789", 100, REEL_FONT_ID);
    const inkRatio = ink ? (ink.bottom - ink.top) / 100 : 0.72;
    let maxW = 0;
    ctx.save();
    ctx.font = ttFontStringPx(100, REEL_FONT_ID);
    REEL_CYCLE_0_9.forEach((d) => { maxW = Math.max(maxW, ctx.measureText(d).width); });
    ctx.restore();
    const m = { inkRatio: inkRatio > 0.2 ? inkRatio : 0.72, inkTop: ink ? ink.top / 100 : 0.14, digitW: (maxW || 55) / 100 };
    if (fontReady) _reelFontMetricsCache[key] = m;
    return m;
}


function reelDrumGeometry(Hw) {
    const halfRad = REEL_WINDOW_HALF_DEG * REEL_DEG;
    const pitchRad = REEL_PITCH_DEG * REEL_DEG;
    const R = (Hw / 2) / Math.sin(halfRad);
    const faceH = R * pitchRad;
    return { Hw, R, faceH, pitchRad, glyphH: faceH * REEL_GLYPH_FRAC };
}

function reelComputeLayout(ctx, px, opts) {
    const fontReady = opts.fontReady !== false;
    const fm = reelFontMetrics(ctx, fontReady);
    const Hw = Math.max(12, Math.round(px * REEL_WINDOW_H_SCALE));
    const main = reelDrumGeometry(Hw);

    function reelWidth(g) {
        const fontPx = g.glyphH / fm.inkRatio;
        return Math.round(fm.digitW * fontPx + g.faceH * REEL_SIDE_MARGIN_FRAC);
    }
    const th = REEL_THEMES[opts.themeId] || REEL_THEMES[REEL_THEME_ORDER[0]];
    const faceplate = opts.faceplate || (th.imageId ? true : null);
    const framed = !th.frameless || !!faceplate;
    const extendW = opts.extend && framed ? Math.round(Hw * REEL_EXTEND_PAD) : 0;
    const padX = (faceplate ? REEL_IMAGE_PAD : REEL_PLATE_PAD + (th.padX || 0)) + extendW / Hw;
    const padY = faceplate ? REEL_IMAGE_PAD : REEL_PLATE_PAD + (th.padY || 0);
    const plateX = Math.round(Hw * (framed ? padX : REEL_FRAMELESS_PAD));
    const plateY = Math.round(Hw * (framed ? padY : REEL_FRAMELESS_PAD));
    const plate = plateY;
    const recess = Math.max(2, Math.round(Hw * REEL_RECESS_PAD));
    const top = plateY + recess;
    const roles = reelRoles(opts.is24h, opts.showSeconds && !opts.secondsLamps);

    const reels = [];
    const groups = [];
    const colons = [];
    let x = plateX;
    function addGroup(roleList, g, y, widthScale) {
        const sx = widthScale || 1;
        const w = Math.round(reelWidth(g) * sx);
        const sep = Math.max(1, Math.round(g.Hw * REEL_SEPARATOR));
        const gx = x;
        x += recess;
        roleList.forEach((role, i) => {
            if (i) x += sep;
            reels.push({ role, x, y, w, h: g.Hw, geo: g, fontPx: g.glyphH / fm.inkRatio, glyphScaleX: sx });
            x += w;
        });
        x += recess;
        groups.push({ x: gx, y: y - recess, w: x - gx, h: g.Hw + recess * 2, r: Math.round(recess * 1.6) });
    }
    addGroup(roles.slice(0, 2), main, top);
    colons.push({ x: x + Math.round(Hw * REEL_COLON_GAP / 2), cy: top + Hw / 2, r: Math.max(1.5, Hw * 0.045), spread: Hw * 0.2 });
    x += Math.round(Hw * REEL_COLON_GAP);
    addGroup(roles.slice(2, 4), main, top);
    const secLamps = [];
    if (opts.showSeconds && opts.secondsLamps) {
        x += Math.round(Hw * REEL_COLON_GAP);
        const sw = Math.round(reelWidth(main) * REEL_SECONDS_WIDTH_SCALE);
        const sep = Math.max(1, Math.round(Hw * REEL_SEPARATOR));
        const pw = recess * 2 + sw * 2 + sep, ph = Hw + recess * 2, py = top - recess;
        const gap = Math.max(1, Math.round(Hw * REEL_SEC_LAMP_GAP));
        const d = Math.max(4, Math.floor(Math.min((ph - gap * 2.5) / 3.5, (pw - gap) / 2)));
        const step = (ph - d) / 2.5;
        const dx = Math.min(pw - d, Math.round(d * REEL_SEC_LAMP_DX));
        const left = x + Math.round((pw - d - dx) / 2);
        REEL_SEC_LAMP_TEXT.forEach((text, i) => {
            const col = i % 2, row = Math.floor(i / 2);
            secLamps.push({ text, i, round: true, x: left + col * dx, y: Math.round(py + (row + col / 2) * step), w: d, h: d });
        });
        x += pw;
    } else if (opts.showSeconds) {
        colons.push({ x: x + Math.round(Hw * REEL_COLON_GAP / 2), cy: top + Hw / 2, r: Math.max(1.5, Hw * 0.045), spread: Hw * 0.2 });
        x += Math.round(Hw * REEL_COLON_GAP);
        addGroup(roles.slice(4, 6), main, top, opts.smallSeconds === false ? 1 : REEL_SECONDS_WIDTH_SCALE);
    }
    const lamps = [];
    if (opts.showAmpm) {
        x += Math.round(Hw * REEL_LAMP_LEFT_GAP);
        const lh = Math.round(Hw * REEL_LAMP_H), gap = Math.round(Hw * REEL_LAMP_GAP);
        ctx.save();
        ctx.font = ttFontStringPx(Math.round(lh * REEL_LAMP_TEXT), REEL_FONT_ID);
        const textW = Math.max(ctx.measureText("AM").width, ctx.measureText("PM").width);
        ctx.restore();
        const lw = Math.round(textW + lh * REEL_LAMP_PAD_X * 2);
        const ly = Math.round(top + (Hw - (lh * 2 + gap)) / 2);
        lamps.push({ text: "AM", x, y: ly, w: lw, h: lh }, { text: "PM", x, y: ly + lh + gap, w: lw, h: lh });
        x += lw;
    }
    x += plateX;
    let width = x;
    let height = top + Hw + recess + plateY;
    let date = null;
    if (opts.showDate) {
        const dpx = Math.max(8, Math.round(Hw * REEL_DATE_PX));
        ctx.save();
        ctx.font = ttFontStringPx(dpx, REEL_FONT_ID);
        const worstW = ctx.measureText(REEL_DATE_WORST).width;
        ctx.restore();
        width = Math.max(width, Math.ceil(worstW + plateX * 2));
        const dy = height - plate + Math.round(Hw * REEL_DATE_GAP);
        date = { px: dpx, y: dy };
        height = dy + Math.round(dpx * 1.15) + plate;
    }
    const shift = Math.round((width - x) / 2);
    if (shift > 0) {
        reels.forEach((r) => { r.x += shift; });
        groups.forEach((g) => { g.x += shift; });
        colons.forEach((c) => { c.x += shift; });
        lamps.forEach((l) => { l.x += shift; });
        secLamps.forEach((l) => { l.x += shift; });
    }
    reels.forEach((r) => { r.cycle = REEL_CYCLES[r.role]; });
    const wear = Math.max(0, Math.min(1, opts.wear || 0));
    const reg = wear > 0 ? Math.max(1, Hw * 0.008) * Math.min(1, wear * 2) : 0;
    reels.forEach((r, i) => {
        r.regDx = Math.round((reelRand(i * 17 + 5) * 2 - 1) * reg);
        r.regDy = Math.round((reelRand(i * 17 + 9) * 2 - 1) * reg * 0.6);
    });
    return { w: width, h: height, Hw, reels, groups, colons, lamps, secLamps, date, radius: Math.round(Hw * 0.12), fm, framed, themeId: opts.themeId,
        plateX, plateY,
        faceplate: faceplate && typeof faceplate === "object" ? faceplate : null,
        extend: extendW ? opts.extend : null, extendW,
        dir: opts.dir === -1 ? -1 : 1, wear, backlight: opts.backlight === undefined ? 1 : Math.max(0, opts.backlight) };
}

function reelSceneIsSS(scene, settings) {
    const f = settings && settings.backglass_clock_force;
    if (f === "ss") return true;
    if (f === "em") return false;
    return !!(scene && scene.ss);
}

function reelDrawWindowRims(c, x, y, w, h, r, lay, pal) {
    const rims = pal.windowRims || [];
    let out = 0;
    rims.forEach((rim) => {
        const lw = Math.max(1, Math.round(lay.Hw * rim.w));
        out += lw;
        reelRoundRectPath(c, x - out + lw / 2, y - out + lw / 2, w + (out - lw / 2) * 2, h + (out - lw / 2) * 2, r + out);
        c.strokeStyle = rim.c;
        c.lineWidth = lw;
        c.stroke();
    });
    return out;
}

function reelSsInnerBox(lay) {
    const parts = lay.groups.concat(lay.lamps, lay.secLamps);
    if (!parts.length) return { x: lay.plateX, y: lay.plateY, w: lay.w - lay.plateX * 2, h: lay.h - lay.plateY * 2 };
    const rim = 0;
    let x0 = Math.min(...parts.map((q) => q.x)), x1 = Math.max(...parts.map((q) => q.x + q.w));
    let y0 = Math.min(...parts.map((q) => q.y)), y1 = Math.max(...parts.map((q) => q.y + q.h));
    if (lay.date) y1 = Math.max(y1, lay.date.y + Math.round(lay.date.px * 1.15));
    x0 = Math.max(0, x0 - rim); y0 = Math.max(0, y0 - rim);
    x1 = Math.min(lay.w, x1 + rim); y1 = Math.min(lay.h, y1 + rim);
    return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
}

function reelBankSize(ctx, px, opts) {
    const fontReady = (() => { try { return reelFontReady(); } catch (e) { return true; } })();
    const lay = reelComputeLayout(ctx, px, { ...opts, fontReady });
    return { w: lay.w, h: lay.h };
}


const reelState = {
    layoutKey: null,
    layout: null,
    reels: [],
    lastDrawMs: -Infinity,
    animEndMs: 0,
    shownKey: null,
    back: null, front: null, rest: null,
    strips: [], windows: [],
    lastStepMs: -Infinity,
    dipDepth: 0,
    secLit: "",
    secHeld: false,
    hhmmOnly: false,
    blank: null, scoreScratch: null,
    flicker: null,
    nextFlickerMs: null,
};

function reelTimeKey(settings, date) {
    const is24h = settings.clock_format === "24h";
    if (reelState.hhmmOnly) return (is24h ? "24|" : "12|") + reelTargetIndexes(date, is24h, false).join(",");
    if (reelSecondsAsLamps(settings)) {
        return (is24h ? "24|" : "12|") + reelTargetIndexes(date, is24h, false).join(",") + "|" +
            reelSecondsLampMask(date.getSeconds(), reelSetting(settings, "reel_seconds_lamp_mode"));
    }
    return (is24h ? "24|" : "12|") + reelTargetIndexes(date, is24h, settings.show_seconds !== false).join(",");
}

function reelThrottled() {
    return typeof systemStatus !== "undefined" && !!(systemStatus && systemStatus.sfx_thermal_throttled);
}

function isReelAnimating(settings) {
    if (!settings || settings.clock_style !== REEL_CLOCK_STYLE) return false;
    if (reelThrottled()) return false;
    const now = performance.now();
    if (now < reelState.animEndMs) return true;
    if (reelState.secHeld) return true;
    if (typeof ssWantsFrame === "function" && ssWantsFrame(now)) return true;
    if (reelState.flicker && now < reelState.flicker.end) return true;
    if (reelState.nextFlickerMs !== null && now >= reelState.nextFlickerMs &&
        now - reelState.lastDrawMs < REEL_STALE_MS && reelSetting(settings, "reel_random_flicker") === true) return true;
    if (reelState.shownKey !== null && now - reelState.lastDrawMs < REEL_STALE_MS &&
        reelTimeKey(settings, new Date()) !== reelState.shownKey) return true;
    return false;
}


function reelRand(seed) {
    let x = Math.sin(seed * 12.9898 + 78.233) * 43758.5453;
    return x - Math.floor(x);
}

const REEL_BURST_DEPTH = 0.15;
function reelBurstInset(Hw) {
    return Math.round(Hw * REEL_BURST_DEPTH * 0.95);
}

function reelDrawFlames(c, x0, w, base, Hw, h0, h1, outer, inner, seed) {
    const n = Math.max(6, Math.round(w / (Hw * 0.12)));
    const fw = (w / n) * 1.5;
    for (let pass = 0; pass < 2; pass++) {
        for (let i = 0; i < n; i++) {
            const fx = x0 + ((i + 0.5) * w) / n;
            const fh = Hw * (h0 + reelRand(i * 5 + seed) * h1) * (pass ? 0.55 : 1);
            const ww = fw * (pass ? 0.5 : 1);
            c.beginPath();
            c.moveTo(fx - ww / 2, base);
            c.quadraticCurveTo(fx - ww * 0.55, base - fh * 0.55, fx + ww * 0.08, base - fh);
            c.quadraticCurveTo(fx + ww * 0.6, base - fh * 0.45, fx + ww / 2, base);
            c.closePath();
            c.fillStyle = pass ? inner : outer;
            c.fill();
        }
    }
}

function reelDrawPlate(c, lay, th) {
    const Hw = lay.Hw;
    let x0 = 0, y0 = 0, w = lay.w, h = lay.h, rad = lay.radius;

    if (th.deco === "burst") {
        const depth = Hw * REEL_BURST_DEPTH;
        const bx = depth / 2, by = depth / 2, bw = w - depth, bh = h - depth;
        const corners = [[bx, by], [bx + bw, by], [bx + bw, by + bh], [bx, by + bh]];
        const normals = [[0, -1], [1, 0], [0, 1], [-1, 0]];
        const step = Hw * 0.16;
        c.beginPath();
        for (let e = 0; e < 4; e++) {
            const [cx0, cy0] = corners[e];
            const [cx1, cy1] = corners[(e + 1) % 4];
            const [nx, ny] = normals[e];
            const pt = (px, py, first) => (first ? c.moveTo(px, py) : c.lineTo(px, py));
            pt(cx0, cy0, e === 0);
            const len = Math.hypot(cx1 - cx0, cy1 - cy0);
            const n = Math.max(2, Math.round(len / step));
            for (let j = 1; j < n * 2; j++) {
                const f = j / (n * 2);
                const off = (j % 2 ? -0.5 : 0.5) * depth;
                pt(cx0 + (cx1 - cx0) * f + nx * off, cy0 + (cy1 - cy0) * f + ny * off, false);
            }
        }
        c.closePath();
        c.fillStyle = th.decoColor;
        c.fill();
        c.strokeStyle = th.decoColor2;
        c.lineWidth = Math.max(1, Hw * 0.008);
        c.stroke();
        x0 = y0 = reelBurstInset(Hw);
        w -= x0 * 2;
        h -= y0 * 2;
        rad = Math.round(Hw * 0.06);
    }

    const g = c.createLinearGradient(0, y0, 0, y0 + h);
    g.addColorStop(0, th.plate[0]);
    g.addColorStop(1, th.plate[1]);
    reelRoundRectPath(c, x0 + 0.5, y0 + 0.5, w - 1, h - 1, rad);
    c.fillStyle = g;
    c.fill();

    c.save();
    reelRoundRectPath(c, x0, y0, w, h, rad);
    c.clip();
    if (th.deco === "stars") {
        const count = Math.round((w * h) / (Hw * Hw) * 16);
        for (let i = 0; i < count; i++) {
            const sx = x0 + reelRand(i * 3 + 1) * w, sy = y0 + reelRand(i * 3 + 2) * h;
            const r = Hw * (0.004 + reelRand(i * 3 + 3) * 0.009);
            c.globalAlpha = 0.45 + reelRand(i + 99) * 0.55;
            c.fillStyle = th.decoColor;
            c.beginPath();
            c.arc(sx, sy, r, 0, Math.PI * 2);
            c.fill();
        }
        c.globalAlpha = 1;
        c.fillStyle = th.decoColor2;
        const sparkles = Math.max(3, Math.round(count / 14));
        for (let i = 0; i < sparkles; i++) {
            const sx = x0 + reelRand(i * 7 + 500) * w, sy = y0 + reelRand(i * 7 + 501) * h;
            const a = Hw * (0.03 + reelRand(i * 7 + 502) * 0.03), b = a * 0.22;
            c.beginPath();
            c.moveTo(sx, sy - a); c.lineTo(sx + b, sy - b); c.lineTo(sx + a, sy); c.lineTo(sx + b, sy + b);
            c.lineTo(sx, sy + a); c.lineTo(sx - b, sy + b); c.lineTo(sx - a, sy); c.lineTo(sx - b, sy - b);
            c.closePath();
            c.fill();
        }
    } else if (th.deco === "chevrons") {
        const t = Hw * 0.085, gap = Hw * 0.06, span = h * 0.32, cy = y0 + h / 2, tipD = Hw * 0.17;
        const rimW = (th.plateRims || []).reduce((a, r) => a + Math.max(1, Math.round(Hw * r.w)), 0);
        [1, -1].forEach((dir) => {
            for (let k = 0; k < 2; k++) {
                const base = dir > 0 ? x0 + rimW + Hw * 0.07 + k * (t + gap) : x0 + w - rimW - Hw * 0.07 - k * (t + gap);
                const tip = base + dir * tipD;
                c.beginPath();
                c.moveTo(base, cy - span);
                c.lineTo(base + dir * t, cy - span);
                c.lineTo(tip + dir * t, cy);
                c.lineTo(base + dir * t, cy + span);
                c.lineTo(base, cy + span);
                c.lineTo(tip, cy);
                c.closePath();
                c.fillStyle = th.decoColor;
                c.fill();
            }
        });
    } else if (th.deco === "modband") {
        const band = Math.round(Hw * 0.11);
        c.fillStyle = th.decoColor;
        c.fillRect(x0, y0 + h - band, w, band);
        c.fillRect(x0, y0 + Math.round(Hw * 0.07), w, Math.max(1, Math.round(Hw * 0.02)));
        c.fillStyle = th.decoColor2;
        c.fillRect(x0, y0 + h - band - Math.max(1, Math.round(Hw * 0.018)), w, Math.max(1, Math.round(Hw * 0.018)));
    } else if (th.deco === "tiles") {
        const band = Hw * (REEL_PLATE_PAD + (th.padY || 0)) * 0.95;
        const tw = Hw * 0.16, rowH = band / 2;
        c.fillStyle = th.decoColor2;
        c.fillRect(x0, y0, w, band * 0.5);
        for (let k = 0; k < 2; k++) {
            const ty = y0 + k * rowH - rowH * 0.25, hh = rowH * 1.25;
            for (let tx = x0 - (k % 2 ? tw / 2 : 0) - tw; tx < x0 + w + tw; tx += tw) {
                c.beginPath();
                c.moveTo(tx, ty);
                c.lineTo(tx + tw, ty);
                c.lineTo(tx + tw, ty + hh - tw / 2);
                c.arc(tx + tw / 2, ty + hh - tw / 2, tw / 2, 0, Math.PI);
                c.closePath();
                c.fillStyle = th.decoColor;
                c.fill();
                c.strokeStyle = th.decoColor2;
                c.lineWidth = Math.max(1, Hw * 0.008);
                c.stroke();
            }
        }
    } else if (th.deco === "rink") {
        const band = Hw * 0.08, lw = Math.max(1, Hw * 0.018);
        c.fillStyle = th.decoColor;
        c.fillRect(x0, y0 + h - band, w, band);
        c.fillStyle = th.decoColor2;
        c.fillRect(x0, y0 + h - band - lw, w, lw);
        const endW = Hw * (REEL_PLATE_PAD + (th.padX || 0));
        const r = Math.min(endW * 0.36, (h - band) * 0.32), cy = y0 + (h - band) / 2;
        [x0 + endW * 0.5, x0 + w - endW * 0.5].forEach((cx) => {
            c.strokeStyle = th.decoColor2;
            c.lineWidth = lw;
            c.beginPath();
            c.arc(cx, cy, r, 0, Math.PI * 2);
            c.stroke();
            c.fillStyle = th.decoColor2;
            c.beginPath();
            c.arc(cx, cy, Math.max(1.5, r * 0.16), 0, Math.PI * 2);
            c.fill();
            [-1, 1].forEach((sx) => [-1, 1].forEach((sy) => {
                c.beginPath();
                c.moveTo(cx + sx * r * 0.35, cy + sy * r);
                c.lineTo(cx + sx * r * 0.35, cy + sy * r * 1.28);
                c.stroke();
            }));
        });
    } else if (th.deco === "ornate") {
        const ins = Hw * 0.075, len = Hw * 0.26, lw = Math.max(1, Hw * 0.016), curl = Hw * 0.035;
        c.strokeStyle = th.decoColor;
        c.fillStyle = th.decoColor;
        c.lineWidth = lw;
        [[1, 1], [-1, 1], [1, -1], [-1, -1]].forEach(([sx, sy]) => {
            const cx = sx > 0 ? x0 + ins : x0 + w - ins, cy = sy > 0 ? y0 + ins : y0 + h - ins;
            c.beginPath();
            c.moveTo(cx + sx * len, cy);
            c.lineTo(cx, cy);
            c.lineTo(cx, cy + sy * len * 0.6);
            c.stroke();
            c.beginPath();
            c.arc(cx + sx * (len + curl), cy, curl, 0, Math.PI * 2);
            c.stroke();
            c.beginPath();
            c.arc(cx + sx * curl * 1.2, cy + sy * curl * 1.2, curl * 0.5, 0, Math.PI * 2);
            c.fill();
        });
        const d = Hw * 0.04;
        [y0 + ins, y0 + h - ins].forEach((dy) => {
            c.beginPath();
            c.moveTo(x0 + w / 2, dy - d);
            c.lineTo(x0 + w / 2 + d * 1.6, dy);
            c.lineTo(x0 + w / 2, dy + d);
            c.lineTo(x0 + w / 2 - d * 1.6, dy);
            c.closePath();
            c.fill();
        });
    } else if (th.deco === "swirl") {
        const cx = x0 + w / 2, cy = y0 + h / 2, R = Math.hypot(w, h) / 2 + 2;
        const arms = 12, twist = 2.6 / R, steps = 28;
        for (let i = 0; i < arms; i += 2) {
            const a0 = (i * 2 * Math.PI) / arms, a1 = a0 + (2 * Math.PI) / arms;
            c.beginPath();
            c.moveTo(cx, cy);
            for (let k = 1; k <= steps; k++) {
                const r = (R * k) / steps;
                c.lineTo(cx + Math.cos(a0 + r * twist) * r, cy + Math.sin(a0 + r * twist) * r);
            }
            for (let k = steps; k >= 1; k--) {
                const r = (R * k) / steps;
                c.lineTo(cx + Math.cos(a1 + r * twist) * r, cy + Math.sin(a1 + r * twist) * r);
            }
            c.closePath();
            c.fillStyle = (i / 2) % 3 === 1 && th.decoColor3 ? th.decoColor3 : th.decoColor;
            c.fill();
        }
    } else if (th.deco === "lava") {
        const base = y0 + h;
        const peaks = [[0.12, 0.42], [0.5, 0.58], [0.88, 0.46]];
        peaks.forEach(([fx, fh]) => {
            const px = x0 + w * fx, top = base - h * fh, half = h * fh * 1.25;
            const glow = c.createRadialGradient(px, top, 0, px, top, Hw * 0.35);
            glow.addColorStop(0, th.decoColor2);
            glow.addColorStop(1, "rgba(255,106,26,0)");
            c.fillStyle = glow;
            c.fillRect(px - Hw * 0.35, top - Hw * 0.35, Hw * 0.7, Hw * 0.7);
            c.beginPath();
            c.moveTo(px - half, base);
            c.lineTo(px - Hw * 0.05, top);
            c.lineTo(px + Hw * 0.05, top);
            c.lineTo(px + half, base);
            c.closePath();
            c.fillStyle = th.decoColor;
            c.fill();
            c.beginPath();
            c.moveTo(px - Hw * 0.04, top);
            c.lineTo(px + Hw * 0.04, top);
            c.lineTo(px + Hw * 0.11, base);
            c.lineTo(px + Hw * 0.02, base);
            c.closePath();
            c.fillStyle = th.decoColor2;
            c.fill();
        });
    } else if (th.deco === "flames") {
        reelDrawFlames(c, x0, w, y0 + h + Hw * 0.02, Hw, 0.2, 0.2, th.decoColor, th.decoColor2, 3);
    } else if (th.deco === "flamedots") {
        const band = Hw * (REEL_PLATE_PAD + (th.padY || 0)) * 0.85;
        if (th.decoColor3) {
            c.fillStyle = th.decoColor3;
            c.fillRect(x0, y0, w, band);
        }
        const dots = Math.max(6, Math.round(w / (Hw * 0.3)));
        c.fillStyle = th.decoColor;
        for (let i = 0; i < dots; i++) {
            const rx = Hw * (0.07 + reelRand(i * 3 + 701) * 0.05), ry = rx * 0.62;
            const cx = x0 + reelRand(i * 3 + 702) * w;
            const cy = y0 + band + ry + reelRand(i * 3 + 703) * Math.max(1, h - band - ry * 2);
            c.beginPath();
            c.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
            c.fill();
        }
        reelDrawFlames(c, x0, w, y0 + band + Hw * 0.05, Hw, 0.13, 0.12, th.decoColor, th.decoColor2, 41);
    }
    c.restore();

    let acc = 0;
    const rims = th.plateRims || [];
    rims.forEach((rim) => {
        const rw = Math.max(1, Math.round(Hw * rim.w));
        reelRoundRectPath(c, x0 + acc + rw / 2, y0 + acc + rw / 2, w - (acc * 2 + rw), h - (acc * 2 + rw), Math.max(0, rad - acc - rw / 2));
        c.strokeStyle = rim.c;
        c.lineWidth = rw;
        c.stroke();
        acc += rw;
    });

    if (th.deco === "marquee" && rims.length) {
        const rw = Math.max(1, Math.round(Hw * rims[0].w));
        const inset = rw / 2, r = Math.max(1, rw * 0.26), step = Math.max(r * 4, Hw * 0.11);
        const ix = x0 + inset, iy = y0 + inset, iw = w - inset * 2, ih = h - inset * 2;
        const straight = Math.max(0, rad - inset);
        c.fillStyle = th.decoColor;
        const dot = (px, py) => { c.beginPath(); c.arc(px, py, r, 0, Math.PI * 2); c.fill(); };
        for (let px = ix + straight; px <= ix + iw - straight + 0.1; px += step) { dot(px, iy); dot(px, iy + ih); }
        for (let py = iy + straight + step; py <= iy + ih - straight - step + 0.1; py += step) { dot(ix, py); dot(ix + iw, py); }
    }
}

function reelDrawBack(lay, pal, ampm, dateStr) {
    const slot = reelState.back || (reelState.back = reelNewCanvas());
    const key = reelState.layoutKey + "|" + ampm + "|" + dateStr + "|" + (reelState.secLit || "");
    if (slot.key === key) return slot.canvas;
    const c = reelPrepCanvas(slot, lay.w, lay.h);
    slot.key = key;

    if (lay.faceplate) reelDrawImagePlate(c, lay, lay.faceplate, pal);
    else if (lay.framed) reelDrawPlate(c, lay, pal);
    if (lay.extend && lay.framed) reelDrawEnds(c, lay, pal);

    lay.groups.forEach((gr) => {
        let out = 0;
        (pal.windowRims || []).forEach((rim) => {
            const w = Math.max(1, Math.round(lay.Hw * rim.w));
            out += w;
            reelRoundRectPath(c, gr.x - out + w / 2, gr.y - out + w / 2, gr.w + (out - w / 2) * 2, gr.h + (out - w / 2) * 2, gr.r + out);
            c.strokeStyle = rim.c;
            c.lineWidth = w;
            c.stroke();
        });
        reelRoundRectPath(c, gr.x, gr.y, gr.w, gr.h, gr.r);
        c.fillStyle = pal.recess;
        c.fill();
        c.strokeStyle = "rgba(255,230,180,0.10)";
        c.lineWidth = 1;
        c.beginPath();
        c.moveTo(gr.x + gr.r, gr.y + gr.h + 0.5);
        c.lineTo(gr.x + gr.w - gr.r, gr.y + gr.h + 0.5);
        c.stroke();
    });

    const shadowed = (fn) => {
        c.save();
        if (!lay.framed) {
            c.shadowColor = "rgba(0,0,0,0.85)";
            c.shadowBlur = Math.max(2, lay.Hw * 0.05);
        }
        fn();
        c.restore();
    };

    shadowed(() => {
    c.fillStyle = lay.framed ? pal.colon : pal.drum;
    lay.colons.forEach((co) => {
        [-1, 1].forEach((s) => {
            c.beginPath();
            c.arc(co.x, co.cy + s * co.spread, co.r, 0, Math.PI * 2);
            c.fill();
        });
    });
    });

    const secLit = reelState.secLit || "";
    (lay.secLamps || []).map((l) => ({ l, lit: secLit.charAt(l.i) === "1" }))
        .concat(lay.lamps.map((l) => ({ l, lit: l.text.toLowerCase() === ampm }))).forEach(({ l, lit }) => {
        const r = l.round ? Math.min(l.w, l.h) / 2 : Math.max(2, Math.round(l.h * 0.22));
        c.save();
        reelRoundRectPath(c, l.x, l.y, l.w, l.h, r);
        if (lit) {
            const rg = c.createRadialGradient(l.x + l.w / 2, l.y + l.h / 2, 0, l.x + l.w / 2, l.y + l.h / 2, l.w * 0.6);
            rg.addColorStop(0, pal.lampOnCenter);
            rg.addColorStop(1, pal.lampOnEdge);
            c.shadowColor = pal.lampOnGlow;
            c.shadowBlur = Math.max(4, l.h * 0.5);
            c.fillStyle = rg;
        } else {
            c.fillStyle = pal.lampOff;
        }
        c.fill();
        c.restore();
        c.save();
        c.font = ttFontStringPx(Math.round(l.h * (l.round ? REEL_SEC_LAMP_TEXT_SCALE : REEL_LAMP_TEXT)), REEL_FONT_ID);
        c.textAlign = "center";
        c.textBaseline = "middle";
        c.fillStyle = lit ? pal.lampOnText : pal.lampOffText;
        c.fillText(l.text, l.x + l.w / 2, l.y + l.h / 2 + l.h * 0.04);
        c.restore();
    });

    if (lay.date && dateStr) {
        shadowed(() => {
            c.font = ttFontStringPx(lay.date.px, REEL_FONT_ID);
            c.textAlign = "center";
            c.textBaseline = "top";
            c.fillStyle = lay.framed ? pal.dateText : pal.drum;
            c.fillText(dateStr, lay.w / 2, lay.date.y);
        });
    }
    return slot.canvas;
}

function reelDrawFront(lay, pal) {
    const slot = reelState.front || (reelState.front = reelNewCanvas());
    if (slot.key === reelState.layoutKey) return slot.canvas;
    const c = reelPrepCanvas(slot, lay.w, lay.h);
    slot.key = reelState.layoutKey;

    lay.reels.forEach((r) => {
        const { x, y, w, h } = r;
        const v = c.createLinearGradient(0, y, 0, y + h);
        const steps = 8;
        for (let i = 0; i <= steps; i++) {
            const f = i / steps;
            const a = Math.abs(f * 2 - 1);
            const dark = 0.75 * Math.pow(a, 1.8) + (f < 0.18 ? 0.28 * (1 - f / 0.18) : 0);
            v.addColorStop(f, `rgba(0,0,0,${Math.min(0.92, dark).toFixed(3)})`);
        }
        c.fillStyle = v;
        c.fillRect(x, y, w, h);
        const k = lay.backlight;
        if (k > 0) {
            const bc = reelRgba(pal.backlight);
            const bl = c.createLinearGradient(0, y, 0, y + h * (0.45 + 0.15 * Math.min(k, 2)));
            bl.addColorStop(0, `rgba(${bc.r},${bc.g},${bc.b},${Math.min(0.75, bc.a * k).toFixed(3)})`);
            bl.addColorStop(1, `rgba(${bc.r},${bc.g},${bc.b},0)`);
            c.fillStyle = bl;
            c.fillRect(x, y, w, h);
            const hs = c.createRadialGradient(x + w / 2, y, 0, x + w / 2, y, Math.max(w, h * 0.6));
            hs.addColorStop(0, `rgba(${bc.r},${bc.g},${bc.b},${Math.min(0.5, 0.12 * k).toFixed(3)})`);
            hs.addColorStop(1, `rgba(${bc.r},${bc.g},${bc.b},0)`);
            c.fillStyle = hs;
            c.fillRect(x, y, w, h);
        }
        const sc = y + h * 0.36, sh = h * 0.1;
        const sp = c.createLinearGradient(0, sc - sh, 0, sc + sh);
        sp.addColorStop(0, "rgba(255,255,255,0)");
        sp.addColorStop(0.5, "rgba(255,255,255,0.13)");
        sp.addColorStop(1, "rgba(255,255,255,0)");
        c.fillStyle = sp;
        c.fillRect(x, sc - sh, w, sh * 2);
        const hz = c.createLinearGradient(x, 0, x + w, 0);
        hz.addColorStop(0, "rgba(0,0,0,0.30)");
        hz.addColorStop(0.08, "rgba(0,0,0,0)");
        hz.addColorStop(0.92, "rgba(0,0,0,0)");
        hz.addColorStop(1, "rgba(0,0,0,0.30)");
        c.fillStyle = hz;
        c.fillRect(x, y, w, h);
    });

    if (!lay.framed) return slot.canvas;
    c.save();
    if (pal.deco === "burst") {
        const ins = reelBurstInset(lay.Hw);
        reelRoundRectPath(c, ins, ins, lay.w - ins * 2, lay.h - ins * 2, Math.round(lay.Hw * 0.06));
    } else {
        reelRoundRectPath(c, 0, 0, lay.w, lay.h, lay.radius);
    }
    c.clip();
    const gl = c.createLinearGradient(lay.w * 0.15, 0, lay.w * 0.45, lay.h);
    gl.addColorStop(0, "rgba(255,255,255,0)");
    gl.addColorStop(0.45, "rgba(255,255,255,0.055)");
    gl.addColorStop(0.55, "rgba(255,255,255,0.055)");
    gl.addColorStop(1, "rgba(255,255,255,0)");
    c.fillStyle = gl;
    c.fillRect(0, 0, lay.w, lay.h);
    c.restore();
    return slot.canvas;
}

function reelRgba(color) {
    const s = String(color || "").trim();
    let m = s.match(/^rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*([\d.]+)\s*)?\)$/);
    if (m) return { r: +m[1], g: +m[2], b: +m[3], a: m[4] === undefined ? 1 : +m[4] };
    m = s.match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i);
    if (m) {
        const h = m[1].length === 3 ? m[1].split("").map((ch) => ch + ch).join("") : m[1];
        return { r: parseInt(h.slice(0, 2), 16), g: parseInt(h.slice(2, 4), 16), b: parseInt(h.slice(4, 6), 16), a: 0.2 };
    }
    return { r: 255, g: 190, b: 100, a: 0.2 };
}

function reelDrawFace(c, lay, pal, ri, face, posIdx, cy) {
    const r = lay.reels[ri];
    const faceH = r.geo.faceH, glyphH = r.geo.glyphH, wear = lay.wear;
    const top = cy - faceH / 2;
    const seed = ri * 1009 + posIdx * 31 + 7;
    if (wear > 0) {
        c.fillStyle = `rgba(120,85,30,${(0.08 * wear).toFixed(3)})`;
        c.fillRect(0, top, r.w, faceH);
        const gx = reelRand(seed + 1) * r.w, gy = top + reelRand(seed + 2) * faceH;
        const gr = faceH * (0.25 + reelRand(seed + 3) * 0.3);
        const g = c.createRadialGradient(gx, gy, 0, gx, gy, gr);
        g.addColorStop(0, `rgba(60,40,15,${(0.12 * wear).toFixed(3)})`);
        g.addColorStop(1, "rgba(60,40,15,0)");
        c.fillStyle = g;
        c.fillRect(0, top, r.w, faceH);
    }
    if (face !== " ") {
        const inkTop = lay.fm.inkTop * r.fontPx;
        const ty = cy - glyphH / 2 - inkTop + (r.regDy || 0);
        c.fillStyle = pal.ink;
        c.save();
        c.translate(r.w / 2 + (r.regDx || 0), 0);
        if (r.glyphScaleX && r.glyphScaleX !== 1) c.scale(r.glyphScaleX, 1);
        c.fillText(face, 0, ty);
        c.restore();
    }
    if (wear > 0) {
        const chips = Math.round(wear * 4 + reelRand(seed + 4) * wear * 3);
        c.fillStyle = pal.drum;
        for (let k = 0; k < chips; k++) {
            const px = r.w / 2 + (reelRand(seed + 10 + k * 3) - 0.5) * r.w * 0.55;
            const py = cy + (reelRand(seed + 11 + k * 3) - 0.5) * glyphH;
            const rad = Math.max(0.7, faceH * (0.008 + reelRand(seed + 12 + k * 3) * 0.018));
            c.beginPath();
            c.arc(px, py, rad, 0, Math.PI * 2);
            c.arc(px + rad * 0.9, py + rad * 0.4, rad * 0.7, 0, Math.PI * 2);
            c.fill();
        }
        const scuffs = Math.round(wear * 3);
        c.lineWidth = Math.max(0.6, faceH * 0.006);
        for (let k = 0; k < scuffs; k++) {
            const y = top + (0.15 + reelRand(seed + 40 + k) * 0.7) * faceH;
            const x0 = reelRand(seed + 50 + k) * r.w * 0.5, x1 = x0 + r.w * (0.25 + reelRand(seed + 60 + k) * 0.5);
            c.strokeStyle = k % 2 ? `rgba(255,255,255,${(0.16 * wear).toFixed(3)})` : `rgba(40,25,10,${(0.14 * wear).toFixed(3)})`;
            c.beginPath();
            c.moveTo(x0, y);
            c.lineTo(x1, y + (reelRand(seed + 70 + k) - 0.5) * faceH * 0.06);
            c.stroke();
        }
        const specks = Math.round(wear * 14);
        c.fillStyle = `rgba(30,20,10,${(0.35 * wear + 0.1).toFixed(3)})`;
        for (let k = 0; k < specks; k++) {
            c.fillRect(reelRand(seed + 100 + k) * r.w, top + reelRand(seed + 200 + k) * faceH, 1, 1);
        }
    }
}

function reelStrip(i, lay, pal, k0) {
    const r = lay.reels[i];
    const L = r.cycle.length;
    k0 = reelMod(k0, L);
    const slot = reelState.strips[i] || (reelState.strips[i] = reelNewCanvas());
    const key = reelState.layoutKey + "|" + k0;
    if (slot.key === key) return slot.canvas;
    const faceH = r.geo.faceH;
    const c = reelPrepCanvas(slot, r.w, faceH * 5);
    slot.key = key;
    c.fillStyle = pal.drum;
    c.fillRect(0, 0, r.w, faceH * 5);
    c.font = ttFontStringPx(r.fontPx, REEL_FONT_ID);
    c.textAlign = "center";
    c.textBaseline = "top";
    for (let s = -2; s <= 2; s++) {
        const posIdx = reelMod(k0 + lay.dir * s, L);
        reelDrawFace(c, lay, pal, i, r.cycle[posIdx], posIdx, (s + 2.5) * faceH);
    }
    return slot.canvas;
}

function reelDrawDrum(dst, ox, oy, i, lay, pal, k0, p, slices) {
    const r = lay.reels[i];
    const strip = reelStrip(i, lay, pal, k0);
    const { R, faceH, pitchRad, Hw } = r.geo;
    const half = Hw / 2;
    const center = lay.dir * p;
    const stripH = faceH * 5;
    for (let s = 0; s < slices; s++) {
        const y0 = -half + (Hw * s) / slices;
        const y1 = -half + (Hw * (s + 1)) / slices;
        const e0 = center + Math.asin(Math.max(-1, Math.min(1, y0 / R))) / pitchRad;
        const e1 = center + Math.asin(Math.max(-1, Math.min(1, y1 / R))) / pitchRad;
        let sy0 = (e0 + 2.5) * faceH, sy1 = (e1 + 2.5) * faceH;
        sy0 = Math.max(0, Math.min(stripH - 0.01, sy0));
        sy1 = Math.max(sy0 + 0.01, Math.min(stripH, sy1));
        const dy0 = Math.round(y0 + half), dy1 = Math.round(y1 + half);
        if (dy1 <= dy0) continue;
        dst.drawImage(strip, 0, sy0, r.w, sy1 - sy0, ox + r.x, oy + r.y + dy0, r.w, dy1 - dy0);
    }
}

function reelSliceCount(Hw, perPx, min, max) {
    return Math.max(min, Math.min(max, Math.round(Hw / perPx)));
}

function reelRestWindow(i, lay, pal, idx) {
    const r = lay.reels[i];
    const slot = reelState.windows[i] || (reelState.windows[i] = reelNewCanvas());
    idx = reelMod(idx, r.cycle.length);
    const key = reelState.layoutKey + "|" + idx;
    if (slot.key === key) return slot.canvas;
    const c = reelPrepCanvas(slot, r.w, r.h);
    slot.key = key;
    reelDrawDrum(c, -r.x, -r.y, i, lay, pal, idx, 0,
        reelSliceCount(r.h, REEL_REST_SLICE_PX, REEL_REST_SLICES_MIN, REEL_REST_SLICES_MAX));
    return slot.canvas;
}

function reelRestBank(lay, pal, ampm, dateStr) {
    const slot = reelState.rest || (reelState.rest = reelNewCanvas());
    const idxs = reelState.reels.map((s) => s.idx).join(",");
    const key = reelState.layoutKey + "|" + ampm + "|" + dateStr + "|" + (reelState.secLit || "") + "|" + idxs;
    if (slot.key === key) return slot.canvas;
    const back = reelDrawBack(lay, pal, ampm, dateStr);
    const front = reelDrawFront(lay, pal);
    const wins = lay.reels.map((r, i) => reelRestWindow(i, lay, pal, reelState.reels[i].idx));
    const c = reelPrepCanvas(slot, lay.w, lay.h);
    slot.key = key;
    c.drawImage(back, 0, 0);
    lay.reels.forEach((r, i) => c.drawImage(wins[i], r.x, r.y));
    c.drawImage(front, 0, 0);
    return slot.canvas;
}


const REEL_STEPPER_STEP_MS = 120;
const REEL_SPIN_MS = 1500;
const REEL_DIP_MS = 100, REEL_DIP_DEPTH = 0.32;

function reelSpinSteps(u, n) {
    if (u <= 0 || n <= 0) return 0;
    if (u >= 1) return n;
    if (u < 0.88) {
        const v = u / 0.88;
        return (v < 0.5 ? 2 * v * v : 1 - Math.pow(-2 * v + 2, 2) / 2) * (n + REEL_OVERSHOOT);
    }
    const v = (u - 0.88) / 0.12;
    return n + REEL_OVERSHOOT * (1 - v) * (1 - v);
}

function reelAnimPos(a, now) {
    const e = now - a.t0;
    if (e <= 0) return 0;
    if (e >= a.dur) return a.n;
    if (a.mode === "spin") return reelSpinSteps(e / a.dur, a.n);
    if (a.mode === "stepper") {
        const ds = a.dur / a.n;
        const i = Math.min(a.n - 1, Math.floor(e / ds));
        return i + reelStepCurve((e - i * ds) / ds);
    }
    return reelStepCurve(e / a.dur) * a.n;
}

function reelAnimDue(a, now) {
    const e = now - a.t0;
    if (e < 0) return 0;
    if (a.mode === "spin") return e >= a.dur * 0.88 ? 1 : 0;
    if (a.mode === "stepper") return Math.min(a.n, Math.floor(e / (a.dur / a.n)) + 1);
    return 1;
}



function reelUpdateState(lay, date, is24h, showSeconds, now, snapAll, opts, onStep) {
    const target = reelTargetIndexes(date, is24h, showSeconds);
    const lengths = lay.reels.map((r) => r.cycle.length);
    reelState.reels.forEach((s, i) => {
        if (!s.anim) return;
        const due = reelAnimDue(s.anim, now);
        while (s.anim.fired < due) { s.anim.fired++; if (onStep) onStep(i); }
        if (now >= s.anim.t0 + s.anim.dur) {
            s.idx = reelMod(s.anim.from + s.anim.n, lengths[i]);
            s.anim = null;
        }
    });
    const current = reelState.reels.map((s, i) => (s.anim ? reelMod(s.anim.from + s.anim.n, lengths[i]) : s.idx));
    const plan = reelPlanSteps(current, target, lengths, snapAll);
    const topOfHour = !snapAll && opts.flourish !== "off" && plan[3] === "step" && target[3] === 0 && target[2] === 0;
    let order = 0;
    for (let i = plan.length - 1; i >= 0; i--) {
        const s = reelState.reels[i];
        const land = () => { if (s.anim) { s.idx = reelMod(s.anim.from + s.anim.n, lengths[i]); s.anim = null; } };
        if (plan[i] === "snap") {
            s.anim = null;
            s.idx = target[i];
        } else if (topOfHour && i <= 3) {
            land();
            const n = lengths[i] + (plan[i] === "step" ? 1 : 0);
            const dur = opts.flourish === "spin" ? REEL_SPIN_MS : n * REEL_STEPPER_STEP_MS;
            s.anim = { from: s.idx, n, t0: now + order * REEL_RIPPLE_MS, dur, mode: opts.flourish, fired: 0 };
            order++;
        } else if (plan[i] === "step") {
            land();
            const stepMs = opts.stepMs || REEL_STEP_MS;
            s.anim = { from: s.idx, n: 1, t0: now + order * Math.round(stepMs * 0.6), dur: stepMs, mode: "step", fired: 0 };
            order++;
        }
    }
    let end = 0;
    reelState.reels.forEach((s) => { if (s.anim) end = Math.max(end, s.anim.t0 + s.anim.dur); });
    if (opts.dip) end = Math.max(end, reelState.lastStepMs + REEL_DIP_MS);
    reelState.animEndMs = end;
}

function reelPositions(lay, now) {
    return reelState.reels.map((s, i) => {
        if (!s.anim) return { k: s.idx, frac: 0 };
        const p = reelAnimPos(s.anim, now);
        const whole = Math.floor(p);
        return { k: reelMod(s.anim.from + whole, lay.reels[i].cycle.length), frac: p - whole };
    });
}

function reelDrawBank(ctx, lay, pal, bx, by, pos, ampm, dateStr) {
    ctx.drawImage(reelDrawBack(lay, pal, ampm, dateStr), bx, by);
    lay.reels.forEach((r, i) => {
        const p = pos[i];
        if (p.frac > 0.0005) {
            reelDrawDrum(ctx, bx, by, i, lay, pal, p.k, p.frac,
                reelSliceCount(r.h, REEL_LIVE_SLICE_PX, REEL_LIVE_SLICES_MIN, REEL_LIVE_SLICES_MAX));
        } else {
            ctx.drawImage(reelRestWindow(i, lay, pal, p.k), bx + r.x, by + r.y);
        }
    });
    ctx.drawImage(reelDrawFront(lay, pal), bx, by);
}

function reelNoteStep(now) {
    const gap = now - reelState.lastStepMs;
    if (gap > 0) reelState.dipDepth = REEL_DIP_DEPTH * Math.max(0.35, Math.min(1, gap / 300));
    reelState.lastStepMs = now;
}

function reelDrawDip(ctx, lay, bx, by, now, ampm) {
    const age = now - reelState.lastStepMs;
    if (!(age >= 0 && age < REEL_DIP_MS)) return;
    const a = (reelState.dipDepth || REEL_DIP_DEPTH) * (1 - age / REEL_DIP_MS);
    ctx.fillStyle = `rgba(0,0,0,${a.toFixed(3)})`;
    lay.reels.forEach((r) => ctx.fillRect(bx + r.x, by + r.y, r.w, r.h));
    lay.lamps.forEach((l) => { if (l.text.toLowerCase() === ampm) ctx.fillRect(bx + l.x, by + l.y, l.w, l.h); });
    reelLitSecLamps(lay).forEach((l) => ctx.fillRect(bx + l.x, by + l.y, l.w, l.h));
}
function reelLitSecLamps(lay) {
    const m = reelState.secLit || "";
    return (lay.secLamps || []).filter((l) => m.charAt(l.i) === "1");
}

const REEL_FLICKER_GAP_MIN = 1000;
const REEL_FLICKER_MAX_S_MIN = 2, REEL_FLICKER_MAX_S_MAX = 30;
const REEL_FLICKER_WHOLE_BANK = 0.25;

function reelPlanFlicker(t0, nLamps, rand) {
    const target = (nLamps <= 0 || rand() < REEL_FLICKER_WHOLE_BANK) ? -1 : Math.min(nLamps - 1, Math.floor(rand() * nLamps));
    const blinks = 2 + Math.floor(rand() * 3);
    const segs = [];
    let t = t0;
    for (let i = 0; i < blinks; i++) {
        const dark = 50 + rand() * 50;
        segs.push({ a: t, b: t + dark, depth: 0.45 + rand() * 0.35 });
        t += dark + 50 + rand() * 50;
    }
    return { t0, end: segs[segs.length - 1].b, target, segs };
}

function reelFlickerGap(rand, maxMs) {
    const top = Math.max(REEL_FLICKER_GAP_MIN, maxMs || 0);
    return REEL_FLICKER_GAP_MIN + rand() * (top - REEL_FLICKER_GAP_MIN);
}

function reelUpdateFlicker(lay, now, enabled, stale, litLamp, maxMs) {
    if (!enabled || reelThrottled()) { reelState.flicker = null; reelState.nextFlickerMs = null; return; }
    if (stale || reelState.nextFlickerMs === null) {
        reelState.flicker = null;
        reelState.nextFlickerMs = now + reelFlickerGap(Math.random, maxMs);
        return;
    }
    if (reelState.flicker && now >= reelState.flicker.end) {
        reelState.nextFlickerMs = reelState.flicker.end + reelFlickerGap(Math.random, maxMs);
        reelState.flicker = null;
    }
    if (!reelState.flicker && now >= reelState.nextFlickerMs) {
        reelState.flicker = reelPlanFlicker(now, lay.reels.length + (litLamp ? 1 : 0), Math.random);
    }
}

function reelDrawFlicker(ctx, lay, bx, by, now, ampm) {
    const f = reelState.flicker;
    if (!f) return;
    const seg = f.segs.find((s) => now >= s.a && now < s.b);
    if (!seg) return;
    ctx.fillStyle = `rgba(0,0,0,${seg.depth.toFixed(3)})`;
    const lit = lay.lamps.filter((l) => ampm && l.text.toLowerCase() === ampm);
    const rects = f.target === -1 ? lay.reels.concat(lit, reelLitSecLamps(lay))
        : f.target < lay.reels.length ? [lay.reels[f.target]] : lit;
    rects.forEach((r) => ctx.fillRect(bx + r.x, by + r.y, r.w, r.h));
}

function reelThemeCacheId(id) {
    const t = REEL_THEMES[id];
    const rev = t && t.rev ? "~" + t.rev : "";
    return t && t.scene ? id + "/" + (t.sceneBase || "") + rev : id + rev;
}

function reelEnsureLayout(ctx, px, lo) {
    const layoutKey = [Math.round(px * 10), lo.is24h, lo.showSeconds, !!lo.secondsLamps, lo.showAmpm, lo.showDate, lo.smallSeconds !== false, lo.fontReady,
        reelThemeCacheId(lo.themeId), lo.framed, lo.faceplateKey || 0, lo.extend || "", lo.dir, lo.wear.toFixed(2), lo.backlight.toFixed(2), pinclockIsHighRes()].join("|");
    if (layoutKey === reelState.layoutKey) return reelState.layout;
    reelState.layoutKey = layoutKey;
    reelState.layout = reelComputeLayout(ctx, px, lo);
    const prev = reelState.reels;
    reelState.reels = reelState.layout.reels.map((r, i) => {
        const p = prev[i];
        if (!p || p.role !== r.role) return { role: r.role, idx: null, anim: null };
        const idx = p.anim ? reelMod(p.anim.from + p.anim.n, r.cycle.length) : p.idx;
        return { role: r.role, idx, anim: null };
    });
    return reelState.layout;
}

function reelHoldTheme(settings, date, now, wanted) {
    const cur = reelState.layout && reelState.layout.themeId;
    if (!cur || cur === wanted || !REEL_THEMES[cur] || !reelCycleKind(settings)) return wanted;
    if (now - reelState.lastDrawMs > REEL_STALE_MS) return wanted;
    if (reelState.reels.some((s) => s.anim)) return cur;
    if (reelState.shownKey !== null && reelTimeKey(settings, date) !== reelState.shownKey) return cur;
    return wanted;
}

const _reelPresetCache = { key: null, px: 0 };
function reelPresetPx(ctx, W, H, zoom, frac, lo, cache) {
    const cc = cache || _reelPresetCache;
    const key = [W, H, zoom, frac, lo.is24h, lo.showSeconds, lo.showAmpm, lo.showDate, lo.smallSeconds !== false, lo.fontReady,
        reelThemeCacheId(lo.themeId), lo.faceplateKey || (lo.faceplate ? 1 : 0)].join("|");
    if (cc.key === key) return cc.px;
    const probe = reelComputeLayout(ctx, 100, lo);
    const m = Math.round(PLATE_PAD_X * zoom) * 2;
    const fit = 100 * Math.min((W - m) / probe.w, (H - m) / probe.h);
    const px = Math.max(12, fit * frac);
    cc.key = key;
    cc.px = px;
    return px;
}

const REEL_SCENE_PREFIX = "scene:";
const REEL_SCENE_PLATE_PREFIX = "bgp:";
const REEL_AUTOFIT_FILL = { w: 0.94, h: 0.86 };
const REEL_SCENE_URL = "/api/reel-scenes/";
let _reelSceneListKey = "";
let _reelSceneRev = 0;

let _reelSceneListRef = null;
function reelSyncSceneThemes(list) {
    if (list === _reelSceneListRef && _reelSceneListKey.indexOf(_reelImageListKey + "#") === 0) return;
    _reelSceneListRef = list;
    const clean = (Array.isArray(list) ? list : []).filter((p) => p && /^[0-9a-f]{8}$/.test(String(p.id)) && !p.hidden);
    const key = _reelImageListKey + "#" + JSON.stringify(clean);
    if (key === _reelSceneListKey) return;
    _reelSceneListKey = key;
    _reelSceneRev++;
    for (let i = REEL_THEME_ORDER.length - 1; i >= 0; i--) {
        const t = String(REEL_THEME_ORDER[i]);
        if (t.indexOf(REEL_SCENE_PREFIX) === 0 || t.indexOf(REEL_SCENE_PLATE_PREFIX) === 0) {
            delete REEL_THEMES[REEL_THEME_ORDER[i]];
            REEL_THEME_ORDER.splice(i, 1);
        }
    }
    const byName = clean.map((p, n) => ({ p, n, name: reelDisplayName(p.name) || "Backglass " + (n + 1) }))
        .sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: "base" }));
    byName.forEach(({ p, n }) => {
        if (!p.colors || typeof p.colors !== "object" || !Object.keys(p.colors).length) return;
        REEL_THEMES[REEL_SCENE_PLATE_PREFIX + p.id] = Object.assign({}, REEL_THEMES.classic, { deco: "none" },
            reelImageColors(p.colors, true), { label: reelDisplayName(p.name) || "Backglass " + (n + 1), plateOf: p.id, rev: _reelSceneRev,
                userId: p.id, userKind: "bgplate" });
        if (!p.plate_hidden) REEL_THEME_ORDER.push(REEL_SCENE_PLATE_PREFIX + p.id);
    });
    byName.forEach(({ p, n }) => {
        const base = REEL_THEMES[p.theme] && !REEL_THEMES[p.theme].scene ? p.theme : "bare";
        const name = reelDisplayName(p.name) || "Backglass " + (n + 1);
        REEL_THEMES[REEL_SCENE_PREFIX + p.id] = Object.assign({}, REEL_THEMES[base], {
            label: name, scene: p, sceneBase: base, userId: p.id, userKind: p.stock ? "stock" : "scene",
            rev: _reelSceneRev,
        });
        REEL_THEME_ORDER.push(REEL_SCENE_PREFIX + p.id);
    });
}

function reelCurrentScene(settings) {
    if (!settings || settings.clock_style !== REEL_CLOCK_STYLE || settings.videos_enabled !== false) return null;
    const date = new Date();
    const id = reelHoldTheme(settings, date, performance.now(), reelActiveThemeId(settings, date));
    const t = REEL_THEMES[id];
    return t && t.scene ? t.scene : null;
}

let reelVideoStandIn = false;
const _reelStandIn = { src: null, out: null };
function reelShownScene(pal) {
    if (!pal || !pal.scene) return null;
    if (typeof reelBackgroundShown !== "undefined" && reelBackgroundShown === pal.scene.id) return pal.scene;
    if (reelVideoStandIn && reelVideoStandIn === pal.scene.id) {
        if (pal.scene.stretch !== false) return pal.scene;
        if (_reelStandIn.src !== pal.scene) { _reelStandIn.src = pal.scene; _reelStandIn.out = Object.assign({}, pal.scene, { stretch: true }); }
        return _reelStandIn.out;
    }
    return null;
}

function reelBackgroundRect(scene, W, H) {
    if (!scene) return null;
    const iw = Number(scene.w), ih = Number(scene.h);
    if (scene.stretch !== false || !(iw > 0 && ih > 0)) return { x: 0, y: 0, w: W, h: H };
    const s = Math.min(W / iw, H / ih);
    return { x: (W - iw * s) / 2, y: (H - ih * s) / 2, w: iw * s, h: ih * s };
}

function reelAutofitRect(scene, W, H) {
    if (!scene || scene.place !== "autofit") return null;
    const pic = reelBackgroundRect(scene, W, H);
    const box = scene.box;
    if (!pic || !Array.isArray(box) || box.length !== 4) return null;
    const [x0, y0, x1, y1] = box.map(Number);
    if (!(x0 >= 0 && y0 >= 0 && x1 <= 1 && y1 <= 1 && x1 > x0 && y1 > y0)) return null;
    return { x: pic.x + x0 * pic.w, y: pic.y + y0 * pic.h, w: (x1 - x0) * pic.w, h: (y1 - y0) * pic.h };
}

const REEL_BG_SIZE_MIN = 0.05, REEL_BG_SIZE_MAX = 1;
const REEL_STRETCH_MIN = 0.5, REEL_STRETCH_MAX = 2.5;
const REEL_BG_DEFAULT_LAYOUT = { x: 0.5, y: 0.5, s: 0.65 };
function reelDefaultBgLayout() {
    return Object.assign({}, REEL_BG_DEFAULT_LAYOUT);
}
function reelBgLayout(scene) {
    const L = scene && scene.layout;
    const ok = L && [L.x, L.y, L.s].every((n) => n !== null && n !== "" && isFinite(Number(n)));
    const src = ok ? L : reelDefaultBgLayout(scene);
    const c01 = (n) => Math.max(0, Math.min(1, Number(n)));
    const st = (n) => (n !== null && n !== undefined && n !== "" && isFinite(Number(n)) ? Math.max(REEL_STRETCH_MIN, Math.min(REEL_STRETCH_MAX, Number(n))) : 1);
    return { x: c01(src.x), y: c01(src.y), s: Math.max(REEL_BG_SIZE_MIN, Math.min(REEL_BG_SIZE_MAX, Number(src.s))),
        sx: ok ? st(L.sx) : 1, sy: ok ? st(L.sy) : 1 };
}
const REEL_LAYOUT_REF_ASPECT = 16 / 9;
function reelLayoutAspectFix(scene, pic) {
    if (!scene || scene.stretch === false || !pic || !(pic.w > 0) || !(pic.h > 0)) return 1;
    return (pic.h / pic.w) * REEL_LAYOUT_REF_ASPECT;
}
function reelManualPlacement(scene, W, H) {
    if (!scene || scene.place !== "manual") return null;
    const pic = reelBackgroundRect(scene, W, H);
    const L = reelBgLayout(scene);
    const k = reelLayoutAspectFix(scene, pic);
    return { cx: pic.x + L.x * pic.w, cy: pic.y + L.y * pic.h, w: L.s * pic.w, sx: L.sx, sy: L.sy * k };
}

const _reelAutofitCache = { key: null, px: 0 };
function reelAutofitPx(ctx, r, lo) {
    const key = [Math.round(r.w), Math.round(r.h), lo.is24h, lo.showSeconds, lo.showAmpm, lo.showDate, lo.smallSeconds !== false, lo.fontReady,
        reelThemeCacheId(lo.themeId), lo.extend || ""].join("|");
    if (_reelAutofitCache.key === key) return _reelAutofitCache.px;
    const probe = reelComputeLayout(ctx, 100, lo);
    const px = Math.max(8, 100 * Math.min((r.w * REEL_AUTOFIT_FILL.w) / probe.w, (r.h * REEL_AUTOFIT_FILL.h) / probe.h));
    _reelAutofitCache.key = key;
    _reelAutofitCache.px = px;
    return px;
}
const _reelManualCache = { key: null, px: 0, squash: 1, squashY: 1 };
function reelManualPx(ctx, place, lo) {
    const key = [Math.round(place.w), lo.is24h, lo.showSeconds, !!lo.secondsLamps, lo.showAmpm, lo.showDate, lo.smallSeconds !== false, lo.fontReady, reelThemeCacheId(lo.themeId),
        lo.faceplateKey || 0, lo.extend || ""].join("|");
    if (_reelManualCache.key !== key) {
        const probe = reelComputeLayout(ctx, 100, lo);
        let squash = 1, squashY = 1, base = probe;
        if (lo.showSeconds || lo.showAmpm || lo.showDate) {
            base = reelComputeLayout(ctx, 100, Object.assign({}, lo, { showSeconds: false, secondsLamps: false, showAmpm: false, showDate: false }));
            if (base.w > 0 && probe.w > base.w) squash = base.w / probe.w;
            if (base.h > 0 && probe.h > base.h) squashY = base.h / probe.h;
        }
        _reelManualCache.key = key;
        _reelManualCache.px = Math.max(8, (100 * place.w) / base.w);
        _reelManualCache.squash = squash;
        _reelManualCache.squashY = squashY;
    }
    place.secSquash = _reelManualCache.squash;
    place.secSquashY = _reelManualCache.squashY;
    return _reelManualCache.px;
}

const REEL_EXTEND_PAD = 0.6;
const REEL_EXTEND_ENDS = ["chevrons", "lamps", "stars", "stripes", "plain"];
function reelDrawEnds(c, lay, th) {
    const Hw = lay.Hw, h = lay.h, ext = lay.extendW;
    if (!ext || lay.extend === "plain") return;
    const c1 = th.decoColor || th.lampOnEdge, c2 = th.decoColor2 || th.colon;
    const inset = Hw * 0.08, zw = ext - inset * 0.5, cy = h / 2;
    [[inset, 1], [lay.w - inset, -1]].forEach(([edge, dir]) => {
        const x0 = dir > 0 ? edge : edge - zw;
        if (lay.extend === "chevrons") {
            const t = zw * 0.16, gap = zw * 0.1, span = h * 0.3, tipD = zw * 0.22;
            for (let k = 0; k < 3; k++) {
                const base = dir > 0 ? edge + k * (t + gap) : edge - k * (t + gap);
                const tip = base + dir * tipD;
                c.beginPath();
                c.moveTo(base, cy - span);
                c.lineTo(base + dir * t, cy - span);
                c.lineTo(tip + dir * t, cy);
                c.lineTo(base + dir * t, cy + span);
                c.lineTo(base, cy + span);
                c.lineTo(tip, cy);
                c.closePath();
                c.fillStyle = k === 1 ? c2 : c1;
                c.fill();
            }
        } else if (lay.extend === "lamps") {
            const r = Math.min(zw * 0.28, h * 0.13);
            const cx = x0 + zw / 2;
            [-1, 0, 1].forEach((k) => {
                const ly = cy + k * r * 2.4;
                const g = c.createRadialGradient(cx - r * 0.3, ly - r * 0.3, r * 0.1, cx, ly, r * 1.6);
                g.addColorStop(0, th.lampOnCenter || "#fff6d0");
                g.addColorStop(0.55, th.lampOnEdge || c1);
                g.addColorStop(1, "rgba(0,0,0,0)");
                c.fillStyle = g;
                c.beginPath();
                c.arc(cx, ly, r * 1.6, 0, Math.PI * 2);
                c.fill();
                c.strokeStyle = "rgba(0,0,0,0.5)";
                c.lineWidth = Math.max(1, r * 0.12);
                c.beginPath();
                c.arc(cx, ly, r, 0, Math.PI * 2);
                c.stroke();
            });
        } else if (lay.extend === "stars") {
            const cx = x0 + zw / 2, a = Math.min(zw * 0.42, h * 0.3), b = a * 0.22;
            c.fillStyle = c2;
            c.beginPath();
            c.moveTo(cx, cy - a); c.lineTo(cx + b, cy - b); c.lineTo(cx + a, cy); c.lineTo(cx + b, cy + b);
            c.lineTo(cx, cy + a); c.lineTo(cx - b, cy + b); c.lineTo(cx - a, cy); c.lineTo(cx - b, cy - b);
            c.closePath();
            c.fill();
            c.fillStyle = c1;
            for (let i = 0; i < 5; i++) {
                const sx = x0 + reelRand(i * 5 + (dir > 0 ? 11 : 77)) * zw, sy = h * (0.15 + reelRand(i * 5 + (dir > 0 ? 12 : 78)) * 0.7);
                c.beginPath();
                c.arc(sx, sy, Math.max(1, Hw * 0.012), 0, Math.PI * 2);
                c.fill();
            }
        } else if (lay.extend === "stripes") {
            const sh = h * 0.08, gap = h * 0.06;
            [-1, 0, 1].forEach((k) => {
                c.fillStyle = k === 0 ? c2 : c1;
                c.fillRect(x0, cy + k * (sh + gap) - sh / 2, zw, sh);
            });
        }
    });
}

const REEL_SCORE_THEME = "bare";

function reelScoreRects(scene, W, H) {
    if (!scene || scene.place !== "score") return null;
    const wins = Array.isArray(scene.scores) ? scene.scores : [];
    const p1 = wins[0];
    if (!p1 || p1.kind !== "em" || !Array.isArray(p1.digits) || p1.digits.length < 4) return null;
    const pic = reelBackgroundRect(scene, W, H);
    if (!pic) return null;
    const out = [];
    for (const d of p1.digits) {
        if (!Array.isArray(d) || d.length !== 4) return null;
        const [x0, y0, x1, y1] = d.map(Number);
        if (!(x0 >= 0 && y0 >= 0 && x1 <= 1 && y1 <= 1 && x1 > x0 && y1 > y0)) return null;
        out.push({ x: pic.x + x0 * pic.w, y: pic.y + y0 * pic.h, w: (x1 - x0) * pic.w, h: (y1 - y0) * pic.h });
    }
    return out;
}

function reelBlankWindow(lay, pal) {
    const slot = reelState.blank || (reelState.blank = reelNewCanvas());
    if (slot.key === reelState.layoutKey) return slot.canvas;
    const n = lay.reels.length, r0 = lay.reels[n - 1];
    const fake = Object.assign({}, lay, { reels: lay.reels.concat([Object.assign({}, r0, { role: "blank", cycle: [" "] })]) });
    const c = reelPrepCanvas(slot, r0.w, r0.h);
    slot.key = reelState.layoutKey;
    reelDrawDrum(c, -r0.x, -r0.y, n, fake, pal, 0, 0, reelSliceCount(r0.h, REEL_REST_SLICE_PX, REEL_REST_SLICES_MIN, REEL_REST_SLICES_MAX));
    c.drawImage(reelDrawFront(lay, pal), r0.x, r0.y, r0.w, r0.h, 0, 0, r0.w, r0.h);
    if (reelState.strips[n]) reelState.strips[n].key = null;
    return slot.canvas;
}

function drawReelScore(ctx, rects, settings, opts) {
    opts = opts || {};
    const date = opts.now || new Date();
    const now = performance.now();
    const pal = REEL_THEMES[REEL_SCORE_THEME];
    const ro = reelOptions(settings);
    const is24h = settings.clock_format === "24h";
    const lo = {
        is24h, showSeconds: false, secondsLamps: false, showAmpm: false, showDate: false, fontReady: reelFontReady(),
        themeId: REEL_SCORE_THEME, framed: false, faceplate: null, faceplateKey: 0, extend: null,
        dir: ro.dir, wear: ro.wear, backlight: ro.backlight,
        smallSeconds: ro.smallSeconds,
    };
    const hs = rects.map((r) => r.h).sort((a, b) => a - b);
    const px = Math.max(8, hs[Math.floor(hs.length / 2)] / REEL_WINDOW_H_SCALE);
    reelState.hhmmOnly = true;
    const lay = reelEnsureLayout(ctx, px, lo);
    const snapAll = now - reelState.lastDrawMs > REEL_STALE_MS || reelThrottled();
    reelUpdateState(lay, date, is24h, false, now, snapAll, ro, () => reelNoteStep(now));
    reelState.secLit = "";
    reelState.secHeld = false;
    reelUpdateFlicker(lay, now, ro.flicker, now - reelState.lastDrawMs > REEL_STALE_MS, false, ro.flickerMaxMs);
    reelState.lastDrawMs = now;
    reelState.shownKey = reelTimeKey(settings, date);

    const moving = reelState.reels.some((s) => s.anim);
    const dipping = ro.dip && now - reelState.lastStepMs >= 0 && now - reelState.lastStepMs < REEL_DIP_MS;
    const flickering = ro.flicker && !!reelState.flicker;
    let src = reelRestBank(lay, pal, "", "");
    if (moving || dipping || flickering) {
        const slot = reelState.scoreScratch || (reelState.scoreScratch = reelNewCanvas());
        const c = reelPrepCanvas(slot, lay.w, lay.h);
        if (moving) reelDrawBank(c, lay, pal, 0, 0, reelPositions(lay, now), "", "");
        else c.drawImage(src, 0, 0);
        if (dipping) reelDrawDip(c, lay, 0, 0, now, "");
        if (flickering) reelDrawFlicker(c, lay, 0, 0, now, "");
        src = slot.canvas;
    }
    const blanks = rects.length - lay.reels.length;
    ctx.save();
    ctx.globalAlpha = opts.alpha !== undefined ? opts.alpha : 1;
    rects.forEach((d, k) => {
        const i = k - blanks;
        if (i < 0) {
            ctx.drawImage(reelBlankWindow(lay, pal), d.x, d.y, d.w, d.h);
        } else {
            const r = lay.reels[i];
            ctx.drawImage(src, r.x, r.y, r.w, r.h, d.x, d.y, d.w, d.h);
        }
    });
    ctx.restore();
}

function drawReelClock(ctx, W, H, settings, opts) {
    opts = opts || {};
    const alpha = opts.alpha !== undefined ? opts.alpha : 1;
    const date = opts.now || new Date();
    const now = performance.now();
    const themeId = reelHoldTheme(settings, date, now, reelActiveThemeId(settings, date));
    const pal = REEL_THEMES[themeId];
    const shownScene = reelShownScene(pal);
    const scoreRects = shownScene ? reelScoreRects(shownScene, W, H) : null;
    if (scoreRects) {
        drawReelScore(ctx, scoreRects, settings, opts);
        return;
    }
    reelState.hhmmOnly = false;
    const fitRect = shownScene ? reelAutofitRect(shownScene, W, H) : null;
    const faceplate = reelThemeImage(pal);
    const framed = !pal.frameless || !!faceplate;
    const ro = reelOptions(settings);

    const is24h = settings.clock_format === "24h";
    const showSeconds = settings.show_seconds !== false;
    const secondsLamps = showSeconds && ro.secStyle === "lamps";
    const ampmRaw = is24h ? "" : (date.getHours() < 12 ? "am" : "pm");
    const showAmpm = !is24h && settings.show_ampm !== false;
    const ampm = showAmpm ? ampmRaw : "";
    const showDate = !!settings.show_date;
    const zoom = zoomFactor(H);
    const fontReady = reelFontReady();
    const lo = {
        is24h, showSeconds, secondsLamps, showAmpm, showDate, fontReady, themeId, framed,
        faceplate, faceplateKey: faceplate ? pal.imageV : 0,
        extend: pal.scene && pal.scene.extend && REEL_EXTEND_ENDS.indexOf(pal.scene.ends) !== -1 ? pal.scene.ends : null,
        dir: ro.dir, wear: ro.wear, backlight: ro.backlight,
        smallSeconds: ro.smallSeconds,
    };
    const cycledPlate = !!reelCycleKind(settings) && reelCycleKind(settings) !== "scenes" && !pal.scene;
    const frac = cycledPlate ? CLOCK_SIZE_PRESET_FRAC.xlarge : reelPresetFrac(settings.clock_size_preset);
    const manual = shownScene && !fitRect ? reelManualPlacement(shownScene, W, H) : null;
    const pct = !fitRect && !manual ? reelSizePct(settings) : null;
    const fullScreen = !fitRect && !manual && pct === null && (cycledPlate || settings.clock_size_preset === "xlarge");
    const px = fitRect ? reelAutofitPx(ctx, fitRect, lo)
        : manual ? reelManualPx(ctx, manual, lo)
        : pct !== null ? reelPresetPx(ctx, W, H, zoom, pct / 100, lo)
        : frac ? reelPresetPx(ctx, W, H, zoom, frac, lo) : resolveSizePx(settings.clock_size, TT_SIZE_PX) * zoom;

    if (manual && manual.secSquash && manual.secSquash !== 1) manual.sx *= manual.secSquash;
    if (manual && manual.secSquashY && manual.secSquashY !== 1) manual.sy *= manual.secSquashY;
    const lay = reelEnsureLayout(ctx, px, lo);
    const snapAll = now - reelState.lastDrawMs > REEL_STALE_MS || reelThrottled();
    reelUpdateState(lay, date, is24h, showSeconds && !secondsLamps, now, snapAll,
        secondsLamps ? Object.assign({}, ro, { stepMs: REEL_LAMPS_STEP_MS }) : ro, () => reelNoteStep(now));
    const wantLit = secondsLamps ? reelSecondsLampMask(date.getSeconds(), ro.secLampMode) : "";
    const rolling = reelState.reels.some((r) => r.anim);
    reelState.secHeld = !!(secondsLamps && !snapAll && rolling && reelState.secLit && wantLit !== reelState.secLit);
    if (!reelState.secHeld) reelState.secLit = wantLit;
    reelUpdateFlicker(lay, now, ro.flicker, now - reelState.lastDrawMs > REEL_STALE_MS, !!ampm && lay.lamps.length > 0, ro.flickerMaxMs);
    reelState.lastDrawMs = now;
    reelState.shownKey = reelTimeKey(settings, date);

    const insets = getBarInsets(settings);
    const margin = Math.round(PLATE_PAD_X * zoom);
    const posFn = cycledPlate && pct === null ? CLOCK_POSITIONS.center
        : CLOCK_POSITIONS[settings.clock_position] || CLOCK_POSITIONS["top-right"];
    let [bx, by] = posFn(W, H, lay.w, lay.h, margin, margin, insets.top, insets.bottom);
    let pbox = null;
    if (pct !== null && lay.w > 0 && lay.h > 0) {
        const bw = Math.round(W * pct / 100), bh = Math.round(H * pct / 100);
        let [px0, py0] = posFn(W, H, bw, bh, margin, margin, insets.top, insets.bottom);
        px0 = bw >= W ? Math.round((W - bw) / 2) : Math.max(0, Math.min(W - bw, Math.round(px0 + (opts.xShift || 0))));
        py0 = bh >= H ? Math.round((H - bh) / 2) : Math.max(0, Math.min(H - bh, Math.round(py0 + (opts.yShift || 0))));
        pbox = { x: px0, y: py0, w: bw, h: bh };
    }
    bx = Math.round(bx + (opts.xShift || 0));
    by = Math.round(by + (opts.yShift || 0));
    if (fitRect) {
        bx = Math.round(fitRect.x + (fitRect.w - lay.w) / 2);
        by = Math.round(fitRect.y + (fitRect.h - lay.h) / 2);
    } else if (manual) {
        bx = Math.round(manual.cx - lay.w / 2);
        by = Math.round(manual.cy - lay.h / 2);
    } else if (fullScreen) {
        bx = Math.round((W - lay.w) / 2);
        by = Math.round((H - lay.h) / 2);
    }

    const dateStr = showDate && typeof getDateString === "function" ? getDateString(date) : "";
    const moving = reelState.reels.some((s) => s.anim);
    reelState.lastBox = pbox ? Object.assign({}, pbox) : { x: bx, y: by, w: lay.w, h: lay.h };

    ctx.save();
    ctx.globalAlpha = alpha;
    if (manual && (manual.sx !== 1 || manual.sy !== 1)) {
        ctx.translate(manual.cx, manual.cy);
        ctx.scale(manual.sx, manual.sy);
        ctx.translate(-manual.cx, -manual.cy);
    } else if (pbox) {
        ctx.translate(pbox.x + pbox.w / 2, pbox.y + pbox.h / 2);
        ctx.scale(pbox.w / lay.w, pbox.h / lay.h);
        ctx.translate(-(bx + lay.w / 2), -(by + lay.h / 2));
    } else if (fullScreen && lay.w > 0 && lay.h > 0) {
        ctx.translate(W / 2, H / 2);
        ctx.scale(W / lay.w, H / lay.h);
        ctx.translate(-(bx + lay.w / 2), -(by + lay.h / 2));
    }
    const ssScene = shownScene && reelSceneIsSS(shownScene, settings) ? shownScene : (settings._ss_scene || settings._ss_preview || null);
    if (ssScene && typeof ssDrawDisplay === "function") {
        let ssBox = { x: bx, y: by, w: lay.w, h: lay.h }, ssRadius = null;
        if (ssScene.ss_plate !== false && lay.framed) {
            ctx.drawImage(reelDrawBack(lay, pal, ampm, dateStr), bx, by);
            const ib = reelSsInnerBox(lay);
            ssBox = { x: bx + ib.x, y: by + ib.y, w: ib.w, h: ib.h };
            ssRadius = lay.groups.length ? lay.groups[0].r : null;
            reelDrawWindowRims(ctx, ssBox.x, ssBox.y, ssBox.w, ssBox.h, ssRadius || 0, lay, pal);
        }
        ssDrawDisplay(ctx, ssBox, {
            cache: !settings._ss_preview, radius: ssRadius, edge: ssRadius === null,
            date, now, is24h, showSeconds, smallSeconds: ro.smallSeconds, ampm, dateStr,
            color: ssScene.ss_color, flicker: ro.flicker, flickerMaxMs: ro.flickerMaxMs,
            dip: false, brightness: ro.backlight,
        });
    } else {
        if (!moving) {
            ctx.drawImage(reelRestBank(lay, pal, ampm, dateStr), bx, by);
        } else {
            reelDrawBank(ctx, lay, pal, bx, by, reelPositions(lay, now), ampm, dateStr);
        }
        if (ro.dip) reelDrawDip(ctx, lay, bx, by, now, ampm);
        if (ro.flicker) reelDrawFlicker(ctx, lay, bx, by, now, ampm);
    }
    ctx.restore();
}


function reelFreshState() {
    return {
        layoutKey: null, layout: null, reels: [], lastDrawMs: -Infinity, animEndMs: 0, shownKey: null,
        back: null, front: null, rest: null, strips: [], windows: [], lastStepMs: -Infinity, dipDepth: 0,
        flicker: null, nextFlickerMs: null, secLit: "", secHeld: false, hhmmOnly: false,
        blank: null, scoreScratch: null, lastBox: null,
    };
}
const reelSfxState = Object.assign(reelFreshState(), { episode: null, themeId: null });

function reelWithState(alt, fn) {
    const saved = Object.assign({}, reelState);
    Object.assign(reelState, alt);
    try {
        return fn();
    } finally {
        Object.assign(alt, reelState);
        Object.assign(reelState, saved);
    }
}

function reelSfxBank(ctx, W, H, settings, showAmpm, seed) {
    return reelWithState(reelSfxState, () => {
        const st = reelState;
        const order = REEL_THEME_ORDER.filter((id) => !REEL_THEMES[id].imageId && !REEL_THEMES[id].scene);
        if (st.episode !== seed) {
            st.episode = seed;
            const salt = typeof FX_DEVICE_SALT === "number" ? FX_DEVICE_SALT : 0;
            const r = typeof fxPseudoRandom === "function" ? fxPseudoRandom(seed * 7 + 3 + salt) : Math.random();
            st.themeId = order[Math.floor(r * order.length) % order.length];
            const r2 = typeof fxPseudoRandom === "function" ? fxPseudoRandom(seed * 13 + 5 + salt) : Math.random();
            st.sizeFrac = r2 < 0.5 ? CLOCK_SIZE_PRESET_FRAC.medium : CLOCK_SIZE_PRESET_FRAC.large;
        }
        const pal = REEL_THEMES[st.themeId] || REEL_THEMES[REEL_THEME_ORDER[0]];
        const ro = reelOptions(settings);
        const lo = { is24h: false, showSeconds: false, showAmpm: !!showAmpm, showDate: false, fontReady: reelFontReady(),
            themeId: st.themeId, framed: !pal.frameless, dir: ro.dir, wear: ro.wear, backlight: ro.backlight };
        const px = reelPresetPx(ctx, W, H, zoomFactor(H), st.sizeFrac || CLOCK_SIZE_PRESET_FRAC.medium, lo, _reelSfxPresetCache);
        const t0 = performance.now();
        const lay = reelEnsureLayout(ctx, px, lo);
        const now = new Date();
        const cur = reelTargetIndexes(now, false, false);
        st.reels.forEach((s, i) => { s.anim = null; s.idx = cur[i]; });
        const ampm = showAmpm ? (now.getHours() < 12 ? "am" : "pm") : "";
        const key = st.rest && st.rest.key;
        const canvas = reelRestBank(lay, pal, ampm, "");
        const buildMs = st.rest.key !== key ? performance.now() - t0 : 0;
        return { canvas, w: lay.w, h: lay.h, buildMs };
    });
}
const _reelSfxPresetCache = { key: null, px: 0 };

function reelRenderPreview(canvas, themeId, extra, date) {
    const c = canvas.getContext("2d");
    reelWithState(reelFreshState(), () => {
        const ex = extra || {};
        const is24 = ex.clock_format === "24h";
        const probe = reelComputeLayout(c, 100, {
            is24h: is24, showSeconds: ex.show_seconds !== false, showAmpm: !is24 && ex.show_ampm !== false,
            showDate: !!ex.show_date, themeId, fontReady: reelFontReady(),
        });
        const scale = Math.min((canvas.width * 0.94) / probe.w, (canvas.height * 0.9) / probe.h);
        const zoom = zoomFactor(canvas.height);
        const settings = {
            clock_style: REEL_CLOCK_STYLE, clock_position: "center", clock_size: (100 * scale) / zoom,
            clock_format: "12h", show_seconds: true, show_ampm: true, show_date: false,
            reel_theme: themeId, title_enabled: false, ticker_enabled: false,
            reel_size_pct: false,
            ...ex,
        };
        c.clearRect(0, 0, canvas.width, canvas.height);
        drawReelClock(c, canvas.width, canvas.height, settings, { now: date || new Date(2026, 0, 1, 22, 28, 45) });
    });
}

