#!/bin/sh

PINCLOCK_RELEASE="${PINCLOCK_RELEASE:-/opt/pinclock/current}"

readlink -f "$PINCLOCK_RELEASE" >/tmp/pinclock-boot-release 2>/dev/null || true

export XDG_RUNTIME_DIR=/run/user/$(id -u)
export WAYLAND_DISPLAY=${WAYLAND_DISPLAY:-wayland-0}

PINCLOCK_BOOT_LOGO=/home/vfw/pinclock-data/boot-logo.png

pinclock_brand() {
    _pb_g=""
    _pb_p=""
    for _pb_d in /boot/firmware /boot; do
        if [ -e "$_pb_d/pinclock-generic" ] || [ -e "$_pb_d/pinclock-generic.txt" ]; then _pb_g=1; fi
        if [ -e "$_pb_d/pinclock-pinballlife" ] || [ -e "$_pb_d/pinclock-pinballlife.txt" ]; then _pb_p=1; fi
    done
    if [ -n "$_pb_g" ] && [ -z "$_pb_p" ]; then echo generic; return; fi
    if [ -n "$_pb_p" ] && [ -z "$_pb_g" ]; then echo pinballlife; return; fi
    _pb_w=""
    if [ -f /home/vfw/pinclock-data/brand ]; then
        _pb_w=$(sed -e 's/#.*//' /home/vfw/pinclock-data/brand 2>/dev/null | tr 'A-Z' 'a-z' | awk 'NF { print $1; exit }')
    fi
    case "$_pb_w" in
        pinballlife|pinball-life|pinball_life|branded) echo pinballlife ;;
        *) echo generic ;;
    esac
}

if [ -f "$PINCLOCK_BOOT_LOGO" ]; then
    SPLASH_IMAGE_PATH="$PINCLOCK_BOOT_LOGO"
else
    PINCLOCK_BRAND=$(pinclock_brand)
    case "$PINCLOCK_BRAND" in
        pinballlife) SPLASH_IMAGE_PATH=/opt/pinclock/current/boot-splash/splash-pinballlife.png ;;
        *)           SPLASH_IMAGE_PATH=/opt/pinclock/current/boot-splash/splash.png ;;
    esac
    [ -f "$SPLASH_IMAGE_PATH" ] || SPLASH_IMAGE_PATH=/opt/pinclock/current/boot-splash/splash.png
    echo "[$(date -Iseconds)] brand: $PINCLOCK_BRAND, splash: $SPLASH_IMAGE_PATH" >>/tmp/pinclock-splash.log
fi

launch_splash() {
    if [ -f /tmp/pinclock-splash.pid ]; then
        kill "$(cat /tmp/pinclock-splash.pid)" 2>/dev/null
    fi
    swaybg -i "$SPLASH_IMAGE_PATH" -m stretch >>/tmp/pinclock-splash.log 2>&1 &
    echo $! > /tmp/pinclock-splash.pid
}

export PINCLOCK_CONFIG=/home/vfw/pinclock-data/config.json
export PINCLOCK_SETTINGS=/home/vfw/pinclock-data/settings.json
export PINCLOCK_PLAYLIST=/tmp/pinclock-playlist.m3u
export PINCLOCK_MPV_SOCKET=/tmp/mpvsocket

CRASH_WINDOW_SECS=60
MAX_CRASHES_PER_WINDOW=5
BACKOFF_SECS=30

supervise() {
    name="$1"
    logfile="$2"
    shift 2

    crash_times=""
    restart_count=0
    first=1

    while true; do
        echo "[$(date -Iseconds)] starting $name" >>"$logfile"
        "$@" >>"$logfile" 2>&1
        code=$?
        now=$(date +%s)
        echo "[$(date -Iseconds)] $name exited (code $code)" >>"$logfile"

        if [ "$first" = "1" ]; then
            first=0
        else
            restart_count=$((restart_count + 1))
            echo "$restart_count" >"/tmp/pinclock-${name}-restart-count"

            mkdir -p /home/vfw/pinclock-data
            restart_log="/home/vfw/pinclock-data/${name}-restarts.log"
            echo "[$(date -Iseconds)] $name restarted (exit code $code, restart #$restart_count this boot)" >>"$restart_log"
            tail -n 200 "$restart_log" >"${restart_log}.tmp" && mv "${restart_log}.tmp" "$restart_log"
        fi

        new_times=""
        for t in $crash_times; do
            if [ $((now - t)) -lt "$CRASH_WINDOW_SECS" ]; then
                new_times="$new_times $t"
            fi
        done
        crash_times="$new_times $now"
        count=$(echo "$crash_times" | wc -w)

        if [ "$count" -ge "$MAX_CRASHES_PER_WINDOW" ]; then
            echo "[$(date -Iseconds)] $name crashed $count times in ${CRASH_WINDOW_SECS}s - backing off ${BACKOFF_SECS}s" >>"$logfile"
            sleep "$BACKOFF_SECS"
            crash_times=""
        else
            sleep 0.2
        fi
    done
}


amixer -c 0 sset PCM 100% unmute >/dev/null 2>&1


python3 /opt/pinclock/identity/device_identity.py >/tmp/pinclock-identity.log 2>&1

sh "$PINCLOCK_RELEASE/scripts/network_boot.sh" >/tmp/pinclock-network.log 2>&1 &


python3 "$PINCLOCK_RELEASE/scripts/gen_playlist.py"


until curl -sf http://127.0.0.1:5000 >/dev/null; do
    sleep 0.2
done

DETECTED_RES=""
CONNECTED_OUTPUT_NAME=""
for status_file in /sys/class/drm/*/status; do
    if [ "$(cat "$status_file" 2>/dev/null)" = "connected" ]; then
        modes_file="$(dirname "$status_file")/modes"
        DETECTED_RES="$(head -n1 "$modes_file" 2>/dev/null)"
        if [ -n "$DETECTED_RES" ]; then
            CONNECTED_OUTPUT_NAME="$(basename "$(dirname "$status_file")" | sed 's/^card[0-9]*-//')"
            break
        fi
    fi
done
# trailing suffix like "i".
DETECTED_RES="$(echo "$DETECTED_RES" | grep -oE '^[0-9]+x[0-9]+' | head -n1)"

if echo "$DETECTED_RES" | grep -qE '^[0-9]+x[0-9]+$'; then
    export COG_PLATFORM_WL_VIEW_WIDTH="${DETECTED_RES%x*}"
    export COG_PLATFORM_WL_VIEW_HEIGHT="${DETECTED_RES#*x}"
    echo "[$(date -Iseconds)] detected display resolution: ${COG_PLATFORM_WL_VIEW_WIDTH}x${COG_PLATFORM_WL_VIEW_HEIGHT}" >>/tmp/pinclock-splash.log
else
    export COG_PLATFORM_WL_VIEW_WIDTH=1920
    export COG_PLATFORM_WL_VIEW_HEIGHT=1080
    echo "[$(date -Iseconds)] could not detect display resolution from sysfs - falling back to 1920x1080" >>/tmp/pinclock-splash.log
fi
# resolution, exactly like before this feature existed.
try_apply_resolution() {
    target_w="$1"
    target_h="$2"

    if [ -z "$CONNECTED_OUTPUT_NAME" ] || ! command -v wlr-randr >/dev/null 2>&1; then
        return 1
    fi

    wlr_out="$(wlr-randr 2>/dev/null | awk -v out="$CONNECTED_OUTPUT_NAME" '/^[^ \t]/ { inblock = ($1 == out) } inblock')"
    candidates="$(echo "$wlr_out" | grep -E "^\s+${target_w}x${target_h} px, ")"
    mode_line=""
    if [ "${target_w}x${target_h}" = "640x480" ]; then
        mode_line="$(echo "$candidates" | grep -E "59\.9[34][0-9]* Hz" | head -n1)"
    fi
    [ -z "$mode_line" ] && mode_line="$(echo "$candidates" | grep "60\.000000 Hz" | head -n1)"
    [ -z "$mode_line" ] && mode_line="$(echo "$candidates" | head -n1)"

    if [ -z "$mode_line" ]; then
        echo "[$(date -Iseconds)] ${target_w}x${target_h} not offered by this display - leaving resolution unchanged" >>/tmp/pinclock-splash.log
        return 1
    fi

    target_hz="$(echo "$mode_line" | grep -oE '[0-9]+\.[0-9]+ Hz' | grep -oE '^[0-9]+\.[0-9]+')"
    if wlr-randr --output "$CONNECTED_OUTPUT_NAME" --mode "${target_w}x${target_h}@${target_hz}Hz" >>/tmp/pinclock-splash.log 2>&1; then
        export COG_PLATFORM_WL_VIEW_WIDTH="$target_w"
        export COG_PLATFORM_WL_VIEW_HEIGHT="$target_h"
        echo "[$(date -Iseconds)] applied resolution: ${target_w}x${target_h}@${target_hz}Hz" >>/tmp/pinclock-splash.log
        return 0
    else
        echo "[$(date -Iseconds)] wlr-randr mode-set to ${target_w}x${target_h} failed - leaving resolution unchanged" >>/tmp/pinclock-splash.log
        return 1
    fi
}
# pick in the control panel - keep the two in step.
TARGET_RESOLUTION_FILE=/home/vfw/pinclock-data/target-resolution
DEFAULT_RESOLUTION_FILE=/opt/pinclock/current/default-resolution
RESOLUTION_APPLIED=0

lowest_offered_mode() {
    [ -n "$CONNECTED_OUTPUT_NAME" ] && command -v wlr-randr >/dev/null 2>&1 || return 0
    wlr-randr 2>/dev/null | awk -v out="$CONNECTED_OUTPUT_NAME" '
        /^[^ \t]/ { inblock = ($1 == out); next }
        inblock && $1 ~ /^[0-9]+x[0-9]+$/ && $2 == "px," {
            split($1, wh, "x"); w = wh[1] + 0; h = wh[2] + 0
            if (w >= 640 && h >= 480 && (best == "" || w * h < best_a)) { best = $1; best_a = w * h }
        }
        END { if (best != "") print best }'
}

DISPLAY_ID=""
if [ -n "$CONNECTED_OUTPUT_NAME" ] && command -v wlr-randr >/dev/null 2>&1; then
    DISPLAY_ID="$(wlr-randr 2>/dev/null | awk -v out="$CONNECTED_OUTPUT_NAME" '
        function trim(v) { gsub(/^[ \t]+|[ \t]+$/, "", v); return v }
        /^[^ \t]/ { inblock = ($1 == out); next }
        !inblock { next }
        /^ +Make:/          { sub(/^ +Make:/, "");          mk = trim($0) }
        /^ +Model:/         { sub(/^ +Model:/, "");         md = trim($0) }
        /^ +Serial:/        { sub(/^ +Serial:/, "");        sn = trim($0) }
        /^ +Physical size:/ { sub(/^ +Physical size:/, ""); ph = trim($0) }
        $1 ~ /^[0-9]+x[0-9]+$/ && $2 == "px," {
            if (first == "") first = $1
            if (pref == "" && $0 ~ /\(preferred/) pref = $1
        }
        END { if (mk != "" || md != "" || first != "") printf "%s|%s|%s|%s|%s", mk, md, sn, ph, (pref != "" ? pref : first) }')"
    echo "[$(date -Iseconds)] display identity: ${DISPLAY_ID:-unknown}" >>/tmp/pinclock-splash.log
fi
printf '%s\n' "$DISPLAY_ID" >/tmp/pinclock-display-id

TARGET_RES=""
if [ -f "$TARGET_RESOLUTION_FILE" ]; then
    TARGET_RES="$(tr -d '\r' < "$TARGET_RESOLUTION_FILE" 2>/dev/null | grep -oE '^[0-9]+x[0-9]+$' | head -n1)"
fi
# for whatever display is attached now, so untouched units keep theirs.
if [ -n "$TARGET_RES" ] && [ -n "$DISPLAY_ID" ]; then
    OVERRIDE_ID="$(tr -d '\r' < "$TARGET_RESOLUTION_FILE" | sed -n 's/^# display-id: //p' | head -n1)"
    if [ -z "$OVERRIDE_ID" ]; then
        printf '# display-id: %s\n' "$DISPLAY_ID" >>"$TARGET_RESOLUTION_FILE"
        echo "[$(date -Iseconds)] rule 1: override $TARGET_RES had no display id - assigned to this display" >>/tmp/pinclock-splash.log
    elif [ "$OVERRIDE_ID" != "$DISPLAY_ID" ]; then
        echo "[$(date -Iseconds)] rule 1: override $TARGET_RES was set for a different display ($OVERRIDE_ID) - set aside, using the rules" >>/tmp/pinclock-splash.log
        mv -f "$TARGET_RESOLUTION_FILE" "$TARGET_RESOLUTION_FILE.other-display"
        TARGET_RES=""
    fi
fi
if [ -n "$TARGET_RES" ]; then
    echo "[$(date -Iseconds)] rule 1: per-device override requests $TARGET_RES" >>/tmp/pinclock-splash.log
    try_apply_resolution "${TARGET_RES%x*}" "${TARGET_RES#*x}" && RESOLUTION_APPLIED=1
fi

if [ "$RESOLUTION_APPLIED" = "0" ]; then
    DEFAULT_RES=""
    [ -f "$DEFAULT_RESOLUTION_FILE" ] && DEFAULT_RES="$(tr -d '\r' < "$DEFAULT_RESOLUTION_FILE" | grep -oE '^[0-9]+x[0-9]+$' | head -n1)"
    if [ -n "$DEFAULT_RES" ]; then
        echo "[$(date -Iseconds)] rule 2: fleet default $DEFAULT_RES" >>/tmp/pinclock-splash.log
        try_apply_resolution "${DEFAULT_RES%x*}" "${DEFAULT_RES#*x}" && RESOLUTION_APPLIED=1
    fi
fi

if [ "$RESOLUTION_APPLIED" = "0" ]; then
    LOWEST_RES="$(lowest_offered_mode)"
    if [ -n "$LOWEST_RES" ]; then
        echo "[$(date -Iseconds)] rule 3: lowest mode this display offers is $LOWEST_RES" >>/tmp/pinclock-splash.log
        try_apply_resolution "${LOWEST_RES%x*}" "${LOWEST_RES#*x}" && RESOLUTION_APPLIED=1
    fi
fi

if [ "$RESOLUTION_APPLIED" = "0" ]; then
    echo "[$(date -Iseconds)] rule 4: no rule applied - staying at native ${COG_PLATFORM_WL_VIEW_WIDTH}x${COG_PLATFORM_WL_VIEW_HEIGHT}" >>/tmp/pinclock-splash.log
fi

launch_splash

sleep 2

if [ -e /proc/asound/vc4hdmi ]; then
    MPV_AUDIO_CARD=vc4hdmi
elif [ "$CONNECTED_OUTPUT_NAME" = "HDMI-A-2" ] && [ -e /proc/asound/vc4hdmi1 ]; then
    MPV_AUDIO_CARD=vc4hdmi1
elif [ -e /proc/asound/vc4hdmi0 ]; then
    MPV_AUDIO_CARD=vc4hdmi0
else
    MPV_AUDIO_CARD=vc4hdmi
fi
export PINCLOCK_MPV_AUDIO_DEVICE="alsa/hdmi:CARD=${MPV_AUDIO_CARD},DEV=0"
echo "[$(date -Iseconds)] mpv audio device: $PINCLOCK_MPV_AUDIO_DEVICE" >>/tmp/pinclock-splash.log

supervise mpv /tmp/pinclock-mpv.log sh -c '
    rm -f "$PINCLOCK_MPV_SOCKET"
    exec mpv \
        --input-ipc-server="$PINCLOCK_MPV_SOCKET" \
        --idle=yes \
        --force-window=yes \
        --hwdec=v4l2m2m-copy \
        --vo=gpu \
        --gpu-context=wayland \
        --fs \
        --osc=no \
        --no-input-default-bindings \
        --cursor-autohide=always \
        --ao=alsa \
        --audio-device="$PINCLOCK_MPV_AUDIO_DEVICE" \
        --keepaspect=no \
        --panscan=1.0 \
        --no-border \
        --loop-playlist=inf \
        --playlist="$PINCLOCK_PLAYLIST"
' &

(
    while true; do
        echo "--- $(date -Iseconds) ---" >>/tmp/pinclock-mpv.log
        sleep 5
    done
) &
echo $! > /tmp/pinclock-mpv-timestamp-loop.pid
echo $! > /tmp/pinclock-mpv-supervisor.pid

supervise cog /tmp/pinclock-cog.log cog \
    --platform=wl \
    --platform-params=use-alpha=1 \
    --enable-page-cache=false \
    --doc-viewer \
    --bg-color=transparent \
    --webprocess-failure=exit \
    http://127.0.0.1:5000 &
echo $! > /tmp/pinclock-cog-supervisor.pid

(
    while true; do
        python3 /opt/pinclock/current/scripts/watchdog.py >>/tmp/pinclock-watchdog.log 2>&1
        sleep 2
    done
) &
echo $! > /tmp/pinclock-watchdog-loop.pid

if command -v wlrctl >/dev/null 2>&1; then
    (
        while true; do
            sleep 2
            wlrctl pointer move 5000 5000 >>/tmp/pinclock-cursor.log 2>&1
        done
    ) &
    echo $! > /tmp/pinclock-cursor-loop.pid
else
    echo "[$(date -Iseconds)] wlrctl not installed - skipping cursor-position workaround" >/tmp/pinclock-cursor.log
fi
