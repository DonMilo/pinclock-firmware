#!/usr/bin/env python3
""
import base64
import hashlib
import os
import re
import sys

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(SCRIPT_DIR)
FONTS_CSS = os.path.join(APP_DIR, "app", "static", "css", "fonts.css")
WEB_FONTS_DIR = os.path.join(APP_DIR, "app", "static", "fonts", "web")
WEB_FONTS_URL = "/static/fonts/web"

_DATA_SRC = re.compile(r"url\('data:([^;']+);base64,([A-Za-z0-9+/=\s]+)'\)")


def slugify(family):
    return re.sub(r"[^a-z0-9]+", "-", family.lower()).strip("-") or "font"


def web_font_name(family, data):
    ""
    ext = "otf" if data[:4] == b"OTTO" else "ttf"
    return f"{slugify(family)}-{hashlib.sha256(data).hexdigest()[:8]}.{ext}"


def write_web_font(family, data):
    ""
    os.makedirs(WEB_FONTS_DIR, exist_ok=True)
    name = web_font_name(family, data)
    path = os.path.join(WEB_FONTS_DIR, name)
    if not os.path.exists(path):
        with open(path, "wb") as f:
            f.write(data)
    return f"{WEB_FONTS_URL}/{name}"


def main():
    dry_run = "--dry-run" in sys.argv
    with open(FONTS_CSS, encoding="utf-8", newline="") as f:
        css = f.read()
    before = len(css)
    count = 0

    def replace_block(m):
        nonlocal count
        block = m.group(0)
        fam = re.search(r"font-family:\s*'([^']+)'", block)
        src = _DATA_SRC.search(block)
        if not fam or not src:
            return block
        data = base64.b64decode(re.sub(r"\s+", "", src.group(2)))
        url = f"{WEB_FONTS_URL}/{web_font_name(fam.group(1), data)}" if dry_run \
            else write_web_font(fam.group(1), data)
        count += 1
        return block[:src.start()] + f"url('{url}')" + block[src.end():]

    css = re.sub(r"@font-face\s*\{.*?\}", replace_block, css, flags=re.S)
    print(f"{count} fonts moved out; fonts.css {before:,} -> {len(css):,} bytes")
    if dry_run:
        print("(dry run - nothing written)")
        return
    with open(FONTS_CSS, "w", encoding="utf-8", newline="") as f:
        f.write(css)


if __name__ == "__main__":
    main()
