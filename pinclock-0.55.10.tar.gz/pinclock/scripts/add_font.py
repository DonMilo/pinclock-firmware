#!/usr/bin/env python3
""

import argparse
import base64
import html
import os
import re
import shutil
import sys
import tempfile

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(SCRIPT_DIR)
FONTS_CSS = os.path.join(APP_DIR, "app", "static", "css", "fonts.css")
RENDERER_JS = os.path.join(APP_DIR, "app", "static", "js", "renderer.js")
FONT_TAGS_TXT = os.path.join(APP_DIR, "fx-styles", "font-tags.txt")
SETTINGS_STORE_PY = os.path.join(APP_DIR, "app", "core", "settings_store.py")
PLAIN_FONT_MARKER = "        # ADD-PLAIN-FONT MARKER: scripts/add_font.py adds new plain fonts above this line.\n"
CONTROL_HTML = os.path.join(APP_DIR, "app", "templates", "control.html")
FONTS_DIR = os.path.join(APP_DIR, "app", "static", "fonts")

sys.path.insert(0, SCRIPT_DIR)
from subset_fonts import subset_font, missing_chars
from externalize_fonts import web_font_name, write_web_font, WEB_FONTS_URL

KEY_RE = re.compile(r"^[a-z][a-z0-9_]*$")

RENDERER_MARKER = (
    "    // ADD-FONT MARKER: scripts/add_font.py appends new TT_FONTS entries\n"
)
FONTS_CSS_MARKER = (
    "/* ADD-FONT MARKER: scripts/add_font.py appends new @font-face blocks\n"
)
CONTROL_MARKER = (
    '          <!-- ADD-FONT MARKER: scripts/add_font.py appends new options\n'
)
STYLE_MARKER = (
    '            <!-- STYLE-FONT MARKER: scripts/add_font.py appends new options\n'
)


def fail(msg):
    print(f"error: {msg}", file=sys.stderr)
    sys.exit(1)


def read_family_name(font_path):
    ""
    from fontTools.ttLib import TTFont

    font = TTFont(font_path, lazy=True)
    name = font["name"].getDebugName(1)
    if not name:
        fail(
            f"couldn't read a family name from {font_path}'s own name table "
            f"(nameID 1) - this font file may be malformed"
        )
    return name


def js_string_escape(s):
    return s.replace("\\", "\\\\").replace('"', '\\"')


def html_escape(s):
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


def find_marker(path, marker, label):
    with open(path, encoding="utf-8") as f:
        content = f.read()
    if marker not in content:
        fail(
            f"couldn't find the ADD-FONT MARKER in {path} ({label}) - "
            f"it may have been edited or removed; nothing was written to "
            f"any file. Restore the marker comment (see this script's own "
            f"README section) and try again."
        )
    return content


def insert_before_marker(content, marker, new_text):
    return content.replace(marker, new_text + marker, 1)


def insert_option_sorted(content, marker, option_line, pinned_values=("auto", "system", "reels_bank")):
    ""
    marker_idx = content.index(marker)
    select_start = content.rfind("<select", 0, marker_idx)
    select_end = content.find("</select>", marker_idx)
    if select_start == -1 or select_end == -1:
        return insert_before_marker(content, marker, option_line)

    new_label = html.unescape(re.search(r">([^<]*)</option>", option_line).group(1)).lower()

    option_re = re.compile(r'[ \t]*<option value="([^"]+)"[^>]*>([^<]*)</option>\n')
    for m in option_re.finditer(content, select_start, select_end):
        if m.group(1) in pinned_values:
            continue
        if html.unescape(m.group(2)).lower() > new_label:
            return content[: m.start()] + option_line + content[m.start() :]

    return insert_before_marker(content, marker, option_line)


def insert_after_marker_line(content, marker, new_text):
    idx = content.index(marker) + len(marker)
    return content[:idx] + new_text + content[idx:]


def check_not_duplicate(content, needle, what, path):
    if needle in content:
        fail(
            f"{what} already appears in {path} - pick a different value, "
            f"or remove the existing one by hand first if you're "
            f"intentionally replacing it (this script never edits or "
            f"removes an existing entry)"
        )


def main():
    parser = argparse.ArgumentParser(
        description="Add a new SFX/clock font to PinClock - subsets it "
        "and registers it in fonts.css, renderer.js, and control.html "
        "in one step.",
    )
    parser.add_argument("font_path", help="path to the source .ttf/.otf file")
    parser.add_argument("--key", required=True)
    parser.add_argument("--label", required=True)
    parser.add_argument("--weight", choices=["normal", "bold"], default="normal")
    parser.add_argument("--color", action="store_true")
    parser.add_argument("--threeD", action="store_true", dest="three_d")
    parser.add_argument("--shadow", action="store_true")
    parser.add_argument("--group", default=None)
    parser.add_argument("--reel-only", action="store_true", dest="reel_only")
    parser.add_argument("--tags", default="")
    parser.add_argument("--checked", action="store_true")
    parser.add_argument("--extra", default="")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    if not os.path.isfile(args.font_path):
        fail(f"no such file: {args.font_path}")
    if not args.font_path.lower().endswith((".ttf", ".otf")):
        fail(f"expected a .ttf or .otf file, got: {args.font_path}")
    if not KEY_RE.match(args.key):
        fail(
            f"--key {args.key!r} is invalid - must start with a lowercase "
            f"letter and contain only lowercase letters, digits, and "
            f"underscores (e.g. 'my_font')"
        )
    if not args.label.strip():
        fail("--label can't be empty")
    tags = [t.strip() for t in re.split(r"[,;]", args.tags) if t.strip()]
    if tags and args.reel_only:
        fail("--tags can't be combined with --reel-only (tags are for the DMD effects clock's fonts)")
    tags_line = f"{args.key} = {', '.join(tags)}" + (f"   # {args.label}" if args.label.lower() != args.key.replace('_', ' ') else "") + "\n" if tags else ""

    missing = missing_chars(args.font_path, args.extra)
    if missing and not args.force:
        fail(
            f"{args.font_path} has no glyph for {''.join(missing)!r} - "
            f"every font here needs to draw whichever of these the "
            f"regular clock and Special Effects Clock might ask for "
            f"(fonts are shared between both pickers). Pass --force to "
            f"add it anyway (will show a tofu box for what's missing)."
        )
    elif missing:
        print(
            f"warning: {args.font_path} has no glyph for {''.join(missing)!r} "
            f"- proceeding anyway because --force was passed"
        )

    for path, label in [
        (RENDERER_JS, "TT_FONTS in renderer.js"),
        (FONTS_CSS, "fonts.css"),
        (CONTROL_HTML, "the Font dropdown in control.html"),
    ]:
        if not os.path.isfile(path):
            fail(f"expected file not found: {path}")

    renderer_content = find_marker(RENDERER_JS, RENDERER_MARKER, "TT_FONTS")
    fonts_css_content = find_marker(FONTS_CSS, FONTS_CSS_MARKER, "fonts.css")
    control_content = find_marker(CONTROL_HTML, CONTROL_MARKER, "Font dropdown")
    find_marker(CONTROL_HTML, STYLE_MARKER, "Style dropdown")

    check_not_duplicate(renderer_content, f"\n    {args.key}:", f"--key {args.key!r}", RENDERER_JS)
    check_not_duplicate(control_content, f'value="{args.key}"', f"--key {args.key!r}", CONTROL_HTML)

    print(f"subsetting {args.font_path}...")
    fd, tmp_out = tempfile.mkstemp(suffix=".ttf")
    os.close(fd)
    subset_font(args.font_path, tmp_out, args.extra)
    before_size = os.path.getsize(args.font_path)
    after_size = os.path.getsize(tmp_out)
    print(f"  {before_size/1024:.1f} KB -> {after_size/1024:.1f} KB")

    family_name = read_family_name(tmp_out)
    print(f"family name (read from the font itself): {family_name!r}")

    check_not_duplicate(
        fonts_css_content, f"font-family: '{family_name}';", f"family {family_name!r}", FONTS_CSS
    )

    with open(tmp_out, "rb") as f:
        font_bytes = f.read()
    web_url = f"{WEB_FONTS_URL}/{web_font_name(family_name, font_bytes)}"

    css_block = (
        "@font-face {\n"
        f"    font-family: '{family_name}';\n"
        f"    src: url('{web_url}');\n"
        f"    font-weight: {args.weight};\n"
        "    font-style: normal;\n"
        "}\n\n"
    )

    js_family = "'" + family_name.replace("'", "\\'") + "'"
    js_fields = [
        f'label: "{js_string_escape(args.label)}"',
        f"family: \"{js_string_escape(js_family)}\"",
        f'weight: "{args.weight}"',
    ]
    if args.color:
        js_fields.append("color: true")
    if args.three_d:
        js_fields.append("threeD: true")
    if args.shadow:
        js_fields.append("shadowFX: true")
    if args.group:
        js_fields.append(f'group: "{js_string_escape(args.group)}"')
    if args.reel_only:
        if args.color or args.three_d or args.shadow or args.group:
            fail("--reel-only can't be combined with --color/--threeD/--shadow/--group (those only matter to the SFX clock)")
        js_fields.append("reelOnly: true")
    js_line = f"    {args.key}: {{ {', '.join(js_fields)} }},\n"

    cat_parts = []
    if args.color:
        cat_parts.append("color")
    if args.three_d:
        cat_parts.append("3d")
    data_cat = " ".join(cat_parts) if cat_parts else "normal"
    if args.shadow:
        data_cat += " shadow"
    suffix_parts = []
    if args.three_d:
        suffix_parts.append("3D")
    if args.color:
        suffix_parts.append("color")
    if args.shadow:
        suffix_parts.append("Shadow")
    suffix = f" ({', '.join(suffix_parts)})" if suffix_parts else ""
    option_line = (
        f'          <option value="{html_escape(args.key)}" data-cat="{data_cat}">'
        f'{html_escape(args.label)}{html_escape(suffix)}</option>\n'
    )

    style_suffix_parts = [p for p in suffix_parts if p != "Shadow"]
    style_suffix = f" ({', '.join(style_suffix_parts)})" if style_suffix_parts else ""
    style_option_line = (
        f'            <option value="{html_escape(args.key)}">'
        f'{html_escape(args.label)}{html_escape(style_suffix)}</option>\n'
    )

    plain_unchecked = not (args.color or args.three_d or args.shadow or args.reel_only or args.checked)
    store_content = None
    if plain_unchecked:
        store_content = find_marker(SETTINGS_STORE_PY, PLAIN_FONT_MARKER, "fx_font_excluded defaults")
        check_not_duplicate(store_content, f'        "{args.key}",\n', f"--key {args.key!r}", SETTINGS_STORE_PY)

    print("\n--- would add to renderer.js (TT_FONTS) ---")
    print(js_line, end="")
    if args.reel_only:
        print("--- control.html: nothing (--reel-only - not in the Font checklist or Style list) ---")
    else:
        print("--- would add to control.html (Font dropdown) ---")
        print(option_line, end="")
    if plain_unchecked:
        print("--- would add to settings_store.py (unchecked by default on the Effects tab) ---")
        print(f'        "{args.key}",')
    if tags_line:
        print("--- would add to fx-styles/font-tags.txt ---")
        print(tags_line, end="")
    print("--- would add to fonts.css ---")
    print(f"@font-face {{ font-family: '{family_name}'; src: url('{web_url}'); ... }}")

    if args.dry_run:
        print("\n(dry run - nothing was written)")
        os.remove(tmp_out)
        return

    new_renderer = insert_before_marker(renderer_content, RENDERER_MARKER, js_line)
    new_fonts_css = insert_before_marker(fonts_css_content, FONTS_CSS_MARKER, css_block)
    if args.reel_only:
        new_control = control_content
    else:
        new_control = insert_option_sorted(control_content, CONTROL_MARKER, option_line)
        new_control = insert_option_sorted(new_control, STYLE_MARKER, style_option_line)

    write_web_font(family_name, font_bytes)
    with open(RENDERER_JS, "w", encoding="utf-8") as f:
        f.write(new_renderer)
    with open(FONTS_CSS, "w", encoding="utf-8") as f:
        f.write(new_fonts_css)
    with open(CONTROL_HTML, "w", encoding="utf-8") as f:
        f.write(new_control)
    os.remove(tmp_out)
    if plain_unchecked:
        with open(SETTINGS_STORE_PY, "w", encoding="utf-8") as f:
            f.write(insert_before_marker(store_content, PLAIN_FONT_MARKER, f'        "{args.key}",\n'))
    if tags_line:
        existing = ""
        if os.path.isfile(FONT_TAGS_TXT):
            with open(FONT_TAGS_TXT, encoding="utf-8") as f:
                existing = f.read()
        else:
            os.makedirs(os.path.dirname(FONT_TAGS_TXT), exist_ok=True)
        with open(FONT_TAGS_TXT, "w", encoding="utf-8") as f:
            f.write(existing + ("" if not existing or existing.endswith("\n") else "\n") + tags_line)

    print(f"\ndone. Added {args.key!r} to:")
    print(f"  {RENDERER_JS}")
    print(f"  {FONTS_CSS}")
    print(f"  app{web_url} (the font file the page loads)")
    if not args.reel_only:
        print(f"  {CONTROL_HTML}")
    if plain_unchecked:
        print(f"  {SETTINGS_STORE_PY} (unchecked by default - plain font; --checked to skip)")
    if tags_line:
        print(f"  {FONT_TAGS_TXT}")
    print(
        "\nNext: bump PINCLOCK_VERSION in app.py yourself, then redeploy "
        "as a normal OTA update."
    )


if __name__ == "__main__":
    main()
