#!/bin/sh

WAIT_SECONDS=20
POLL_INTERVAL=2
HOTSPOT_ADDR="10.42.0.1/24"
IFACE="wlan0"

IDENTITY_ENV="/home/vfw/pinclock-data/device_identity.env"
if [ -f "$IDENTITY_ENV" ]; then
    . "$IDENTITY_ENV"
fi
HOTSPOT_SSID="${PINCLOCK_HOTSPOT_SSID:-PinClock-Setup}"
HOTSPOT_NAME="$HOTSPOT_SSID"


elapsed=0
connected=0
while [ "$elapsed" -lt "$WAIT_SECONDS" ]; do
    state=$(sudo nmcli -t -f DEVICE,STATE device status 2>/dev/null | grep "^${IFACE}:" | cut -d: -f2)
    if [ "$state" = "connected" ]; then
        connected=1
        break
    fi
    sleep "$POLL_INTERVAL"
    elapsed=$((elapsed + POLL_INTERVAL))
done

if [ "$connected" = "1" ]; then
    echo "[network_boot] WiFi connected, no hotspot needed"
    exit 0
fi

echo "[network_boot] no WiFi after ${WAIT_SECONDS}s, bringing up setup hotspot"

if sudo nmcli -t -f NAME connection show | grep -qx "$HOTSPOT_NAME"; then
    sudo nmcli connection delete "$HOTSPOT_NAME" >/dev/null 2>&1
fi

sudo nmcli connection add \
    type wifi \
    ifname "$IFACE" \
    con-name "$HOTSPOT_NAME" \
    autoconnect yes \
    connection.autoconnect-priority -100 \
    ssid "$HOTSPOT_SSID" \
    mode ap \
    ipv4.method shared \
    ipv4.addresses "$HOTSPOT_ADDR"

sudo nmcli connection up "$HOTSPOT_NAME"
