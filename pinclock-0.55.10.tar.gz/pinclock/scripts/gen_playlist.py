#!/usr/bin/env python3
""

import json
import os
import random
import sys

CONFIG_PATH = os.environ.get(
    "PINCLOCK_CONFIG", "/home/vfw/pinclock-data/config.json"
)
SETTINGS_PATH = os.environ.get(
    "PINCLOCK_SETTINGS", "/home/vfw/pinclock-data/settings.json"
)
PLAYLIST_PATH = os.environ.get(
    "PINCLOCK_PLAYLIST", "/tmp/pinclock-playlist.m3u"
)
SHIPPED_VIDEOS_DIR = os.environ.get(
    "PINCLOCK_SHIPPED_VIDEOS", "/opt/pinclock/shipped-videos"
)
EM_VIDEO_DIRS = [
    os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "em-videos"),
    os.environ.get("PINCLOCK_STOCK_EM_VIDEOS", "/opt/pinclock/em-videos"),
    os.environ.get("PINCLOCK_EM_VIDEOS", "/home/vfw/pinclock-data/em-videos"),
]


def load_config(path):
    with open(path, "r") as f:
        return json.load(f)


def load_settings(path):
    try:
        with open(path, "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def _source_dir(source, user_videos_dir):
    return user_videos_dir if source == "user" else SHIPPED_VIDEOS_DIR


def build_em_playlist(settings=None):
    ""
    found = {}
    for i, d in enumerate(EM_VIDEO_DIRS):
        source = "user" if i == len(EM_VIDEO_DIRS) - 1 else "stock"
        try:
            names = os.listdir(d)
        except OSError:
            continue
        for n in names:
            full = os.path.join(d, n)
            if n.lower().endswith(".mp4") and not n.startswith(".") and os.path.isfile(full):
                found[n] = (source, full)
    entries = (settings or {}).get("em_playlist")
    if isinstance(entries, list):
        files = []
        for e in entries:
            if not isinstance(e, dict):
                continue
            hit = found.get(e.get("name"))
            if hit and hit[0] == e.get("source"):
                files.append(hit[1])
            else:
                print(f"[gen_playlist] skipping missing EM video: {e.get('name')!r}", file=sys.stderr)
    else:
        files = [path for _, path in found.values()]
    random.shuffle(files)
    if not files:
        print("[gen_playlist] EM effect is on but the EM playlist is empty", file=sys.stderr)
    return files


def build_playlist(config, settings):
    if settings.get("fx_mode") == "em" and settings.get("em_source") != "backglasses":
        if settings.get("em_video_clips") is False:
            return []
        return build_em_playlist(settings)
    if settings.get("fx_mode") == "em" and settings.get("em_source") == "backglasses":
        return []
    videos_cfg = config.get("videos", {})
    user_videos_dir = videos_cfg.get("path", "/home/vfw/pinclock-data/videos")
    randomize = bool(settings.get("randomize", videos_cfg.get("randomize", False)))
    entries = settings.get("playlist", [])

    files = []
    for entry in entries:
        name = entry.get("name")
        source = entry.get("source")
        if not name or source not in ("user", "shipped"):
            continue
        full_path = os.path.join(_source_dir(source, user_videos_dir), name)
        if os.path.isfile(full_path):
            files.append(full_path)
        else:
            print(f"[gen_playlist] skipping missing file: {full_path}", file=sys.stderr)

    if not files:
        print("[gen_playlist] playlist is empty (no videos added yet, or all entries stale)", file=sys.stderr)
        return []

    if randomize:
        random.shuffle(files)

    return files


def write_playlist(paths, out_path):
    with open(out_path, "w") as f:
        for p in paths:
            f.write(p + "\n")


def main():
    config = load_config(CONFIG_PATH)
    settings = load_settings(SETTINGS_PATH)
    paths = build_playlist(config, settings)
    write_playlist(paths, PLAYLIST_PATH)
    print(f"[gen_playlist] wrote {len(paths)} entries to {PLAYLIST_PATH}")


if __name__ == "__main__":
    main()
