#!/usr/bin/env python3
""
import json
import re
import sys
from pathlib import Path

from fontTools.ttLib import TTFont

APP_DIR = Path(__file__).resolve().parent.parent
FONTS_CSS = APP_DIR / "app" / "static" / "css" / "fonts.css"
RENDERER_JS = APP_DIR / "app" / "static" / "js" / "renderer.js"
MESSAGES_JS = APP_DIR / "app" / "static" / "js" / "messages.js"
START = "// FONT-COVERAGE START (scripts/font_coverage.py --write)"
END = "// FONT-COVERAGE END"
ASCII = [chr(c) for c in range(0x20, 0x7F)]


def build_table():
    css = FONTS_CSS.read_text()
    fam_to_file = {}
    for fam, url in re.findall(r"font-family:\s*'([^']+)';\s*src:\s*url\('([^']+)'\)", css):
        fam_to_file[fam] = APP_DIR / "app" / url.lstrip("/")
    js = RENDERER_JS.read_text()
    table, problems = {}, []
    for fid, fam in re.findall(r"^\s{4}([a-z0-9_]+): \{ label: \"[^\"]*\", family: \"'([^']+)'", js, re.M):
        if fid == "system":
            continue
        path = fam_to_file.get(fam)
        if not path or not path.exists():
            problems.append(f"{fid}: no font file found for family {fam!r} in fonts.css")
            continue
        font = TTFont(str(path))
        cmap = font.getBestCmap() or {}
        glyf = font["glyf"] if "glyf" in font else None

        def blank(ch):
            if glyf is None or ch == " ":
                return False
            g = glyf[cmap[ord(ch)]]
            return g.numberOfContours == 0

        missing = "".join(ch for ch in ASCII if ord(ch) not in cmap or blank(ch))
        if missing:
            table[fid] = missing
    return table, problems


def main():
    table, problems = build_table()
    if problems:
        print("\n".join(problems), file=sys.stderr)
        sys.exit(1)
    body = "const MSG_FONT_MISSING = " + json.dumps(table, indent=4, sort_keys=True) + ";"
    if "--write" not in sys.argv:
        print(body)
        return
    src = MESSAGES_JS.read_text()
    a, b = src.find(START), src.find(END)
    if a < 0 or b < 0:
        print(f"markers not found in {MESSAGES_JS}", file=sys.stderr)
        sys.exit(1)
    MESSAGES_JS.write_text(src[:a] + START + "\n" + body + "\n" + src[b:])
    print(f"updated {MESSAGES_JS} ({len(table)} fonts with gaps)")


if __name__ == "__main__":
    main()
