#!/usr/bin/env python3
"""
PinClock - turn a plain single-color font into a 3D color font.

Bakes the "3D" look into the font file itself (a COLRv1 color font - the
same format Honk and Nabla use), so the Pi just draws text: no extra
drawing work per frame.

    python make_3d_font.py <input.ttf> <output.ttf> --color "#ff6600"
    python make_3d_font.py liquid.ttf liquid-3d.ttf --color "#1e90ff" --family "Liquid 3D"
    python make_3d_font.py merkin-goo.ttf merkin-goo-3d.ttf --color "#1e90ff" --family "Merkin Goo 3D" \
        --shine-width 0.06 --shine-sliver-from 0.035 --shine-color "#ffffff"     (v0.30.6)

Every glyph gets, back to front:
  1. an extrusion - the letter pushed back and down-right, in darker
     shades of the color the further back it goes (--depth, --bands)
  2. the letter's face, with a gradient from lighter at the top to
     darker at the bottom
  3. shine: the thin holes some fonts cut into their letters to fake a
     highlight (Liquid, Orange Gummy, Coffee Town...) are filled with a
     light tint, so they read as shine on a dark background instead of
     as gaps. Real letter holes (the inside of an "0", "8", "B") are
     wider and stay open - see --shine-width.

--shadow makes a "shadow" font instead (v0.23.43): no extrusion and no
baked color - each letter is drawn in WHATEVER COLOR THE CLOCK DRAWS IT
IN (the Color setting / color Auto-Cycle still work), with a black drop
shadow behind it and a light-to-dark gloss on top. It replaces the
clock drawing a second black copy of the text every frame.

    python make_3d_font.py arbutus.ttf arbutus-shadow.ttf --shadow

--snow (v0.25.9, with --shadow) is for fonts like Snowtop Caps whose snow
caps are HOLES in the letter (so they showed the background through them):
those holes are filled with white (fading to a pale icy blue lower down),
on top of the letter, and included in the drop shadow. Real letter holes
(the inside of an "O" or "A") are left alone - see find_snow().

    python make_3d_font.py snowtop-caps.ttf snowtop-shadow.ttf --shadow --snow

Add a --shadow font with add_font.py WITHOUT --color/--threeD/--shadow
(it's a normal, recolorable font that happens to carry its own shadow).

Also writes <output>.preview.html next to the font: open it in Chrome to
check the result before adding the font with add_font.py (use
--threeD there - 3D is its own group in PinClock, separate from Color;
the colors are baked in, so the clock's Color setting doesn't apply).

Requires: pip install fonttools skia-pathops   (Windows, Mac or Linux)

The output font's family name is "<original> 3D" unless --family is
given, so it never clashes with the original. The plain letter shapes
stay as the non-color fallback. Check the font's license allows
modified versions before shipping one (OFL does, under a new name).
"""
import argparse
import math
import os
import sys

from fontTools.colorLib.builder import buildCOLR, buildCPAL
from fontTools.pens.areaPen import AreaPen
from fontTools.pens.basePen import BasePen
from fontTools.pens.boundsPen import BoundsPen
from fontTools.pens.cu2quPen import Cu2QuPen
from fontTools.pens.pointInsidePen import PointInsidePen
from fontTools.pens.recordingPen import DecomposingRecordingPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.ttLib import TTFont
from fontTools.ttLib.tables import otTables as ot

try:
    import pathops
except ImportError:
    sys.exit("skia-pathops is missing - run:  pip install skia-pathops")


def parse_hex(h):
    h = h.lstrip("#")
    if len(h) != 6:
        raise argparse.ArgumentTypeError(f"expected a color like #ff6600, got {h!r}")
    return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))


def mix(c, other, t):
    return tuple(a + (b - a) * t for a, b in zip(c, other))


WHITE, BLACK = (1, 1, 1), (0, 0, 0)


class FlattenPen(BasePen):
    """Records each contour as a list of points, curves approximated by
    short straight segments."""

    def __init__(self, steps=8):
        super().__init__(None)
        self.steps = steps
        self.contours = []

    def _moveTo(self, p):
        self.contours.append([p])

    def _lineTo(self, p):
        self.contours[-1].append(p)

    def _curveToOne(self, a, b, c):
        p0 = self._getCurrentPoint()
        for i in range(1, self.steps + 1):
            t = i / self.steps
            m = 1 - t
            self.contours[-1].append((
                m ** 3 * p0[0] + 3 * m * m * t * a[0] + 3 * m * t * t * b[0] + t ** 3 * c[0],
                m ** 3 * p0[1] + 3 * m * m * t * a[1] + 3 * m * t * t * b[1] + t ** 3 * c[1]))

    def _qCurveToOne(self, a, b):
        p0 = self._getCurrentPoint()
        for i in range(1, self.steps + 1):
            t = i / self.steps
            m = 1 - t
            self.contours[-1].append((
                m * m * p0[0] + 2 * m * t * a[0] + t * t * b[0],
                m * m * p0[1] + 2 * m * t * a[1] + t * t * b[1]))


def split_contours(recording):
    out, cur = [], []
    for op, args in recording:
        cur.append((op, args))
        if op in ("closePath", "endPath"):
            out.append(cur)
            cur = []
    return out


def replay(ops, pen):
    for op, args in ops:
        getattr(pen, op)(*args)


def signed_area(ops):
    pen = AreaPen()
    replay(ops, pen)
    return pen.value


def perimeter(points):
    return sum(math.dist(points[i], points[(i + 1) % len(points)]) for i in range(len(points)))


def find_shine(contours, max_width, sliver_from=None, min_elong=0.0):
    """Indexes of the hole contours thin enough to be a painted-on shine
    rather than a real letter hole. A hole is a contour sitting inside an
    odd number of other contours; its width is estimated as
    2 x area / perimeter (about the stroke width for a thin shape).
    v0.30.6: a hole wider than sliver_from (but still within max_width) only
    counts when it's a long sliver - perimeter^2 / area >= min_elong - so a
    small but compact real hole (the triangle inside Merkin Goo's "A" and
    "4", the eye of its "e") stays open. None = no such test (as before)."""
    shine = []
    for i, c in enumerate(contours):
        start = c[0][1][0]
        inside = 0
        for j, other in enumerate(contours):
            if j == i:
                continue
            pen = PointInsidePen(None, start)
            replay(other, pen)
            inside += bool(pen.getResult())
        if inside % 2 == 0:
            continue
        flat = FlattenPen()
        replay(c, flat)
        pts = flat.contours[0] if flat.contours else []
        if len(pts) < 3:
            continue
        area, per = abs(signed_area(c)), max(perimeter(pts), 1e-6)
        width = 2 * area / per
        if width <= max_width:
            if sliver_from is not None and width > sliver_from and per * per / max(area, 1e-6) < min_elong:
                continue
            shine.append(i)
    return shine


def find_snow(contours, max_gap):
    """v0.25.9 (--snow): indexes of the hole contours that are snow caps.
    A hole counts as snow when it hugs the letter's OUTER edge just above
    it: straight up from the hole's highest point, the next outline crossed
    belongs to an outer contour (not another hole) and is less than
    max_gap away - the thin rim of letter drawn around the snow. A real
    letter hole (the inside of an "O") has solid letter, or a snow cap,
    above it instead, so it's left open. Checked on Snowtop Caps: every
    cap and drip on M/E/H/X/A/S is found, the counters of O/A/0/8/B stay
    open (see the v0.25.9 specimen)."""
    flats = []
    for c in contours:
        f = FlattenPen(steps=8)
        replay(c, f)
        flats.append(f.contours[0] if f.contours else [])

    areas = [signed_area(c) for c in contours]
    outer_sign = 1 if max(areas, key=abs) > 0 else -1
    is_hole = [(a > 0) != (outer_sign > 0) for a in areas]
    snow = []
    for i, pts in enumerate(flats):
        if not is_hole[i] or len(pts) < 3:
            continue
        tx, ty = max(pts, key=lambda p: p[1])
        best, best_j = None, None
        for j, other in enumerate(flats):
            if j == i:
                continue
            n = len(other)
            for k in range(n):
                (x1, y1), (x2, y2) = other[k], other[(k + 1) % n]
                if (x1 - tx) * (x2 - tx) > 0 or x1 == x2:
                    continue
                y = y1 + (y2 - y1) * (tx - x1) / (x2 - x1)
                if y > ty and (best is None or y < best):
                    best, best_j = y, j
        if best is not None and not is_hole[best_j] and best - ty <= max_gap:
            snow.append(i)
    return snow


def _simplified(path):
    path.fillType = pathops.FillType.WINDING
    path.simplify(fix_winding=True)
    return path


def extrusion_path(contours, dx, dy):
    """The letter swept from where it is to (dx, dy) away: the letter,
    its moved copy, and a four-sided strip joining every edge to its moved
    copy, all merged into one outline. Merged step by step (letter + copy
    first, then each contour's strips), so one awkward spot can't spoil
    the whole letter; a piece that won't merge is kept as-is - every
    piece is wound the same way, so overlaps just fill, it's only a
    little bigger in the file."""
    outer_sign = 1 if max((signed_area(c) for c in contours), key=abs) > 0 else -1
    body = pathops.Path()
    pen = body.getPen()
    for c in contours:
        replay(c, pen)
        replay(c, TransformPen(pen, (1, 0, 0, 1, dx, dy)))
    try:
        result = _simplified(body)
    except pathops.PathOpsError:
        result = body
        STATS["unmerged"] += 1
    raw = pathops.Path()
    for c in contours:
        flat = FlattenPen(steps=6)
        replay(c, flat)
        for pts in flat.contours:
            quads = []
            n = len(pts)
            for k in range(n):
                p, q = pts[k], pts[(k + 1) % n]
                if math.dist(p, q) < 0.5:
                    continue
                quad = [p, q, (q[0] + dx, q[1] + dy), (p[0] + dx, p[1] + dy)]
                a = sum(quad[m][0] * quad[(m + 1) % 4][1] - quad[(m + 1) % 4][0] * quad[m][1] for m in range(4))
                if abs(a) < 1.0:
                    continue
                if (a > 0) != (outer_sign > 0):
                    quad.reverse()
                quads.append(quad)
            for chunk in (quads[i:i + 64] for i in range(0, len(quads), 64)):
                strip = pathops.Path()
                sp = strip.getPen()
                for quad in chunk:
                    sp.moveTo(quad[0])
                    for pt in quad[1:]:
                        sp.lineTo(pt)
                    sp.closePath()
                try:
                    result = pathops.op(result, _simplified(strip), pathops.PathOp.UNION, fix_winding=True)
                except pathops.PathOpsError:
                    rp = raw.getPen()
                    for quad in chunk:
                        rp.moveTo(quad[0])
                        for pt in quad[1:]:
                            rp.lineTo(pt)
                        rp.closePath()
                    STATS["unmerged"] += 1
    if len(raw):
        out = pathops.Path()
        op_ = out.getPen()
        result.draw(op_)
        raw.draw(op_)
        return out
    return result


STATS = {"unmerged": 0}


def to_ttglyph(draw, glyphset):
    tt = TTGlyphPen(glyphset)
    draw(Cu2QuPen(tt, max_err=1.0, reverse_direction=False))
    return tt.glyph()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--color", type=parse_hex, help='main color, e.g. "#ff6600" (3D mode)')
    ap.add_argument("--shadow", action="store_true",
                    help="make a shadow font (drop shadow + gloss, letters take the clock's color) "
                         "instead of a 3D one")
    ap.add_argument("--shadow-offset", type=float, default=0.07,
                    help="shadow offset as a fraction of the font's height (default 0.07, the "
                         "same as the clock's own drawn shadow)")
    ap.add_argument("--snow", action="store_true",
                    help="(with --shadow) fill snow-cap holes just under the letter's top edge "
                         "with white, e.g. Snowtop Caps - see find_snow()")
    ap.add_argument("--family", help='new family name (default: "<original> 3D" / "<original> Shadow")')
    ap.add_argument("--depth", type=float, default=0.07,
                    help="extrusion depth as a fraction of the font's height (default 0.07)")
    ap.add_argument("--bands", type=int, default=4,
                    help="extrusion shading steps, darker further back (default 4)")
    ap.add_argument("--shine-width", type=float, default=0.03,
                    help="holes thinner than this (fraction of font height) count as shine "
                         "and get filled (default 0.03); 0 turns shine filling off")
    ap.add_argument("--shine-sliver-from", type=float,
                    help="(with a wider --shine-width) holes wider than this only count as shine when "
                         "they're long slivers - see --shine-min-elong (default: off)")
    ap.add_argument("--shine-min-elong", type=float, default=25.0,
                    help="perimeter^2/area a hole wider than --shine-sliver-from needs (default 25)")
    ap.add_argument("--shine-color", type=parse_hex,
                    help='color the shine holes are filled with, e.g. "#ffffff" (default: a light tint of --color)')
    args = ap.parse_args()
    if not args.shadow and args.color is None:
        ap.error("--color is required (or use --shadow)")

    font = TTFont(args.input)
    if "glyf" not in font:
        sys.exit("only TrueType-outline fonts (.ttf with a glyf table) are supported")
    if "COLR" in font or "SVG " in font or "CBDT" in font or "sbix" in font:
        sys.exit("this font already has built-in colors - nothing to do")

    upm = font["head"].unitsPerEm
    glyphset = font.getGlyphSet()
    cmap = font.getBestCmap()
    order = font.getGlyphOrder()
    glyf, hmtx = font["glyf"], font["hmtx"]

    top = None
    for ch in "8H0":
        if ord(ch) in cmap:
            bp = BoundsPen(glyphset)
            glyphset[cmap[ord(ch)]].draw(bp)
            if bp.bounds:
                top = bp.bounds[3]
                break
    if top is None:
        top = getattr(font.get("OS/2"), "sCapHeight", 0) or upm * 0.7

    base = args.color or (1, 1, 1)
    palette = [
        mix(base, WHITE, 0.35),
        base,
        mix(base, BLACK, 0.45),
        args.shine_color or mix(base, WHITE, 0.75),
    ]
    bands = max(1, args.bands)
    for b in range(bands):
        palette.append(mix(base, BLACK, 0.55 + 0.30 * b / max(1, bands - 1)))
    depth = args.depth * upm
    BLACK_I = len(palette)
    palette += [BLACK, WHITE]
    SNOW_I = len(palette)
    palette += [WHITE, mix((0.80, 0.90, 1.0), WHITE, 0.2)]
    snow_count = 0
    FOREGROUND = 0xFFFF
    shadow_off = int(round(args.shadow_offset * upm))
    step = depth / math.sqrt(2) / bands

    new_glyphs = {}
    color_glyphs = {}
    clip_boxes = {}
    shine_count = 0
    for gname in order:
        rec = DecomposingRecordingPen(glyphset)
        glyphset[gname].draw(rec)
        contours = [c for c in split_contours(rec.value) if len(c) > 2]
        if not contours:
            continue
        if args.shadow:
            glyph_paint = lambda paint, g=gname: {"Format": ot.PaintFormat.PaintGlyph, "Glyph": g, "Paint": paint}
            snow_name = None
            if args.snow:
                snow = find_snow(contours, 0.06 * upm)
                if snow:
                    snow = find_snow(contours, 0.15 * upm)
                if snow:
                    snow_count += 1
                    snow_name = f"{gname}.snow"
                    sel = [contours[i] for i in snow]
                    new_glyphs[snow_name] = (to_ttglyph(lambda pen: [replay(c, pen) for c in sel], glyphset),
                                             hmtx[gname][0])
            shadow_layers = [{"Format": ot.PaintFormat.PaintTranslate, "dx": shadow_off, "dy": -shadow_off,
                              "Paint": glyph_paint({"Format": ot.PaintFormat.PaintSolid, "PaletteIndex": BLACK_I, "Alpha": 1.0}, g)}
                             for g in ([gname, snow_name] if snow_name else [gname])]
            snow_layers = [glyph_paint({"Format": ot.PaintFormat.PaintLinearGradient,
                                        "ColorLine": {"Extend": "pad", "ColorStop": [
                                            {"StopOffset": 0.0, "PaletteIndex": SNOW_I, "Alpha": 1.0},
                                            {"StopOffset": 1.0, "PaletteIndex": SNOW_I + 1, "Alpha": 1.0}]},
                                        "x0": 0, "y0": int(top), "x1": 0, "y1": int(top - 0.45 * upm),
                                        "x2": upm, "y2": int(top)}, snow_name)] if snow_name else []
            color_glyphs[gname] = {"Format": ot.PaintFormat.PaintColrLayers, "Layers": shadow_layers + [
                glyph_paint({"Format": ot.PaintFormat.PaintSolid, "PaletteIndex": FOREGROUND, "Alpha": 1.0}),
                glyph_paint({"Format": ot.PaintFormat.PaintLinearGradient,
                             "ColorLine": {"Extend": "pad", "ColorStop": [
                                 {"StopOffset": 0.0, "PaletteIndex": BLACK_I + 1, "Alpha": 0.40},
                                 {"StopOffset": 0.45, "PaletteIndex": BLACK_I + 1, "Alpha": 0.0},
                                 {"StopOffset": 0.55, "PaletteIndex": BLACK_I, "Alpha": 0.0},
                                 {"StopOffset": 1.0, "PaletteIndex": BLACK_I, "Alpha": 0.45}]},
                             "x0": 0, "y0": int(top), "x1": 0, "y1": 0, "x2": upm, "y2": int(top)}),
            ] + snow_layers}
            bp = BoundsPen(glyphset)
            glyphset[gname].draw(bp)
            if bp.bounds:
                x0, y0, x1, y1 = bp.bounds
                clip_boxes[gname] = (int(math.floor(x0)), int(math.floor(y0 - shadow_off)),
                                     int(math.ceil(x1 + shadow_off)), int(math.ceil(y1)))
            continue
        layers = []
        ext_bounds = None
        for b in range(bands, 0, -1):
            path = extrusion_path(contours, step * b, -step * b)
            name = f"{gname}.3dx{b}"
            new_glyphs[name] = (to_ttglyph(path.draw, glyphset), hmtx[gname][0])
            layers.append({"Format": ot.PaintFormat.PaintGlyph, "Glyph": name,
                           "Paint": {"Format": ot.PaintFormat.PaintSolid,
                                     "PaletteIndex": 4 + b - 1, "Alpha": 1.0}})
            if b == bands:
                ext_bounds = path.bounds
        layers.append({"Format": ot.PaintFormat.PaintGlyph, "Glyph": gname,
                       "Paint": {"Format": ot.PaintFormat.PaintLinearGradient,
                                 "ColorLine": {"Extend": "pad", "ColorStop": [
                                     {"StopOffset": 0.0, "PaletteIndex": 0, "Alpha": 1.0},
                                     {"StopOffset": 0.45, "PaletteIndex": 1, "Alpha": 1.0},
                                     {"StopOffset": 1.0, "PaletteIndex": 2, "Alpha": 1.0}]},
                                 "x0": 0, "y0": int(top), "x1": 0, "y1": 0,
                                 "x2": upm, "y2": int(top)}})
        if args.shine_width > 0:
            shine = find_shine(contours, args.shine_width * upm,
                               None if args.shine_sliver_from is None else args.shine_sliver_from * upm,
                               args.shine_min_elong)
            if shine:
                shine_count += 1
                name = f"{gname}.3ds"
                sel = [contours[i] for i in shine]
                new_glyphs[name] = (to_ttglyph(lambda pen: [replay(c, pen) for c in sel], glyphset),
                                    hmtx[gname][0])
                layers.append({"Format": ot.PaintFormat.PaintGlyph, "Glyph": name,
                               "Paint": {"Format": ot.PaintFormat.PaintSolid,
                                         "PaletteIndex": 3, "Alpha": 1.0}})
        color_glyphs[gname] = {"Format": ot.PaintFormat.PaintColrLayers, "Layers": layers}
        bp = BoundsPen(glyphset)
        glyphset[gname].draw(bp)
        if bp.bounds and ext_bounds:
            clip_boxes[gname] = (int(math.floor(min(bp.bounds[0], ext_bounds[0]))),
                                 int(math.floor(min(bp.bounds[1], ext_bounds[1]))),
                                 int(math.ceil(max(bp.bounds[2], ext_bounds[2]))),
                                 int(math.ceil(max(bp.bounds[3], ext_bounds[3]))))

    new_order = order + list(new_glyphs)
    font.setGlyphOrder(new_order)
    for name, (glyph, adv) in new_glyphs.items():
        glyf[name] = glyph
        glyph.recalcBounds(glyf)
        hmtx[name] = (adv, getattr(glyph, "xMin", 0))
    font["maxp"].numGlyphs = len(new_order)
    for tag in ("hdmx", "LTSH", "VDMX", "DSIG"):
        if tag in font:
            del font[tag]
    if "post" in font and font["post"].formatType == 2.0:
        font["post"].extraNames = []
        font["post"].mapping = {}

    font["COLR"] = buildCOLR(color_glyphs, version=1, clipBoxes=clip_boxes)
    font["CPAL"] = buildCPAL([[(r, g, b, 1.0) for r, g, b in palette]])

    name = font["name"]
    old_family = name.getDebugName(16) or name.getDebugName(1) or "Font"
    family = args.family or f"{old_family} {'Shadow' if args.shadow else '3D'}"
    ps = "".join(ch for ch in family if ch.isalnum()) + "-Regular"
    for nid in (16, 17, 21, 22):
        name.removeNames(nameID=nid)
    name.setName(family, 1, 3, 1, 0x409)
    name.setName("Regular", 2, 3, 1, 0x409)
    name.setName(f"{family}; made with PinClock make_3d_font.py", 3, 3, 1, 0x409)
    name.setName(family, 4, 3, 1, 0x409)
    name.setName(ps, 6, 3, 1, 0x409)
    for rec_ in list(name.names):
        if rec_.platformID == 1 and rec_.nameID in (1, 3, 4, 6):
            name.names.remove(rec_)

    font.save(args.output)

    preview = args.output + ".preview.html"
    with open(preview, "w", encoding="utf-8") as f:
        f.write(f"""<!doctype html><meta charset="utf-8"><title>{family}</title>
<style>@font-face{{font-family:'{family}';src:url('{os.path.basename(args.output)}')}}
body{{background:#000;color:{'#ff6600' if args.shadow else '#fff'};margin:24px;font-family:'{family}'}}
p{{font-size:120px;margin:10px 0}} small{{font:14px sans-serif;color:#999}}</style>
<small>{family} - preview (open in Chrome)</small>
<p>12:35:48 pm</p><p style="font-size:64px">0123456789 AM PM</p>
<p style="font-size:48px">ABCDEFGHIJKLM NOPQRSTUVWXYZ</p><p style="font-size:48px">Merry Christmas! Happy Halloween</p>
""")
    print(f"wrote {args.output}  ({family}; {len(color_glyphs)} color glyphs"
          + ("" if args.shadow else f", {shine_count} with shine")
          + (f", {snow_count} with snow caps" if args.snow else "")
          + f"; {os.path.getsize(args.output) // 1024} KB)")
    print(f"preview: {preview}")
    if STATS["unmerged"]:
        print(f"note: {STATS['unmerged']} extrusion piece(s) left unmerged (draws the same, slightly larger file)")


if __name__ == "__main__":
    main()
