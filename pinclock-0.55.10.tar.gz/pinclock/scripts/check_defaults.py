#!/usr/bin/env python3
""
import ast
import json
import re
import sys
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent.parent

SETTINGS_STORE = APP_DIR / "app" / "core" / "settings_store.py"
APP_PY = APP_DIR / "app.py"
TEMPLATES = {
    "display.html": APP_DIR / "app" / "templates" / "display.html",
    "control.html": APP_DIR / "app" / "templates" / "control.html",
}
JS_FILES = [
    APP_DIR / "app" / "static" / "js" / name
    for name in ("display.js", "renderer.js", "bars.js", "clock.js", "dmdfont.js", "ledfont.js", "messages.js", "reels.js", "ssdisplay.js")
]

INJECTION_LINE = "<script>window.PINCLOCK_DEFAULTS = {{ pinclock_defaults | tojson }};</script>"
CLOCK_TAB_LINE = "var CLOCK_MODE_DEFAULTS = {{ clock_mode_defaults | tojson }};"

PILL_ALLOWLIST = {
    "clock-size-value",
    "me-duration-value", "me-backdrop-value", "me-maxsize-value",
    "me-bsize-value", "me-bspeed-value",
    "reel-bg-x-value", "reel-bg-y-value", "reel-bg-s-value",
}

RETIRED_PATTERNS = [
    (re.compile(r"\bconst\s+DEFAULT_SETTINGS\s*=\s*\{"), "hand-written DEFAULT_SETTINGS object literal"),
    (re.compile(r"\bFX_CLOCK_SIZE_DEFAULT\b"), "FX_CLOCK_SIZE_DEFAULT constant (use PINCLOCK_DEFAULTS.fx_size)"),
    (re.compile(r"\bCLOCK_TAB_DEFAULTS\s*=\s*\{(?!\{)"), "hand-written CLOCK_TAB_DEFAULTS object literal"),
    (re.compile(r"\bCLOCK_MODE_DEFAULTS\s*=\s*\{(?!\{)"), "hand-written CLOCK_MODE_DEFAULTS object literal"),
]


def _read_python_defaults():
    ""
    tree = ast.parse(SETTINGS_STORE.read_text(), filename=str(SETTINGS_STORE))
    found = {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            name = node.targets[0].id
            if name in ("DEFAULT_SETTINGS", "CLOCK_TAB_KEYS", "EM_CLOCK_DEFAULTS", "CLOCK_PROFILE_KEYS"):
                found[name] = ast.literal_eval(node.value)
    missing = {"DEFAULT_SETTINGS", "CLOCK_TAB_KEYS", "EM_CLOCK_DEFAULTS", "CLOCK_PROFILE_KEYS"} - found.keys()
    _EXTRA.update(em=found["EM_CLOCK_DEFAULTS"], profile_keys=list(found["CLOCK_PROFILE_KEYS"]))
    if missing:
        raise RuntimeError(f"couldn't find {sorted(missing)} as literal assignments in {SETTINGS_STORE}")
    return found["DEFAULT_SETTINGS"], tuple(found["CLOCK_TAB_KEYS"])


_EXTRA = {}


def _line_of(text, index):
    return text.count("\n", 0, index) + 1


def _rel(path):
    return path.relative_to(APP_DIR).as_posix()


def run_checks():
    ""
    problems = []

    try:
        defaults, clock_tab_keys = _read_python_defaults()
    except Exception as e:
        return [f"{_rel(SETTINGS_STORE)}: {e}"]

    unknown = [k for k in clock_tab_keys if k not in defaults]
    if unknown:
        problems.append(f"{_rel(SETTINGS_STORE)}: CLOCK_TAB_KEYS has keys not in DEFAULT_SETTINGS: {unknown}")

    app_src = APP_PY.read_text()
    for tpl in TEMPLATES:
        pat = re.compile(r'render_template\(\s*"' + re.escape(tpl) + r'"[^)]*\*\*_template_defaults\(\)')
        if not pat.search(app_src):
            problems.append(f"app.py: render_template(\"{tpl}\", ...) no longer passes **_template_defaults()")

    template_src = {name: path.read_text() for name, path in TEMPLATES.items()}
    for name, src in template_src.items():
        inj = src.find(INJECTION_LINE)
        if inj < 0:
            problems.append(f"{_rel(TEMPLATES[name])}: missing the window.PINCLOCK_DEFAULTS injection line:\n      {INJECTION_LINE}")
            continue
        first_src_script = re.search(r"<script\s+src=", src)
        if first_src_script and first_src_script.start() < inj:
            problems.append(
                f"{_rel(TEMPLATES[name])}:{_line_of(src, first_src_script.start())}: a <script src=...> loads before the "
                f"PINCLOCK_DEFAULTS injection (line {_line_of(src, inj)}) - it must come first"
            )

    if CLOCK_TAB_LINE not in template_src["control.html"]:
        problems.append(f"{_rel(TEMPLATES['control.html'])}: missing the rendered reset-defaults line:\n      {CLOCK_TAB_LINE}")

    scan_targets = [(p, p.read_text()) for p in JS_FILES if p.exists()]
    scan_targets += [(TEMPLATES[n], template_src[n]) for n in TEMPLATES]
    for path, src in scan_targets:
        for pat, what in RETIRED_PATTERNS:
            for m in pat.finditer(src):
                problems.append(f"{_rel(path)}:{_line_of(src, m.start())}: {what}")

    keys_alt = "|".join(sorted(map(re.escape, defaults), key=len, reverse=True))
    literal = r"""(?:-?\d|"[^"]|'[^']|true\b|false\b)"""
    fallback_pats = [
        re.compile(r"\.(" + keys_alt + r")\b\s*(?:\|\||\?\?)\s*" + literal),
        re.compile(r"\.(" + keys_alt + r")\b\s*!==?\s*undefined\s*\?[^:;]*:\s*" + literal),
    ]
    for path, src in scan_targets:
        for pat in fallback_pats:
            for m in pat.finditer(src):
                line_start = src.rfind("\n", 0, m.start()) + 1
                if src[line_start:m.start()].lstrip().startswith("//"):
                    continue
                problems.append(
                    f"{_rel(path)}:{_line_of(src, m.start())}: literal fallback for setting "
                    f"'{m.group(1)}' - use PINCLOCK_DEFAULTS.{m.group(1)}"
                )

    ctrl = template_src["control.html"]
    for m in re.finditer(r'<span class="value-pill" id="([^"]+)">([^<]*)</span>', ctrl):
        pid, content = m.group(1), m.group(2)
        if pid in PILL_ALLOWLIST:
            continue
        if "{{" not in content:
            problems.append(
                f"{_rel(TEMPLATES['control.html'])}:{_line_of(ctrl, m.start())}: value pill #{pid} has hardcoded text "
                f"'{content}' - render it from pinclock_defaults (or add it to PILL_ALLOWLIST with a reason)"
            )

    for name, src in template_src.items():
        for m in re.finditer(r"[Dd]efault(?: is|:)\s*\d", src):
            problems.append(
                f"{_rel(TEMPLATES[name])}:{_line_of(src, m.start())}: hint states a default as a literal number - "
                f"render it from pinclock_defaults"
            )

    problems.extend(_render_check(defaults, clock_tab_keys))
    return problems


def _render_check(defaults, clock_tab_keys):
    try:
        import jinja2
    except ImportError:
        print("note: jinja2 not installed - skipped the template render check")
        return []

    problems = []
    env = jinja2.Environment(loader=jinja2.FileSystemLoader(str(TEMPLATES["display.html"].parent)))
    ctx = {
        "v": "check",
        "pinclock_defaults": defaults,
        "clock_tab_defaults": {k: defaults[k] for k in clock_tab_keys if k in defaults},
    }
    tt = dict(ctx["clock_tab_defaults"], videos_enabled=defaults.get("videos_enabled"), clock_style="truetype")
    ctx["clock_mode_defaults"] = {"truetype": tt, "reels": dict(tt, **_EXTRA.get("em", {}))}
    ctx["clock_profile_keys"] = _EXTRA.get("profile_keys", [])
    for name in TEMPLATES:
        try:
            html = env.get_template(name).render(**ctx)
        except Exception as e:
            problems.append(f"{_rel(TEMPLATES[name])}: failed to render: {e}")
            continue
        m = re.search(r"<script>window\.PINCLOCK_DEFAULTS = (.*?);</script>", html, re.S)
        if not m:
            problems.append(f"{_rel(TEMPLATES[name])}: rendered output has no PINCLOCK_DEFAULTS assignment")
            continue
        try:
            emitted = json.loads(m.group(1))
        except json.JSONDecodeError as e:
            problems.append(f"{_rel(TEMPLATES[name])}: rendered PINCLOCK_DEFAULTS isn't valid JSON: {e}")
            continue
        if emitted != defaults:
            problems.append(f"{_rel(TEMPLATES[name])}: rendered PINCLOCK_DEFAULTS doesn't match DEFAULT_SETTINGS")
        html = re.sub(r"var CLOCK_MODE_DEFAULTS = \{.*?\};\n", "", html)
        if "{{" in html or "}}" in html:
            problems.append(f"{_rel(TEMPLATES[name])}: rendered output still contains '{{{{' or '}}}}' - a template expression didn't render")
    return problems


def main():
    problems = run_checks()
    if problems:
        print(f"check_defaults: {len(problems)} problem(s) - settings defaults must only live in "
              f"settings_store.DEFAULT_SETTINGS:", file=sys.stderr)
        for p in problems:
            print(f"  - {p}", file=sys.stderr)
        return 1
    print("check_defaults: OK - no hardcoded copies of settings defaults found")
    return 0


if __name__ == "__main__":
    sys.exit(main())
