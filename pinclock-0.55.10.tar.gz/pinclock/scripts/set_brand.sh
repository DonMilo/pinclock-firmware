#!/bin/sh

BRAND_FILE=/home/vfw/pinclock-data/brand

show_markers() {
    for d in /boot/firmware /boot; do
        for f in pinclock-generic pinclock-generic.txt pinclock-pinballlife pinclock-pinballlife.txt; do
            if [ -e "$d/$f" ]; then
                echo "NOTE: $d/$f exists on the boot partition - it overrides $BRAND_FILE."
            fi
        done
    done
}

case "$(printf '%s' "$1" | tr 'A-Z' 'a-z')" in
    "")
        if [ -f "$BRAND_FILE" ]; then
            echo "$BRAND_FILE says: $(sed -e 's/#.*//' "$BRAND_FILE" | awk 'NF { print $1; exit }')"
        else
            echo "$BRAND_FILE not set - this clock is generic (the default since v0.40.1)."
        fi
        show_markers
        exit 0
        ;;
    generic|unbranded) BRAND=generic ;;
    pinballlife|pinball-life|branded) BRAND=pinballlife ;;
    *)
        echo "usage: $0 [generic|pinballlife]" >&2
        exit 2
        ;;
esac

mkdir -p "$(dirname "$BRAND_FILE")"
printf '%s\n# set by set_brand.sh, %s\n' "$BRAND" "$(date '+%Y-%m-%d %H:%M:%S')" >"$BRAND_FILE.tmp" &&
    mv "$BRAND_FILE.tmp" "$BRAND_FILE" || { echo "could not write $BRAND_FILE" >&2; exit 1; }
# the app can update it (a brand override from the update server).
if [ "$(id -u)" = "0" ] && id vfw >/dev/null 2>&1; then
    chown vfw:vfw "$BRAND_FILE"
fi
echo "Brand set to $BRAND ($BRAND_FILE). The boot splash changes at the next reboot."
show_markers
