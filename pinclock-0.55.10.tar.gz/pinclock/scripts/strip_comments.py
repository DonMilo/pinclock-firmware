"""
PinClock - comment stripping for release builds (build_release.py --strip).

Removes comments from a COPY of the release tree so the shipped code is
harder to read. Never touches the source tree - build_release.py copies
the files into a temporary directory first and packages that copy.

What it strips, and how each change is verified before it is kept:

  *.py            # comments and docstrings. Verified by parsing the file
                  before and after and requiring an identical syntax tree
                  (docstrings compared as empty). Files that mention
                  __doc__ (they print their own docstring as help text,
                  e.g. build_release.py, subset_fonts.py) keep their
                  docstrings. The shebang and an encoding line are kept.
  *.js            // and /* */ comments. Needs Node.js on the build
                  machine: a file is only replaced if `node --check`
                  passes on both the original and the stripped version.
                  Without Node, JS is left as-is (reported as skipped).
  *.css           /* */ comments. Verified by an unchanged count of
                  braces, parentheses, quotes and semicolons.
  *.html          <!-- --> and Jinja {# #} comments, plus the comments in
                  inline <style> (as CSS) and inline <script> (as JS, same
                  Node check, with Jinja {{ }} / {% %} neutralised for the
                  check). A script block that doesn't pass the check is
                  left as it was.

Never stripped: anything under vendor/, *.min.js, fonts and licenses,
data files (known-displays, default-resolution, ...), the labwc
`environment` file. v0.50.8: shell scripts (*.sh, autostart,
autostart-legacy) ARE stripped - comment lines and trailing comments,
verified with `bash --pretty-print` (bash 5.2+; without it they're left
as they are and reported).

A file whose stripped version fails verification is left unstripped and
listed in the report - a bad strip can never reach the package.

Standalone use (makes a stripped copy of a whole tree):
    python3 scripts/strip_comments.py <source_dir> <dest_dir>
"""
import ast
import io
import re
import os
import shutil
import subprocess
import sys
import tempfile
import tokenize
from pathlib import Path

SKIP_DIR_NAMES = {"vendor", "fonts", "LICENSES", "__pycache__"}
SKIP_FILE_PATTERNS = (re.compile(r"\.min\.js$"),)


def _apply_edits(text, edits):
    """edits: list of (start, end, replacement) absolute char offsets,
    non-overlapping. Applied back to front so offsets stay valid."""
    for start, end, repl in sorted(edits, key=lambda e: e[0], reverse=True):
        text = text[:start] + repl + text[end:]
    return text


def _comment_edit(text, start, end, block=False):
    """Edit that removes the comment text[start:end]. If the comment is
    the only thing on its line(s), the whole line goes (newline too).
    Otherwise the comment and the whitespace before it are removed; a
    /* */ comment that spanned lines becomes a newline, so JS's
    automatic semicolon insertion sees the same line break as before."""
    line_start = text.rfind("\n", 0, start) + 1
    line_end = text.find("\n", end)
    if line_end == -1:
        line_end = len(text)
    before = text[line_start:start]
    after = text[end:line_end]
    if before.strip() == "" and after.strip() == "":
        return (line_start, min(line_end + 1, len(text)), "")
    ws_start = start
    while ws_start > line_start and text[ws_start - 1] in " \t":
        ws_start -= 1
    if block:
        if "\n" in text[start:end]:
            return (ws_start, end, "\r\n" if "\r\n" in text[start:end] else "\n")
        if after.strip() == "":
            return (ws_start, end, "")
        return (start, end, " ")
    return (ws_start, end, "")


def _docstring_nodes(tree):
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            body = getattr(node, "body", None)
            if body and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant) \
                    and isinstance(body[0].value.value, str):
                yield body[0].value


def _blank_docstrings(tree):
    for c in _docstring_nodes(tree):
        c.value = ""
    return tree


def strip_python(src):
    """Returns (stripped_source, None) or (None, reason)."""
    try:
        tree = ast.parse(src)
    except SyntaxError as e:
        return None, f"doesn't parse: {e}"
    lines = src.splitlines(keepends=True)
    line_starts = [0]
    for ln in lines:
        line_starts.append(line_starts[-1] + len(ln))

    def offset(row, char_col):
        return line_starts[row - 1] + char_col

    def byte_to_char(row, byte_col):
        return len(lines[row - 1].encode("utf-8")[:byte_col].decode("utf-8", errors="ignore"))

    edits = []
    keep_docstrings = "__doc__" in src
    if not keep_docstrings:
        for c in _docstring_nodes(tree):
            start = offset(c.lineno, byte_to_char(c.lineno, c.col_offset))
            end = offset(c.end_lineno, byte_to_char(c.end_lineno, c.end_col_offset))
            edits.append((start, end, '""'))

    try:
        tokens = list(tokenize.generate_tokens(io.StringIO(src).readline))
    except (tokenize.TokenError, SyntaxError) as e:
        return None, f"tokenize failed: {e}"
    for tok in tokens:
        if tok.type != tokenize.COMMENT:
            continue
        row, col = tok.start
        if row <= 2 and (tok.string.startswith("#!") or re.match(r"#.*coding[:=]", tok.string)):
            continue
        start = offset(row, col)
        edits.append(_comment_edit(src, start, start + len(tok.string)))

    out = _apply_edits(src, _dedupe(edits))
    try:
        before = ast.dump(_blank_docstrings(ast.parse(src)) if not keep_docstrings else ast.parse(src))
        after = ast.dump(_blank_docstrings(ast.parse(out)) if not keep_docstrings else ast.parse(out))
    except SyntaxError as e:
        return None, f"stripped version doesn't parse: {e}"
    if before != after:
        return None, "stripped version's syntax tree differs"
    return out, None


def _dedupe(edits):
    """Whole-line removals of adjacent comment lines can't overlap, but
    guard anyway: drop any edit overlapping an earlier-starting one."""
    result, last_end = [], -1
    for e in sorted(edits, key=lambda e: e[0]):
        if e[0] >= last_end:
            result.append(e)
            last_end = e[1]
    return result


_REGEX_AFTER = set("(,=:[!&|?{};+-*%<>~^")
_REGEX_KEYWORDS = {"return", "typeof", "instanceof", "in", "of", "new", "delete", "void",
                   "throw", "case", "do", "else", "yield", "await"}


def _js_comment_spans(src):
    """Lexes JS just enough to find comments: skips strings, template
    literals (including nested ${ } code), and regex literals (decided by
    the previous significant token). Returns [(start, end, is_block)]."""
    spans = []
    i, n = 0, len(src)
    last = ""
    stack = []
    depth = 0
    while i < n:
        c = src[i]
        if c in " \t\r\n":
            i += 1
            continue
        if c == "/" and i + 1 < n and src[i + 1] == "/":
            j = src.find("\n", i)
            j = n if j == -1 else j
            if j > i and src[j - 1] == "\r":
                j -= 1
            spans.append((i, j, False))
            i = j
            continue
        if c == "/" and i + 1 < n and src[i + 1] == "*":
            j = src.find("*/", i + 2)
            if j == -1:
                raise ValueError("unterminated /* comment")
            spans.append((i, j + 2, True))
            i = j + 2
            continue
        if c in "'\"":
            j = i + 1
            while j < n and src[j] != c:
                if src[j] == "\\":
                    j += 1
                elif src[j] == "\n":
                    raise ValueError("newline in string")
                j += 1
            i = j + 1
            last = "str"
            continue
        if c == "`" or (c == "}" and stack and depth == stack[-1]):
            if c == "}":
                stack.pop()
                depth -= 1
            j = i + 1
            while j < n:
                if src[j] == "\\":
                    j += 2
                    continue
                if src[j] == "`":
                    break
                if src[j] == "$" and j + 1 < n and src[j + 1] == "{":
                    break
                j += 1
            if j >= n:
                raise ValueError("unterminated template literal")
            if src[j] == "`":
                i = j + 1
                last = "str"
            else:
                depth += 1
                stack.append(depth)
                i = j + 2
                last = "{"
            continue
        if c == "/":
            prev_is_word = re.match(r"[A-Za-z_$][\w$]*$", last) is not None
            if last == "" or last in _REGEX_AFTER or last == "}" or (prev_is_word and last in _REGEX_KEYWORDS):
                j, in_class, is_regex = i + 1, False, True
                while j < n:
                    ch = src[j]
                    if ch == "\\":
                        j += 2
                        continue
                    if ch == "\n":
                        is_regex = False
                        break
                    if ch == "[":
                        in_class = True
                    elif ch == "]":
                        in_class = False
                    elif ch == "/" and not in_class:
                        break
                    j += 1
                if not is_regex or j >= n:
                    i += 1
                    last = "/"
                    continue
                j += 1
                while j < n and (src[j].isalnum() or src[j] == "_"):
                    j += 1
                i = j
                last = "regex"
                continue
            i += 1
            last = "/"
            continue
        m = re.compile(r"[A-Za-z_$][\w$]*|\d[\w.]*").match(src, i)
        if m:
            last = m.group(0)
            i = m.end()
            continue
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
        last = c
        i += 1
    return spans


def strip_js_text(src):
    spans = _js_comment_spans(src)
    return _apply_edits(src, _dedupe([_comment_edit(src, s, e, block=b) for s, e, b in spans]))


def _node():
    return shutil.which("node")


def _node_check(code):
    with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False, encoding="utf-8") as f:
        f.write(code)
        path = f.name
    try:
        return subprocess.run([_node(), "--check", path], capture_output=True).returncode == 0
    finally:
        Path(path).unlink(missing_ok=True)


def strip_js(src):
    if not _node():
        return None, "Node.js not found - JS left unstripped (install Node to strip JS)"
    if not _node_check(src):
        return None, "original doesn't pass node --check"
    try:
        out = strip_js_text(src)
    except ValueError as e:
        return None, f"lexer: {e}"
    if not _node_check(out):
        return None, "stripped version fails node --check"
    return out, None


_CSS_SIGNATURE = re.compile(r"""[{}();"']""")


def strip_css(src):
    edits, i, n = [], 0, len(src)
    while i < n:
        c = src[i]
        if c in "'\"":
            j = i + 1
            while j < n and src[j] != c:
                j += 2 if src[j] == "\\" else 1
            i = j + 1
            continue
        if src.startswith("/*", i):
            j = src.find("*/", i + 2)
            if j == -1:
                return None, "unterminated /* comment"
            edits.append(_comment_edit(src, i, j + 2, block=True))
            i = j + 2
            continue
        i += 1
    out = _apply_edits(src, _dedupe(edits))
    strip_all = lambda s: re.sub(r"/\*.*?\*/", "", s, flags=re.S)
    if _CSS_SIGNATURE.findall(strip_all(src)) != _CSS_SIGNATURE.findall(out):
        return None, "structure check failed"
    return out, None


_BLOCK_RE = re.compile(r"(<script\b[^>]*>)(.*?)(</script>)|(<style\b[^>]*>)(.*?)(</style>)", re.S | re.I)


def _neutralise_jinja(code):
    code = re.sub(r"\{\{.*?\}\}", "0", code, flags=re.S)
    code = re.sub(r"\{%.*?%\}", "", code, flags=re.S)
    return re.sub(r"\{#.*?#\}", "", code, flags=re.S)


def strip_html(src):
    """Returns (stripped, notes) - never fails as a whole; blocks that
    can't be verified are kept as they were and noted."""
    notes, parts, pos = [], [], 0
    for m in _BLOCK_RE.finditer(src):
        parts.append(("html", src[pos:m.start()]))
        if m.group(1):
            open_tag, body, close = m.group(1), m.group(2), m.group(3)
            new_body = body
            if "src=" not in open_tag.lower() and body.strip():
                if not _node():
                    notes.append("inline <script> kept: Node.js not found")
                else:
                    try:
                        cand = strip_js_text(body)
                        if _node_check(_neutralise_jinja(body)) and _node_check(_neutralise_jinja(cand)):
                            new_body = cand
                        else:
                            notes.append("an inline <script> kept: didn't pass node --check")
                    except ValueError as e:
                        notes.append(f"an inline <script> kept: lexer: {e}")
            parts.append(("raw", open_tag + new_body + close))
        else:
            open_tag, body, close = m.group(4), m.group(5), m.group(6)
            cand, err = strip_css(body)
            if err:
                notes.append(f"a <style> kept: {err}")
                cand = body
            parts.append(("raw", open_tag + cand + close))
        pos = m.end()
    parts.append(("html", src[pos:]))

    out = []
    for kind, text in parts:
        if kind == "html":
            edits = [_comment_edit(text, m.start(), m.end(), block=True)
                     for m in re.finditer(r"<!--.*?-->|\{#.*?#\}", text, re.S)]
            text = _apply_edits(text, _dedupe(edits))
        out.append(text)
    return "".join(out), notes



SHELL_NAMES = {"autostart", "autostart-legacy"}
_HEREDOC_RE = re.compile(r"<<-?\s*(['\"]?)([A-Za-z_][A-Za-z0-9_]*)\1")
_bash_ok = None
_bash_path = None


def _find_bash():
    """A bash that can read our temp files: $PINCLOCK_BASH if set, else
    `bash` on the PATH (not Windows' WSL launcher in System32 / WindowsApps,
    which can't see Windows paths), else - on Windows - Git for Windows'
    bash in its usual places (Git 2.41+ ships bash 5.2). v0.54.5: it used to
    look only on the PATH, where Git's bash usually isn't."""
    env = os.environ.get("PINCLOCK_BASH")
    if env and Path(env).is_file():
        return env
    b = shutil.which("bash")
    win = sys.platform.startswith("win")
    if b and not (win and Path(b).parent.name.lower() in ("system32", "windowsapps")):
        return b
    if win:
        roots = [os.environ.get(k) for k in ("ProgramFiles", "ProgramW6432", "ProgramFiles(x86)")]
        roots.append(os.path.join(os.environ.get("LOCALAPPDATA") or "", "Programs"))
        git = shutil.which("git")
        if git:
            roots.append(str(Path(git).parent.parent.parent))
        for root in roots:
            if not root:
                continue
            for sub in (("Git", "bin", "bash.exe"), ("Git", "usr", "bin", "bash.exe")):
                cand = Path(root, *sub)
                if cand.is_file():
                    return str(cand)
    return None


def _bash_pretty(text):
    """bash --pretty-print of text, or None if bash can't (missing / old /
    a parse error)."""
    global _bash_ok
    if _bash_ok is None:
        _bash_ok = True
        if (_bash_pretty("# test\necho ok\n") or "").strip() != "echo ok":
            _bash_ok = False
    if _bash_ok is False:
        return None
    global _bash_path
    if _bash_path is None:
        _bash_path = _find_bash() or ""
    bash = _bash_path
    if not bash:
        _bash_ok = False
        return None
    with tempfile.NamedTemporaryFile("w", suffix=".sh", delete=False, encoding="utf-8", newline="") as f:
        f.write(text)
        tmp = f.name
    try:
        r = subprocess.run([bash, "--pretty-print", tmp], capture_output=True, text=True, timeout=30)
    except (OSError, subprocess.SubprocessError):
        return None
    finally:
        try:
            Path(tmp).unlink()
        except OSError:
            pass
    if r.returncode != 0:
        return None
    return r.stdout


def _shell_candidates(lines):
    """(full-line comment indexes, {index: trailing-comment start})."""
    full, trailing = [], {}
    heredoc = None
    prev_cont = False
    for i, raw in enumerate(lines):
        line = raw.rstrip("\r\n")
        if heredoc is not None:
            if line.lstrip("\t") == heredoc:
                heredoc = None
            prev_cont = False
            continue
        stripped = line.lstrip()
        if i == 0 and line.startswith("#!"):
            pass
        elif stripped.startswith("#") and not prev_cont:
            full.append(i)
        else:
            q, esc = None, False
            for j, ch in enumerate(line):
                if esc:
                    esc = False
                    continue
                if ch == "\\" and q != "'":
                    esc = True
                    continue
                if q:
                    if ch == q:
                        q = None
                    continue
                if ch in "'\"`":
                    q = ch
                    continue
                if ch == "#" and j > 0 and line[j - 1] in " \t" and line[:j].strip():
                    trailing[i] = j
                    break
            m = _HEREDOC_RE.search(line)
            if m and "<<<" not in line:
                heredoc = m.group(2)
        prev_cont = line.endswith("\\") and not line.endswith("\\\\")
    return full, trailing


def _shell_apply(lines, drop, cut):
    out = []
    for i, raw in enumerate(lines):
        if i in drop:
            continue
        if i in cut:
            end = raw[len(raw.rstrip("\r\n")):]
            raw = raw[:cut[i]].rstrip(" \t") + end
        out.append(raw)
    return "".join(out)


def strip_shell(src):
    """Returns (stripped, None) or (None, reason)."""
    want = _bash_pretty(src)
    if want is None:
        return None, ("bash 5.2+ not found - shell scripts left unstripped (install Git for Windows, "
                      "or set PINCLOCK_BASH to a bash 5.2+)" if _bash_ok is False
                      else "bash couldn't parse it - left unstripped")
    lines = src.splitlines(keepends=True)
    full, trailing = _shell_candidates(lines)
    if not full and not trailing:
        return src, None
    for drop, cut in ((set(full), trailing), (set(full), {})):
        out = _shell_apply(lines, drop, cut)
        if _bash_pretty(out) == want:
            return out, None
    drop, cut = set(), {}
    for i in full:
        if _bash_pretty(_shell_apply(lines, drop | {i}, cut)) == want:
            drop.add(i)
    for i, j in trailing.items():
        if _bash_pretty(_shell_apply(lines, drop, {**cut, i: j})) == want:
            cut[i] = j
    return _shell_apply(lines, drop, cut), None


def _eligible(rel_path):
    parts = Path(rel_path).parts
    if any(p in SKIP_DIR_NAMES for p in parts[:-1]):
        return False
    if any(p.search(rel_path) for p in SKIP_FILE_PATTERNS):
        return False
    return Path(rel_path).suffix in (".py", ".js", ".css", ".html", ".sh") or Path(rel_path).name in SHELL_NAMES


def strip_tree(root, rel_paths):
    """Strips eligible files under root IN PLACE (root must be a copy).
    Returns a report dict."""
    report = {"stripped": [], "skipped": [], "notes": [], "bytes_before": 0, "bytes_after": 0}
    for rel in rel_paths:
        if not _eligible(rel):
            continue
        path = Path(root) / rel
        with open(path, encoding="utf-8", newline="") as f:
            src = f.read()
        suffix = path.suffix
        if suffix == ".py":
            out, err = strip_python(src)
        elif suffix == ".js":
            out, err = strip_js(src)
        elif suffix == ".css":
            out, err = strip_css(src)
        elif suffix == ".sh" or path.name in SHELL_NAMES:
            out, err = strip_shell(src)
        else:
            out, notes = strip_html(src)
            err = None
            report["notes"] += [f"{rel}: {n}" for n in notes]
        if err:
            report["skipped"].append(f"{rel}: {err}")
            continue
        report["bytes_before"] += len(src.encode("utf-8"))
        report["bytes_after"] += len(out.encode("utf-8"))
        with open(path, "w", encoding="utf-8", newline="") as f:
            f.write(out)
        report["stripped"].append(rel)
    return report


def print_report(report):
    b, a = report["bytes_before"], report["bytes_after"]
    pct = (100 - a * 100 // b) if b else 0
    print(f"Stripped comments from {len(report['stripped'])} files ({b:,} -> {a:,} bytes, -{pct}%)")
    for line in report["skipped"]:
        print(f"  left unstripped: {line}")
    for line in report["notes"]:
        print(f"  note: {line}")


def main():
    if len(sys.argv) != 3:
        print(__doc__)
        sys.exit(2)
    src, dest = Path(sys.argv[1]), Path(sys.argv[2])
    if dest.exists():
        print(f"ERROR: {dest} already exists - refusing to overwrite", file=sys.stderr)
        sys.exit(1)
    shutil.copytree(src, dest, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    rels = [p.relative_to(dest).as_posix() for p in sorted(dest.rglob("*")) if p.is_file()]
    print_report(strip_tree(dest, rels))


if __name__ == "__main__":
    main()
