#!/usr/bin/env python3
"""
PinClock release packaging tool.

Run manually by a developer on their own machine - never on the Pi
itself, and never deployed to a device. Produces two things:

  1. pinclock-<version>.tar.gz  - upload this as a GitHub Release asset
  2. update-manifest.json        - commit + push this to the
                                    pinclock-firmware repo's default branch

Nothing here talks to GitHub's API or pushes anything automatically
(by design - see the project's step 3 design discussion): you run this
script, then upload/commit the two outputs yourself.

Usage:
    python3 scripts/build_release.py 0.9.0 \\
        --changelog "Fixes X, adds Y" \\
        [--min-upgrade-from 0.8.0] \\
        [--repo DonMilo/pinclock-firmware] \\
        [--output-dir dist] \\
        [--strip]

EM videos (v0.30.11, on request - they pushed a build past 120 MB):
  --compress-videos    re-encode em-videos/*.mp4 smaller in the packaged
                       copy (ffmpeg; same settings and cache rules as
                       make_stripped_copy.py --compress-videos - cache in
                       <output-dir>/.video-cache). Source never touched.
  --em-videos new      package only the EM videos not shipped before (new
                       names, or a changed file under an old name). What
                       was shipped is recorded in <output-dir>/
                       em-videos-shipped.json (--em-ledger to put it
                       elsewhere) after every build that packages any.
  --em-videos none     package no EM videos.  all (default) = every one.
  Clocks keep stock EM videos in /opt/pinclock/em-videos/ and never delete
  them, so leaving old ones out of a release is safe - IF the clock has
  the v0.28.19+ updater (opt-pinclock-updater/run_update.py, manual deploy)
  and installed the release that brought them. A clock with an older
  updater, one that skipped that release, or a new one set up from an older
  image needs one build with --em-videos all (or the files copied to
  /home/vfw/pinclock-data/em-videos/ by hand).

FIRMWARE AND CONTENT (v0.53.1) - --build:
  combined (default)  one firmware tarball with everything, as before.
  firmware            the firmware tarball WITHOUT the content below - much
                      smaller. Clocks then get their stock backglasses from
                      content updates (until then they keep showing the ones
                      the release they're running carried).
  content             only the content: <output-dir>/content/ =
                      content-manifest.json + files/<sha256> (one file per
                      distinct file, named by its checksum). Upload the whole
                      folder to the content address (default
                      https://digitalconcepts.net/pinclock/content/) - files/
                      first, the manifest LAST. Clocks download only files they
                      don't have; nothing already uploaded ever changes.
  separate            both of the above from the same tree.
  Content = shipped-backgrounds/ (pictures, .json, faceplates/), em-videos/
  *.mp4, shipped-videos/*, retired-stock-videos.json (app/core/
  content_update.py CONTENT rules - keep the two in step). READMEs in those
  folders stay with the firmware.
  --content-version   default: today's date and time (2026.11.05-1308)
  --content-changelog shown on the Device tab with "New content is available"
  --content-base-url  where files/ is served (default: the manifest's folder +
                      files/ on the clock - only needed for another place)
  --content-min-firmware  oldest firmware that may install it (default
                      0.53.1, the first that can; raise it when content needs
                      newer code - older clocks are told to update first)
  Bump --content-version for every content upload; a clock compares the
  files, so even a same-named version only downloads what changed.

FIRMWARE ON YOUR OWN SITE (v0.53.1):
  --release-base-url https://digitalconcepts.net/pinclock/firmware/
                      the tarball's address in update-manifest.json becomes
                      <base>pinclock-<version>.tar.gz instead of the GitHub
                      release asset. Put update-manifest.json beside it and
                      set the website's manifest_urls to it (config.php) - the
                      clock's updater accepts a manifest on digitalconcepts.net
                      (needs the 2026-10-27 updater, the same as a per-brand
                      repository) and downloads the tarball from wherever the
                      manifest says (https).

v0.41.0: releases are COMPILED by default (.pyc only - see
scripts/compile_pyc.py; must be built on a Pi). --source ships plain .py.

--strip packages a copy of the tree with code comments removed, so the
shipped code is harder to read - see scripts/strip_comments.py for what
is stripped and how every stripped file is verified. The source tree is
never modified. JavaScript is only stripped when Node.js is installed on
the machine running this script (it's needed to verify the result);
without Node, JS ships unstripped and the report says so.

The <version> argument must match PINCLOCK_VERSION in app.py (after
stripping a leading "v") - this is deliberate and not just a sanity
check: it forces the version to actually be bumped in the source before
a release can be cut, so there's no way to publish a tarball whose
contents disagree with what the running device will report as its own
version once installed.

WHAT GETS INCLUDED:
Every file under the pinclock/ directory (the same one this script
lives inside), except the exclusions below. Notably, this does NOT
include .config/labwc/autostart or .config/labwc/environment - those
live outside pinclock/ entirely (they're siblings of it, installed to
~/.config/labwc/ on the device, not under the app's own directory) and
so are never part of an automated update by construction. That's
intentional: system-config files stay a manual, reviewed change (see
the project's step 3 scoping discussion) rather than something this
tool can silently overwrite.
"""
import argparse
import fnmatch
import hashlib
import json
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
from pathlib import Path

EXCLUDED_DIR_NAMES = {
    ".git", "__pycache__", ".pytest_cache", "venv", "node_modules",
    "logs", "uploads", "converted", "dist",
}
EXCLUDED_FILE_PATTERNS = [
    "*.pyc", "*.pyo", ".DS_Store", "*.tmp", ".gitignore", ".gitattributes",
]


def _sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _discover_files(source_dir):
    """Walk source_dir, returning a sorted list of (relative_posix_path,
    absolute_path) for every file to include. Sorted so the resulting
    tarball and manifest are byte-for-byte reproducible across runs on
    the same input."""
    included = []
    for path in sorted(source_dir.rglob("*")):
        if path.is_dir():
            continue
        rel_parts = path.relative_to(source_dir).parts
        if any(part in EXCLUDED_DIR_NAMES for part in rel_parts[:-1]):
            continue
        if any(fnmatch.fnmatch(path.name, pat) for pat in EXCLUDED_FILE_PATTERNS):
            continue
        included.append((path.relative_to(source_dir).as_posix(), path))
    return included


def _read_app_version(source_dir):
    app_py = source_dir / "app.py"
    if not app_py.exists():
        return None
    m = re.search(r'^PINCLOCK_VERSION\s*=\s*["\'](.+?)["\']', app_py.read_text(), re.MULTILINE)
    return m.group(1).lstrip("v") if m else None


def _check_retired_stock_videos(source_dir):
    """Returns the retired filenames, or exits with an error if the list
    is malformed or overlaps shipped-videos/. Missing file is fine (=
    nothing retired)."""
    path = source_dir / "retired-stock-videos.json"
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text())
        entries = data["retired"]
        names = [e["filename"] if isinstance(e, dict) else e for e in entries]
    except (ValueError, KeyError, TypeError) as e:
        print(f"ERROR: {path} is malformed ({e}) - fix it or run "
              f"scripts/retire_stock_video.py list", file=sys.stderr)
        sys.exit(1)
    bad = [n for n in names if not isinstance(n, str) or not n or n != Path(n).name or n.startswith(".")]
    if bad:
        print(f"ERROR: {path} has entries that aren't plain file names: {bad}", file=sys.stderr)
        sys.exit(1)
    shipped = source_dir / "shipped-videos"
    both = [n for n in names if (shipped / n).exists()]
    if both:
        print(f"ERROR: these are both shipped (shipped-videos/) and retired "
              f"(retired-stock-videos.json) in this release: {both} - pick one", file=sys.stderr)
        sys.exit(1)
    return names


def _check_retired_em_videos(source_dir):
    """v0.30.13: the same checks for the "retired_em" list (stock EM
    videos) against em-videos/. Returns the names."""
    path = source_dir / "retired-stock-videos.json"
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text())
        entries = data.get("retired_em", [])
        names = [e["filename"] if isinstance(e, dict) else e for e in entries]
    except (ValueError, KeyError, TypeError, AttributeError) as e:
        print(f"ERROR: {path} is malformed ({e}) - fix it or run "
              f"scripts/retire_stock_video.py list --em", file=sys.stderr)
        sys.exit(1)
    bad = [n for n in names if not isinstance(n, str) or not n or n != Path(n).name or n.startswith(".")]
    if bad:
        print(f"ERROR: {path} has retired_em entries that aren't plain file names: {bad}", file=sys.stderr)
        sys.exit(1)
    both = [n for n in names if (source_dir / "em-videos" / n).exists()]
    if both:
        print(f"ERROR: these EM videos are both in em-videos/ and retired (retired-stock-videos.json "
              f"retired_em) in this release: {both} - delete the file or take it off the list", file=sys.stderr)
        sys.exit(1)
    return names


def _check_retired_uploads(source_dir):
    """v0.31.7: the "retired_user" list (videos the clock deletes from My
    Videos, once) must be plain file names. Returns the names."""
    path = source_dir / "retired-stock-videos.json"
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text())
        names = [e["filename"] if isinstance(e, dict) else e for e in data.get("retired_user", [])]
    except (ValueError, KeyError, TypeError, AttributeError) as e:
        print(f"ERROR: {path} is malformed ({e}) - fix it or run "
              f"scripts/retire_stock_video.py list --uploads", file=sys.stderr)
        sys.exit(1)
    bad = [n for n in names if not isinstance(n, str) or not n or n != Path(n).name or n.startswith(".")]
    if bad:
        print(f"ERROR: {path} has retired_user entries that aren't plain file names: {bad}", file=sys.stderr)
        sys.exit(1)
    return names


CONTENT_PICTURE_EXT = {".png", ".jpg", ".jpeg", ".webp", ".json"}
CONTENT_MIN_FIRMWARE = "0.53.1"
DEFAULT_CONTENT_BASE = "https://digitalconcepts.net/pinclock/content/"


def is_content(rel):
    """True for a file that ships as content (not firmware). A README in
    those folders is neither - it stays with the firmware."""
    parts = rel.split("/")
    name = parts[-1]
    if any(p.startswith(".") for p in parts) or name.upper().startswith("README"):
        return False
    if parts == ["retired-stock-videos.json"]:
        return True
    ext = Path(name).suffix.lower()
    if parts[0] == "shipped-backgrounds":
        return (len(parts) == 2 or (len(parts) == 3 and parts[1] == "faceplates")) and ext in CONTENT_PICTURE_EXT
    if parts[0] == "em-videos":
        return len(parts) == 2 and ext == ".mp4"
    if parts[0] == "shipped-videos":
        return len(parts) == 2
    return False


def in_content_folder(rel):
    """Everything under the content folders (READMEs too) - left out of a
    firmware-only build, so the release has no shipped-backgrounds/ and the
    clock reads its stock backglasses from content updates."""
    return rel.split("/")[0] in ("shipped-backgrounds", "em-videos", "shipped-videos") \
        or rel == "retired-stock-videos.json"


def build_content(files, output_dir, content_version, changelog, base_url, min_firmware):
    """Writes <output-dir>/content/: files/<sha256> for each content file
    (copied only if not there yet) and content-manifest.json. Returns
    (manifest path, count, total bytes, new bytes)."""
    out = output_dir / "content"
    fdir = out / "files"
    fdir.mkdir(parents=True, exist_ok=True)
    entries = {}
    new_bytes = 0
    for rel, p in files:
        sha = _sha256_file(p)
        size = p.stat().st_size
        entries[rel] = {"sha256": sha, "size": size}
        dst = fdir / sha
        if not dst.exists():
            tmp = fdir / (sha + ".tmp")
            shutil.copy2(p, tmp)
            tmp.replace(dst)
            new_bytes += size
    manifest = {"format": 1, "content_version": content_version, "min_firmware": min_firmware,
                "changelog": changelog or "", "files": dict(sorted(entries.items()))}
    if base_url:
        manifest["base_url"] = base_url if base_url.endswith("/") else base_url + "/"
    mpath = out / "content-manifest.json"
    tmp = out / "content-manifest.json.tmp"
    tmp.write_text(json.dumps(manifest, indent=1) + "\n")
    tmp.replace(mpath)
    return mpath, len(entries), sum(e["size"] for e in entries.values()), new_bytes


EM_VIDEO_DIR = "em-videos/"
EM_LEDGER_NAME = "em-videos-shipped.json"


def _is_em_video(rel_path):
    return rel_path.startswith(EM_VIDEO_DIR) and rel_path.count("/") == 1 and rel_path.lower().endswith(".mp4")


def _load_em_ledger(path):
    """{file name: {"sha256", "size", "version", "date"}} of the EM videos
    earlier releases packaged - {} if there's no ledger yet."""
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        vids = data.get("videos") if isinstance(data, dict) else None
        return vids if isinstance(vids, dict) else {}
    except FileNotFoundError:
        return {}
    except (ValueError, OSError) as e:
        print(f"ERROR: {path} is unreadable ({e}) - fix or delete it", file=sys.stderr)
        sys.exit(1)


def _prepare_em_videos(files, mode, ledger_path, compress, video_opts, work_dir, cache_dir):
    """v0.30.11: compresses (--compress-videos) and filters (--em-videos) the
    EM videos in `files`. Returns (files, packaged [(name, sha256, size)],
    report lines)."""
    em = [(rel, p) for rel, p in files if _is_em_video(rel)]
    if not em:
        return files, [], []
    lines = []
    if compress:
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        from make_stripped_copy import compress_video_files
        work_dir.mkdir(parents=True, exist_ok=True)
        swapped = {}
        for rel, p in em:
            dst = work_dir / Path(rel).name
            shutil.copy2(p, dst)
            swapped[rel] = dst
        lines += compress_video_files(list(swapped.values()), cache_dir, *video_opts)
        files = [(rel, swapped.get(rel, p)) for rel, p in files]
        em = [(rel, swapped[rel]) for rel, _ in em]
    ledger = _load_em_ledger(ledger_path)
    info = {rel: (_sha256_file(p), p.stat().st_size) for rel, p in em}
    shipped_before = [rel for rel in info
                      if ledger.get(Path(rel).name, {}).get("sha256") == info[rel][0]]
    if mode == "none":
        drop = set(info)
    elif mode == "new":
        drop = set(shipped_before)
    else:
        drop = set()
    files = [(rel, p) for rel, p in files if rel not in drop]
    packaged = [(Path(rel).name, info[rel][0], info[rel][1]) for rel in info if rel not in drop]
    mb = lambda rels: sum(info[r][1] for r in rels) / 1e6
    kept = [rel for rel in info if rel not in drop]
    print(f"EM videos ({mode}): packaging {len(kept)} ({mb(kept):.1f} MB)"
          + (f", leaving out {len(drop)} ({mb(drop):.1f} MB)" if drop else ""))
    for rel in sorted(drop):
        why = "already shipped in v" + str(ledger.get(Path(rel).name, {}).get("version", "?")) if rel in shipped_before else "--em-videos none"
        print(f"  left out: {Path(rel).name}  ({why})")
    if mode == "all" and shipped_before:
        print(f"  NOTE: {len(shipped_before)} of these ({mb(shipped_before):.1f} MB) were already shipped "
              f"(see {ledger_path}) - add --em-videos new to leave them out")
    if mode != "all":
        print("  (clocks keep EM videos from earlier releases only with the v0.28.19+ updater - see --help)")
    lines.append(f"EM videos ({mode}): {len(kept)} packaged, {len(drop)} left out")
    return files, packaged, lines


def _record_em_ledger(ledger_path, packaged, version, retired=()):
    """v0.30.13: also forgets retired EM videos - clocks delete them, so if
    one is ever taken off the retired list and put back in em-videos/,
    --em-videos new must ship it again."""
    ledger = _load_em_ledger(ledger_path)
    forget = [n for n in retired if n in ledger]
    if not packaged and not forget:
        return
    for n in forget:
        del ledger[n]
    stamp = time.strftime("%Y-%m-%d")
    for name, sha, size in packaged:
        ledger[name] = {"sha256": sha, "size": size, "version": version, "date": stamp}
    Path(ledger_path).parent.mkdir(parents=True, exist_ok=True)
    Path(ledger_path).write_text(json.dumps({"videos": dict(sorted(ledger.items()))}, indent=2) + "\n", encoding="utf-8")
    if packaged:
        print(f"Recorded {len(packaged)} EM video(s) as shipped in {ledger_path}")
    if forget:
        print(f"Dropped {len(forget)} retired EM video(s) from {ledger_path}: {', '.join(forget)}")


def build_release(version, source_dir, output_dir, repo, changelog, min_upgrade_from, post_install_hook=None,
                  strip=False, em_videos="all", em_ledger=None, compress_videos=False, video_opts=(26, 720, True),
                  compiled=True, any_python=False, build="combined", content_version=None,
                  content_changelog="", content_base_url=None, content_min_firmware=CONTENT_MIN_FIRMWARE,
                  release_base_url=None):
    if build not in ("combined", "firmware", "content", "separate"):
        print(f"ERROR: --build {build}?", file=sys.stderr)
        sys.exit(1)
    if build in ("content", "separate"):
        _build_content_part(source_dir, output_dir, content_version, content_changelog, content_base_url,
                            content_min_firmware, compress_videos, video_opts)
        if build == "content":
            return
        print()
    _build_firmware_part(version, source_dir, output_dir, repo, changelog, min_upgrade_from, post_install_hook,
                         strip, em_videos, em_ledger, compress_videos, video_opts, compiled, any_python,
                         firmware_only=(build != "combined"), release_base_url=release_base_url)


def _build_content_part(source_dir, output_dir, content_version, changelog, base_url, min_firmware,
                        compress_videos, video_opts):
    _check_retired_stock_videos(source_dir)
    _check_retired_em_videos(source_dir)
    _check_retired_uploads(source_dir)
    if base_url and not base_url.startswith("https://"):
        print("ERROR: --content-base-url must be https://", file=sys.stderr)
        sys.exit(1)
    content_version = content_version or time.strftime("%Y.%m.%d-%H%M")
    files = [(rel, p) for rel, p in _discover_files(source_dir) if is_content(rel)]
    if not files:
        print(f"ERROR: no content found under {source_dir}", file=sys.stderr)
        sys.exit(1)
    output_dir.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix="pinclock-content-em-"))
    try:
        files, _, _ = _prepare_em_videos(files, "all", work / "no-ledger.json", compress_videos, video_opts,
                                         work / "em", output_dir / ".video-cache")
        mpath, n, total, new = build_content(files, output_dir, content_version, changelog, base_url, min_firmware)
    finally:
        shutil.rmtree(work, ignore_errors=True)
    print(f"Content {content_version}: {n} files, {total / 1e6:.1f} MB "
          f"({new / 1e6:.1f} MB new in {mpath.parent / 'files'})")
    print(f"Wrote {mpath}")
    print("Next steps (content):")
    print(f"  1. Upload {mpath.parent / 'files'}/ to {DEFAULT_CONTENT_BASE}files/ (only new files need copying)")
    print(f"  2. THEN upload {mpath.name} to {DEFAULT_CONTENT_BASE}")
    print("     (clocks see the new content the next time someone checks for an update)")


def _build_firmware_part(version, source_dir, output_dir, repo, changelog, min_upgrade_from, post_install_hook,
                         strip, em_videos, em_ledger, compress_videos, video_opts, compiled, any_python,
                         firmware_only=False, release_base_url=None):
    app_version = _read_app_version(source_dir)
    if app_version is None:
        print(f"ERROR: couldn't find PINCLOCK_VERSION in {source_dir / 'app.py'}", file=sys.stderr)
        sys.exit(1)
    if app_version != version:
        print(
            f"ERROR: --version {version} doesn't match PINCLOCK_VERSION "
            f"(\"v{app_version}\") in app.py.\n"
            f"Bump PINCLOCK_VERSION in app.py to \"v{version}\" first, so the "
            f"code you're about to package actually reports the version "
            f"you're releasing it as.",
            file=sys.stderr,
        )
        sys.exit(1)

    checker = source_dir / "scripts" / "check_defaults.py"
    if not checker.exists():
        print(f"ERROR: {checker} not found - refusing to package without the defaults check", file=sys.stderr)
        sys.exit(1)
    if subprocess.run([sys.executable, str(checker)]).returncode != 0:
        print("ERROR: settings-defaults check failed (see above) - fix before packaging", file=sys.stderr)
        sys.exit(1)

    fx_checker = source_dir / "scripts" / "check_fx_styles.py"
    if fx_checker.exists():
        subprocess.run([sys.executable, str(fx_checker), "--quiet"])

    retired = _check_retired_stock_videos(source_dir)
    retired_em = _check_retired_em_videos(source_dir)
    if retired_em:
        print(f"Retired stock EM videos (removed from clocks by this release): {', '.join(retired_em)}")
    retired_user = _check_retired_uploads(source_dir)
    if retired_user:
        print(f"My Videos removed once from each clock by this release ({len(retired_user)}): "
              f"{', '.join(retired_user)}")

    output_dir.mkdir(parents=True, exist_ok=True)
    tarball_path = output_dir / f"pinclock-{version}.tar.gz"
    manifest_path = output_dir / "update-manifest.json"

    files = _discover_files(source_dir)
    if not files:
        print(f"ERROR: no files discovered under {source_dir} - check the path", file=sys.stderr)
        sys.exit(1)
    if firmware_only:
        left = [rel for rel, _ in files if in_content_folder(rel)]
        files = [(rel, p) for rel, p in files if not in_content_folder(rel)]
        print(f"Firmware only: leaving out {len(left)} content file(s) (shipped-backgrounds/, em-videos/, "
              f"shipped-videos/, retired-stock-videos.json)")

    strip_dir = None
    if strip:
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        import strip_comments
        strip_dir = Path(tempfile.mkdtemp(prefix="pinclock-strip-"))
        for rel_path, abs_path in files:
            dest = strip_dir / rel_path
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(abs_path, dest)
        report = strip_comments.strip_tree(strip_dir, [rel for rel, _ in files])
        strip_comments.print_report(report)
        if any("Node.js not found" in line for line in report["skipped"] + report["notes"]):
            print("  WARNING: Node.js isn't installed here, so JavaScript was NOT stripped. "
                  "Install Node.js and rebuild to strip it.")
        files = [(rel, strip_dir / rel) for rel, _ in files]
        print()

    pyc_dir = None
    if compiled:
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        import compile_pyc
        if not (compile_pyc.on_a_pi_like_machine() or any_python):
            print("ERROR: compiled releases must be built on a Raspberry Pi (the .pyc files only load in "
                  "the Python version that made them). Build on the Pi, or pass --source to ship plain "
                  ".py, or --any-python if you're sure this Python matches the clocks'.", file=sys.stderr)
            sys.exit(1)
        pyc_dir = Path(tempfile.mkdtemp(prefix="pinclock-pyc-"))
        for rel_path, abs_path in files:
            dest = pyc_dir / rel_path
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(abs_path, dest)
        res = compile_pyc.compile_tree(pyc_dir)
        problems = compile_pyc.check_compiled(pyc_dir)
        if problems:
            print("ERROR: " + "; ".join(problems), file=sys.stderr)
            sys.exit(1)
        gone = set(res["removed"])
        files = [(rel, pyc_dir / rel) for rel, _ in files if rel not in gone]
        files += [(rel, pyc_dir / rel) for rel in res["added"]]
        print(f"Compiled {len(res['added'])} Python files to .pyc with Python {sys.version.split()[0]} "
              f"(app.py is now the launcher; --source to ship plain .py)")
        print()

    em_ledger = Path(em_ledger) if em_ledger else output_dir / EM_LEDGER_NAME
    em_work = Path(tempfile.mkdtemp(prefix="pinclock-em-"))
    files, em_packaged, _ = _prepare_em_videos(files, em_videos, em_ledger, compress_videos, video_opts,
                                               em_work, output_dir / ".video-cache")
    print()

    print(f"Packaging {len(files)} files from {strip_dir or source_dir}{' (comments stripped)' if strip else ''}...")
    file_hashes = {}
    for rel_path, abs_path in files:
        file_hashes[rel_path] = "sha256:" + _sha256_file(abs_path)

    release_manifest = {
        "version": version,
        "files": file_hashes,
    }
    if compiled:
        release_manifest["python"] = ".".join(map(str, sys.version_info[:2]))
    if min_upgrade_from:
        release_manifest["min_upgrade_from"] = min_upgrade_from
    if post_install_hook:
        hook_full_path = source_dir / post_install_hook
        if post_install_hook not in file_hashes:
            print(
                f"ERROR: --post-install-hook {post_install_hook} was not found among the "
                f"discovered files under {source_dir} - check the path is relative to "
                f"source_dir and wasn't caught by an exclusion pattern",
                file=sys.stderr,
            )
            sys.exit(1)
        release_manifest["post_install_hook"] = post_install_hook

    release_manifest_bytes = json.dumps(release_manifest, indent=2).encode()

    with tarfile.open(tarball_path, "w:gz") as tf:
        for rel_path, abs_path in files:
            tf.add(abs_path, arcname=f"pinclock/{rel_path}")
        info = tarfile.TarInfo(name="release-manifest.json")
        info.size = len(release_manifest_bytes)
        info.mtime = 0
        tf.addfile(info, __import__("io").BytesIO(release_manifest_bytes))

    tarball_sha256 = _sha256_file(tarball_path)
    release_url = f"https://github.com/{repo}/releases/download/v{version}/pinclock-{version}.tar.gz"
    if release_base_url:
        release_url = release_base_url.rstrip("/") + f"/pinclock-{version}.tar.gz"

    update_manifest = {
        "latest": version,
        "url": release_url,
        "sha256": tarball_sha256,
        "changelog": changelog or "",
    }
    manifest_path.write_text(json.dumps(update_manifest, indent=2))
    if strip_dir is not None:
        shutil.rmtree(strip_dir, ignore_errors=True)
    if pyc_dir is not None:
        shutil.rmtree(pyc_dir, ignore_errors=True)
    shutil.rmtree(em_work, ignore_errors=True)
    _record_em_ledger(em_ledger, em_packaged, version, retired_em)

    print()
    print(f"Built {tarball_path} ({tarball_path.stat().st_size:,} bytes, sha256 {tarball_sha256})")
    print(f"Wrote {manifest_path}")
    if retired:
        print(f"Retired stock videos in this release ({len(retired)}) - devices will delete these "
              f"after the update succeeds: {', '.join(retired)}")
    print()
    if release_base_url:
        print("Next steps (firmware on your own site):")
        print(f"  1. Upload {tarball_path.name} so it's exactly at {release_url}")
        print(f"  2. THEN upload {manifest_path.name} next to it, and point the website's")
        print(f"     manifest_urls (config.php) at it")
        print("Clocks need the 2026-10-27+ updater to follow a manifest that isn't on GitHub.")
        return
    print("Next steps:")
    print(f"  1. Create a GitHub Release in {repo} tagged exactly:  v{version}")
    print(f"  2. Upload {tarball_path.name} as that release's asset (filename must match exactly)")
    print(f"  3. Confirm the asset URL is exactly:")
    print(f"       {release_url}")
    print(f"     (GitHub derives this from the tag + filename - if either doesn't match, devices")
    print(f"     will get a 404 when they try to download it)")
    print(f"  4. Commit and push {manifest_path.name} to the {repo} default branch")
    print()
    print("Nothing is live on any device until step 4 - devices only ever read")
    print("update-manifest.json from the repo, never GitHub's release list directly.")


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("version", nargs="?", default=None,
                        help="Version being released, e.g. 0.9.0 (must match PINCLOCK_VERSION in app.py; "
                             "not needed with --build content)")
    parser.add_argument("--build", choices=("combined", "firmware", "content", "separate"), default="combined",
                        help="combined (default, as before), firmware (no content), content (content only), "
                             "separate (firmware + content, each on its own)")
    parser.add_argument("--content-version", default=None, help="content version (default: date-time)")
    parser.add_argument("--content-changelog", default="", help="short note shown with new content")
    parser.add_argument("--content-base-url", default=None,
                        help="https address of the content files/ folder, if not next to the manifest")
    parser.add_argument("--content-min-firmware", default=CONTENT_MIN_FIRMWARE,
                        help=f"oldest firmware that may install this content (default {CONTENT_MIN_FIRMWARE})")
    parser.add_argument("--release-base-url", default=None,
                        help="https folder the firmware tarball is served from (default: the GitHub release)")
    parser.add_argument("--changelog", default="", help="Short human-readable changelog shown on the Device tab")
    parser.add_argument("--min-upgrade-from", default=None,
                         help="Refuse to install this release on devices older than this version")
    parser.add_argument("--post-install-hook", default=None,
                         help="Path (relative to source-dir) to a script run before the symlink "
                              "swap, e.g. scripts/post_install.py - see run_update.py's "
                              "_run_post_install_hook docstring for the idempotency requirement "
                              "before writing one of these")
    parser.add_argument("--repo", default="DonMilo/pinclock-firmware",
                         help="GitHub owner/repo releases are published to (default: DonMilo/pinclock-firmware)")
    parser.add_argument("--source-dir", default=None,
                         help="Path to the pinclock/ app directory to package (default: this script's own parent pinclock/ dir)")
    parser.add_argument("--output-dir", default="dist", help="Where to write the tarball + manifest (default: ./dist)")
    parser.add_argument("--strip", action="store_true",
                         help="Remove code comments from the packaged copy (source is untouched) - "
                              "see scripts/strip_comments.py")
    parser.add_argument("--source", action="store_true",
                        help="v0.41.0: ship plain .py instead of compiled .pyc (the default) - see scripts/compile_pyc.py")
    parser.add_argument("--any-python", action="store_true",
                        help="compile even when not on a Raspberry Pi (only if this Python is the clocks' version)")
    parser.add_argument("--em-videos", choices=("all", "new", "none"), default="all",
                         help="which EM videos to package: all (default), new (not shipped before - see "
                              "em-videos-shipped.json in the output dir), or none")
    parser.add_argument("--em-ledger", default=None,
                         help="the record of EM videos already shipped (default: <output-dir>/em-videos-shipped.json)")
    parser.add_argument("--compress-videos", action="store_true",
                         help="re-encode the packaged EM videos smaller with ffmpeg (source untouched)")
    parser.add_argument("--video-crf", type=int, default=26, help="--compress-videos quality: higher = smaller (default 26)")
    parser.add_argument("--video-height", type=int, default=720, help="--compress-videos: max height (default 720)")
    parser.add_argument("--video-no-audio", action="store_true", help="--compress-videos: drop the sound track")
    args = parser.parse_args()

    source_dir = Path(args.source_dir) if args.source_dir else Path(__file__).resolve().parent.parent
    output_dir = Path(args.output_dir)

    if args.build != "content" and not args.version:
        parser.error("the version is needed (it must match PINCLOCK_VERSION in app.py)")
    if args.release_base_url and not args.release_base_url.startswith("https://"):
        parser.error("--release-base-url must be https://")
    build_release(
        version=args.version,
        source_dir=source_dir,
        output_dir=output_dir,
        repo=args.repo,
        changelog=args.changelog,
        min_upgrade_from=args.min_upgrade_from,
        post_install_hook=args.post_install_hook,
        strip=args.strip,
        em_videos=args.em_videos,
        em_ledger=args.em_ledger,
        compress_videos=args.compress_videos,
        video_opts=(args.video_crf, args.video_height, not args.video_no_audio),
        compiled=not args.source,
        any_python=args.any_python,
        build=args.build,
        content_version=args.content_version,
        content_changelog=args.content_changelog,
        content_base_url=args.content_base_url,
        content_min_firmware=args.content_min_firmware,
        release_base_url=args.release_base_url,
    )


if __name__ == "__main__":
    main()
