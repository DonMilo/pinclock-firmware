#!/usr/bin/env python3
""
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import tarfile
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path

DATA_DIR = Path("/home/vfw/pinclock-data")
RELEASES_DIR = Path("/opt/pinclock/releases")
CURRENT_LINK = Path("/opt/pinclock/current")
STATUS_FILE = DATA_DIR / "update_status.json"
LOCK_FILE = Path("/opt/pinclock/updater/.update.lock")

FACTORY_ROOT = Path("/opt/pinclock-factory")
LABWC_DIR = Path("/home/vfw/.config/labwc")

PERSISTENT_SHIPPED_VIDEOS_DIR = Path("/opt/pinclock/shipped-videos")
PERSISTENT_EM_VIDEOS_DIR = Path("/opt/pinclock/em-videos")

UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/DonMilo/pinclock-firmware/main/update-manifest.json"

UPDATE_SOURCE_FILE = DATA_DIR / "update-source.json"
ALLOWED_MANIFEST_HOSTS = {"raw.githubusercontent.com", "digitalconcepts.net", "www.digitalconcepts.net"}


def _manifest_url():
    try:
        url = json.loads(UPDATE_SOURCE_FILE.read_text()).get("manifest_url")
        if not isinstance(url, str) or not url:
            return UPDATE_MANIFEST_URL
        from urllib.parse import urlparse
        u = urlparse(url)
        if u.scheme == "https" and (u.hostname or "").lower() in ALLOWED_MANIFEST_HOSTS:
            return url
        print(f"[run_update] ignoring manifest URL {url!r} from {UPDATE_SOURCE_FILE} - not an allowed https host")
    except (OSError, ValueError, AttributeError, TypeError):
        pass
    return UPDATE_MANIFEST_URL

HEALTHCHECK_URL = "http://127.0.0.1:5000/"
HEALTHCHECK_TIMEOUT_S = 15
HEALTHCHECK_POLL_INTERVAL_S = 1


class UpdateError(Exception):
    ""


def _now_iso():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _atomic_write_json(path, data):
    ""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(dir=str(path.parent), prefix=".tmp-", suffix=".json")
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(data, f, indent=2)
        os.replace(tmp_path, str(path))
    except BaseException:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


def _write_status(state, from_version=None, to_version=None, message="", operation="update"):
    payload = {
        "operation": operation,
        "state": state,
        "from_version": from_version,
        "to_version": to_version,
        "message": message,
        "updated_at": _now_iso(),
    }
    try:
        _atomic_write_json(STATUS_FILE, payload)
    except OSError as e:
        print(f"[run_update] WARNING: could not write status file: {e}")
    print(f"[run_update] {state}: {message}")


def _current_version():
    ""
    if not CURRENT_LINK.exists():
        return None
    app_py = CURRENT_LINK.resolve() / "app.py"
    if not app_py.exists():
        return None
    m = re.search(r'^PINCLOCK_VERSION\s*=\s*["\'](.+?)["\']', app_py.read_text(), re.MULTILINE)
    return m.group(1).lstrip("v") if m else None


def _current_version_live():
    ""
    try:
        with urllib.request.urlopen(f"{HEALTHCHECK_URL}api/system/status", timeout=5) as resp:
            data = json.loads(resp.read().decode())
            return data.get("version", "").lstrip("v")
    except (urllib.error.URLError, OSError, json.JSONDecodeError, ValueError):
        return None


def _fetch_json(url):
    try:
        with urllib.request.urlopen(url, timeout=15) as resp:
            return json.loads(resp.read().decode())
    except (urllib.error.URLError, OSError) as e:
        raise UpdateError(f"could not fetch {url}: {e}")
    except json.JSONDecodeError as e:
        raise UpdateError(f"{url} did not return valid JSON: {e}")


def _sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _download(url, dest_path):
    try:
        urllib.request.urlretrieve(url, str(dest_path))
    except (urllib.error.URLError, OSError) as e:
        raise UpdateError(f"download failed: {e}")


def _release_correctly_installed(version):
    ""
    target = RELEASES_DIR / version / "pinclock"
    return (
        target.is_dir()
        and CURRENT_LINK.exists()
        and CURRENT_LINK.resolve() == target.resolve()
    )


def _is_newer(latest, current):
    ""
    try:
        return _parse_version(latest) > _parse_version(current)
    except UpdateError as e:
        print(
            f"[run_update] WARNING: {e} - falling back to a simple inequality check for "
            f"update_available, which can't tell an older version from a newer one."
        )
        return latest != current


def check_for_update():
    ""
    current = _current_version()
    manifest = _fetch_json(_manifest_url())
    latest = manifest.get("latest", "")
    return {
        "current": current,
        "latest": latest,
        "update_available": bool(current and latest and _is_newer(latest, current)),
        "changelog": manifest.get("changelog", ""),
        "url": manifest.get("url"),
        "sha256": manifest.get("sha256"),
    }


def _guard_no_foreign_flask():
    ""
    try:
        out = subprocess.run(
            ["systemctl", "--user", "show", "-p", "MainPID", "--value", "pinclock.service"],
            capture_output=True, text=True, timeout=10,
        )
        managed_pid = out.stdout.strip()
    except (subprocess.SubprocessError, OSError) as e:
        raise UpdateError(f"could not query pinclock.service state: {e}")

    try:
        listeners = subprocess.run(
            ["ss", "-ltnp", "sport", "=", ":5000"],
            capture_output=True, text=True, timeout=10,
        ).stdout
    except (subprocess.SubprocessError, OSError):
        listeners = ""

    if listeners and managed_pid and managed_pid != "0" and f"pid={managed_pid}" not in listeners:
        raise UpdateError(
            "port 5000 appears to be held by a process other than the "
            "pinclock.service-managed one - refusing to proceed. Run "
            "`systemctl --user status pinclock.service` and `sudo ss "
            "-ltnp sport = :5000` to investigate before retrying."
        )


def _acquire_lock():
    LOCK_FILE.parent.mkdir(parents=True, exist_ok=True)
    if LOCK_FILE.exists():
        try:
            pid = int(LOCK_FILE.read_text().strip())
            os.kill(pid, 0)
            raise UpdateError(f"an update is already in progress (pid {pid})")
        except (ValueError, ProcessLookupError, PermissionError):
            pass
    LOCK_FILE.write_text(str(os.getpid()))


def _release_lock():
    try:
        LOCK_FILE.unlink()
    except FileNotFoundError:
        pass


def _restart_and_healthcheck():
    subprocess.run(["systemctl", "--user", "restart", "pinclock.service"], check=True, timeout=30)
    deadline = time.time() + HEALTHCHECK_TIMEOUT_S
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(HEALTHCHECK_URL, timeout=3) as resp:
                if resp.status == 200:
                    return True
        except (urllib.error.URLError, OSError):
            pass
        time.sleep(HEALTHCHECK_POLL_INTERVAL_S)
    return False


def _rollback(previous_target, to_version, reason, operation="update"):
    _write_status("rolled_back", to_version=to_version, message=f"rolling back: {reason}", operation=operation)
    if previous_target is not None:
        _atomic_symlink(CURRENT_LINK, previous_target)
    healthy = _restart_and_healthcheck()
    if healthy:
        _write_status("rolled_back", to_version=to_version,
                       message=f"rolled back successfully after: {reason}", operation=operation)
    else:
        _write_status("failed", to_version=to_version,
                       message=f"UPDATE AND ROLLBACK BOTH FAILED ({reason}) - "
                               f"needs manual intervention, see journalctl --user -u pinclock",
                       operation=operation)


def _atomic_symlink(link_path, target_path):
    tmp_link = link_path.with_name(link_path.name + ".tmp")
    if tmp_link.exists() or tmp_link.is_symlink():
        tmp_link.unlink()
    tmp_link.symlink_to(target_path)
    tmp_link.replace(link_path)


def _make_writable(path):
    ""
    for root, dirs, files in os.walk(path):
        for d in dirs:
            os.chmod(os.path.join(root, d), 0o755)
        for f in files:
            os.chmod(os.path.join(root, f), 0o644)
    os.chmod(path, 0o755)


def _parse_version(v):
    ""
    try:
        return tuple(int(p) for p in v.split("."))
    except (ValueError, AttributeError):
        raise UpdateError(f"couldn't parse version string {v!r} as X.Y.Z")


def _check_min_upgrade_from(from_version, release_manifest):
    ""
    min_from = release_manifest.get("min_upgrade_from")
    if not min_from or not from_version:
        return
    if _parse_version(from_version) < _parse_version(min_from):
        raise UpdateError(
            f"this release requires upgrading from {min_from} or later "
            f"(currently on {from_version}) - upgrade to an intermediate "
            f"version first"
        )


SIDELOAD_PENDING_PATH = DATA_DIR / "sideload-pending.tar.gz"


def run_update():
    from_version = _current_version()
    previous_target = CURRENT_LINK.resolve() if CURRENT_LINK.exists() else None

    _acquire_lock()
    try:
        _guard_no_foreign_flask()

        if SIDELOAD_PENDING_PATH.exists():
            _run_sideload(from_version, previous_target)
            return

        _write_status("checking", from_version=from_version, message="fetching update manifest")
        manifest = _fetch_json(_manifest_url())
        to_version = manifest.get("latest")
        tarball_url = manifest.get("url")
        expected_sha256 = manifest.get("sha256")
        if not (to_version and tarball_url and expected_sha256):
            raise UpdateError("update manifest is missing required fields (latest/url/sha256)")

        if from_version and to_version == from_version and _release_correctly_installed(to_version):
            _write_status("success", from_version, to_version, message="already up to date")
            return

        if from_version and to_version != from_version and not _is_newer(to_version, from_version):
            raise UpdateError(
                f"manifest's latest ({to_version}) is not newer than the currently "
                f"running version ({from_version}) - refusing to proceed. This path only "
                f"ever moves forward; if a genuine rollback is actually intended, that's "
                f"Factory Reset (see scripts/bless_factory.py's snapshot) or a deliberate "
                f"manual symlink swap, never this automatic one. (v0.14.16+ - see "
                f"check_for_update()'s own _is_newer() note: this is the same class of bug "
                f"that made /api/firmware/check report an update available for a manifest "
                f"pointing at an OLDER version - here, unchecked, it would have meant "
                f"actually installing that older version.)"
            )

        with tempfile.TemporaryDirectory(dir=str(RELEASES_DIR.parent)) as tmp:
            tmp = Path(tmp)
            tarball_path = tmp / "release.tar.gz"

            _write_status("downloading", from_version, to_version, message=f"downloading {tarball_url}")
            _download(tarball_url, tarball_path)

            _write_status("verifying", from_version, to_version, message="checking tarball checksum")
            actual_sha256 = _sha256_file(tarball_path)
            if actual_sha256 != expected_sha256:
                raise UpdateError(
                    f"tarball checksum mismatch (expected {expected_sha256}, got {actual_sha256}) "
                    f"- refusing to install, download may be corrupt or tampered with"
                )

            _extract_and_install(tarball_path, from_version, previous_target, expected_to_version=to_version)

    except Exception as e:
        _write_status("failed", from_version, message=str(e))
        if CURRENT_LINK.exists() and CURRENT_LINK.resolve() != previous_target and previous_target is not None:
            _rollback(previous_target, None, str(e))
    finally:
        _release_lock()


def _run_sideload(from_version, previous_target):
    ""
    try:
        _extract_and_install(SIDELOAD_PENDING_PATH, from_version, previous_target, expected_to_version=None)
    finally:
        try:
            SIDELOAD_PENDING_PATH.unlink()
        except FileNotFoundError:
            pass


def _extract_and_install(tarball_path, from_version, previous_target, expected_to_version=None):
    ""
    with tempfile.TemporaryDirectory(dir=str(RELEASES_DIR.parent)) as tmp:
        tmp = Path(tmp)
        extract_dir = tmp / "extracted"
        extract_dir.mkdir()

        _write_status("staging", from_version, message="extracting release")
        with tarfile.open(tarball_path) as tf:
            _safe_extract(tf, extract_dir)

        release_manifest_path = extract_dir / "release-manifest.json"
        if not release_manifest_path.exists():
            raise UpdateError("staged release is missing release-manifest.json")
        release_manifest = json.loads(release_manifest_path.read_text())

        to_version = release_manifest.get("version")
        if not to_version:
            raise UpdateError("release-manifest.json is missing its own version field")
        if expected_to_version and to_version != expected_to_version:
            raise UpdateError(
                f"release-manifest.json reports version {to_version!r}, but the update "
                f"manifest promised {expected_to_version!r} - refusing to install a "
                f"mismatched release"
            )

        if from_version and to_version == from_version and _release_correctly_installed(to_version):
            _write_status("success", from_version, to_version, message="already up to date")
            return

        if from_version and to_version != from_version and not _is_newer(to_version, from_version):
            raise UpdateError(
                f"release ({to_version}) is not newer than the currently running version "
                f"({from_version}) - refusing to proceed. This path only ever moves "
                f"forward; if a genuine rollback is actually intended, that's Factory "
                f"Reset (see scripts/bless_factory.py's snapshot) or a deliberate manual "
                f"symlink swap, never this automatic one."
            )

        release_dir = RELEASES_DIR / to_version
        if release_dir.exists():
            shutil.rmtree(release_dir)
        shutil.move(str(extract_dir), str(release_dir))

        _check_min_upgrade_from(from_version, release_manifest)

        _write_status("verifying", from_version, to_version, message="checking staged file hashes")
        _verify_release_files(release_dir, release_manifest)

        newly_synced_videos = _sync_shipped_videos_and_strip(release_dir, from_version, to_version)
        _sync_stock_em_videos_and_strip(release_dir, from_version, to_version)

        _run_post_install_hook(release_dir, release_manifest, from_version, to_version)

    _write_status("restarting", from_version, to_version, message="switching to new release")
    new_target = RELEASES_DIR / to_version / "pinclock"
    _atomic_symlink(CURRENT_LINK, new_target)

    _write_status("healthchecking", from_version, to_version, message="waiting for pinclock.service to come up")
    healthy = _restart_and_healthcheck()
    if not healthy:
        _rollback(previous_target, to_version, "new release failed health check after restart")
        return

    reported = _current_version_live()
    if reported != to_version:
        _rollback(previous_target, to_version,
                  f"new release came up but reports version {reported!r}, expected {to_version!r}")
        return

    if newly_synced_videos:
        _add_new_shipped_videos_to_playlist(newly_synced_videos)

    _write_status("success", from_version, to_version, message=f"updated {from_version} -> {to_version}")
    _prune_old_releases(keep=3)


def _safe_extract(tf, dest_dir):
    ""
    dest_dir = dest_dir.resolve()
    for member in tf.getmembers():
        member_path = (dest_dir / member.name).resolve()
        if not str(member_path).startswith(str(dest_dir) + os.sep):
            raise UpdateError(f"tarball contains an unsafe path: {member.name}")
    tf.extractall(dest_dir)


def _verify_release_files(release_dir, release_manifest):
    for rel_path, expected_hash in release_manifest.get("files", {}).items():
        full_path = release_dir / "pinclock" / rel_path
        if not full_path.exists():
            raise UpdateError(f"release manifest lists {rel_path} but it wasn't extracted")
        expected = expected_hash.split("sha256:")[-1]
        actual = _sha256_file(full_path)
        if actual != expected:
            raise UpdateError(f"checksum mismatch for {rel_path} in staged release")


POST_INSTALL_HOOK_TIMEOUT_S = 120


def _sync_shipped_videos_and_strip(release_dir, from_version, to_version):
    ""
    src_dir = release_dir / "pinclock" / "shipped-videos"
    if not src_dir.exists():
        return []

    to_copy = [f for f in src_dir.iterdir() if f.is_file()]
    newly_added = []
    if to_copy:
        _write_status("staging", from_version, to_version,
                       message=f"syncing {len(to_copy)} shipped video(s) to persistent storage")
        PERSISTENT_SHIPPED_VIDEOS_DIR.mkdir(parents=True, exist_ok=True)
        for src_file in to_copy:
            dst_file = PERSISTENT_SHIPPED_VIDEOS_DIR / src_file.name
            if dst_file.exists() and dst_file.stat().st_size == src_file.stat().st_size \
                    and _sha256_file(dst_file) == _sha256_file(src_file):
                continue
            _copy_whole(src_file, dst_file)
            newly_added.append(src_file.name)

    shutil.rmtree(src_dir)
    return newly_added


def _sync_stock_em_videos_and_strip(release_dir, from_version, to_version):
    ""
    src_dir = release_dir / "pinclock" / "em-videos"
    if not src_dir.exists():
        return
    to_copy = [f for f in src_dir.iterdir() if f.is_file() and f.suffix.lower() == ".mp4"]
    if to_copy:
        _write_status("staging", from_version, to_version,
                       message=f"syncing {len(to_copy)} stock EM video(s) to persistent storage")
        PERSISTENT_EM_VIDEOS_DIR.mkdir(parents=True, exist_ok=True)
        for src_file in to_copy:
            dst_file = PERSISTENT_EM_VIDEOS_DIR / src_file.name
            if dst_file.exists() and dst_file.stat().st_size == src_file.stat().st_size \
                    and _sha256_file(dst_file) == _sha256_file(src_file):
                continue
            _copy_whole(src_file, dst_file)
    shutil.rmtree(src_dir)


def _add_new_shipped_videos_to_playlist(filenames):
    ""
    for name in filenames:
        try:
            body = json.dumps({"name": name, "source": "shipped"}).encode()
            req = urllib.request.Request(
                f"{HEALTHCHECK_URL}api/playlist/add", method="POST", data=body,
                headers={"Content-Type": "application/json"},
            )
            urllib.request.urlopen(req, timeout=10)
        except (urllib.error.URLError, OSError) as e:
            print(f"[run_update] WARNING: could not auto-add {name!r} to playlist: {e}")


def _run_post_install_hook(release_dir, release_manifest, from_version, to_version):
    ""
    hook_rel_path = release_manifest.get("post_install_hook")
    if not hook_rel_path:
        return

    hook_path = release_dir / "pinclock" / hook_rel_path
    if not hook_path.exists():
        raise UpdateError(f"release manifest specifies post_install_hook {hook_rel_path!r} but it wasn't extracted")

    _write_status("staging", from_version, to_version, message=f"running post-install hook {hook_rel_path}")
    try:
        result = subprocess.run(
            ["/usr/bin/python3", str(hook_path)],
            capture_output=True, text=True, timeout=POST_INSTALL_HOOK_TIMEOUT_S,
        )
    except subprocess.TimeoutExpired:
        raise UpdateError(f"post-install hook {hook_rel_path} timed out after {POST_INSTALL_HOOK_TIMEOUT_S}s")
    except OSError as e:
        raise UpdateError(f"could not run post-install hook {hook_rel_path}: {e}")

    if result.returncode != 0:
        raise UpdateError(
            f"post-install hook {hook_rel_path} failed (exit {result.returncode}): "
            f"{result.stderr.strip() or result.stdout.strip() or 'no output'}"
        )


def _find_factory_snapshot():
    ""
    if not FACTORY_ROOT.exists():
        raise UpdateError(f"{FACTORY_ROOT} doesn't exist - this device has no blessed factory snapshot")
    candidates = [d for d in FACTORY_ROOT.iterdir() if d.is_dir()]
    if len(candidates) == 0:
        raise UpdateError(f"{FACTORY_ROOT} exists but contains no factory snapshot")
    if len(candidates) > 1:
        raise UpdateError(
            f"{FACTORY_ROOT} contains more than one snapshot ({[c.name for c in candidates]}) - "
            f"refusing to guess which is the real factory baseline"
        )
    return candidates[0]


def _restore_labwc_files(factory_dir):
    ""
    labwc_snapshot = factory_dir / "labwc"
    if not labwc_snapshot.exists():
        return
    LABWC_DIR.mkdir(parents=True, exist_ok=True)
    for name in ("autostart", "autostart-legacy", "environment", "MANUAL_FILES_VERSION"):
        src = labwc_snapshot / name
        if src.exists():
            dst = LABWC_DIR / name
            if dst.exists():
                dst.chmod(0o644)
            shutil.copy2(src, dst)


def _wipe_videos():
    ""
    videos_dir = DATA_DIR / "videos"
    if not videos_dir.exists():
        return
    for f in videos_dir.iterdir():
        if f.is_file():
            f.unlink()


def run_factory_reset():
    ""
    from_version = _current_version()
    previous_target = CURRENT_LINK.resolve() if CURRENT_LINK.exists() else None
    op = "factory_reset"
    new_release_dir = None

    _acquire_lock()
    try:
        _guard_no_foreign_flask()

        _write_status("checking", from_version=from_version, message="locating factory snapshot", operation=op)
        factory_dir = _find_factory_snapshot()
        manifest_path = factory_dir / "release-manifest.json"
        if not manifest_path.exists():
            raise UpdateError(f"factory snapshot at {factory_dir} is missing release-manifest.json")
        factory_manifest = json.loads(manifest_path.read_text())
        to_version = factory_manifest.get("version")
        if not to_version:
            raise UpdateError("factory snapshot manifest is missing a version field")

        _write_status("verifying", from_version, to_version, message="checking factory snapshot integrity", operation=op)
        _verify_release_files(factory_dir, factory_manifest)

        _write_status("staging", from_version, to_version, message="restoring factory release", operation=op)
        new_release_dir = RELEASES_DIR / f"{to_version}-factory-{int(time.time())}"
        shutil.copytree(factory_dir / "pinclock", new_release_dir / "pinclock")
        _make_writable(new_release_dir)
        _restore_labwc_files(factory_dir)
        _write_status("restarting", from_version, to_version, message="switching to factory release", operation=op)
        _atomic_symlink(CURRENT_LINK, new_release_dir / "pinclock")

        _write_status("healthchecking", from_version, to_version,
                       message="waiting for pinclock.service to come up", operation=op)
        healthy = _restart_and_healthcheck()
        if not healthy:
            _rollback(previous_target, to_version, "factory release failed health check after restart", operation=op)
            return

        _write_status("wiping_data", from_version, to_version, message="clearing videos", operation=op)
        _wipe_videos()

        _write_status("success", from_version, to_version,
                       message="factory release restored - resetting settings/WiFi and rebooting", operation=op)
        _prune_old_releases(keep=3)
        try:
            req = urllib.request.Request(
                f"{HEALTHCHECK_URL}api/system/reset-defaults", method="POST", data=b"{}",
                headers={"Content-Type": "application/json"},
            )
            urllib.request.urlopen(req, timeout=10)
        except (urllib.error.URLError, OSError) as e:
            raise UpdateError(f"factory code restored, but couldn't trigger settings/WiFi reset: {e}")

    except Exception as e:
        _write_status("failed", from_version, message=str(e), operation=op)
        if CURRENT_LINK.exists() and previous_target is not None and CURRENT_LINK.resolve() != previous_target:
            _rollback(previous_target, None, str(e), operation=op)
        if new_release_dir is not None and new_release_dir.exists():
            shutil.rmtree(new_release_dir, ignore_errors=True)
    finally:
        _release_lock()


def _prune_old_releases(keep=3):
    ""
    current_target = CURRENT_LINK.resolve() if CURRENT_LINK.exists() else None
    releases = sorted(
        (d for d in RELEASES_DIR.iterdir() if d.is_dir()),
        key=lambda d: d.stat().st_mtime, reverse=True,
    )
    for old in releases[keep:]:
        if current_target and old in current_target.parents:
            continue
        try:
            shutil.rmtree(old)
        except OSError as e:
            print(f"[run_update] WARNING: could not prune old release {old}: {e}")


def _copy_whole(src, dst):
    ""
    part = dst.with_name("." + dst.name + ".part")
    try:
        shutil.copy2(src, part)
        os.replace(part, dst)
    except BaseException:
        try:
            part.unlink()
        except OSError:
            pass
        raise


class Terminated(Exception):
    ""


def _on_sigterm(signum, frame):
    raise Terminated("the update was stopped before it finished (it took too long, or the clock "
                     "was shutting down) - nothing was changed; try again")


if __name__ == "__main__":
    RELEASES_DIR.mkdir(parents=True, exist_ok=True)
    if "--check" not in sys.argv:
        signal.signal(signal.SIGTERM, _on_sigterm)
    if "--check" in sys.argv:
        try:
            print(json.dumps(check_for_update()))
        except UpdateError as e:
            print(json.dumps({"error": str(e)}))
            sys.exit(1)
        sys.exit(0)

    if "--factory-reset" in sys.argv:
        try:
            run_factory_reset()
        except Exception as e:
            _write_status("failed", message=str(e), operation="factory_reset")
            sys.exit(1)
        sys.exit(0)

    try:
        run_update()
    except Exception as e:
        _write_status("failed", message=str(e))
        sys.exit(1)
