#!/usr/bin/env python3
"""
PinClock - make a comment-stripped copy of all three project folders, for
dragging onto test devices. Works on Windows (VS Code terminal) and Linux.

    python home-vfw-pinclock/scripts/make_stripped_copy.py C:\\pinclock-stripped
    python3 home-vfw-pinclock/scripts/make_stripped_copy.py ~/pinclock-stripped

Produces, inside the output folder:
    home-vfw-pinclock/        the app, comments stripped (same rules and
                              verification as build_release.py --strip)
    home-vfw-config-labwc/    launcher/boot files (v0.50.8: autostart /
                              autostart-legacy comment-stripped too; the
                              labwc `environment` file copied as-is)
    opt-pinclock-updater/     run_update.py, comments stripped
    STRIPPED-FROM.txt         version, time, and what was left unstripped

It only ever reads the source folders. The same files build_release.py
leaves out are left out here too (.git, dist, __pycache__, venv, ...), so
what you test is what a release would contain.

Safety:
  - Refuses an output folder inside your source repo (so a stripped copy
    can't end up committed next to the real code).
  - Re-running replaces the previous copy, but only if that folder was
    made by this script (it checks for STRIPPED-FROM.txt) - it never
    deletes a folder it didn't create.
  - Shell files with Windows line endings (CRLF) fail on the Pi. The copy
    always gets LF endings, and the source files that had CRLF are listed
    so you can fix them there too (see the .gitattributes note printed).

Shell scripts (*.sh, autostart) are stripped only when bash 5.2+ is on the
PATH - it checks each result (`bash --pretty-print`). On Windows that's
Git for Windows' bash (Git Bash); without it they're copied unstripped and
the report says so. build_release.py --strip on the Pi always has it.

JavaScript is stripped only when Node.js is installed (it's used to check
the result); without it the JS is copied unstripped and a warning says so.

--compress-videos (v0.30.9, on request - the EM videos had pushed a
firmware build past 120 MB): the copy's EM videos (home-vfw-pinclock/
em-videos/*.mp4) are re-encoded with ffmpeg - H.264 (the Pi 3B+ decodes it
in hardware; it has no H.265 decoder), at most 720 lines tall, CRF 26,
"slow" preset, AAC 96k sound if the video has any, moov atom up front. A
backglass video is a still picture for its first 30 seconds, which
compresses very well. A result is only used when it's smaller than the
original; otherwise the original is kept. The source folder is never
touched. Encoded files are cached next to the output folder
("<output>-video-cache"), keyed by the original's checksum and the
settings, so a re-run only encodes new or changed videos. Without ffmpeg
on the PATH the videos are copied unchanged, with a warning saying how to
install it (Windows: winget install Gyan.FFmpeg).

    python home-vfw-pinclock/scripts/make_stripped_copy.py C:\\pinclock-stripped --compress-videos
    ... --compress-videos --video-crf 28 --video-height 600 --video-no-audio
"""
import argparse
import datetime
import fnmatch
import hashlib
import re
import shutil
import subprocess
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
APP_DIR = SCRIPT_DIR.parent
REPO_ROOT = APP_DIR.parent
FOLDERS = ("home-vfw-pinclock", "home-vfw-config-labwc", "opt-pinclock-updater")
MARKER = "STRIPPED-FROM.txt"

sys.path.insert(0, str(SCRIPT_DIR))
import strip_comments
from build_release import EXCLUDED_DIR_NAMES, EXCLUDED_FILE_PATTERNS

SHELL_NAMES = {"autostart", "autostart-legacy", "environment"}


def is_shell(path):
    return path.suffix == ".sh" or path.name in SHELL_NAMES


def discover(folder):
    """Same inclusion rules as build_release._discover_files."""
    files = []
    for path in sorted(folder.rglob("*")):
        if path.is_dir():
            continue
        rel = path.relative_to(folder)
        if any(part in EXCLUDED_DIR_NAMES for part in rel.parts[:-1]):
            continue
        if any(fnmatch.fnmatch(path.name, pat) for pat in EXCLUDED_FILE_PATTERNS):
            continue
        files.append(rel)
    return files


def read_version():
    m = re.search(r'^PINCLOCK_VERSION\s*=\s*["\'](.+?)["\']',
                  (APP_DIR / "app.py").read_text(encoding="utf-8"), re.MULTILINE)
    return m.group(1) if m else "unknown"


VIDEO_DIRS = ("home-vfw-pinclock/em-videos",)


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def compress_videos(out, cache_dir, crf, height, audio):
    """Re-encodes the copy's EM videos in place (see the module docstring).
    Returns report lines for STRIPPED-FROM.txt."""
    videos = [v for d in VIDEO_DIRS if (out / d).is_dir() for v in sorted((out / d).glob("*.mp4"))]
    if not videos:
        print("videos: no EM videos to compress")
        return []
    return compress_video_files(videos, cache_dir, crf, height, audio)


def compress_video_files(videos, cache_dir, crf, height, audio):
    """v0.30.11: the re-encode itself, for any list of .mp4 files (replaced
    in place when smaller) - shared with build_release.py --compress-videos.
    Returns report lines."""
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        print("WARNING: --compress-videos: ffmpeg isn't on the PATH, so the EM videos were left unchanged. "
              "Install it (Windows: 'winget install Gyan.FFmpeg', then open a new terminal; "
              "Linux: 'sudo apt install ffmpeg') and run this again.")
        return ["videos: NOT compressed (ffmpeg not found)"]
    settings = f"h264-crf{crf}-h{height}-{'aac96' if audio else 'noaudio'}-v1"
    cache_dir.mkdir(parents=True, exist_ok=True)
    lines, before, after = [], 0, 0
    print(f"videos: compressing {len(videos)} EM video(s) ({settings})...")
    for v in videos:
        size0 = v.stat().st_size
        cached = cache_dir / f"{_sha256(v)}-{settings}.mp4"
        from_cache = cached.exists()
        if not from_cache:
            tmp = cache_dir / (cached.name + ".part.mp4")
            cmd = [ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-i", str(v),
                   "-map", "0:v:0", "-vf", f"scale=-2:min(ih\\,{height})",
                   "-c:v", "libx264", "-preset", "slow", "-crf", str(crf), "-pix_fmt", "yuv420p",
                   "-movflags", "+faststart"]
            cmd += ["-map", "0:a?", "-c:a", "aac", "-b:a", "96k"] if audio else ["-an"]
            cmd.append(str(tmp))
            r = subprocess.run(cmd, capture_output=True, text=True)
            if r.returncode != 0 or not tmp.exists():
                tmp.unlink(missing_ok=True)
                msg = (r.stderr or "").strip().splitlines()[-1:] or ["unknown error"]
                print(f"  WARNING: {v.name}: ffmpeg failed ({msg[0]}) - kept the original")
                lines.append(f"videos: {v.name} kept (ffmpeg failed)")
                before += size0
                after += size0
                continue
            tmp.replace(cached)
        size1 = cached.stat().st_size
        if size1 < size0:
            shutil.copyfile(cached, v)
            print(f"  {v.name}: {size0 / 1e6:.1f} MB -> {size1 / 1e6:.1f} MB" + ("  (cached)" if from_cache else ""))
        else:
            size1 = size0
            print(f"  {v.name}: {size0 / 1e6:.1f} MB (already small - kept the original)")
        before += size0
        after += size1
    print(f"videos: {before / 1e6:.1f} MB -> {after / 1e6:.1f} MB")
    lines.append(f"videos: EM videos compressed ({settings}): {before / 1e6:.1f} MB -> {after / 1e6:.1f} MB")
    return lines


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("output", help="folder to create the stripped copy in (outside the repo)")
    ap.add_argument("--compress-videos", action="store_true",
                    help="re-encode the copy's EM videos with ffmpeg to make them smaller (see above)")
    ap.add_argument("--video-crf", type=int, default=26,
                    help="H.264 quality for --compress-videos: higher = smaller (default 26; 23-30 is sensible)")
    ap.add_argument("--video-height", type=int, default=720,
                    help="--compress-videos: scale taller videos down to this many lines (default 720)")
    ap.add_argument("--video-no-audio", action="store_true",
                    help="--compress-videos: drop the sound track")
    args = ap.parse_args()
    out = Path(args.output).expanduser().resolve()

    try:
        out.relative_to(REPO_ROOT.resolve())
        sys.exit(f"ERROR: {out} is inside the source repo ({REPO_ROOT}) - pick a folder outside it.")
    except ValueError:
        pass
    missing = [f for f in FOLDERS if not (REPO_ROOT / f).is_dir()]
    if missing:
        sys.exit(f"ERROR: expected these folders next to each other in {REPO_ROOT}: missing {', '.join(missing)}")

    if out.exists():
        if not (out / MARKER).is_file():
            sys.exit(f"ERROR: {out} already exists and wasn't made by this script "
                     f"(no {MARKER}) - refusing to delete it. Pick another folder.")
        shutil.rmtree(out)
    out.mkdir(parents=True)

    report_lines, crlf_sources, node_missing = [], [], False
    for name in FOLDERS:
        src, dst = REPO_ROOT / name, out / name
        rels = discover(src)
        for rel in rels:
            (dst / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src / rel, dst / rel)
            if is_shell(rel):
                data = (dst / rel).read_bytes()
                if b"\r\n" in data:
                    crlf_sources.append(f"{name}/{rel.as_posix()}")
                    (dst / rel).write_bytes(data.replace(b"\r\n", b"\n"))
        report = strip_comments.strip_tree(dst, [r.as_posix() for r in rels])
        print(f"{name}:")
        strip_comments.print_report(report)
        for line in report["skipped"] + report["notes"]:
            report_lines.append(f"{name}: {line}")
            node_missing |= "Node.js not found" in line

    if args.compress_videos:
        report_lines += compress_videos(out, out.parent / (out.name + "-video-cache"),
                                        args.video_crf, args.video_height, not args.video_no_audio)

    version = read_version()
    (out / MARKER).write_text(
        f"Comment-stripped copy of PinClock {version}\n"
        f"Made {datetime.datetime.now().isoformat(timespec='seconds')} from {REPO_ROOT}\n"
        "Test copy only - never commit it. Publish with build_release.py --strip.\n"
        + ("\nLeft unstripped / notes:\n" + "\n".join(report_lines) + "\n" if report_lines else ""),
        encoding="utf-8")

    print(f"\nDone: {out}  ({version})")
    if node_missing:
        print("WARNING: Node.js isn't installed, so JavaScript was NOT stripped. "
              "Install Node.js (LTS), restart the terminal, and run this again.")
    if crlf_sources:
        print("WARNING: these shell files have Windows (CRLF) line endings in your source. "
              "The copy was fixed to LF, but a release built from the source would break on the Pi:")
        for f in crlf_sources:
            print(f"  {f}")
        print("Fix: add a .gitattributes with '* text=auto eol=lf' at the repo root, then "
              "'git add --renormalize .' and commit.")


if __name__ == "__main__":
    main()
