#!/usr/bin/env python3
"""
PinClock - font subsetting tool

Every bundled clock font only ever needs to draw a fixed, small
character set - see CLOCK_CHARS below for exactly what and why. Google
Fonts ships the full Latin character set (accented letters, punctuation,
currency symbols, the works) in every download, which is most of each
file's size for a use case this narrow. Subsetting drops everything
this app will never draw, which is the single biggest lever on the
fonts/ folder's total size - and that size matters directly: every byte
in it rides along with EVERY firmware update from now on, not just the
one that adds a new font (see app/static/fonts/ itself, referenced from
the OTA-versioned pinclock/ tree).

Run this against a font BEFORE adding it to app/static/fonts/ - see
this repo's own font-adding history for the full list of fonts already
subsetted this way. Safe to re-run against an already-subsetted file
(subsetting is idempotent - it can only ever be a no-op or shrink
further, never break something that already dropped the same glyphs).

Preserves variable-font axes (fvar/gvar) and color tables (COLR/CPAL,
SVG) as-is for whichever glyphs survive the subset - this only removes
UNUSED glyphs/data, it doesn't collapse a variable font to a static
instance or touch how a color font's remaining glyphs are colored.

Usage:
    python3 subset_fonts.py <input.ttf> <output.ttf>
    python3 subset_fonts.py <input.ttf> <output.ttf> --extra "XYZ"

    # v0.21.0+: batch mode - subset every font in a directory (recursively)
    # into a flat output directory in one pass, so adding a batch of new
    # fonts (e.g. a font pack with one file per weight/color variant) is
    # one command instead of one subset_font() invocation per file typed
    # by hand. Skips any input whose cmap doesn't cover CLOCK_CHARS + extra
    # (missing the colon glyph is the recurring one - see README below -
    # and shipping a font that can't draw ':' would silently break every
    # clock face that picks it) rather than writing a broken subset, and
    # prints a coverage/size report for the whole batch at the end so a
    # skip is loud, not a silent gap in app/static/fonts/ nobody notices
    # until Auto-Cycle happens to land on it.
    python3 subset_fonts.py --batch <input_dir> <output_dir>
    python3 subset_fonts.py --batch <input_dir> <output_dir> --extra "XYZ"
"""

import os
import sys

from fontTools import subset
from fontTools.ttLib import TTFont

CLOCK_CHARS = "0123456789: APMDFJNOSTWabcdeghilmnoprstuvy"

BANNER_CHARS = "".join(chr(c) for c in range(0x20, 0x7F))


def subset_font(input_path, output_path, extra_chars=""):
    chars = CLOCK_CHARS + BANNER_CHARS + extra_chars
    options = subset.Options()
    options.name_IDs = ["*"]
    options.layout_features = ["*"]
    options.notdef_glyph = True
    options.notdef_outline = False
    options.recalc_bounds = True
    options.recalc_timestamp = False

    font = subset.load_font(input_path, options)
    subsetter = subset.Subsetter(options=options)
    subsetter.populate(text=chars)
    subsetter.subset(font)
    subset.save_font(font, output_path, options)


def missing_chars(input_path, extra_chars=""):
    """Returns the sorted characters in CLOCK_CHARS + extra_chars that
    input_path's cmap has no glyph for at all - checked against the
    UNSUBSETTED font, before we'd otherwise find out the hard way by
    subsetting it down to a tofu box. Space is exempt (canvas advances
    past it with no glyph needed)."""
    font = TTFont(input_path, lazy=True)
    cmap = font.getBestCmap() or {}
    have = set(chr(c) for c in cmap.keys())
    needed = set(CLOCK_CHARS + extra_chars) - {" "}
    return sorted(needed - have)


FONT_EXTS = (".ttf", ".otf")


def batch_subset(input_dir, output_dir, extra_chars=""):
    """Walks input_dir recursively for .ttf/.otf files, subsets each one
    that has full CLOCK_CHARS(+extra) coverage into a FLAT output_dir
    (collisions on identical filenames from different subfolders are
    resolved by erroring rather than silently overwriting - rename one
    of the source files if that happens), and skips + reports the rest.
    Returns (written, skipped) - written is a list of (name, before_bytes,
    after_bytes), skipped is a list of (name, missing_chars_string)."""
    os.makedirs(output_dir, exist_ok=True)
    written, skipped = [], []
    seen_names = {}

    for root, _dirs, filenames in os.walk(input_dir):
        for name in sorted(filenames):
            if not name.lower().endswith(FONT_EXTS):
                continue
            in_path = os.path.join(root, name)
            missing = missing_chars(in_path, extra_chars)
            if missing:
                skipped.append((in_path, "".join(missing)))
                continue
            if name in seen_names:
                raise SystemExit(
                    f"duplicate output filename {name!r}: {seen_names[name]} "
                    f"and {in_path} would collide in {output_dir} - rename one"
                )
            seen_names[name] = in_path
            out_path = os.path.join(output_dir, name)
            subset_font(in_path, out_path, extra_chars)
            written.append((name, os.path.getsize(in_path), os.path.getsize(out_path)))

    return written, skipped


def _print_batch_report(written, skipped):
    if written:
        print(f"subsetted {len(written)} font(s):")
        total_before = total_after = 0
        for name, before, after in written:
            total_before += before
            total_after += after
            print(f"  {name:55s} {before/1024:8.1f} KB -> {after/1024:7.1f} KB")
        print(f"  {'TOTAL':55s} {total_before/1024:8.1f} KB -> {total_after/1024:7.1f} KB")
    if skipped:
        print(f"\nskipped {len(skipped)} font(s) - missing required glyph(s):")
        for path, missing in skipped:
            print(f"  {path}: missing {missing!r}")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)

    extra = ""
    if "--extra" in sys.argv:
        idx = sys.argv.index("--extra")
        extra = sys.argv[idx + 1]
        del sys.argv[idx : idx + 2]

    if sys.argv[1] == "--batch":
        if len(sys.argv) < 4:
            print(__doc__)
            sys.exit(1)
        in_dir, out_dir = sys.argv[2], sys.argv[3]
        written, skipped = batch_subset(in_dir, out_dir, extra)
        _print_batch_report(written, skipped)
    else:
        in_path, out_path = sys.argv[1], sys.argv[2]
        missing = missing_chars(in_path, extra)
        if missing:
            print(f"warning: {in_path} has no glyph for {''.join(missing)!r} - "
                  f"the subset will still be written, but this font can't draw "
                  f"everything CLOCK_CHARS needs")
        subset_font(in_path, out_path, extra)
        print(f"wrote {out_path}")
