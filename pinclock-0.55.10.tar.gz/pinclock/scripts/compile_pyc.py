#!/usr/bin/env python3
""
import argparse
import importlib.util
import marshal
import platform
import py_compile
import re
import shutil
import sys
from pathlib import Path

LAUNCHER = '''#!/usr/bin/env python3
# PinClock launcher - compiled release (scripts/compile_pyc.py, v0.41.0).
# The app is pinclock_app.pyc next to this file. This stays plain .py:
# pinclock.service runs app.py by path, and the updater reads the version
# line below from this file's text - keep it in exactly this form.
PINCLOCK_VERSION = "{version}"
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pinclock_app  # noqa: E402

if __name__ == "__main__":
    pinclock_app.main()
'''

VERSION_RE = re.compile(r'^PINCLOCK_VERSION\s*=\s*["\'](.+?)["\']', re.MULTILINE)


def is_compiled(root):
    return (Path(root) / "pinclock_app.pyc").exists()


def compile_tree(root):
    ""
    root = Path(root)
    app_py = root / "app.py"
    text = app_py.read_text()
    m = VERSION_RE.search(text)
    if not m:
        raise RuntimeError(f"no PINCLOCK_VERSION line in {app_py}")
    if "pinclock_app.main()" in text:
        raise RuntimeError(f"{root} is already compiled")
    targets = [root / "pinclock_app.py"] + sorted((root / "app" / "core").glob("*.py"))
    (root / "pinclock_app.py").write_text(text)
    added, removed = [], []
    try:
        for src in targets:
            dst = src.with_suffix(".pyc")
            py_compile.compile(str(src), cfile=str(dst), dfile=src.name, doraise=True)
            added.append(dst.relative_to(root).as_posix())
    except py_compile.PyCompileError:
        (root / "pinclock_app.py").unlink(missing_ok=True)
        for rel in added:
            (root / rel).unlink(missing_ok=True)
        raise
    for src in targets:
        src.unlink()
        if src.name != "pinclock_app.py":
            removed.append(src.relative_to(root).as_posix())
    app_py.write_text(LAUNCHER.format(version=m.group(1)))
    for cache in (root / "__pycache__", root / "app" / "core" / "__pycache__"):
        shutil.rmtree(cache, ignore_errors=True)
    return {"added": added, "removed": removed, "version": m.group(1)}


def check_compiled(root):
    ""
    problems = []
    root = Path(root)
    for pyc in [root / "pinclock_app.pyc"] + sorted((root / "app" / "core").glob("*.pyc")):
        data = pyc.read_bytes()
        if data[:4] != importlib.util.MAGIC_NUMBER:
            problems.append(f"{pyc.name}: made by a different Python version")
            continue
        try:
            marshal.loads(data[16:])
        except Exception as e:
            problems.append(f"{pyc.name}: unreadable ({e})")
    return problems


def on_a_pi_like_machine():
    return sys.platform.startswith("linux") and platform.machine().lower() in ("aarch64", "armv7l", "armv6l", "arm64")


def main():
    ap = argparse.ArgumentParser(description="Compile an installed PinClock release in place (.pyc only).")
    ap.add_argument("release_dir", nargs="?", default="/opt/pinclock/current")
    args = ap.parse_args()
    root = Path(args.release_dir).resolve()
    if not (root / "app.py").exists():
        sys.exit(f"{root} doesn't look like a PinClock release (no app.py)")
    if is_compiled(root) and "pinclock_app.main()" in (root / "app.py").read_text():
        sys.exit(f"{root} is already compiled - nothing to do")
    venv_py = Path("/opt/pinclock/venv/bin/python")
    if venv_py.exists() and Path(sys.executable).resolve() != venv_py.resolve():
        print(f"NOTE: compiling with {sys.executable} (Python {platform.python_version()}); "
              f"pinclock.service uses {venv_py} - they must be the same version.")
    res = compile_tree(root)
    problems = check_compiled(root)
    if problems:
        sys.exit("Compiled, but: " + "; ".join(problems))
    print(f"Compiled PinClock {res['version']} in {root}: {len(res['added'])} .pyc files, "
          f"app.py is now the launcher. Restart it:  systemctl --user restart pinclock.service")


if __name__ == "__main__":
    main()
