#!/usr/bin/env python3
"""
Edit retired-stock-videos.json - the list of stock videos a firmware
update removes from devices (v0.24.6+; see app/core/stock_retire.py for
how and when devices apply it).

Usage (from the pinclock/ folder):
    python3 scripts/retire_stock_video.py list
    python3 scripts/retire_stock_video.py add <filename> [--note "why"]
    python3 scripts/retire_stock_video.py remove <filename>
    ... add --em <filename>   (v0.30.13: a stock EM video, from em-videos/;
                              list / remove take --em too)
    ... add --uploads <filename> [<filename> ...]
                              (v0.31.7: a video to delete from My Videos -
                              the clock's OWN uploads, pinclock-data/videos/ -
                              once per clock; see app/core/stock_retire.py.
                              For videos that went out on SD cards by
                              mistake. list / remove take --uploads too)

Then bump PINCLOCK_VERSION and build as usual - the list ships inside the
release, and build_release.py checks it.

<filename> is the stock video's exact file name as it appears in
/opt/pinclock/shipped-videos/ on the device (case matters), e.g.
"attract-loop-2024.mp4".

"remove" takes a video OFF the retired list - only needed to bring a
retired video back, which also means shipping the file again in
shipped-videos/. Otherwise the list should only ever grow: a device
that skips releases only applies the list of the one it lands on.

Edits only this one JSON file; nothing is deleted anywhere by running
this script. (With --em it also drops the name from build_release.py's
em-videos-shipped.json the next time a release is built - see there - so
--em-videos new ships it again if it's ever brought back.)
"""
import argparse
import json
import re
import sys
from pathlib import Path

PINCLOCK_DIR = Path(__file__).resolve().parent.parent
LIST_FILE = PINCLOCK_DIR / "retired-stock-videos.json"


def _load():
    if not LIST_FILE.exists():
        return {"retired": []}
    return json.loads(LIST_FILE.read_text())


def _save(data):
    LIST_FILE.write_text(json.dumps(data, indent=2) + "\n")


def _app_version():
    m = re.search(r'^PINCLOCK_VERSION\s*=\s*["\'](.+?)["\']', (PINCLOCK_DIR / "app.py").read_text(), re.M)
    return m.group(1).lstrip("v") if m else "?"


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    lp = sub.add_parser("list")
    lp.add_argument("--em", action="store_true", help="the stock EM videos list")
    lp.add_argument("--uploads", action="store_true", help="the My Videos list")
    a = sub.add_parser("add")
    a.add_argument("filenames", nargs="+", metavar="filename")
    a.add_argument("--note", default="")
    a.add_argument("--em", action="store_true", help="a stock EM video (em-videos/)")
    a.add_argument("--uploads", action="store_true", help="a video in My Videos (the clock's own uploads)")
    r = sub.add_parser("remove")
    r.add_argument("filenames", nargs="+", metavar="filename")
    r.add_argument("--em", action="store_true", help="a stock EM video (em-videos/)")
    r.add_argument("--uploads", action="store_true", help="a video in My Videos")
    args = ap.parse_args()
    if args.em and args.uploads:
        print("ERROR: use --em or --uploads, not both", file=sys.stderr)
        return 1

    if args.uploads:
        key, folder, what = "retired_user", None, "My Videos"
    elif args.em:
        key, folder, what = "retired_em", "em-videos", "stock EM videos"
    else:
        key, folder, what = "retired", "shipped-videos", "stock videos"
    data = _load()
    entries = data.setdefault(key, [])
    names = [e["filename"] if isinstance(e, dict) else e for e in entries]

    if args.cmd == "list":
        if not entries:
            print(f"No retired {what}.")
        for e in entries:
            e = e if isinstance(e, dict) else {"filename": e}
            extra = "".join(f"  {k}: {e[k]}" for k in ("since", "note") if e.get(k))
            print(f"{e['filename']}{extra}")
        return 0

    for name in args.filenames:
        if name != Path(name).name or name.startswith(".") or not name:
            print(f"ERROR: {name!r} must be a plain file name (no folders) - nothing changed", file=sys.stderr)
            return 1

    if args.cmd == "add":
        lower = {n.lower() for n in names}
        added = []
        for name in args.filenames:
            if name.lower() in lower:
                print(f"{name} is already on the retired {what} list - skipped.")
                continue
            if folder and (PINCLOCK_DIR / folder / name).exists():
                print(f"ERROR: {folder}/{name} is in this release - remove the file from "
                      f"{folder}/ first, or the release would add and remove it at once. Nothing changed.",
                      file=sys.stderr)
                return 1
            entry = {"filename": name, "since": _app_version()}
            if args.note:
                entry["note"] = args.note
            entries.append(entry)
            lower.add(name.lower())
            added.append(name)
        if added:
            _save(data)
            print(f"Added {len(added)} to the retired {what} list (since {_app_version()}): {', '.join(added)}. "
                  f"The next release built from this tree removes them from clocks.")
        return 0

    gone = [n for n in args.filenames if n in names]
    for n in args.filenames:
        if n not in names:
            print(f"{n} isn't on the retired {what} list - skipped.")
    if gone:
        data[key] = [e for e in entries if (e["filename"] if isinstance(e, dict) else e) not in gone]
        _save(data)
        if folder:
            print(f"Took {', '.join(gone)} off the retired {what} list. To bring them back on devices, "
                  f"also ship the files again in {folder}/.")
        else:
            print(f"Took {', '.join(gone)} off the retired {what} list. Clocks that already removed them "
                  f"won't remove them again.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
