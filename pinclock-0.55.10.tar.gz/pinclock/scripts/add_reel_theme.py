#!/usr/bin/env python3
"""
PinClock - add a Score Reels theme (v0.26.3)

Adds one new entry to REEL_THEMES in app/static/js/reels.js and appends its
id to REEL_THEME_ORDER - the control panel's theme picker builds itself from
that list, so this is the whole change. Same safety rules as add_font.py:
it only ever APPENDS (never edits or removes an existing theme), it inserts
at explicit ADD-THEME markers and refuses to run if they're missing, and
every value is validated before anything is written. After building the
new reels.js text it re-reads it with Node and checks the theme came out
exactly as intended before the file is replaced.

A theme starts as a copy of an existing one (--base, default "classic"),
then gets colors from, in this order (later wins):
  1. --json FILE      a JSON object of theme fields (any subset)
  2. --image FILE     an automatic starting palette picked from a picture,
                      e.g. a backglass photo (needs Pillow:
                      sudo apt install python3-pil). A starting point to
                      tweak, not a finished design - check --preview.
  3. --set KEY=VALUE  individual fields, repeatable

Usage:
    python3 scripts/add_reel_theme.py --list
    python3 scripts/add_reel_theme.py --key surf --label "Surf's Up" \\
        --base space --set plate="#1aa6d9,#0b5f8a" --set deco=none \\
        --preview surf.html --dry-run
    python3 scripts/add_reel_theme.py --key surf --label "Surf's Up" \\
        --image backglass.jpg --preview surf.html
    python3 scripts/add_reel_theme.py --key surf --label "Surf's Up" \\
        --json surf.json

--preview FILE writes a self-contained HTML page (open it in any browser,
no PinClock needed) showing the theme framed and frameless, 12h and 24h,
and a live rolling clock - exactly what the kiosk draws, since it runs the
real reels.js with the new theme in it. Combine with --dry-run to preview
without adding anything.

Theme fields (see the REEL_THEMES comment in reels.js for what each does;
*W/padX/padY are fractions of the reel window height):
    label                    name shown in the control panel
    frameless                true/false (v0.26.5) - true: no plate, deco or
                             glass, just the reels (like "Reels Only")
    plate                    "#top,#bottom"         (two colors)
    plateRims, windowRims    "#color:width,..."     (or "none")
    deco                     one of REEL_DECOS in reels.js (--list shows them)
    decoColor, decoColor2, decoColor3, padX, padY
    recess, drum, ink, colon, dateText, backlight,
    lampOnCenter, lampOnEdge, lampOnGlow, lampOnText, lampOff, lampOffText
Colors: #rgb, #rrggbb, rgb(r,g,b) or rgba(r,g,b,a).

Needs Node.js (already on the build Pi - build_release.py uses it too).

After running it: bump PINCLOCK_VERSION in app.py yourself and build as a
normal OTA release. reels.js is ordinary app code - no manual install step.
To change or remove a theme later, edit reels.js by hand (this script never
touches an existing one), keeping its id in REEL_THEME_ORDER in step.
Don't remove a theme people may have selected without a reason: a device
whose saved reel_theme no longer exists just falls back to the default
(reelThemeId() in reels.js), which is safe but may surprise its owner.
"""
import argparse
import ast
import base64
import colorsys
import datetime
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(SCRIPT_DIR)
JS_DIR = os.path.join(APP_DIR, "app", "static", "js")
REELS_JS = os.path.join(JS_DIR, "reels.js")
FONTS_CSS = os.path.join(APP_DIR, "app", "static", "css", "fonts.css")
SETTINGS_STORE = os.path.join(APP_DIR, "app", "core", "settings_store.py")

THEME_MARKER = "    // ADD-THEME MARKER: scripts/add_reel_theme.py adds new themes directly\n"
ORDER_MARKER = "    // ADD-THEME-ORDER MARKER: scripts/add_reel_theme.py appends new ids here.\n"

KEY_RE = re.compile(r"^[a-z][a-z0-9_]*$")
COLOR_RE = re.compile(
    r"^(#[0-9a-fA-F]{3}|#[0-9a-fA-F]{6}"
    r"|rgba?\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*(,\s*(0|1|0?\.\d+|1\.0+)\s*)?\))$"
)

FIELD_ORDER = [
    "label", "frameless", "plate", "plateRims", "deco", "decoColor", "decoColor2", "decoColor3",
    "padX", "padY", "recess", "windowRims", "drum", "ink", "colon", "backlight",
    "lampOnCenter", "lampOnEdge", "lampOnGlow", "lampOnText", "lampOff", "lampOffText",
    "dateText",
]
RIM_FIELDS = ("plateRims", "windowRims")
PAD_FIELDS = ("padX", "padY")


def fail(msg):
    print(f"error: {msg}", file=sys.stderr)
    sys.exit(1)



def node_path():
    node = shutil.which("node")
    if not node:
        fail("Node.js not found - this script reads reels.js with Node so it "
             "never has to guess at JavaScript syntax. Install it (the build Pi "
             "already has it for build_release.py) and run this again.")
    return node


NODE_READ = r"""
const fs = require("fs"), vm = require("vm");
const files = JSON.parse(process.argv[1]);
const ctx = {};
vm.createContext(ctx);
let src = "";
for (const f of files) src += fs.readFileSync(f, "utf8") + "\n;\n";
src += ";this.__out = { themes: REEL_THEMES, order: REEL_THEME_ORDER, decos: REEL_DECOS," +
       " font: (typeof TT_FONTS !== 'undefined' && TT_FONTS[REEL_FONT_ID]) || null };";
vm.runInContext(src, ctx);
process.stdout.write(JSON.stringify(ctx.__out));
"""


def read_reels(reels_path, with_renderer=False):
    """REEL_THEMES / REEL_THEME_ORDER / REEL_DECOS as parsed by Node itself
    (and the reel font's TT_FONTS entry when with_renderer)."""
    files = []
    if with_renderer:
        files += [os.path.join(JS_DIR, "dmdfont.js"), os.path.join(JS_DIR, "renderer.js")]
    files.append(reels_path)
    res = subprocess.run([node_path(), "-e", NODE_READ, json.dumps(files)],
                         capture_output=True, text=True, timeout=60)
    if res.returncode != 0:
        fail(f"Node couldn't read {reels_path}:\n{res.stderr.strip()}")
    return json.loads(res.stdout)



def check_color(field, v):
    if not isinstance(v, str) or not COLOR_RE.match(v.strip()):
        fail(f"{field}: {v!r} isn't a color (use #rgb, #rrggbb, rgb(...) or rgba(...))")
    return v.strip()


def check_rims(field, v):
    if not isinstance(v, list):
        fail(f"{field}: expected a list of {{c, w}}")
    out = []
    for i, rim in enumerate(v):
        if not isinstance(rim, dict) or set(rim) != {"c", "w"}:
            fail(f"{field}[{i}]: expected {{\"c\": color, \"w\": width}}, got {rim!r}")
        w = rim["w"]
        if not isinstance(w, (int, float)) or not (0 < w <= 0.2):
            fail(f"{field}[{i}].w: {w!r} - widths are fractions of the reel height, 0 < w <= 0.2")
        out.append({"c": check_color(f"{field}[{i}].c", rim["c"]), "w": round(float(w), 4)})
    return out


def validate(theme, decos, required):
    out = {}
    for k, v in theme.items():
        if k not in FIELD_ORDER:
            fail(f"unknown field {k!r} - known fields: {', '.join(FIELD_ORDER)}")
        if k == "frameless":
            if not isinstance(v, bool):
                fail(f"frameless: expected true or false, got {v!r}")
            out[k] = v
        elif k == "label":
            if not isinstance(v, str) or not v.strip():
                fail("label can't be empty")
            out[k] = v.strip()
        elif k == "plate":
            if not isinstance(v, list) or len(v) != 2:
                fail("plate: expected two colors (top, bottom)")
            out[k] = [check_color("plate[0]", v[0]), check_color("plate[1]", v[1])]
        elif k in RIM_FIELDS:
            out[k] = check_rims(k, v)
        elif k == "deco":
            if v not in decos:
                fail(f"deco: {v!r} isn't one reels.js can draw - choose from: {', '.join(decos)}")
            out[k] = v
        elif k in PAD_FIELDS:
            if not isinstance(v, (int, float)) or not (0 <= v <= 1):
                fail(f"{k}: {v!r} - a fraction of the reel height, 0..1")
            out[k] = round(float(v), 4)
        else:
            out[k] = check_color(k, v)
    missing = [k for k in required if k not in out]
    if missing:
        fail(f"missing fields: {', '.join(missing)}")
    return out


def parse_set(item):
    if "=" not in item:
        fail(f"--set {item!r}: expected KEY=VALUE")
    k, v = item.split("=", 1)
    k, v = k.strip(), v.strip()
    if k == "frameless":
        if v.lower() not in ("true", "false"):
            fail(f"--set frameless: true or false (got {v!r})")
        return k, v.lower() == "true"
    if k == "plate":
        return k, [p.strip() for p in v.split(",")]
    if k in RIM_FIELDS:
        if v.lower() in ("", "none"):
            return k, []
        rims = []
        for part in v.split(","):
            if ":" not in part:
                fail(f"--set {k}: each rim is color:width, e.g. \"#c8202c:0.03\" (got {part!r})")
            c, w = part.rsplit(":", 1)
            try:
                rims.append({"c": c.strip(), "w": float(w)})
            except ValueError:
                fail(f"--set {k}: width {w!r} isn't a number")
        return k, rims
    if k in PAD_FIELDS:
        try:
            return k, float(v)
        except ValueError:
            fail(f"--set {k}: {v!r} isn't a number")
    return k, v



def _hex(rgb):
    return "#%02x%02x%02x" % tuple(max(0, min(255, int(round(c)))) for c in rgb)


def _mix(rgb, target, f):
    return tuple(a + (b - a) * f for a, b in zip(rgb, target))


def _lum(rgb):
    r, g, b = (c / 255 for c in rgb)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


class ImagePaletteError(Exception):
    """v0.27.3: palette_from_image()'s failure when used as a library (app.py's
    face plate upload) - the command line still turns it into fail()."""


def _trim_frame(im):
    """v0.27.5: crops a photo's frame/mat and caption (a Polaroid-style white
    border with the title written on it, as on Pinside photos) - otherwise
    the border's white and the caption ink outweigh the artwork itself. Keeps
    the longest run of rows, then columns, that are mostly NOT the border
    color (35%+ of the row/column), plus a 3% inset. Leaves the image alone if that would keep less
    than a third of it (no real frame)."""
    from PIL import ImageChops
    w, h = im.size
    ring = [im.getpixel((x, y)) for x in range(0, w, max(1, w // 40)) for y in (0, h - 1)] + \
           [im.getpixel((x, y)) for y in range(0, h, max(1, h // 40)) for x in (0, w - 1)]
    border = tuple(sorted(c[i] for c in ring)[len(ring) // 2] for i in range(3))
    plain = sum(1 for c in ring if max(abs(c[i] - border[i]) for i in range(3)) <= 40)
    if plain < 0.7 * len(ring):
        return im
    from PIL import Image
    near = ImageChops.difference(im, Image.new("RGB", im.size, border)).convert("L").point(lambda v: 255 if v > 48 else 0)
    hh, ss, vv = im.convert("HSV").split()
    pale = ImageChops.multiply(ss.point(lambda v: 255 if v < 31 else 0), vv.point(lambda v: 255 if v > 178 else 0))
    mask = ImageChops.subtract(near, pale)
    px = mask.load()

    def longest_run(n, frac):
        runs, start = [], None
        for i in range(n + 1):
            on = i < n and frac(i) > 0.35
            if on and start is None:
                start = i
            elif not on and start is not None:
                runs.append([start, i])
                start = None
        if not runs:
            return (0, n)
        merged = [runs[0]]
        for r in runs[1:]:
            if r[0] - merged[-1][1] <= 0.2 * n:
                merged[-1][1] = r[1]
            else:
                merged.append(r)
        best = max(merged, key=lambda r: r[1] - r[0])
        return (best[0], best[1])
    y0, y1 = longest_run(h, lambda y: sum(1 for x in range(0, w, 2) if px[x, y]) / ((w + 1) // 2))
    x0, x1 = longest_run(w, lambda x: sum(1 for y in range(y0, y1, 2) if px[x, y]) / max(1, (y1 - y0 + 1) // 2))
    if (x1 - x0) * (y1 - y0) < w * h / 3:
        return im
    ix, iy = int((x1 - x0) * 0.03), int((y1 - y0) * 0.03)
    box = (x0 + ix, y0 + iy, x1 - ix, y1 - iy)
    out = im.crop(box)
    out._frame_box = (box[0] / w, box[1] / h, box[2] / w, box[3] / h)
    return out


def frame_box(im):
    """v0.27.5: _trim_frame()'s crop as fractions (x0, y0, x1, y1) of `im`,
    worked out on a small copy - app.py uses it to crop the frame off an
    image used as the EM Clock's face plate, at full size. (0, 0, 1, 1) when
    there's no frame."""
    small = im.convert("RGB")
    small.thumbnail((240, 240))
    t = _trim_frame(small)
    return getattr(t, "_frame_box", (0.0, 0.0, 1.0, 1.0))


PALETTE_VERSION = 3


def palette_from_image(path, quiet=False):
    """A complete theme palette from a picture (plate, rims, deco, colon,
    lamps), using Pillow's median-cut quantizer (no numpy needed).
    v0.27.3: also used by app.py for the EM Clock's uploaded images, so it
    raises ImagePaletteError instead of exiting, takes a path or a file
    object, and quiet=True skips the summary line.
    v0.27.5 (reported: "Create Theme from Image" on a Fireball backglass
    photo gave one flat brown): v0.26.3's rule - plate = the MOST COMMON
    vivid color - picked the photo's dull brown over its reds, and the
    white photo frame counted too. Now, closer to how the hand-made themes
    were built from backglasses:
      - the frame/caption is cropped first (_trim_frame)
      - vivid colors are ranked by count x saturation x brightness, so a
        smaller area of strong red beats a big area of brown
      - plate: the picture's background - its darker colors, when they
        cover a fifth of it, in the most colorful of their hues (made a
        little richer) - else the top vivid color
      - accent (plate rims, lamps) = the top vivid color; second accent =
        the next vivid color at least ~25 degrees of hue away
      - deco: a dark plate with a warm accent gets none (v0.51.14: never
        flames - v0.27.5-v0.51.13 added them for "fire on black", which
        bold art on black also passed); a dark plate with a cool accent
        gets stars, a bright plate a mod
        band in the second accent (its lamps take that accent too)
      - colon/date: the second accent if it's bright, else the light color."""
    try:
        from PIL import Image
    except ImportError:
        raise ImagePaletteError("--image needs Pillow (on the Pi: sudo apt install python3-pil)")
    try:
        im = Image.open(path).convert("RGB")
    except Exception as e:
        raise ImagePaletteError(f"couldn't open {path}: {e}")
    im.thumbnail((240, 240))
    im.thumbnail((160, 160))
    q = im.quantize(colors=16, method=Image.Quantize.MEDIANCUT)
    pal = q.getpalette()
    colors = []
    for count, idx in sorted(q.getcolors(), reverse=True):
        rgb = tuple(pal[idx * 3: idx * 3 + 3])
        h, s, v = colorsys.rgb_to_hsv(*(c / 255 for c in rgb))
        colors.append({"n": count, "rgb": rgb, "h": h, "s": s, "v": v})
    total = sum(c["n"] for c in colors) or 1

    def hue_gap(a, b):
        d = abs(a - b)
        return min(d, 1 - d)

    def hsv(h, s, v):
        return tuple(c * 255 for c in colorsys.hsv_to_rgb(h, max(0, min(1, s)), max(0, min(1, v))))

    vivid = sorted((c for c in colors if c["s"] >= 0.4 and c["v"] >= 0.4),
                   key=lambda c: -(c["n"] * c["s"] * c["v"] ** 1.5))
    if not vivid:
        vivid = sorted(colors, key=lambda c: -(c["n"] * (c["s"] + 0.05)))
    acc = vivid[0]
    acc2 = next((c for c in vivid[1:] if hue_gap(c["h"], acc["h"]) >= 0.07), None)
    darks = sorted((c for c in colors if c["v"] < 0.3), key=lambda c: c["v"])
    dark = darks[0]["rgb"] if darks else (17, 17, 17)
    lights = sorted((c for c in colors if c["s"] < 0.25 and c["v"] > 0.8), key=lambda c: -c["v"])
    light = lights[0]["rgb"] if lights else (246, 238, 219)

    backs = [c for c in colors if c["v"] < 0.45]
    dark_plate = sum(c["n"] for c in backs) / total >= 0.2
    if dark_plate:
        back = max(backs, key=lambda c: c["n"] * c["s"])
        bh, bs, bv = back["h"], back["s"], back["v"]
        if bs < 0.25 or bv < 0.06:
            bh, bs, bv = acc["h"], 0.5, 0.2
        top = hsv(bh, max(bs, 0.45), min(0.38, max(bv * 1.3, 0.2)))
        bottom = hsv(bh, max(bs, 0.45), 0.07)
    else:
        top = _mix(acc["rgb"], (255, 255, 255), 0.12)
        bottom = _mix(acc["rgb"], (0, 0, 0), 0.25)
    plate_mid = _mix(top, bottom, 0.5)

    warm = acc["h"] <= 0.13 or acc["h"] >= 0.94
    a1 = hsv(acc["h"], max(acc["s"], 0.8), max(acc["v"], 0.95))
    if acc2 is not None:
        a2 = hsv(acc2["h"], max(acc2["s"], 0.7), max(acc2["v"], 0.95))
    else:
        a2 = hsv((acc["h"] + 0.08) % 1, 0.75, 1.0)
    theme = {
        "plate": [_hex(top), _hex(bottom)],
        "plateRims": [{"c": _hex(a1), "w": 0.02}, {"c": _hex(dark), "w": 0.01}],
        "recess": "#050505",
        "windowRims": [{"c": "#2b2b2b", "w": 0.014}, {"c": _hex(_mix(light, (246, 230, 196), 0.5)), "w": 0.026}],
        "deco": "none",
    }
    if dark_plate and warm:
        pass
    elif dark_plate:
        theme.update(deco="stars", decoColor="#ffffff", decoColor2=_hex(a2))
    else:
        theme.update(deco="modband", decoColor=_hex(a2), decoColor2=_hex(dark))
    on_plate = a2 if (_lum(a2) > 0.45 and _lum(plate_mid) < 0.35) else (dark if _lum(plate_mid) > 0.45 else light)
    lamp = a1 if dark_plate else a2
    lamp_off = _mix(plate_mid, lamp, 0.12)
    theme.update({
        "colon": _hex(on_plate),
        "dateText": _hex(on_plate),
        "lampOnCenter": _hex(_mix(lamp, (255, 255, 255), 0.7)),
        "lampOnEdge": _hex(lamp),
        "lampOnGlow": "rgba(%d,%d,%d,0.9)" % tuple(int(c) for c in lamp),
        "lampOnText": _hex(_mix(lamp, (0, 0, 0), 0.75)),
        "lampOff": _hex(lamp_off),
        "lampOffText": _hex(_mix(lamp_off, (255, 255, 255), 0.25)),
    })
    if not quiet:
        print(f"--image {os.path.basename(str(path))}: plate {theme['plate'][0]}..{theme['plate'][1]}, "
              f"accent {_hex(a1)}, second {_hex(a2)}, deco {theme['deco']}")
    return theme



def js_str(s):
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'


def js_num(n):
    """0.03 -> "0.03", 0.1 -> "0.1", 1.0 -> "1" (same style as the hand-written themes)."""
    return f"{float(n):.4f}".rstrip("0").rstrip(".")


def js_rims(rims):
    return "[" + ", ".join(f"{{ c: {js_str(r['c'])}, w: {js_num(r['w'])} }}" for r in rims) + "]"


def theme_js(key, theme, note):
    today = datetime.date.today().isoformat()
    lines = [f"    // Added by scripts/add_reel_theme.py ({today})" + (f": {note}" if note else ".")]
    lines.append(f"    {key}: {{")
    for k in FIELD_ORDER:
        if k not in theme:
            continue
        v = theme[k]
        if k == "frameless":
            if not v:
                continue
            val = "true"
        elif k == "plate":
            val = f"[{js_str(v[0])}, {js_str(v[1])}]"
        elif k in RIM_FIELDS:
            val = js_rims(v)
        elif k in PAD_FIELDS:
            val = js_num(v)
        else:
            val = js_str(v)
        lines.append(f"        {k}: {val},")
    lines.append("    },")
    return "\n".join(lines) + "\n"


def insert(text, key, entry):
    if THEME_MARKER not in text:
        fail("couldn't find the ADD-THEME MARKER in reels.js (inside REEL_THEMES) - "
             "restore it and try again; nothing was written.")
    if ORDER_MARKER not in text:
        fail("couldn't find the ADD-THEME-ORDER MARKER in reels.js (inside "
             "REEL_THEME_ORDER) - restore it and try again; nothing was written.")
    text = text.replace(THEME_MARKER, entry + THEME_MARKER, 1)
    return text.replace(ORDER_MARKER, f"    {js_str(key)},\n" + ORDER_MARKER, 1)



PREVIEW_HTML = """<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<title>PinClock reel theme: __LABEL__</title>
<style>
@font-face { font-family: __FAMILY__; src: url(data:font/ttf;base64,__FONT__); font-weight: __WEIGHT__; }
body { margin: 0; padding: 20px; background: #161616; color: #ddd; font: 15px/1.4 system-ui, sans-serif; }
h1 { font-size: 20px; margin: 0 0 4px; }
.sub { color: #999; margin-bottom: 16px; }
.grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(420px, 1fr)); gap: 16px; }
.card { background: #222; border-radius: 10px; padding: 10px; }
.card b { display: block; margin-bottom: 6px; font-weight: 600; }
canvas { width: 100%; height: auto; display: block; border-radius: 6px;
         background: linear-gradient(135deg, #1d5b8a, #7a2f6b 50%, #d0782a); }
</style></head><body>
<h1>__LABEL__ <span style="color:#888">(__KEY__)</span></h1>
<div class="sub">PinClock Score Reels theme preview - drawn by the real reels.js. The colorful background stands in for the video.</div>
<div class="grid">
  <div class="card"><b>Live (rolls every second)</b><canvas id="live" width="900" height="300"></canvas></div>
  <div class="card"><b>12h with seconds</b><canvas data-x='{}' width="900" height="300"></canvas></div>
  <div class="card"><b>12h, no seconds, factory-new (Worn look 0)</b><canvas data-x='{"show_seconds": false, "reel_wear": 0}' width="900" height="300"></canvas></div>
  <div class="card"><b>24h with date</b><canvas data-x='{"clock_format": "24h", "show_seconds": false, "show_date": true}' width="900" height="300"></canvas></div>
  <div class="card"><b>Well worn, bright backlight</b><canvas data-x='{"reel_wear": 80, "reel_backlight": 100}' width="900" height="300"></canvas></div>
  <div class="card"><b>Next to Score Glass</b><canvas id="classic" width="900" height="300"></canvas></div>
</div>
<script>window.PINCLOCK_DEFAULTS = __DEFAULTS__;</script>
__SCRIPTS__
<script>
(function () {
  var KEY = __KEYJSON__;
  function drawAll() {
    document.querySelectorAll("canvas[data-x]").forEach(function (cv) {
      reelRenderPreview(cv, KEY, JSON.parse(cv.dataset.x), new Date(2026, 9, 12, 21, 59, 45));
    });
    reelRenderPreview(document.getElementById("classic"), "classic");
  }
  var live = document.getElementById("live"), lctx = live.getContext("2d");
  var probe = reelComputeLayout(lctx, 100, { is24h: false, showSeconds: true, showAmpm: true, showDate: false, themeId: KEY, fontReady: true });
  var scale = Math.min(live.width * 0.94 / probe.w, live.height * 0.9 / probe.h);
  var liveSettings = Object.assign({}, window.PINCLOCK_DEFAULTS, {
    clock_style: "reels", reel_theme: KEY, clock_position: "center", clock_size: 100 * scale / zoomFactor(live.height),
    clock_format: "12h", show_seconds: true, show_ampm: true, show_date: false,
    title_enabled: false, ticker_enabled: false
  });
  function frame() {
    try { lctx.clearRect(0, 0, live.width, live.height); drawReelClock(lctx, live.width, live.height, liveSettings); } catch (e) { console.error(e); }
    requestAnimationFrame(frame);
  }
  drawAll();
  (document.fonts ? document.fonts.load(__FONTSPEC__) : Promise.resolve()).then(drawAll, drawAll);
  requestAnimationFrame(frame);
})();
</script>
</body></html>
"""


def write_preview(path, key, label, reels_text, font_def):
    """Self-contained HTML: every script inlined (reels.js with the new theme
    in it), the reel font embedded, no network or PinClock needed."""
    def inline(name, text=None):
        if text is None:
            with open(os.path.join(JS_DIR, name), encoding="utf-8") as f:
                text = f.read()
        return f"<script>/* {name} */\n" + text.replace("</script", "<\\/script") + "\n</script>"

    scripts = "\n".join([
        inline("dmdfont.js"), inline("ledfont.js"), inline("clock.js"), inline("bars.js"),
        inline("renderer.js"), inline("reels.js", reels_text),
    ])
    family = (font_def or {}).get("family", "'Barlow Condensed'")
    weight = (font_def or {}).get("weight", "bold")
    font_b64 = ""
    with open(FONTS_CSS, encoding="utf-8") as f:
        css = f.read()
    m = re.search(r"@font-face\s*\{[^}]*font-family:\s*" + re.escape(family) + r"\s*;[^}]*?src:\s*url\('([^']+)'\)", css)
    if m:
        font_file = os.path.join(APP_DIR, "app", m.group(1).lstrip("/"))
        if os.path.isfile(font_file):
            with open(font_file, "rb") as f:
                font_b64 = base64.b64encode(f.read()).decode("ascii")
    if not font_b64:
        print(f"warning: couldn't find the reel font ({family}) in fonts.css - the preview will use a fallback font")
    defaults = {}
    with open(SETTINGS_STORE, encoding="utf-8") as f:
        for node in ast.parse(f.read()).body:
            if isinstance(node, ast.Assign) and getattr(node.targets[0], "id", "") == "DEFAULT_SETTINGS":
                defaults = ast.literal_eval(node.value)
    html = (PREVIEW_HTML
            .replace("__SCRIPTS__", scripts)
            .replace("__DEFAULTS__", json.dumps(defaults))
            .replace("__FAMILY__", family)
            .replace("__WEIGHT__", weight)
            .replace("__FONTSPEC__", json.dumps(f"{weight} 100px {family}"))
            .replace("__FONT__", font_b64)
            .replace("__KEYJSON__", json.dumps(key))
            .replace("__KEY__", key)
            .replace("__LABEL__", label.replace("&", "&amp;").replace("<", "&lt;")))
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"preview written: {path}")



def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--list", action="store_true", help="list existing themes and decos, then exit")
    ap.add_argument("--key", help="new theme id (lowercase letters, digits, _), e.g. surf")
    ap.add_argument("--label", help='name shown in the control panel, e.g. "Surf\'s Up"')
    ap.add_argument("--base", default="classic", help="existing theme to start from (default classic)")
    ap.add_argument("--json", help="JSON file of theme fields")
    ap.add_argument("--image", help="picture to take a starting palette from (needs Pillow)")
    ap.add_argument("--set", action="append", default=[], metavar="KEY=VALUE", help="set one field (repeatable)")
    ap.add_argument("--note", default="", help="short note for the comment above the theme")
    ap.add_argument("--preview", metavar="FILE.html", help="also write a self-contained preview page")
    ap.add_argument("--dry-run", action="store_true", help="show what would be added, write nothing to reels.js")
    args = ap.parse_args()

    if not os.path.isfile(REELS_JS):
        fail(f"expected file not found: {REELS_JS}")
    with open(REELS_JS, encoding="utf-8") as f:
        reels_text = f.read()
    info = read_reels(REELS_JS)
    themes, order, decos = info["themes"], info["order"], info["decos"]

    if args.list:
        print("themes (in picker order):")
        for k in order:
            t = themes.get(k, {})
            print(f"  {k:<12} {t.get('label', '?'):<20} deco={t.get('deco', 'none')}")
        print("decos:", ", ".join(decos))
        return

    if not args.key or not args.label:
        fail("--key and --label are required (or use --list)")
    if not KEY_RE.match(args.key):
        fail(f"--key {args.key!r}: lowercase letters, digits and _ only, starting with a letter")
    if args.key in themes:
        fail(f"a theme called {args.key!r} already exists - pick another key (this script "
             f"never changes an existing theme; edit reels.js by hand for that)")
    if args.base not in themes:
        fail(f"--base {args.base!r} isn't a theme - choose from: {', '.join(order)}")

    theme = json.loads(json.dumps(themes[args.base]))
    if args.json:
        try:
            with open(args.json, encoding="utf-8") as f:
                extra = json.load(f)
        except (OSError, ValueError) as e:
            fail(f"couldn't read --json {args.json}: {e}")
        if not isinstance(extra, dict):
            fail("--json must contain one JSON object of theme fields")
        theme.update(extra)
    if args.image:
        try:
            theme.update(palette_from_image(args.image))
        except ImagePaletteError as e:
            fail(str(e))
    for item in args.set:
        k, v = parse_set(item)
        theme[k] = v
    theme["label"] = args.label
    explicit = {parse_set(i)[0] for i in args.set}
    if args.json:
        explicit |= set(extra)
    if theme.get("deco") != themes[args.base].get("deco"):
        for k in ("decoColor", "decoColor2", "decoColor3", "padX", "padY"):
            if k not in explicit:
                theme.pop(k, None)

    required = [k for k in FIELD_ORDER if all(k in t for t in themes.values())]
    theme = validate(theme, decos, required)
    if theme.get("frameless") is False:
        del theme["frameless"]

    entry = theme_js(args.key, theme, args.note)
    new_text = insert(reels_text, args.key, entry)

    fd, tmp = tempfile.mkstemp(suffix=".js")
    os.close(fd)
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(new_text)
        check = subprocess.run([node_path(), "--check", tmp], capture_output=True, text=True)
        if check.returncode != 0:
            fail(f"the edited reels.js didn't pass node --check (nothing written):\n{check.stderr}")
        back = read_reels(tmp, with_renderer=bool(args.preview))
    finally:
        os.remove(tmp)
    if back["themes"].get(args.key) != theme:
        fail("verification failed: the theme read back from the edited reels.js "
             "doesn't match what was meant to be written (nothing written)")
    if back["order"] != order + [args.key]:
        fail("verification failed: REEL_THEME_ORDER didn't come out as expected (nothing written)")
    for k, t in themes.items():
        if back["themes"].get(k) != t:
            fail(f"verification failed: existing theme {k!r} changed (nothing written)")

    print("--- theme entry ---")
    print(entry, end="")
    if args.preview:
        write_preview(args.preview, args.key, theme["label"], new_text, back.get("font"))
    if args.dry_run:
        print("(dry run - reels.js not changed)")
        return
    with open(REELS_JS, "w", encoding="utf-8", newline="\n") as f:
        f.write(new_text)
    print(f"added {args.key!r} to {REELS_JS}")
    print("Next: bump PINCLOCK_VERSION in app.py, then build as a normal OTA release.")


if __name__ == "__main__":
    main()
