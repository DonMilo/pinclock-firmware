#!/usr/bin/env python3
""

import json
import re
import os
import signal
import socket
import subprocess
import time
from datetime import datetime
from pathlib import Path

MPV_SOCKET = os.environ.get("PINCLOCK_MPV_SOCKET", "/tmp/mpvsocket")
REBOOT_LOG_FILE = Path("/home/vfw/pinclock-data/watchdog-reboots.log")
REBOOT_LOG_MAX_LINES = 100

PROBE_INTERVAL_S = 5

MPV_TIMEOUT_S = 3
MPV_FAIL_THRESHOLD = 3

MPV_STALL_CONSECUTIVE = 3

MPV_REBOOT_ESCALATION_RESTARTS = 10
MPV_REBOOT_ESCALATION_WINDOW_S = 300

MPV_UNHEALTHY_CONSECUTIVE = 4

MPV_KILL_REBOOT_ESCALATION = 3
MPV_KILL_REBOOT_WINDOW_S = 900
MAX_AUTO_REBOOTS_PER_HOUR = 2

GPU_V3D_RESTART_KB = 140 * 1024
GPU_RESTART_COOLDOWN_S = 120
GPU_LOG_INTERVAL_S = 60
BO_STATS_PATHS = ("/sys/kernel/debug/dri/0/bo_stats", "/sys/kernel/debug/dri/1/bo_stats")

WPE_CPU_THRESHOLD_PCT = 85.0
WPE_HANG_CONSECUTIVE = 12
WPE_HANG_HEARTBEAT_S = 45

RENDER_HEARTBEAT_FILE = "/tmp/pinclock-render-heartbeat"
RENDER_HEARTBEAT_STALE_S = 90

ITERATION_HARD_TIMEOUT_S = 10


class IterationTimeout(Exception):
    ""


def _alarm_handler(signum, frame):
    raise IterationTimeout()


signal.signal(signal.SIGALRM, _alarm_handler)


def _log(message):
    line = f"[{datetime.now().isoformat(timespec='seconds')}] {message}"
    print(line, flush=True)


def _log_reboot(reason):
    ""
    entry = f"[{datetime.now().isoformat(timespec='seconds')}] {reason}"
    try:
        lines = []
        if REBOOT_LOG_FILE.exists():
            lines = REBOOT_LOG_FILE.read_text().splitlines()
        lines.append(entry)
        lines = lines[-REBOOT_LOG_MAX_LINES:]
        REBOOT_LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        REBOOT_LOG_FILE.write_text("\n".join(lines) + "\n")
    except OSError as e:
        _log(f"couldn't write REBOOT_LOG_FILE (continuing with the reboot anyway): {e}")


def _mpv_ipc_request(command_list, timeout=MPV_TIMEOUT_S):
    ""
    if not os.path.exists(MPV_SOCKET):
        return True, None
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as sock:
            sock.settimeout(timeout)
            sock.connect(MPV_SOCKET)
            sock.sendall(json.dumps({"command": command_list}).encode("utf-8") + b"\n")
            buf = b""
            while b"\n" not in buf:
                chunk = sock.recv(4096)
                if not chunk:
                    return False, None
                buf += chunk
            line = buf.split(b"\n", 1)[0]
            try:
                return True, json.loads(line.decode("utf-8"))
            except ValueError:
                return True, None
    except socket.timeout:
        return False, None
    except OSError:
        return True, None


def probe_mpv():
    ""
    ok, _resp = _mpv_ipc_request(["get_property", "pause"])
    return ok


def mpv_time_pos():
    ""
    ok, resp = _mpv_ipc_request(["get_property", "time-pos"])
    if not ok or resp is None or resp.get("error") != "success":
        return None
    return resp.get("data")


def mpv_health_sample():
    ""
    ok, pause_resp = _mpv_ipc_request(["get_property", "pause"])
    if not ok:
        return "timeout", None, "IPC timeout on pause query"
    ok, pos_resp = _mpv_ipc_request(["get_property", "time-pos"])
    if not ok:
        return "timeout", None, "IPC timeout on time-pos query"
    if pause_resp is not None and pause_resp.get("error") == "success" and pause_resp.get("data") is True:
        return "neutral", None, "paused"
    if pos_resp is None or pos_resp.get("error") != "success" or pos_resp.get("data") is None:
        return "neutral", None, "not running or idle"
    return "playing", pos_resp.get("data"), None


def recent_auto_reboots(window_s=3600):
    ""
    try:
        lines = REBOOT_LOG_FILE.read_text().splitlines()
    except OSError:
        return 0
    now = datetime.now()
    count = 0
    for line in lines:
        if not line.startswith("["):
            continue
        try:
            ts = datetime.fromisoformat(line[1:line.index("]")])
        except ValueError:
            continue
        if 0 <= (now - ts).total_seconds() <= window_s:
            count += 1
    return count


def reboot_with_guard(reason):
    ""
    if recent_auto_reboots() >= MAX_AUTO_REBOOTS_PER_HOUR:
        _log(f"WOULD reboot ({reason}) but {MAX_AUTO_REBOOTS_PER_HOUR} automatic reboots already "
             f"happened in the last hour - skipping to avoid a reboot loop")
        return False
    reason = f"{reason} [CmaFree {cma_free_kb()} kB, V3D {gpu_v3d()}]"
    _log(reason)
    _log_reboot(reason)
    subprocess.run(["sudo", "systemctl", "reboot"])
    return True


def cma_free_kb():
    ""
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("CmaFree:"):
                    return int(line.split()[1])
    except (OSError, ValueError, IndexError):
        pass
    return None


def gpu_v3d():
    ""
    for path in BO_STATS_PATHS:
        try:
            out = subprocess.run(["sudo", "-n", "/usr/bin/cat", path],
                                 capture_output=True, text=True, timeout=3)
        except (subprocess.SubprocessError, OSError):
            continue
        if out.returncode != 0:
            continue
        m = re.search(r"^\s*V3D:\s*(\d+)kb BOs \((\d+)\)", out.stdout, re.MULTILINE)
        if m:
            return int(m.group(1)), int(m.group(2))
    return None


def mpv_restart_count():
    ""
    try:
        return int(Path("/tmp/pinclock-mpv-restart-count").read_text().strip())
    except (OSError, ValueError):
        return None


def render_heartbeat_stale():
    ""
    try:
        age = time.time() - os.path.getmtime(RENDER_HEARTBEAT_FILE)
        return age > RENDER_HEARTBEAT_STALE_S
    except OSError:
        return False


def render_heartbeat_age():
    ""
    try:
        return time.time() - os.path.getmtime(RENDER_HEARTBEAT_FILE)
    except OSError:
        return None


def find_pid(name):
    ""
    try:
        out = subprocess.run(["pgrep", "-x", name], capture_output=True, text=True, timeout=5)
        pids = out.stdout.split()
        return int(pids[0]) if pids else None
    except (subprocess.SubprocessError, ValueError):
        return None


def cpu_seconds(pid):
    ""
    try:
        with open(f"/proc/{pid}/stat") as f:
            content = f.read()
        after_comm = content[content.rindex(")") + 2:]
        fields = after_comm.split()
        utime, stime = int(fields[11]), int(fields[12])
        hz = os.sysconf("SC_CLK_TCK")
        return (utime + stime) / hz
    except (OSError, IndexError, ValueError):
        return None


def main():
    _log("watchdog starting")
    mpv_bad_streak = 0
    mpv_last_time_pos = None
    mpv_kill_times = []
    gpu_last_restart = 0.0
    gpu_last_log = 0.0
    gpu_unreadable_logged = False
    wpe_high_streak = 0
    wpe_busy_logged = False
    wpe_pid = None
    wpe_pid_since = 0.0
    wpe_last_cpu_s = None
    mpv_restart_window_start = None
    mpv_restart_count_at_window_start = None

    while True:
        signal.alarm(ITERATION_HARD_TIMEOUT_S)
        try:
            state, cur_time_pos, why = mpv_health_sample()
            if state == "timeout":
                bad = why
            elif state == "playing" and cur_time_pos == mpv_last_time_pos:
                bad = f"time-pos not advancing, stuck at {cur_time_pos}"
            else:
                bad = None

            if bad is None:
                mpv_bad_streak = 0
                mpv_last_time_pos = cur_time_pos
            else:
                mpv_bad_streak += 1
                _log(f"mpv unhealthy: {bad} ({mpv_bad_streak}/{MPV_UNHEALTHY_CONSECUTIVE})")
                if mpv_bad_streak >= MPV_UNHEALTHY_CONSECUTIVE:
                    _log("mpv stuck past threshold - killing it for supervise() to restart")
                    subprocess.run(["pkill", "-9", "-x", "mpv"])
                    mpv_bad_streak = 0
                    mpv_last_time_pos = None
                    now = time.time()
                    mpv_kill_times = [t for t in mpv_kill_times if now - t <= MPV_KILL_REBOOT_WINDOW_S]
                    mpv_kill_times.append(now)
                    if len(mpv_kill_times) >= MPV_KILL_REBOOT_ESCALATION:
                        reason = (f"watchdog killed a stuck mpv {len(mpv_kill_times)} times within "
                                  f"{MPV_KILL_REBOOT_WINDOW_S}s - decoder likely wedged below the "
                                  f"process level, escalating to a full reboot")
                        if reboot_with_guard(reason):
                            mpv_kill_times = []

            cur_restarts = mpv_restart_count()
            if cur_restarts is not None:
                if mpv_restart_window_start is None or \
                        time.time() - mpv_restart_window_start > MPV_REBOOT_ESCALATION_WINDOW_S:
                    mpv_restart_window_start = time.time()
                    mpv_restart_count_at_window_start = cur_restarts
                elif cur_restarts - mpv_restart_count_at_window_start >= MPV_REBOOT_ESCALATION_RESTARTS:
                    reason = (f"mpv restarted {cur_restarts - mpv_restart_count_at_window_start} times in "
                              f"under {MPV_REBOOT_ESCALATION_WINDOW_S}s despite process-level restarts - "
                              f"escalating to a full reboot (confirmed on real hardware that this actually "
                              f"clears it when a plain restart doesn't)")
                    reboot_with_guard(reason)
                    mpv_restart_window_start = None

            current_wpe_pid = find_pid("WPEWebProcess")
            if current_wpe_pid != wpe_pid:
                wpe_pid = current_wpe_pid
                wpe_pid_since = time.time()
                wpe_last_cpu_s = None
                wpe_high_streak = 0
                wpe_busy_logged = False

            if wpe_pid is not None:
                cur_cpu_s = cpu_seconds(wpe_pid)
                if cur_cpu_s is not None and wpe_last_cpu_s is not None:
                    pct = (cur_cpu_s - wpe_last_cpu_s) / PROBE_INTERVAL_S * 100
                    if pct >= WPE_CPU_THRESHOLD_PCT:
                        wpe_high_streak += 1
                        if not wpe_busy_logged:
                            _log(f"WPEWebProcess at {pct:.0f}% CPU ({min(wpe_high_streak, WPE_HANG_CONSECUTIVE)}/{WPE_HANG_CONSECUTIVE})")
                    else:
                        if wpe_busy_logged:
                            _log(f"WPEWebProcess back to {pct:.0f}% CPU")
                        wpe_high_streak = 0
                        wpe_busy_logged = False
                    if wpe_high_streak >= WPE_HANG_CONSECUTIVE:
                        hb_age = render_heartbeat_age()
                        if hb_age is not None and hb_age <= WPE_HANG_HEARTBEAT_S:
                            if not wpe_busy_logged:
                                _log(f"WPEWebProcess busy (pid {wpe_pid}) but still rendering "
                                     f"(heartbeat {hb_age:.0f}s ago) - left alone")
                                wpe_busy_logged = True
                            wpe_high_streak = WPE_HANG_CONSECUTIVE
                        else:
                            hb_txt = "no heartbeat yet" if hb_age is None else f"no heartbeat for {hb_age:.0f}s"
                            _log(f"WPEWebProcess pegged past threshold (pid {wpe_pid}, {hb_txt}) - killing it; "
                                 f"Cog's --webprocess-failure=exit + supervise() should recover it")
                            subprocess.run(["kill", "-9", str(wpe_pid)])
                            wpe_pid = None
                            wpe_last_cpu_s = None
                            wpe_high_streak = 0
                            wpe_busy_logged = False
                wpe_last_cpu_s = cur_cpu_s

            v3d = gpu_v3d()
            now = time.time()
            if v3d is None and not gpu_unreadable_logged:
                _log("can't read vc4 bo_stats (is sudoers/pinclock-gpustats installed?) - "
                     "GPU buffer guard is OFF; logging CmaFree only")
                gpu_unreadable_logged = True
            if now - gpu_last_log >= GPU_LOG_INTERVAL_S:
                v3d_txt = f"V3D {v3d[0]} kB ({v3d[1]} buffers)" if v3d else "V3D unknown"
                _log(f"GPU: {v3d_txt}, CmaFree {cma_free_kb()} kB")
                gpu_last_log = now
            if (v3d is not None and v3d[0] > GPU_V3D_RESTART_KB
                    and now - gpu_last_restart >= GPU_RESTART_COOLDOWN_S):
                _log(f"GPU buffers high (V3D {v3d[0]} kB, {v3d[1]} buffers > {GPU_V3D_RESTART_KB} kB) - "
                     f"restarting Cog to free them before mpv is starved")
                subprocess.run(["pkill", "-x", "cog"])
                gpu_last_restart = now
                wpe_pid = None
                wpe_last_cpu_s = None
                wpe_high_streak = 0

            if (wpe_pid is not None and time.time() - wpe_pid_since > RENDER_HEARTBEAT_STALE_S
                    and render_heartbeat_stale()):
                _log(f"render heartbeat stale past {RENDER_HEARTBEAT_STALE_S}s (pid {wpe_pid}) - "
                     f"killing it; Cog's --webprocess-failure=exit + supervise() should recover it")
                subprocess.run(["kill", "-9", str(wpe_pid)])
                wpe_pid = None
                wpe_last_cpu_s = None
                wpe_high_streak = 0
        except IterationTimeout:
            _log("watchdog iteration hit the hard timeout ({}s) - something didn't respect its own "
                 "timeout; forcibly continuing".format(ITERATION_HARD_TIMEOUT_S))
        except Exception as e:
            _log(f"watchdog iteration error (continuing): {e}")
        finally:
            signal.alarm(0)

        time.sleep(PROBE_INTERVAL_S)


if __name__ == "__main__":
    main()
