# Adding a font to PinClock

One command, using `scripts/add_font.py`. This replaces what used to be
four separate manual edits (subsetting the font, base64-embedding it in
`fonts.css`, registering it in `renderer.js`, adding its dropdown option
in `control.html`) with a single script run.

## Requirements

- Python 3 with `fontTools` installed: `pip install fonttools`
- A `.ttf` or `.otf` font file

## Basic usage

```
cd scripts
python3 add_font.py /path/to/YourFont.ttf --key your_font --label "Your Font"
```

- `--key` — the internal id. Lowercase letters, digits, underscores only,
  must start with a letter (e.g. `my_cool_font`). This is what gets saved
  in settings, so don't pick something you'll want to rename later.
- `--label` — what shows up in the Font dropdown, e.g. `"My Cool Font"`.

That's the minimum. Run it, and it:

1. Subsets the font down to just the characters PinClock ever draws
   (shrinks the file, same as every other font already in the project).
2. Reads the font's own family name from the file itself — you don't
   type this by hand, which avoids a mismatch that would make the font
   silently fail to render with no error anywhere explaining why.
3. Adds the new `@font-face` block, `TT_FONTS` entry, and dropdown
   `<option>` — one line appended to each of three files.
4. Copies the subsetted file into `app/static/fonts/` for the record.

## Optional flags

```
python3 add_font.py /path/to/YourFont.ttf --key your_font --label "Your Font" \
  --color --threeD --group your_font_family
```

- `--color` — the font has its own built-in colors (a COLR/SVG color
  font). It'll ignore the SFX Color setting and always show its own
  colors.
- `--threeD` — the font has a raised/beveled look. Purely cosmetic
  labeling for the dropdown (shows "(3D)" or "(3D, color)").
- `--group SOMENAME` — use this when you're adding **several color/style
  variants of one typeface** (like the existing DigitaltS or ResotE
  fonts, which each ship as 2-4 separate color versions). Give every
  variant the *same* `--group` value. This is what makes Auto-Cycle
  avoid picking two variants of the same font back-to-back — without
  it, "Font A (Red)" could be immediately followed by "Font A (Blue)",
  which reads as the same font repeating itself. Skip this entirely for
  a standalone font with no siblings.
- `--weight normal` or `--weight bold` — defaults to `normal`. Only
  matters if the font is specifically a bold-weight file.
- `--extra "XYZ"` — keep extra characters beyond the standard set. You
  almost certainly don't need this; see `subset_fonts.py`'s own
  `CLOCK_CHARS` comment for what's already covered (every digit, colon,
  space, AM/PM, and every letter needed to spell out any weekday name
  or month abbreviation).
- `--dry-run` — show exactly what would be added to each file without
  writing anything. Good for checking a font before committing to it.

## Always try `--dry-run` first

```
python3 add_font.py /path/to/YourFont.ttf --key your_font --label "Your Font" --dry-run
```

This prints the family name it read from the font, the file size
before/after subsetting, and exactly what line would be added to each
of the three files — with nothing actually written. If anything looks
off (wrong family name, unexpected size), you'll see it here before it
touches any file.

## If it refuses to run

The script is built to refuse rather than guess when something's not
right. Each refusal tells you exactly what to do:

- **"already appears in ..."** — you're reusing a `--key` or the font's
  internal family name collides with a font already in the project.
  Pick a different one.
- **"has no glyph for ..."** — the font can't draw every character
  PinClock might need (every font is shared between the regular clock's
  date line and the Special Effects Clock, so this bar applies even to
  fonts you only plan to use for SFX). Usually this means the digits or
  colon are missing, which would break the clock outright — don't
  override this without checking exactly what's missing first, listed
  right in the error. If you're confident the gap doesn't matter for
  how you'll actually use it, `--force` adds it anyway.
- **"couldn't find the ADD-FONT MARKER in ..."** — one of the three
  files has been edited by hand in a way that removed the marker
  comment the script inserts new fonts next to. Nothing gets written if
  this happens — it's all-or-nothing across the three files, never a
  partial edit. You'd need to restore the marker comment by hand (search
  the file for "ADD-FONT MARKER" in the other two files to see the exact
  wording) before the script can run again.

## After adding a font

The script doesn't touch `app.py` or trigger a deploy — that's
deliberate, so you stay in control of when a new version actually ships.
Two steps left:

1. Bump `PINCLOCK_VERSION` in `app.py` (a new font is a real, visible
   change worth a version bump, same as any other update).
2. Redeploy as a normal OTA update. This is app code, not a
   manual-deploy file — no `deploy_manual_files.sh` needed, just the
   regular update flow.

## Removing a font

This script only ever adds — it doesn't touch existing entries at all.
Removing one is still a manual, three-file edit: delete its
`@font-face` block from `fonts.css`, its entry from `TT_FONTS` in
`renderer.js`, and its `<option>` from `control.html`. (A companion
"remove" mode could be added later if this becomes a common enough
need to justify it.)
