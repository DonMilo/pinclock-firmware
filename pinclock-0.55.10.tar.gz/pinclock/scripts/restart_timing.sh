#!/bin/sh

HB=/tmp/pinclock-render-heartbeat
now() { date +%s.%N; }
since() { awk -v a="$T0" -v b="$(now)" 'BEGIN { printf "%5.1f", b - a }'; }

OLD_COG="$(pgrep -x cog | head -n1)"
OLD_WPE="$(pgrep -x WPEWebProcess | head -n1)"
if [ -z "$OLD_COG" ]; then
    echo "Cog isn't running - nothing to time." >&2
    exit 1
fi

rm -f "$HB"
T0="$(now)"
pkill -x cog

T_COG=""; T_WPE=""; T_HB=""
i=0
while [ "$i" -lt 600 ]; do
    if [ -z "$T_COG" ]; then
        P="$(pgrep -x cog | head -n1)"
        [ -n "$P" ] && [ "$P" != "$OLD_COG" ] && T_COG="$(since)"
    fi
    if [ -z "$T_WPE" ]; then
        P="$(pgrep -x WPEWebProcess | head -n1)"
        [ -n "$P" ] && [ "$P" != "$OLD_WPE" ] && T_WPE="$(since)"
    fi
    if [ -f "$HB" ]; then
        T_HB="$(since)"
        break
    fi
    sleep 0.1
    i=$((i + 1))
done

echo "Cog restart timing (seconds after the restart):"
echo "  new Cog running:          ${T_COG:-  never}"
echo "  page renderer running:    ${T_WPE:-  never}"
echo "  clock drawing again:      ${T_HB:-  not within 60 s}"
