#!/usr/bin/env python3
"""
v0.31.0: checks fx-styles/font-tags.txt and fx-styles/video-styles.txt
(font tags and per-video DMD effect styles - see their own headers) and
shows what the clock will make of them.

    python3 scripts/check_fx_styles.py                 summary + warnings
    python3 scripts/check_fx_styles.py --video Stern_Godzilla.mp4
                                                       which section a video gets
    python3 scripts/check_fx_styles.py --tags          every tag and its fonts
    python3 scripts/check_fx_styles.py --strict        exit 1 on any warning
    python3 scripts/check_fx_styles.py --data-dir DIR  also read DIR/fx-styles/
                                                       (a clock's own files)

build_release.py runs it (warnings are printed, the build goes on).
Same parser as the clock (app/core/fx_styles.py), loaded by path so this
needs nothing installed.
"""
import argparse
import fnmatch
import importlib.util
import sys
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent.parent


def _load_parser():
    spec = importlib.util.spec_from_file_location("fx_styles", APP_DIR / "app" / "core" / "fx_styles.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def match_video(data, video):
    """Same rule as renderer.js fxVideoRule() (without the decoded
    on-screen name): exact name first, then the first wildcard match."""
    file = Path(video).name.lower()
    names = [file, file.rsplit(".", 1)[0] if "." in file else file]
    def hit(p):
        return any(fnmatch.fnmatchcase(n, p) for n in names)
    for r in data["videos"]:
        if any(not any(c in p for c in "*?") and hit(p) for p in r["patterns"]):
            return r
    for r in data["videos"]:
        if any(any(c in p for c in "*?") and hit(p) for p in r["patterns"]):
            return r
    return None


def _show(v, field):
    val = v.get(field)
    if val is None:
        return "(Effects tab)"
    if val == "any":
        return "any (Auto-Cycle colors)"
    return ", ".join(val) + f"  [{len(val)}]"


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--video", action="append", default=[], help="show the section this video file gets")
    ap.add_argument("--tags", action="store_true", help="list every tag with its fonts")
    ap.add_argument("--strict", action="store_true", help="exit 1 if there are any warnings")
    ap.add_argument("--data-dir", default=None, help="a clock's data folder (reads its fx-styles/ too)")
    ap.add_argument("--quiet", action="store_true", help="warnings only")
    args = ap.parse_args(argv)

    fx = _load_parser()
    data_dir = Path(args.data_dir) if args.data_dir else APP_DIR / ".no-device-dir"
    data = fx.build(APP_DIR, data_dir)
    reg = fx.registry(APP_DIR / "app" / "static" / "js" / "renderer.js")

    if not args.quiet:
        print("fx-styles: read " + (", ".join(data["files"]) or "nothing"))
        untagged = [f for f in reg["fonts"] if f not in data["fontTags"]]
        print(f"fonts: {len(reg['fonts'])}, tagged {len(reg['fonts']) - len(untagged)}, "
              f"tags: {', '.join(f'{t} ({len(v)})' for t, v in sorted(data['tags'].items())) or 'none'}")
        if untagged:
            print("untagged: " + ", ".join(untagged))
        if args.tags:
            for t, ids in sorted(data["tags"].items()):
                print(f"  {t}: " + ", ".join(reg["fonts"][i]["label"] for i in ids))
        print(f"video sections: {len(data['videos'])}")
        for v in data["videos"]:
            print(f"  [{v['label']}]  ({v['where']})")
            for field, name in (("fonts", "fonts"), ("fontTypes", "font_types"), ("colors", "colors"), ("effects", "effects")):
                if v.get(field) is not None:
                    print(f"      {name:10} = {_show(v, field)}")
        for name in args.video:
            r = match_video(data, name)
            print(f"video {name}: " + (f"[{r['label']}] ({r['where']})" if r else "no section - the Effects tab's choices"))
            if r:
                for field, label in (("fonts", "fonts"), ("fontTypes", "font_types"), ("colors", "colors"), ("effects", "effects")):
                    print(f"      {label:10} = {_show(r, field)}")

    if data["warnings"]:
        print(f"fx-styles: {len(data['warnings'])} warning(s):")
        for w in data["warnings"]:
            print("  WARNING " + w)
    elif not args.quiet:
        print("fx-styles: no warnings")
    return 1 if (args.strict and data["warnings"]) else 0


if __name__ == "__main__":
    sys.exit(main())
