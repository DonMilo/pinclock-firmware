#!/bin/sh

BRAND_ARG=""
MAC_UNLOCK=""
KEEP_SETTINGS=""
KEEP_UPLOADS=""
for arg in "$@"; do
    case "$arg" in
        --generic) BRAND_ARG=generic ;;
        --branded|--pinballlife) BRAND_ARG=pinballlife ;;
        --mac-unlock) MAC_UNLOCK=1 ;;
        --keep-settings) KEEP_SETTINGS=1 ;;
        --keep-uploads) KEEP_UPLOADS=1 ;;
        *) echo "unknown option: $arg (use --generic, --branded, --mac-unlock, --keep-settings or --keep-uploads)" >&2; exit 2 ;;
    esac
done
SCRIPT_DIR=$(dirname "$0")

PINCLOCK_DATA_DIR="/home/vfw/pinclock-data"
CONFIG_FILE="$PINCLOCK_DATA_DIR/config.json"
STATE_FILE="$PINCLOCK_DATA_DIR/state.json"
IDENTITY_ENV="$PINCLOCK_DATA_DIR/device_identity.env"

echo "== PinClock: settings and user content =="
VFW_UID=$(id -u vfw 2>/dev/null)
if [ -n "$VFW_UID" ]; then
    if sudo -u vfw XDG_RUNTIME_DIR="/run/user/$VFW_UID" systemctl --user stop pinclock.service 2>/dev/null; then
        echo "Stopped pinclock.service (the screen may show an error page until you power off - that's expected)."
    else
        echo "WARNING: couldn't stop pinclock.service - resetting anyway."
    fi
fi
RESET_ARGS=""
[ -n "$KEEP_SETTINGS" ] && RESET_ARGS="$RESET_ARGS --keep-settings"
[ -n "$KEEP_UPLOADS" ] && RESET_ARGS="$RESET_ARGS --keep-uploads"
# load in the Python version that made them, which is the venv's.
RESET_PY=/opt/pinclock/venv/bin/python
[ -x "$RESET_PY" ] || RESET_PY=python3
APP_PY_DIR="$SCRIPT_DIR/../app"
if (cd "$APP_PY_DIR" && "$RESET_PY" -m core.shipping_reset $RESET_ARGS); then
    :
else
    echo "WARNING: the settings/content reset failed (see above) - press Default Settings on the"
    echo "Device tab instead, then run this script again."
fi
# Run as root, anything it rewrote would be root's - give it all back to vfw.
if id vfw >/dev/null 2>&1 && [ -d "$PINCLOCK_DATA_DIR" ]; then
    chown -R vfw:vfw "$PINCLOCK_DATA_DIR"
fi
echo

echo "== PinClock: clearing WiFi credentials before shipping =="

if [ -f "$IDENTITY_ENV" ]; then
    . "$IDENTITY_ENV"
fi
HOTSPOT_NAME="${PINCLOCK_HOTSPOT_SSID:-PinClock-Setup}"

nmcli -t -f NAME,TYPE connection show 2>/dev/null | while IFS=: read -r name type; do
    if { [ "$type" = "wifi" ] || [ "$type" = "802-11-wireless" ]; } && [ "$name" != "$HOTSPOT_NAME" ]; then
        echo "Deleting NetworkManager profile: $name"
        nmcli connection delete "$name" >/dev/null 2>&1
    fi
done

if [ -f "$CONFIG_FILE" ]; then
    python3 - "$CONFIG_FILE" <<'PYEOF'
import json, sys
path = sys.argv[1]
with open(path) as f:
    cfg = json.load(f)
cfg["wifi"] = {"configured": False, "ssid": "", "connection_name": ""}
with open(path, "w") as f:
    json.dump(cfg, f, indent=2)
print(f"Cleared wifi section of {path}")
PYEOF
fi

if [ -f "$STATE_FILE" ]; then
    rm -f "$STATE_FILE"
    echo "Removed $STATE_FILE (time-validity + first_boot state - regenerates fresh on next boot, so the new owner gets the real first-boot QR/countdown experience instead of the outgoing test run's leftover state)"
fi

echo
echo "Clearing /etc/machine-id (will regenerate fresh on next boot)..."
truncate -s 0 /etc/machine-id

if [ -f /var/lib/dbus/machine-id ] && [ ! -L /var/lib/dbus/machine-id ]; then
    truncate -s 0 /var/lib/dbus/machine-id
    echo "Also cleared /var/lib/dbus/machine-id (real file, not a symlink here)"
fi

if [ -d /var/log/journal ]; then
    echo "Clearing persistent journal logs..."
    rm -rf /var/log/journal/*
fi

echo
echo "== Brand =="
if [ -n "$BRAND_ARG" ]; then
    sh "$SCRIPT_DIR/set_brand.sh" "$BRAND_ARG"
else
    sh "$SCRIPT_DIR/set_brand.sh"
    echo "(unchanged - pass --generic or --branded to set it)"
fi

echo
echo "== Mac Lock =="
if [ -n "$MAC_UNLOCK" ]; then
    python3 -c "import sys; sys.path.insert(0, '$SCRIPT_DIR/../app'); from core import mac_lock; print('Mac Lock cleared.' if mac_lock.clear_lock() else 'Mac Lock: nothing to clear.')"
else
    python3 -c "import sys; sys.path.insert(0, '$SCRIPT_DIR/../app'); from core import mac_lock as m; r = m._lock_record(m._load()); d = m._load(); print(('Mac Lock: %s to %s (%s)' % (r['mode'], r['mac'], r.get('how', ''))) if r else 'Mac Lock: not set'); print('Mac Lock: Unlock pending - registers to the next Pi it starts in' if m._rebind_record(d) else '', end='')"
    echo "(for a MASTER image: rerun with --mac-unlock - see the top of this script)"
fi
BOOT_OK=""
for d in /boot/firmware /boot; do
    if [ -f "$d/pinclock-macunlock.txt" ]; then BOOT_OK="$d/pinclock-macunlock.txt"; fi
done
if [ -n "$BOOT_OK" ]; then
    echo "SD-card unlock file present: $BOOT_OK (cards from this image start unlocked)"
else
    echo "No pinclock-macunlock.txt on the boot partition - a card made from this image"
    echo "locks itself to the first Pi it boots in."
fi

echo
echo "== Code =="
LIVE=$(readlink -f /opt/pinclock/current 2>/dev/null)
if [ -n "$LIVE" ] && grep -q "pinclock_app.main()" "$LIVE/app.py" 2>/dev/null && [ -f "$LIVE/pinclock_app.pyc" ] \
        && ! ls "$LIVE"/app/core/*.py >/dev/null 2>&1; then
    echo "Compiled release: $LIVE (no Python source in app/core)"
else
    echo "*****************************************************************"
    echo "  WARNING: $LIVE is Python SOURCE (.py), not a compiled release."
    echo "  DO NOT image this card - it would ship the source code."
    echo "  Install the release .tar.gz (firmware update / sideload) or run"
    echo "  /opt/pinclock/venv/bin/python $LIVE/scripts/compile_pyc.py"
    echo "*****************************************************************"
fi

echo
echo "== Done clearing what's safe to automate. =="
echo
echo "IMPORTANT: if your WiFi was originally set up via the Pi's initial"
echo "imaging/setup tool (not PinClock's own WiFi tab), it likely also"
echo "lives in a netplan YAML file, e.g.:"
echo
echo "  grep -rl 'wifis:' /etc/netplan/"
echo
echo "Open whatever file that finds and remove the wifis: block (or just"
echo "the access-points/password lines) before imaging - otherwise"
echo "NetworkManager will recreate the same profile with your real"
echo "credentials on the next boot, undoing the cleanup above. With that"
echo "block removed, a fresh boot will have no saved WiFi at all and will"
echo "fall straight into the PinClock-Setup hotspot, which is exactly the"
echo "flow the next owner should use to set up their own WiFi."
echo
echo "======================================================="
echo "  IMPORTANT: power off, do NOT reboot, before imaging"
echo "======================================================="
echo "A reboot would immediately regenerate a machine-id right now, on"
echo "THIS device, before you ever get to cloning it - which just bakes"
echo "a single new (but still shared-across-every-future-clone) id into"
echo "the image, right back where this step started. Once you've checked"
echo "the netplan file above, run:"
echo
echo "  sudo poweroff"
echo
echo "then pull the card and image it from there."
