#!/usr/bin/env python3
""
import hashlib
import json
import os
import shutil
import stat
import sys
from pathlib import Path

CURRENT_LINK = Path("/opt/pinclock/current")
RELEASES_ROOT = Path("/opt/pinclock/releases")
FACTORY_ROOT = Path("/opt/pinclock-factory")
LABWC_DIR = Path("/home/vfw/.config/labwc")
OWNER_USER = "root"
OWNER_GROUP = "root"


class BlessError(Exception):
    pass


def _read_version(app_dir):
    app_py = app_dir / "app.py"
    if not app_py.exists():
        raise BlessError(f"{app_py} doesn't exist")
    import re
    m = re.search(r'^PINCLOCK_VERSION\s*=\s*["\'](.+?)["\']', app_py.read_text(), re.MULTILINE)
    if not m:
        raise BlessError(f"couldn't find PINCLOCK_VERSION in {app_py}")
    return m.group(1).lstrip("v")


def _fix_mislabeled_release_dir(live_dir, version):
    ""
    if live_dir.name != "pinclock" or live_dir.parent.parent != RELEASES_ROOT:
        print(
            f"NOTE: {live_dir} doesn't match the expected "
            f"{RELEASES_ROOT}/<version>/pinclock layout - skipping the release-folder-"
            f"naming check below (can't safely reason about a layout this script doesn't "
            f"recognize). Double check by hand that this is really the release you mean "
            f"to bless."
        )
        return live_dir

    release_dir = live_dir.parent
    if release_dir.name == version:
        return live_dir

    print(
        f"WARNING: {CURRENT_LINK} resolves to {live_dir}, but that code reports "
        f"PINCLOCK_VERSION {version} - the release folder is misnamed (almost certainly "
        f"from a manual deploy that overwrote an existing release folder's contents "
        f"in place instead of creating a new {RELEASES_ROOT}/{version}/ and swapping the "
        f"symlink). Fixing this now, before it gets baked into the factory snapshot:"
    )

    correct_dir = RELEASES_ROOT / version
    if correct_dir.exists():
        raise BlessError(
            f"{correct_dir} already exists, so this can't be auto-fixed by a simple "
            f"rename - resolve the collision by hand first (figure out which of "
            f"{release_dir} or {correct_dir} is the code you actually want to bless, "
            f"then repoint {CURRENT_LINK} at it yourself) and re-run this script."
        )

    print(f"  Renaming {release_dir} -> {correct_dir}")
    os.rename(release_dir, correct_dir)

    new_target = correct_dir / "pinclock"
    print(f"  Repointing {CURRENT_LINK} -> {new_target}")
    tmp_link = CURRENT_LINK.with_name(CURRENT_LINK.name + ".bless-tmp")
    if tmp_link.exists() or tmp_link.is_symlink():
        tmp_link.unlink()
    os.symlink(new_target, tmp_link)
    os.replace(tmp_link, CURRENT_LINK)

    print(f"  Fixed. {CURRENT_LINK} now correctly resolves to {new_target}")
    print()
    return new_target


def _sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _lock_down(path):
    ""
    for root, dirs, files in os.walk(path):
        for d in dirs:
            os.chown(os.path.join(root, d), 0, 0)
            os.chmod(os.path.join(root, d), 0o555)
        for f in files:
            os.chown(os.path.join(root, f), 0, 0)
            os.chmod(os.path.join(root, f), 0o444)
    os.chown(path, 0, 0)
    os.chmod(path, 0o555)


def _release_is_compiled(release_dir):
    ""
    release_dir = Path(release_dir)
    try:
        launcher = "pinclock_app.main()" in (release_dir / "app.py").read_text(errors="replace")
    except OSError:
        return False
    core_src = list((release_dir / "app" / "core").glob("*.py"))
    return launcher and (release_dir / "pinclock_app.pyc").is_file() and not core_src


def bless():
    if os.geteuid() != 0:
        raise BlessError("must be run with sudo (see module docstring for why)")

    if not CURRENT_LINK.exists():
        raise BlessError(
            f"{CURRENT_LINK} doesn't exist - this device hasn't been migrated to the "
            f"blue-green layout yet (see scripts/migrate_to_blue_green.py)"
        )

    live_dir = CURRENT_LINK.resolve()
    version = _read_version(live_dir)
    live_dir = _fix_mislabeled_release_dir(live_dir, version)
    compiled = _release_is_compiled(live_dir)
    if not compiled and "--allow-source" not in sys.argv[1:]:
        raise BlessError(
            f"{live_dir} is Python SOURCE (.py), not a compiled release - blessing it would ship "
            f"the source in the factory snapshot. Install the release from its .tar.gz (firmware "
            f"update or sideload) or run scripts/compile_pyc.py first, then bless. "
            f"(--allow-source blesses it anyway.)"
        )
    print(f"Blessing currently-running version {version} as the factory baseline "
          f"({'compiled' if compiled else 'SOURCE - --allow-source'})...")

    snapshot_dir = FACTORY_ROOT / version
    if snapshot_dir.exists():
        raise BlessError(
            f"{snapshot_dir} already exists - refusing to overwrite an existing factory "
            f"snapshot. If you genuinely need to re-bless, remove it manually first: "
            f"sudo rm -rf {snapshot_dir}"
        )

    snapshot_pinclock = snapshot_dir / "pinclock"
    print(f"Copying {live_dir} -> {snapshot_pinclock}...")
    snapshot_pinclock.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(
        live_dir, snapshot_pinclock,
        ignore=shutil.ignore_patterns("__pycache__", ".git"),
    )
    if compiled and not (snapshot_pinclock / "pinclock_app.pyc").is_file():
        raise BlessError(f"{snapshot_pinclock} is missing pinclock_app.pyc - snapshot incomplete")

    snapshot_labwc = snapshot_dir / "labwc"
    snapshot_labwc.mkdir(parents=True, exist_ok=True)
    for name in ("autostart", "autostart-legacy", "environment", "MANUAL_FILES_VERSION"):
        src = LABWC_DIR / name
        if src.exists():
            print(f"Copying {src} -> {snapshot_labwc / name}...")
            shutil.copy2(src, snapshot_labwc / name)
        else:
            print(f"WARNING: {src} doesn't exist - skipping (factory reset will leave this file alone)")

    print("Computing checksums...")
    file_hashes = {}
    for p in snapshot_pinclock.rglob("*"):
        if p.is_file():
            rel = p.relative_to(snapshot_pinclock).as_posix()
            file_hashes[rel] = "sha256:" + _sha256_file(p)

    manifest = {"version": version, "files": file_hashes}
    manifest_path = snapshot_dir / "release-manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2))
    print(f"Wrote {manifest_path} ({len(file_hashes)} files)")

    print("Locking down snapshot as read-only, root-owned...")
    _lock_down(snapshot_dir)

    print()
    print(f"Factory snapshot for version {version} is ready at {snapshot_dir}")
    print("Factory Reset (see run_update.py's run_factory_reset) will restore to this from now on.")

    _remove_stale_snapshots(snapshot_dir, version)


def _snapshot_summary(d):
    ""
    version = d.name
    try:
        version = json.loads((d / "release-manifest.json").read_text()).get("version", version)
    except (OSError, ValueError):
        try:
            version = _read_version(d / "pinclock")
        except BlessError:
            pass
    try:
        from datetime import datetime
        when = datetime.fromtimestamp(d.stat().st_mtime).strftime("%Y-%m-%d %H:%M")
    except OSError:
        when = "unknown date"
    size = 0
    for p in d.rglob("*"):
        try:
            if p.is_file() and not p.is_symlink():
                size += p.stat().st_size
        except OSError:
            pass
    return f"version {version}, blessed {when}, {size / (1024 * 1024):.1f} MB"


def _new_snapshot_looks_good(just_blessed_dir, version):
    ""
    try:
        if _read_version(just_blessed_dir / "pinclock") != version:
            return False
    except BlessError:
        return False
    return (just_blessed_dir / "release-manifest.json").is_file()


def _ask_yes_no(question):
    ""
    try:
        answer = input(question)
    except (EOFError, KeyboardInterrupt):
        print()
        return False
    return answer.strip().lower() in ("y", "yes")


def _remove_stale_snapshots(just_blessed_dir, version, label="just blessed"):
    ""
    others = sorted(
        d for d in FACTORY_ROOT.iterdir()
        if d.is_dir() and d != just_blessed_dir
    )
    print()
    print(f"Snapshots now under {FACTORY_ROOT}:")
    for d in sorted(FACTORY_ROOT.iterdir()):
        if d.is_dir():
            marker = f"   <- {label}" if d == just_blessed_dir else ""
            print(f"  {d.name}  ({_snapshot_summary(d)}){marker}")

    if not others:
        print()
        print("Only one snapshot - Factory Reset is ready to use.")
        return

    print()
    print(f"{len(others)} older snapshot(s) found. Factory Reset won't run while more than one")
    print("snapshot exists (it refuses to guess which is the real baseline), so the old one(s)")
    print("need to go.")

    if not _new_snapshot_looks_good(just_blessed_dir, version):
        print()
        print(f"WARNING: the new snapshot at {just_blessed_dir} doesn't look complete, so NOT")
        print("offering to delete the old one(s). Check the new snapshot first; once it's good,")
        print("remove the old one(s) by hand:")
        for d in others:
            print(f"  sudo rm -rf {d}")
        return

    if not sys.stdin.isatty():
        print("No terminal to ask on (running from a script?) - remove them by hand:")
        for d in others:
            print(f"  sudo rm -rf {d}")
        return

    kept = []
    for d in others:
        print()
        print(f"Old snapshot: {d}")
        print(f"  {_snapshot_summary(d)}")
        if not _ask_yes_no("Delete it? This can't be undone. [y/N] "):
            print("  Kept.")
            kept.append(d)
            continue
        if d.is_symlink() or d.parent != FACTORY_ROOT or d.resolve() == just_blessed_dir.resolve():
            print(f"  Not deleting {d} - it isn't a plain snapshot folder under {FACTORY_ROOT}.")
            kept.append(d)
            continue
        try:
            shutil.rmtree(d)
            print("  Deleted.")
        except OSError as e:
            print(f"  Couldn't delete it: {e}")
            print(f"  Try by hand: sudo rm -rf {d}")
            kept.append(d)

    print()
    remaining = [d.name for d in sorted(FACTORY_ROOT.iterdir()) if d.is_dir()]
    if len(remaining) == 1:
        print(f"Only {remaining[0]} is left - Factory Reset is ready to use.")
    else:
        print(f"Still {len(remaining)} snapshots ({', '.join(remaining)}) - Factory Reset will refuse")
        print("to run until only one is left. Re-run this check any time with:")
        print("  sudo python3 scripts/bless_factory.py --cleanup")


def cleanup_only():
    ""
    if os.geteuid() != 0:
        raise BlessError("must be run with sudo (see module docstring for why)")
    if not FACTORY_ROOT.exists():
        raise BlessError(f"{FACTORY_ROOT} doesn't exist - nothing has been blessed yet")
    snaps = sorted(d for d in FACTORY_ROOT.iterdir() if d.is_dir())
    if not snaps:
        raise BlessError(f"{FACTORY_ROOT} contains no snapshots - nothing to clean up")
    if len(snaps) == 1:
        print(f"Only one snapshot ({snaps[0].name}) - nothing to clean up, Factory Reset is ready.")
        return
    keep = None
    if CURRENT_LINK.exists():
        try:
            running = _read_version(CURRENT_LINK.resolve())
            keep = next((d for d in snaps if d.name == running), None)
        except BlessError:
            pass
    if keep is None:
        if not sys.stdin.isatty():
            raise BlessError("several snapshots and none matches the running version - "
                             "run this from a terminal to choose which to keep")
        print("Snapshots:")
        for i, d in enumerate(snaps, 1):
            print(f"  {i}. {d.name}  ({_snapshot_summary(d)})")
        try:
            choice = input("Number of the snapshot to KEEP (Enter to cancel): ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        if not choice.isdigit() or not 1 <= int(choice) <= len(snaps):
            print("Cancelled - nothing deleted.")
            return
        keep = snaps[int(choice) - 1]
    print(f"Keeping {keep.name}.")
    _remove_stale_snapshots(keep, keep.name, label="keeping")


if __name__ == "__main__":
    try:
        if "--cleanup" in sys.argv[1:]:
            cleanup_only()
        else:
            bless()
    except BlessError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)
