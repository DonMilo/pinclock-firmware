""
import re
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

W, H = 1920, 1080

PRODUCT_NAME = "PinClock"
COMPANY_NAME = "YOUR COMPANY NAME"

BG = (8, 8, 12)
FG_PRIMARY = (255, 255, 255)
FG_SECONDARY = (140, 140, 150)
FG_TERTIARY = (90, 90, 100)
ACCENT = (80, 170, 255)

FONT_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FONT_REGULAR = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"


def _read_app_version():
    ""
    app_py = Path(__file__).resolve().parent.parent / "app.py"
    if not app_py.exists():
        print(f"ERROR: couldn't find app.py at {app_py}", file=sys.stderr)
        sys.exit(1)
    m = re.search(r'^PINCLOCK_VERSION\s*=\s*["\'](.+?)["\']', app_py.read_text(), re.MULTILINE)
    if not m:
        print(f"ERROR: couldn't find PINCLOCK_VERSION in {app_py}", file=sys.stderr)
        sys.exit(1)
    return m.group(1)


def load_font(path, size):
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        return ImageFont.load_default()


def center_text(draw, text, font, y, fill):
    bbox = draw.textbbox((0, 0), text, font=font)
    w = bbox[2] - bbox[0]
    draw.text(((W - w) / 2, y), text, font=font, fill=fill)
    return bbox[3] - bbox[1]


def build():
    version = _read_app_version()

    img = Image.new("RGB", (W, H), BG)
    draw = ImageDraw.Draw(img)

    bar_w, bar_h = 140, 8
    draw.rectangle(
        [(W - bar_w) / 2, 300, (W + bar_w) / 2, 300 + bar_h], fill=ACCENT
    )

    center_text(draw, PRODUCT_NAME, load_font(FONT_BOLD, 220), 360, FG_PRIMARY)
    center_text(draw, COMPANY_NAME, load_font(FONT_REGULAR, 54), 620, FG_SECONDARY)
    center_text(draw, version, load_font(FONT_REGULAR, 36), 960, FG_TERTIARY)

    img.save("splash.png")
    print(f"wrote splash.png ({version})")


if __name__ == "__main__":
    build()
