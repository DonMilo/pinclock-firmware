pkill labwc
pkill mpv
pkill cog
pkill -f "pinclock/app.py"

rm -f /tmp/mpvsocket /tmp/pinclock-playlist.m3u

