# PinClock setup card

`pinclock-setup-card.pdf` - a printable one-page card with two QR codes:
1. Scan to join the "PinClock-Setup" WiFi network (no typing the SSID)
2. Scan to open `http://10.42.0.1:5000/control` directly

Print it and keep it near the clock (taped to the back, in the box,
wherever) for whenever it's showing "Demo" mode and needs its WiFi set up.

As of v0.6.0, these same two images are also shown directly on the clock's
own display (see `app/static/img/`) as an on-screen overlay for a window
after boot - the printed card is a physical backup for whenever someone
isn't standing right in front of the running clock.

Both scans still need a manual tap to confirm - that's an OS-level
security requirement on iOS/Android, not something a QR code can skip.
There's no way to make a single QR code both join a network *and* open a
URL automatically; the real way to get a true "join WiFi -> settings page
just opens by itself" experience is a captive portal (the same mechanism
hotel/airport WiFi login pages use) - ask if you want that built out,
it's a bigger, separate piece of work involving DNS/iptables changes on
the Pi, not just this card.

## Regenerating

Only needed if the hotspot's SSID or URL ever changes - these are static
images, not generated live by the Pi itself, since "PinClock-Setup" is a
fixed, hardcoded network name.

```
pip install qrcode[pil] reportlab pypdf --break-system-packages
python3 make_card.py
```
Requires only Python packages, not anything Pi-specific - run this on
any dev machine, then drop the resulting files back in here.
