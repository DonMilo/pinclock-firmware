from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle
from reportlab.lib import colors

styles = getSampleStyleSheet()
title_style = ParagraphStyle("TitleC", parent=styles["Title"], alignment=TA_CENTER, fontSize=20)
sub_style = ParagraphStyle("SubC", parent=styles["Normal"], alignment=TA_CENTER, fontSize=11, textColor=colors.grey)
step_style = ParagraphStyle("Step", parent=styles["Normal"], alignment=TA_CENTER, fontSize=11, spaceAfter=4)
caption_style = ParagraphStyle("Caption", parent=styles["Normal"], alignment=TA_CENTER, fontSize=10, textColor=colors.grey)

doc = SimpleDocTemplate("pinclock-setup-card.pdf", pagesize=letter,
                         topMargin=0.75*inch, bottomMargin=0.75*inch,
                         leftMargin=0.75*inch, rightMargin=0.75*inch)

story = []
story.append(Paragraph("PinClock Setup", title_style))
story.append(Paragraph("No WiFi configured yet? Use this card to get into settings.", sub_style))
story.append(Spacer(1, 0.4*inch))

qr_size = 2.1*inch
img1 = Image("wifi-join-qr.png", width=qr_size, height=qr_size)
img2 = Image("control-url-qr.png", width=qr_size, height=qr_size)

col1 = [
    img1,
    Spacer(1, 0.12*inch),
    Paragraph("<b>1. Scan to join WiFi</b>", step_style),
    Paragraph("Network: PinClock-Setup (open, no password)", caption_style),
]
col2 = [
    img2,
    Spacer(1, 0.12*inch),
    Paragraph("<b>2. Scan to open settings</b>", step_style),
    Paragraph("http://10.42.0.1:5000/control", caption_style),
]

table = Table([[col1, col2]], colWidths=[3.4*inch, 3.4*inch])
table.setStyle(TableStyle([
    ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ("ALIGN", (0, 0), (-1, -1), "CENTER"),
]))
story.append(table)

story.append(Spacer(1, 0.45*inch))
story.append(Paragraph(
    "Both steps need a manual tap to confirm (phones don't auto-join WiFi from a QR scan, "
    "and won't auto-open a page after joining) - but no typing required either way.",
    ParagraphStyle("Note", parent=styles["Normal"], alignment=TA_CENTER, fontSize=9.5, textColor=colors.grey)
))
story.append(Spacer(1, 0.15*inch))
story.append(Paragraph(
    "Already on your home WiFi? The clock keeps its own clock synced automatically - "
    "you only need this card if it's showing \u201cDemo\u201d mode.",
    ParagraphStyle("Note2", parent=styles["Normal"], alignment=TA_CENTER, fontSize=9.5, textColor=colors.grey)
))

doc.build(story)
print("built pinclock-setup-card.pdf")
