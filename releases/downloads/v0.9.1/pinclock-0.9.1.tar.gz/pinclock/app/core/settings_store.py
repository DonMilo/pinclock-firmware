"""
PinClock - settings & video-library store.

Adapted from the earlier pygame-era shared.py, but simplified for this
architecture: there's no separate display.py process to hand commands to
over a file - mpv itself is the source of truth for playback state, and we
talk to it directly over its JSON IPC socket (see mpv_ipc.py). So this
module only owns settings.json (clock/effects/display config) and the
videos/ folder.
"""
import json
import os
import tempfile
from pathlib import Path

from .paths import DATA_DIR, SHIPPED_VIDEOS_DIR

SETTINGS_FILE = DATA_DIR / "settings.json"
VIDEOS_DIR = DATA_DIR / "videos"  # user-uploaded videos only - see SHIPPED_VIDEOS_DIR

ALLOWED_VIDEO_EXT = {".mp4"}

DEFAULT_SETTINGS = {
    "clock_style": "truetype",
    "dmd_font_style": "5x7",
    "clock_position": "center",
    "clock_size": "small",
    "clock_format": "12h",
    "show_date": True,
    "dot_color": "#ffff00",
    "dot_glow": True,
    "dot_gap": 2,
    "bg_enabled": True,
    "bg_color": "#0000ff",
    "border_enabled": True,
    "border_color": "#ffffff",
    "border_width": 4,
    "position_rotate": True,
    "position_rotate_interval": 5,
    "effect": "fade",
    "effect_speed": "medium",
    "video_volume": 80,
    "video_loop": True,
    "brightness": 100,
    "show_fps": False,
    # not in original control.html schema, but drives gen_playlist.py -
    # exposed on the control panel as part of the Current Playlist tab
    "randomize": False,
    # Ordered list of {"name": str, "source": "user"|"shipped"} entries -
    # the explicit, curated set of videos that actually get played.
    # Empty here is just the schema default; see _bootstrap_playlist for
    # what actually populates it the first time (and after a reset).
    "playlist": [],

    # -- title bar (static text, top strip) --------------------------------
    "title_enabled": False,
    "title_text": "",
    "title_font_size": 28,
    "title_color": "#ffffff",
    "title_align": "center",
    "title_bg_enabled": True,
    "title_bg_color": "#000000",
    "title_bg_opacity": 60,
    "title_border_enabled": False,
    "title_border_color": "#ffffff",
    "title_border_width": 2,

    # -- ticker (scrolling text, bottom strip) ------------------------------
    "ticker_enabled": False,
    "ticker_text": "",
    "ticker_font_size": 32,
    "ticker_color": "#ffffff",
    "ticker_speed": 80,
    "ticker_direction": "rtl",
    "ticker_bg_enabled": True,
    "ticker_bg_color": "#000000",
    "ticker_bg_opacity": 60,
    "ticker_border_enabled": False,
    "ticker_border_color": "#ffffff",
    "ticker_border_width": 2,
}


def atomic_write_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(dir=str(path.parent), prefix=".tmp_", suffix=".json")
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(data, f, indent=2)
        os.replace(tmp_path, str(path))
    except Exception:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


def load_settings() -> dict:
    try:
        with open(SETTINGS_FILE, "r") as f:
            data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        data = {}
    if not isinstance(data, dict):
        data = {}

    if "playlist" not in data:
        # First load since the playlist feature shipped (or a genuinely
        # fresh install) - populate with everything currently on disk
        # rather than starting silently empty, so nothing already
        # playing "disappears" the moment this update lands. Persisted
        # immediately (via atomic_write_json directly, not
        # save_settings(), to avoid re-entering load_settings()) so
        # this bootstrap only ever runs once - a device that
        # deliberately empties its playlist later stays empty, since
        # the key will already exist (as []) from then on.
        data["playlist"] = _bootstrap_playlist_entries()
        merged = dict(DEFAULT_SETTINGS)
        merged.update(data)
        atomic_write_json(SETTINGS_FILE, merged)
        return merged

    merged = dict(DEFAULT_SETTINGS)
    merged.update(data)
    return merged


def save_settings(partial: dict) -> dict:
    current = load_settings()
    current.update(partial)
    atomic_write_json(SETTINGS_FILE, current)
    return current


def reset_to_defaults() -> dict:
    """Used by the Device tab's "Default settings" action (and, via
    that same endpoint, by Factory Reset - see run_update.py's
    run_factory_reset) - overwrites settings.json with DEFAULT_SETTINGS
    wholesale (not merged with whatever's currently saved), so this is
    a genuine reset rather than a partial update.

    The playlist specifically gets re-bootstrapped to everything
    currently on disk, same as a fresh install - a first-time user (or
    someone who just reset) would expect everything available to play,
    not a curated subset from before the reset. For Factory Reset this
    composes correctly for free: _wipe_videos() already deletes user
    videos before this runs, so the freshly bootstrapped playlist ends
    up containing only whatever shipped videos remain, exactly as
    intended."""
    defaults = dict(DEFAULT_SETTINGS)
    defaults["playlist"] = _bootstrap_playlist_entries()
    atomic_write_json(SETTINGS_FILE, defaults)
    return defaults


def _bootstrap_playlist_entries():
    """Every video currently on disk, in list_videos()'s natural
    (alphabetical) order. See load_settings() and reset_to_defaults()
    for the two situations this gets called from."""
    return [{"name": v["name"], "source": v["source"]} for v in list_videos()]


def _video_exists(name, source):
    return any(v["name"] == name and v["source"] == source for v in list_videos())


def get_playlist():
    """Returns the current playlist - self-healing: any entry
    referencing a video that no longer actually exists on disk (e.g.
    deleted directly via SSH, bypassing this app) is dropped and the
    correction is persisted, so a stale reference doesn't keep
    reappearing on every subsequent read."""
    settings = load_settings()
    existing = {(v["name"], v["source"]) for v in list_videos()}
    playlist = settings["playlist"]
    cleaned = [e for e in playlist if (e.get("name"), e.get("source")) in existing]
    if len(cleaned) != len(playlist):
        save_settings({"playlist": cleaned})
    return cleaned


def add_to_playlist(name, source):
    """Idempotent - adding something already in the playlist is a
    no-op, not a duplicate entry. Validates the (name, source) pair
    actually exists before adding, so a typo'd or stale reference can't
    sneak in. Raises ValueError if it doesn't (callers - see app.py -
    are expected to turn that into a 400)."""
    if not _video_exists(name, source):
        raise ValueError(f"no such video: {name!r} (source={source!r})")
    playlist = get_playlist()
    if any(e["name"] == name and e["source"] == source for e in playlist):
        return playlist
    playlist.append({"name": name, "source": source})
    save_settings({"playlist": playlist})
    return playlist


def remove_from_playlist(name, source):
    """Playlist-only removal - never touches the underlying file, only
    settings.json's playlist list. See app.py's delete_video() for
    actually deleting a user video (which also calls this, so a deleted
    file can't linger as a stale entry until the next self-healing read
    happens to catch it)."""
    playlist = get_playlist()
    filtered = [e for e in playlist if not (e["name"] == name and e["source"] == source)]
    save_settings({"playlist": filtered})
    return filtered


def list_videos():
    """
    Returns a list of dicts, one per video, from BOTH sources:
        {"path": Path, "name": str, "source": "user"|"shipped", "deletable": bool}
    merged and sorted by name. "shipped" entries come from
    SHIPPED_VIDEOS_DIR (versioned with app code - see paths.py) and are
    never deletable through this app; "user" entries come from
    VIDEOS_DIR (DATA_DIR/videos) and are the only ones a person can
    upload or delete.

    If a shipped and a user video happen to share the same filename,
    both are still listed (they're different files in different
    directories) - callers that need to unambiguously locate one must
    match on (name, source) together, not name alone. See
    app.py's delete_video()/play_video() for how that's handled.
    """
    entries = []

    VIDEOS_DIR.mkdir(parents=True, exist_ok=True)
    for p in VIDEOS_DIR.iterdir():
        if p.is_file() and p.suffix.lower() in ALLOWED_VIDEO_EXT:
            entries.append({"path": p, "name": p.name, "source": "user", "deletable": True})

    if SHIPPED_VIDEOS_DIR.exists():
        for p in SHIPPED_VIDEOS_DIR.iterdir():
            if p.is_file() and p.suffix.lower() in ALLOWED_VIDEO_EXT:
                entries.append({"path": p, "name": p.name, "source": "shipped", "deletable": False})

    entries.sort(key=lambda e: e["name"].lower())
    return entries
