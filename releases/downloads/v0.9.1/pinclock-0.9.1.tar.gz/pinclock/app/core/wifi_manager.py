"""
PinClock - WiFi management via NetworkManager (nmcli).

Assumes NetworkManager is the active network backend. Works whether
NetworkManager is driving things directly (stock Raspberry Pi OS
Bookworm+) or is itself being configured by netplan (Ubuntu) - in the
netplan case, existing connection profiles are named like
"netplan-wlan0-4242a" rather than after the SSID, so we never assume the
NM connection name equals the SSID; see _active_wifi_ssid() and
connect()/forget() below, which track the real profile name separately.

All state that needs to persist across reboots (whether WiFi has been
configured, the last-known SSID, and the underlying NM profile name)
lives in config.json under the "wifi" key; the actual PSK is never
stored by us - NetworkManager keeps it in its own connection profile
under /etc/NetworkManager/system-connections/, so a lost/corrupted
config.json can't leak or lose credentials we don't otherwise need.

Two nmcli connection profiles matter here:
  - Whatever profile NetworkManager creates/reuses when we call
    `nmcli device wifi connect` (normal client/station mode).
  - HOTSPOT_CON_NAME: an open AP we create on demand so a phone can talk
    to the Pi directly at 10.42.0.1 when no home WiFi is reachable.

IMPORTANT: the WiFi tab's on/off toggle must never call set_radio()
(`nmcli radio wifi off`). That disables the WiFi hardware outright,
taking the setup hotspot down with it, and NetworkManager persists that
"off" state across reboots - so a person turning it off over WiFi
strands themselves with no fallback and no easy recovery (physical
console or an SD-card edit). Use disconnect_to_hotspot() /
reconnect_client() instead, which only ever change which network the
(always-on) radio is associated with.

Every nmcli call goes through a short timeout - this runs in a Flask
request thread and must never hang the settings UI if the WiFi adapter
is in a weird state.
"""
import json
import subprocess

from .paths import DATA_DIR

CONFIG_FILE = DATA_DIR / "config.json"

WIFI_IFACE = "wlan0"
HOTSPOT_CON_NAME = "PinClock-Setup"
HOTSPOT_SSID = "PinClock-Setup"
HOTSPOT_ADDR = "10.42.0.1/24"

NMCLI_TIMEOUT = 15


class WifiError(Exception):
    pass


def _run(args, timeout=NMCLI_TIMEOUT):
    try:
        result = subprocess.run(
            args, capture_output=True, text=True, timeout=timeout,
        )
        return result
    except subprocess.TimeoutExpired as e:
        raise WifiError(f"command timed out: {' '.join(args)}") from e
    except FileNotFoundError as e:
        raise WifiError("nmcli not found - is NetworkManager installed?") from e


def _nmcli(*args, timeout=NMCLI_TIMEOUT):
    """
    Runs nmcli via sudo (passwordless, same pattern as /bin/date in
    app.py's /api/time route - see the sudoers snippet in
    sudoers/pinclock-nmcli). Started out relying on polkit rules instead
    (see polkit/50-pinclock-nm.rules), but real-world testing showed that
    covers some NetworkManager actions (radio on/off) but not others
    (adding a connection) without being able to pin down the exact
    action-id mismatch remotely - sudo avoids the guessing game entirely,
    since root bypasses NM's polkit checks altogether.
    """
    result = _run(["sudo", "nmcli", *args], timeout=timeout)
    if result.returncode != 0:
        raise WifiError(result.stderr.strip() or f"nmcli {' '.join(args)} failed")
    return result.stdout


# ------------------------------------------------------------- config -----
def _load_config():
    try:
        with open(CONFIG_FILE, "r") as f:
            data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        data = {}
    if not isinstance(data, dict):
        data = {}
    return data


def _save_config(data):
    tmp = CONFIG_FILE.with_suffix(".json.tmp")
    with open(tmp, "w") as f:
        json.dump(data, f, indent=2)
    tmp.replace(CONFIG_FILE)


def _remember_ssid(ssid, connection_name=None):
    cfg = _load_config()
    cfg.setdefault("wifi", {})
    cfg["wifi"]["configured"] = True
    cfg["wifi"]["ssid"] = ssid
    cfg["wifi"]["connection_name"] = connection_name or ssid
    cfg["wifi"].pop("password", None)  # never persist a plaintext password
    _save_config(cfg)


def get_remembered_ssid():
    cfg = _load_config()
    return (cfg.get("wifi") or {}).get("ssid") or ""


def _get_remembered_connection_name():
    cfg = _load_config()
    wifi_cfg = cfg.get("wifi") or {}
    return wifi_cfg.get("connection_name") or wifi_cfg.get("ssid") or ""


# --------------------------------------------------------------- status ---
def radio_enabled():
    try:
        out = _nmcli("radio", "wifi", timeout=5).strip()
        return out == "enabled"
    except WifiError:
        return False


def _active_wifi_ssid():
    """
    The NM *connection profile name* is not necessarily the SSID - e.g. on
    a netplan-managed system (Ubuntu) it looks like "netplan-wlan0-4242a".
    `nmcli device wifi` always reports the true over-the-air SSID though,
    so use that for anything user-facing.
    """
    try:
        out = _nmcli("-t", "-f", "ACTIVE,SSID", "device", "wifi", timeout=8)
    except WifiError:
        return None
    for line in out.splitlines():
        parts = line.split(":", 1)
        if len(parts) == 2 and parts[0] == "yes":
            return parts[1]
    return None


def get_status():
    """
    Returns:
      {
        "radio_enabled": bool,
        "connected": bool,       # associated with a real AP (not our own hotspot)
        "ssid": str | None,      # currently associated SSID
        "connection_name": str | None,  # underlying NM profile name (may differ from ssid)
        "ip": str | None,
        "hotspot_active": bool,  # our own fallback AP is up
      }
    """
    enabled = radio_enabled()
    status = {
        "radio_enabled": enabled,
        "connected": False,
        "ssid": None,
        "connection_name": None,
        "ip": None,
        "hotspot_active": False,
    }
    if not enabled:
        return status

    try:
        out = _nmcli(
            "-t", "-f", "DEVICE,TYPE,STATE,CONNECTION", "device", "status", timeout=8
        )
    except WifiError:
        return status

    wifi_line = None
    for line in out.splitlines():
        parts = line.split(":")
        if len(parts) >= 4 and parts[0] == WIFI_IFACE and parts[1] == "wifi":
            wifi_line = parts
            break

    if not wifi_line:
        return status

    state, con_name = wifi_line[2], wifi_line[3]

    if con_name == HOTSPOT_CON_NAME and "connected" in state:
        status["hotspot_active"] = True
        status["ip"] = HOTSPOT_ADDR.split("/")[0]
        return status

    if "connected" in state and con_name and con_name != "--":
        status["connected"] = True
        status["connection_name"] = con_name
        status["ssid"] = _active_wifi_ssid() or con_name
        try:
            ip_out = _nmcli(
                "-g", "IP4.ADDRESS", "device", "show", WIFI_IFACE, timeout=5
            ).strip()
            status["ip"] = ip_out.split("/")[0].splitlines()[0] if ip_out else None
        except WifiError:
            pass

    return status


# -------------------------------------------------------------- connect ---
def connect(ssid, password):
    """
    Tear down our setup hotspot (if any) and connect to a real WiFi network.
    Returns (ok: bool, message: str).

    Builds the connection profile explicitly (connection add + up) rather
    than using `nmcli device wifi connect ssid password ...`. That
    shortcut infers the security type (key-mgmt) from the AP's entry in
    NetworkManager's WiFi scan cache - if that entry is stale, missing, or
    the AP just isn't in range of the last scan, it can create a profile
    with a password set but no key-mgmt, which NetworkManager then
    rejects with "802-11-wireless-security.key-mgmt: property is
    missing". Setting key-mgmt explicitly sidesteps that entirely.
    """
    if not ssid:
        return False, "SSID is required"

    teardown_hotspot()

    # A stale profile from a previous attempt at this same SSID (e.g. one
    # nmcli partially created before failing) can conflict with a fresh
    # `connection add` below - clear it first. Not an error if there
    # wasn't one.
    try:
        _nmcli("connection", "delete", ssid, timeout=8)
    except WifiError:
        pass

    add_args = [
        "connection", "add",
        "type", "wifi",
        "con-name", ssid,
        "ifname", WIFI_IFACE,
        "ssid", ssid,
    ]
    if password:
        # wpa-psk covers WPA/WPA2-Personal, which is what the overwhelming
        # majority of home networks use. A WPA3-only ("sae") network would
        # need a different key-mgmt value here - not handled yet.
        #
        # psk-flags 0 explicitly marks the secret as "stored in the
        # connection file" (NetworkManager's default assumption otherwise
        # can end up treating it as "ask an agent for this each time" -
        # which there is no agent for here - producing "Secrets were
        # required, but not provided" on activation even though a psk
        # value was given at creation time).
        add_args += [
            "wifi-sec.key-mgmt", "wpa-psk",
            "wifi-sec.psk", password,
            "wifi-sec.psk-flags", "0",
        ]

    try:
        _nmcli(*add_args, timeout=15)
        _nmcli("connection", "up", ssid, timeout=30)
    except WifiError as e:
        # Clean up a half-created profile rather than leaving a broken one
        # sitting around to confuse the next attempt.
        try:
            _nmcli("connection", "delete", ssid, timeout=8)
        except WifiError:
            pass
        return False, str(e)

    status = get_status()
    _remember_ssid(ssid, status.get("connection_name") or ssid)
    return True, "connected"


def set_radio(enabled: bool):
    """
    !! DO NOT wire this to any user-facing API route. !!

    `nmcli radio wifi off` disables the WiFi hardware entirely - which
    also takes down our own setup hotspot, since it needs the same radio.
    Worse, NetworkManager persists that "off" state to disk
    (NetworkManager.state), so it survives a reboot too. If the person
    calling this is themselves connected over WiFi (the normal way to
    reach the settings page), this cuts their own access with no
    fallback - recovering means physical console access or editing the
    SD card's NetworkManager.state by hand. This is exactly what
    happened during testing of an earlier version of this toggle.

    Kept only for interactive debugging over a wired/console session
    where you can see the consequences directly. The WiFi tab's "off"
    behavior is disconnect_to_hotspot() below instead, which keeps the
    radio on and always leaves 10.42.0.1 reachable.
    """
    try:
        _nmcli("radio", "wifi", "on" if enabled else "off", timeout=10)
    except WifiError as e:
        return False, str(e)
    return True, "ok"


def disconnect_to_hotspot():
    """
    What the WiFi tab's toggle actually calls for "off": disconnect from
    whatever home network is active and bring up the PinClock-Setup
    hotspot instead. The radio itself is never disabled, so 10.42.0.1
    should always stay reachable - this is the safe alternative to
    set_radio().

    Returns (ok: bool, message: str). On most single-radio WiFi hardware
    (including the Pi Zero's onboard chip) the radio can be a client OR
    an access point, never both - so bringing the hotspot up necessarily
    means bringing the client connection down first, and there's a real
    chance the hotspot then fails to come up for its own reasons (driver
    limitations, an unset WiFi regulatory/country code blocking AP mode,
    etc). If that happens, this reconnects to the known-good network
    automatically rather than leaving the device on neither network -
    which is exactly what happened during testing before this existed.
    """
    status = get_status()
    con_name = status.get("connection_name")
    was_connected = status.get("connected") and not status.get("hotspot_active")

    if con_name and was_connected:
        try:
            _nmcli("connection", "down", con_name, timeout=15)
        except WifiError:
            pass

    try:
        ensure_hotspot()
    except WifiError as e:
        # Hotspot didn't come up - reconnect to the known-good network
        # rather than stranding the device with nothing active.
        if con_name and was_connected:
            try:
                _nmcli("connection", "up", con_name, timeout=30)
            except WifiError:
                pass
        return False, f"Setup hotspot failed to start ({e}); reconnected to your network instead."

    return True, "ok"


def reconnect_client():
    """
    What the WiFi tab's toggle calls for "on": tear down the setup
    hotspot and reconnect to whatever network was last remembered.
    Returns (ok, message) - ok is True even if there's nothing to
    reconnect to (that's not an error, just nothing to do).
    """
    con_name = _get_remembered_connection_name()
    teardown_hotspot()
    if con_name:
        try:
            _nmcli("connection", "up", con_name, timeout=30)
        except WifiError as e:
            return False, str(e)
    return True, "ok"


def forget():
    """
    Remove every WiFi connection profile except our own setup hotspot -
    not just whichever one config.json happens to remember.

    That bookkeeping can go stale, or simply never get populated at all:
    a profile created by the Pi's initial imaging tool, or reconnected
    by hand over SSH (`nmcli device wifi connect ...` directly, bypassing
    this app entirely - both of which happened during testing), never
    touches config.json. Relying on it alone meant "Default settings"
    reset our own record but left the actual NetworkManager profile
    completely intact, autoconnect and all - it just reconnected on the
    very next reboot as if nothing had happened. Enumerating NM's actual
    connection list directly (same approach as
    scripts/prepare_for_shipping.sh) doesn't have that blind spot.

    Returns (ok: bool, message: str) - ok is False if *any* profile
    failed to delete, with the specific failures named, rather than
    silently reporting success regardless of what actually happened.
    """
    try:
        out = _nmcli("-t", "-f", "NAME,TYPE", "connection", "show", timeout=10)
    except WifiError as e:
        cfg = _load_config()
        cfg.setdefault("wifi", {})
        cfg["wifi"]["configured"] = False
        cfg["wifi"]["ssid"] = ""
        cfg["wifi"]["connection_name"] = ""
        _save_config(cfg)
        return False, f"couldn't list connections: {e}"

    failures = []
    deleted = []
    for line in out.splitlines():
        # NAME can itself contain ":" (rare, but SSIDs allow it) - TYPE
        # never does, so split from the right to keep NAME intact.
        parts = line.rsplit(":", 1)
        if len(parts) != 2:
            continue
        name, con_type = parts
        if con_type == "wifi" and name != HOTSPOT_CON_NAME:
            try:
                _nmcli("connection", "delete", name, timeout=10)
                deleted.append(name)
            except WifiError as e:
                failures.append(f"{name}: {e}")

    cfg = _load_config()
    cfg.setdefault("wifi", {})
    cfg["wifi"]["configured"] = False
    cfg["wifi"]["ssid"] = ""
    cfg["wifi"]["connection_name"] = ""
    _save_config(cfg)

    if failures:
        return False, "Failed to remove: " + "; ".join(failures)
    if not deleted:
        return True, "no saved networks to forget"
    return True, f"removed {', '.join(deleted)}"


# ---------------------------------------------------------------- scan ---
def scan_networks(rescan=True):
    """
    Returns a deduplicated, signal-sorted list of nearby networks:
      [{"ssid": str, "signal": int, "secure": bool}, ...]

    Hidden networks (blank SSID) are skipped - there's nothing useful to
    show or click on for those; a user with a hidden network still types
    the SSID in by hand, which the form supports either way.

    `rescan=True` asks the WiFi adapter to actively scan first (takes a
    couple seconds); `rescan=False` just reads NetworkManager's existing
    cache, which is instant but can be stale/empty right after boot.
    """
    args = ["-t", "-f", "SSID,SIGNAL,SECURITY", "device", "wifi", "list"]
    if rescan:
        args += ["--rescan", "yes"]

    try:
        out = _nmcli(*args, timeout=20 if rescan else 8)
    except WifiError:
        return []

    best = {}
    for line in out.splitlines():
        # SSID can't contain a literal ":" once nmcli escapes it, but it
        # can be empty (hidden network) - split from the right so a
        # SIGNAL/SECURITY pair we can always trust is intact.
        parts = line.rsplit(":", 2)
        if len(parts) != 3:
            continue
        ssid, signal_str, security = parts
        ssid = ssid.strip()
        if not ssid:
            continue
        try:
            signal = int(signal_str)
        except ValueError:
            signal = 0
        secure = bool(security.strip())

        existing = best.get(ssid)
        if existing is None or signal > existing["signal"]:
            best[ssid] = {"ssid": ssid, "signal": signal, "secure": secure}

    return sorted(best.values(), key=lambda n: n["signal"], reverse=True)


def _system_dnsmasq_conflict():
    """
    True if a separate, systemd-managed 'dnsmasq.service' is currently
    running. NetworkManager's own hotspot-mode DHCP server is a private
    dnsmasq instance it spawns directly (not a systemd unit), so this
    specifically detects the *other*, independent one - which is what
    conflicted with the hotspot during testing (both trying to bind
    10.42.0.1:53/67).
    """
    try:
        result = subprocess.run(
            ["systemctl", "is-active", "dnsmasq"],
            capture_output=True, text=True, timeout=5,
        )
        return result.stdout.strip() == "active"
    except Exception:
        return False


def _hotspot_exists():
    try:
        out = _nmcli("-t", "-f", "NAME", "connection", "show", timeout=8)
    except WifiError:
        return False
    return HOTSPOT_CON_NAME in out.splitlines()


def ensure_hotspot():
    """
    Bring up the PinClock-Setup open AP at 10.42.0.1 so a phone can reach
    the control page directly when no home WiFi is available.

    Always deletes and recreates the profile rather than reusing an
    existing one by that name. A prior version of this function set
    "wifi-sec.key-mgmt none" trying to mean "open network" - which in
    NetworkManager's model actually means WEP, producing a profile that
    then had no WEP key and refused to activate ("password for
    '802-11-wireless-security.wep-key0' not given"). Reusing-if-exists
    meant that broken profile kept getting silently reused across
    restarts even after the bug causing it was fixed, since "does a
    profile named PinClock-Setup exist" was the only check - the fix
    changed what a *newly created* profile looks like, but did nothing
    for one already sitting in NetworkManager's connection store. Always
    recreating avoids that whole class of "stale profile from an earlier
    bug" problem, at the cost of a couple of extra nmcli calls each time
    - this isn't a hot path.
    """
    if _hotspot_exists():
        try:
            _nmcli("connection", "delete", HOTSPOT_CON_NAME, timeout=10)
        except WifiError:
            pass

    _nmcli(
        "connection", "add",
        "type", "wifi",
        "ifname", WIFI_IFACE,
        "con-name", HOTSPOT_CON_NAME,
        "autoconnect", "yes",
        "ssid", HOTSPOT_SSID,
        "mode", "ap",
        "ipv4.method", "shared",
        "ipv4.addresses", HOTSPOT_ADDR,
        timeout=15,
    )
    try:
        _nmcli("connection", "up", HOTSPOT_CON_NAME, timeout=20)
    except WifiError as e:
        # A system-wide dnsmasq.service (distinct from the private
        # instance NetworkManager's own "ipv4.method shared" spawns
        # internally for the hotspot) binding port 53/67 first is a
        # real failure mode that came up during testing: the AP itself
        # comes up fine, WiFi association succeeds, but no DHCP leases
        # are ever handed out, so nothing that joins can reach
        # 10.42.0.1. Surfacing this directly saves re-running the whole
        # SSH/journalctl diagnostic chain if it happens again.
        if _system_dnsmasq_conflict():
            e = WifiError(
                f"{e} Hint: a separate system 'dnsmasq' service is already running and is "
                f"likely blocking the hotspot's own DHCP server from binding 10.42.0.1 - "
                f"if you don't need it for anything else, "
                f"'sudo systemctl disable --now dnsmasq' resolves this."
            )
        raise e


def teardown_hotspot():
    if _hotspot_exists():
        try:
            _nmcli("connection", "down", HOTSPOT_CON_NAME, timeout=10)
        except WifiError:
            pass
