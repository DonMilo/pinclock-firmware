
// ===============================
// PinClock - DMD dot-matrix renderer
// Ported from overlay.py (ClockRenderer)
// ===============================

function hexToRgb(hex) {
    const h = hex.replace("#", "");
    return [
        parseInt(h.substring(0, 2), 16),
        parseInt(h.substring(2, 4), 16),
        parseInt(h.substring(4, 6), 16),
    ];
}

function easeInOut(t) {
    return t * t * (3 - 2 * t);
}

const SIZE_PX = { small: 5, medium: 8, large: 12, xlarge: 20 };
const EFFECT_FRAMES = { slow: 60, medium: 36, fast: 18 };

function dotScale(clockSize) {
    return SIZE_PX[clockSize] || SIZE_PX.large;
}

function effectFrameCount(effectSpeed) {
    return EFFECT_FRAMES[effectSpeed] || EFFECT_FRAMES.medium;
}

const DMD_FONT_ROWS = { "5x7": 7, "7x9": 9 };

function dmdRowCount(fontStyle) {
    return DMD_FONT_ROWS[fontStyle] || DMD_FONT_ROWS["5x7"];
}

/** Width in px of a DMD string at the given size/gap settings. */
function dmdTextWidth(text, clockSize, dotGap, fontStyle) {
    const scale = dotScale(clockSize);
    const cell = scale + dotGap;
    const chars = Array.from(text);
    let total = 0;
    chars.forEach((ch, i) => {
        const glyph = dmdGlyph(ch, fontStyle);
        total += glyph[0].length * cell;
        if (i < chars.length - 1) total += cell; // gap between characters only
    });
    return total;
}

function dmdTextHeight(clockSize, dotGap, fontStyle) {
    const scale = dotScale(clockSize);
    return dmdRowCount(fontStyle) * (scale + dotGap);
}

// Roughly matched to the visual height of the DMD font at each size tier
// (DejaVu Sans bold's cap-height runs smaller than its px size, so these
// run noticeably larger than the DMD px scale to look the same size).
const TT_SIZE_PX = { small: 60, medium: 120, large: 180, xlarge: 220 };

/**
 * Draws DMD text as dots onto a 2D canvas context.
 * opts: { color, glow, gap, size, alpha, fontStyle: "5x7"|"7x9" }
 *
 * Batches dots into up to 3 groups (glow / dim / lit), drawing each group
 * with a single beginPath+fill using the context's own path - not Path2D,
 * whose support in an embedded WebKitGTK build (as used by Cog) is much
 * less battle-tested than the plain 2D context path API every canvas
 * implementation has supported reliably for well over a decade.
 */
function drawDmdText(ctx, text, x0, y0, opts) {
    const scale = dotScale(opts.size);
    const gap = opts.gap;
    const cell = scale + gap;
    const [r, g, b] = hexToRgb(opts.color);
    const dim = [r * 0.1, g * 0.1, b * 0.1];
    const glow = opts.glow;
    const alpha = opts.alpha !== undefined ? opts.alpha : 1;
    const rad = scale / 2;
    const fontStyle = opts.fontStyle || "5x7";

    const litDots = [];
    const dimDots = [];

    let xoff = x0;
    for (const ch of text) {
        const glyph = dmdGlyph(ch, fontStyle);
        const colsN = glyph[0].length;

        for (let rIdx = 0; rIdx < glyph.length; rIdx++) {
            const row = glyph[rIdx];
            for (let c = 0; c < row.length; c++) {
                const lit = row[c] === "1";
                const cx = xoff + c * cell + rad;
                const cy = y0 + rIdx * cell + rad;
                (lit ? litDots : dimDots).push(cx, cy);
            }
        }
        xoff += (colsN + 1) * cell;
    }

    function fillDots(dots, radius, color) {
        if (dots.length === 0) return;
        ctx.beginPath();
        for (let i = 0; i < dots.length; i += 2) {
            ctx.moveTo(dots[i] + radius, dots[i + 1]);
            ctx.arc(dots[i], dots[i + 1], radius, 0, Math.PI * 2);
        }
        ctx.fillStyle = color;
        ctx.fill();
    }

    if (glow) {
        const gCol = [Math.min(255, r * 1.4), Math.min(255, g * 1.4), Math.min(255, b * 1.4)];
        fillDots(litDots, rad + 3, `rgba(${gCol[0]},${gCol[1]},${gCol[2]},${alpha * 0.4})`);
    }
    fillDots(dimDots, rad, `rgba(${dim[0]},${dim[1]},${dim[2]},${alpha})`);
    fillDots(litDots, rad, `rgba(${r},${g},${b},${alpha})`);
}

function ttFontString(clockSize) {
    const px = TT_SIZE_PX[clockSize] || TT_SIZE_PX.large;
    return `bold ${px}px 'DejaVu Sans', Arial, sans-serif`;
}

function ttTextWidth(ctx, text, clockSize) {
    ctx.save();
    ctx.font = ttFontString(clockSize);
    const w = ctx.measureText(text).width;
    ctx.restore();
    return w;
}

function ttTextHeight(clockSize) {
    return (TT_SIZE_PX[clockSize] || TT_SIZE_PX.large) * 1.0;
}

/** Draws plain TrueType text (used when clock_style === "truetype"). */
function drawTtText(ctx, text, x0, y0, opts) {
    ctx.save();
    ctx.font = ttFontString(opts.size);
    ctx.fillStyle = hexWithAlpha(opts.color, opts.alpha);
    ctx.textBaseline = "top";
    ctx.textAlign = "left";
    ctx.fillText(text, x0, y0);
    ctx.restore();
}

function hexWithAlpha(hex, alpha) {
    const [r, g, b] = hexToRgb(hex);
    const a = alpha !== undefined ? alpha : 1;
    return `rgba(${r},${g},${b},${a})`;
}

const PLATE_PAD_X = 16;
const PLATE_PAD_Y = 10;

/** Solid background plate + optional border behind the clock text. */
function drawClockBackground(ctx, x, y, w, h, settings, alpha) {
    if (!settings.bg_enabled && !settings.border_enabled) return;

    const bx = x - PLATE_PAD_X;
    const by = y - PLATE_PAD_Y;
    const bw = w + PLATE_PAD_X * 2;
    const bh = h + PLATE_PAD_Y * 2;
    const radius = 8;

    ctx.save();
    ctx.beginPath();
    ctx.moveTo(bx + radius, by);
    ctx.arcTo(bx + bw, by, bx + bw, by + bh, radius);
    ctx.arcTo(bx + bw, by + bh, bx, by + bh, radius);
    ctx.arcTo(bx, by + bh, bx, by, radius);
    ctx.arcTo(bx, by, bx + bw, by, radius);
    ctx.closePath();

    if (settings.bg_enabled) {
        ctx.fillStyle = hexWithAlpha(settings.bg_color, alpha);
        ctx.fill();
    }
    if (settings.border_enabled) {
        ctx.lineWidth = settings.border_width || 2;
        ctx.strokeStyle = hexWithAlpha(settings.border_color, alpha);
        ctx.stroke();
    }
    ctx.restore();
}

/**
 * Clock position presets. bw/bh are the overall clock-block bounding box -
 * the wider of the time/date lines, and their combined height - not just
 * the time line, so a date string wider than the time string still gets
 * fully reserved space instead of overflowing the margin. topInset/
 * bottomInset are the reserved title-bar and ticker strip heights (0 when
 * disabled). See pinclock-ticker-titlebar-design.md section 3.
 */
const CLOCK_POSITIONS = {
    "top-left": (W, H, bw, bh, padX, padY, topInset) => [padX, topInset + padY],
    "top-center": (W, H, bw, bh, padX, padY, topInset) => [(W - bw) / 2, topInset + padY],
    "top-right": (W, H, bw, bh, padX, padY, topInset) => [W - bw - padX, topInset + padY],
    "center": (W, H, bw, bh, padX, padY, topInset, bottomInset) =>
        [(W - bw) / 2, topInset + (H - topInset - bottomInset - bh) / 2],
    "bottom-left": (W, H, bw, bh, padX, padY, topInset, bottomInset) =>
        [padX, H - bottomInset - bh - padY],
    "bottom-center": (W, H, bw, bh, padX, padY, topInset, bottomInset) =>
        [(W - bw) / 2, H - bottomInset - bh - padY],
    "bottom-right": (W, H, bw, bh, padX, padY, topInset, bottomInset) =>
        [W - bw - padX, H - bottomInset - bh - padY],
};

const ROTATE_CORNERS = ["top-left", "top-right", "bottom-right", "bottom-left"];

/**
 * Renders one full frame of the clock (+ optional date line) onto the given
 * canvas context, honoring position/size/color/glow/gap/format/show_date,
 * plus the optional background plate, border, and clock_style (dotmatrix vs
 * truetype).
 * xShift/yShift are used for scroll transitions; alpha (0-1) for fade.
 */
function renderClockFrame(ctx, W, H, settings, opts) {
    opts = opts || {};
    const alpha = opts.alpha !== undefined ? opts.alpha : 1;
    const xShift = opts.xShift || 0;
    const yShift = opts.yShift || 0;
    const isTt = settings.clock_style === "truetype";

    const { displayStr, ampm } = getCurrentTime(settings.clock_format);
    const now = opts.now || new Date();
    const fullText = displayStr + (ampm ? " " + ampm : "");

    // Edge-justified by default (0 = literally flush with the screen edge).
    // But if a background plate/border is on, reserve exactly its own
    // padding as the margin, so the plate itself stays fully on-canvas
    // instead of being clipped at the true edge.
    const hasPlate = settings.bg_enabled || settings.border_enabled;
    const padX = hasPlate ? PLATE_PAD_X : 0;
    const padY = hasPlate ? PLATE_PAD_Y : 0;

    const dmdFont = settings.dmd_font_style || "5x7";

    const cw = isTt
        ? ttTextWidth(ctx, fullText, settings.clock_size)
        : dmdTextWidth(fullText, settings.clock_size, settings.dot_gap, dmdFont);
    const ch = isTt
        ? ttTextHeight(settings.clock_size)
        : dmdTextHeight(settings.clock_size, settings.dot_gap, dmdFont);

    // Date size has to be known *before* positioning, not just for
    // centering under the clock line afterward - a date string (e.g. a
    // full "Wednesday, September 30" with show_date) can easily be wider
    // than the time string, and the reserved margin/background/border
    // must be sized to whichever line is actually wider.
    const DATE_GAP = 10; // px between the clock line and the date line
    let dateStr = null, dw = 0, dh = 0;
    if (settings.show_date) {
        dateStr = getDateString(now);
        dw = isTt ? ttTextWidth(ctx, dateStr, "small") : dmdTextWidth(dateStr, "small", settings.dot_gap, dmdFont);
        dh = isTt ? ttTextHeight("small") : dmdTextHeight("small", settings.dot_gap, dmdFont);
    }
    const dateH = settings.show_date ? dh + DATE_GAP : 0;

    // Overall clock-block bounding box: whichever line (time or date) is
    // wider, plus both lines' combined height.
    const bw = settings.show_date ? Math.max(cw, dw) : cw;
    const bh = ch + dateH;

    // Reserved title/ticker strips (0 when disabled) - see getBarInsets()
    // in bars.js. Kept as a single source of truth so the clock's usable
    // area always matches the DOM strips' actual on-screen height.
    const insets = getBarInsets(settings);

    const posFn = CLOCK_POSITIONS[settings.clock_position] || CLOCK_POSITIONS["top-right"];
    let [boxX, boxY] = posFn(W, H, bw, bh, padX, padY, insets.top, insets.bottom);
    boxX += xShift;
    boxY += yShift;

    // Each line is centered horizontally within the shared block, so a
    // narrower time or date line sits centered rather than flush to
    // whichever edge the block itself is anchored to.
    const x = boxX + (bw - cw) / 2;
    const y = boxY;

    let dx = 0, dy = 0;
    if (settings.show_date) {
        dx = boxX + (bw - dw) / 2;
        dy = y + ch + DATE_GAP;
    }

    // Background plate spans the full bounding box of the clock line, plus
    // the date line too if present (which may be narrower or wider).
    const bgLeft = settings.show_date ? Math.min(x, dx) : x;
    const bgRight = settings.show_date ? Math.max(x + cw, dx + dw) : x + cw;
    const bgTop = y;
    const bgBottom = settings.show_date ? dy + dh : y + ch;
    drawClockBackground(ctx, bgLeft, bgTop, bgRight - bgLeft, bgBottom - bgTop, settings, alpha);

    if (isTt) {
        drawTtText(ctx, fullText, x, y, { color: settings.dot_color, size: settings.clock_size, alpha });
        if (settings.show_date) {
            drawTtText(ctx, dateStr, dx, dy, { color: settings.dot_color, size: "small", alpha: alpha * 0.7 });
        }
    } else {
        const dotOpts = {
            color: settings.dot_color,
            glow: settings.dot_glow,
            gap: settings.dot_gap,
            size: settings.clock_size,
            alpha,
            fontStyle: dmdFont,
        };
        drawDmdText(ctx, fullText, x, y, dotOpts);
        if (settings.show_date) {
            drawDmdText(ctx, dateStr, dx, dy, { ...dotOpts, size: "small", alpha: alpha * 0.7 });
        }
    }
}
