
// ===============================
// PinClock - Main display loop
// ===============================

// Version string is now sourced from systemStatus.version (fetched from
// /api/system/status) rather than hardcoded here - see PINCLOCK_VERSION
// in app.py for the single source of truth.

const canvas = document.getElementById("display");
const ctx = canvas.getContext("2d");

/**
 * Use the actual viewport size, not screen.width/height - screen reflects
 * the full physical monitor resolution, which is wrong whenever the page
 * isn't truly filling the display (a normal browser window, DevTools docked
 * and shrinking the viewport, etc). That mismatch is what caused bottom
 * positions to render past the visible viewport and get clipped by
 * overflow:hidden, while top positions (near y=0) still appeared fine.
 */
function getScreenSize() {
    return [window.innerWidth, window.innerHeight];
}

function resizeCanvas() {
    const [w, h] = getScreenSize();
    canvas.width = w;
    canvas.height = h;
}
window.addEventListener("resize", resizeCanvas);
resizeCanvas();

// Re-check every frame instead of relying solely on the 'resize' event,
// since some Wayland/WPE kiosk setups may not fire one after startup.
function ensureCanvasSize() {
    const [w, h] = getScreenSize();
    if (canvas.width !== w || canvas.height !== h) {
        canvas.width = w;
        canvas.height = h;
    }
}

// ── Settings (synced from /api/settings + socket.io "settings_updated") ───
const DEFAULT_SETTINGS = {
    clock_style: "dotmatrix",
    dmd_font_style: "5x7",
    clock_position: "top-right",
    clock_size: "medium",
    clock_format: "24h",
    show_date: true,
    dot_color: "#ff6600",
    dot_glow: true,
    dot_gap: 2,
    bg_enabled: false,
    bg_color: "#000000",
    border_enabled: false,
    border_color: "#ffffff",
    border_width: 2,
    position_rotate: false,
    position_rotate_interval: 10,
    effect: "fade",
    effect_speed: "medium",
    brightness: 100,
    show_fps: false,

    title_enabled: false,
    title_text: "",
    title_font_size: 28,
    title_color: "#ffffff",
    title_align: "center",
    title_bg_enabled: true,
    title_bg_color: "#000000",
    title_bg_opacity: 60,
    title_border_enabled: false,
    title_border_color: "#ffffff",
    title_border_width: 2,

    ticker_enabled: false,
    ticker_text: "",
    ticker_font_size: 32,
    ticker_color: "#ffffff",
    ticker_speed: 80,
    ticker_direction: "rtl",
    ticker_bg_enabled: true,
    ticker_bg_color: "#000000",
    ticker_bg_opacity: 60,
    ticker_border_enabled: false,
    ticker_border_color: "#ffffff",
    ticker_border_width: 2,
};

let settings = { ...DEFAULT_SETTINGS };

// ── System status (demo mode / time validity) ──────────────────────────────
// "Demo mode" means the Pi doesn't yet trust its system clock (no NTP sync,
// no manual set from the settings UI). While it's on, the title bar and
// ticker are force-overridden to explain that to whoever's looking at the
// screen, regardless of what the user has configured for those bars - the
// user's own title/ticker settings are never touched, just visually
// superseded until a valid time is available again.
const DEMO_TICKER_TEXT = "To set the time, go to http://10.42.0.1/control";
let systemStatus = { demo_mode: false, time_valid: false };

async function loadSystemStatus() {
    try {
        const res = await fetch("/api/system/status");
        systemStatus = await res.json();
    } catch (err) {
        // keep last-known state if unreachable
    }
    applyBarSettings();
    updateSetupOverlay();
}
loadSystemStatus();

// ── Setup overlay (QR codes / instructions for a window after boot) ────────
// Separate from demo mode above - this is about *getting onto a network at
// all*, not about the clock trusting its time. Shown only for a limited
// window, not forever - once someone's had a chance to see it, permanently
// covering the clock with setup instructions would be more annoying than
// helpful.
const SETUP_OVERLAY_WINDOW_MS = 90 * 1000;
let overlayVisibleUntil = Date.now() + SETUP_OVERLAY_WINDOW_MS;
let wifiStatus = { connected: false, hotspot_active: false, remembered_ssid: "", hostname_url: "" };
let wasConnected = false;

async function loadWifiStatus() {
    try {
        const res = await fetch("/api/wifi/status");
        wifiStatus = await res.json();
    } catch (err) {
        // keep last-known state if unreachable
    }
    checkWifiTransition();
    updateSetupOverlay();
}
loadWifiStatus();

function checkWifiTransition() {
    // Boot itself can take a while (up to a minute or more) before this
    // page even loads, let alone before WiFi finishes associating - a
    // fixed window measured from page-load can easily have already
    // expired by the time the connection actually succeeds, meaning the
    // "here's how to reach settings" QR would never actually get shown.
    // Reset the window fresh every time WiFi genuinely just connected
    // (false -> true), so it's tied to the event that actually matters
    // rather than an unrelated page-load timestamp.
    if (wifiStatus.connected && !wasConnected) {
        overlayVisibleUntil = Date.now() + SETUP_OVERLAY_WINDOW_MS;
    }
    wasConnected = wifiStatus.connected;
}

function updateSetupOverlay() {
    const overlay = document.getElementById("setup-overlay");
    const withinWindow = Date.now() < overlayVisibleUntil;
    const wifiKnown = wifiStatus.connected || wifiStatus.remembered_ssid || wifiStatus.hotspot_active;

    // Once someone's actually reached /control, the overlay's job is
    // done - no reason to keep it up for the rest of the window just
    // because the timer hasn't run out yet.
    if (systemStatus.control_page_loaded || !withinWindow || !wifiKnown) {
        overlay.style.display = "none";
        return;
    }

    const qr1 = document.getElementById("setup-qr-1");
    const qr2Block = document.getElementById("setup-qr-2-block");
    const qr1Label = document.getElementById("setup-qr-1-label");
    const text = document.getElementById("setup-overlay-text");
    const ssidEl = document.getElementById("setup-overlay-ssid");
    const ipEl = document.getElementById("setup-overlay-ip");

    if (wifiStatus.connected) {
        // On a real network - show the way back to settings from here on,
        // since 10.42.0.1 no longer applies once off the hotspot. SSID +
        // raw IP shown directly (not just the .local address) so a wrong
        // network - e.g. an isolated guest WiFi that can't reach the LAN -
        // is obvious at a glance instead of needing a debugging session.
        qr1.src = "/api/qr/settings.png";
        qr1Label.textContent = "Scan for settings";
        qr2Block.style.display = "none";
        ssidEl.textContent = "Connected to: " + (wifiStatus.ssid || "");
        text.textContent = wifiStatus.hostname_url || "";
        ipEl.textContent = wifiStatus.ip ? ("IP: " + wifiStatus.ip) : "";
        overlay.style.display = "flex";
    } else {
        // Still on the setup hotspot (or otherwise not connected) - show
        // both the WiFi-join and settings-URL QR codes, same pair as the
        // printed setup card.
        qr1.src = "/static/img/wifi-join-qr.png";
        qr1Label.textContent = "Scan to join WiFi";
        qr2Block.style.display = "flex";
        document.getElementById("setup-qr-2").src = "/static/img/control-url-qr.png";
        document.getElementById("setup-qr-2-label").textContent = "Scan to open settings";
        ssidEl.textContent = "";
        ipEl.textContent = "";
        text.textContent = "Set up WiFi to keep accurate time automatically";
        overlay.style.display = "flex";
    }
}
// Time-boxed, so re-check on an interval rather than only on data changes -
// it needs to disappear after its window even with no new events at all.
setInterval(updateSetupOverlay, 5000);

function getEffectiveBarSettings() {
    if (!systemStatus.demo_mode) return settings;
    return {
        ...settings,
        title_enabled: true,
        title_text: "Demo",
        title_align: "center",
        title_color: "#ffffff",
        title_bg_enabled: true,
        title_bg_color: "#000000",
        title_bg_opacity: 80,
        title_border_enabled: false,
        ticker_enabled: true,
        ticker_text: DEMO_TICKER_TEXT,
        ticker_color: "#ffffff",
        ticker_bg_enabled: true,
        ticker_bg_color: "#000000",
        ticker_bg_opacity: 80,
        ticker_border_enabled: false,
        ticker_direction: "rtl",
        ticker_speed: settings.ticker_speed || 80,
    };
}

async function loadSettings() {
    try {
        const res = await fetch("/api/settings");
        settings = { ...DEFAULT_SETTINGS, ...(await res.json()) };
    } catch (err) {
        // keep defaults if the backend isn't reachable yet
    }
    applyBarSettings();
}
loadSettings();

if (window.io) {
    const socket = io();
    socket.on("settings_updated", (s) => {
        settings = { ...DEFAULT_SETTINGS, ...s };
        applyBarSettings();
    });
    socket.on("system_status", (s) => {
        systemStatus = s;
        applyBarSettings();
        updateSetupOverlay();
    });
    socket.on("wifi_status", (w) => {
        wifiStatus = w;
        checkWifiTransition();
        updateSetupOverlay();
    });
}

// Title bar/ticker are DOM/CSS, updated on settings changes - not driven
// by the rAF render loop, since they're static (title) or a CSS
// compositor animation (ticker), not a per-frame canvas redraw.
function applyBarSettings() {
    const effective = getEffectiveBarSettings();
    updateTitleBar(effective);
    updateTicker(effective);
}

// The ticker's scroll distance depends on the track's actual pixel width,
// so a viewport resize needs to rebuild its animation too (debounced,
// title bar just needs its width restyled which CSS handles for free).
window.addEventListener("resize", () => scheduleBarsResize(getEffectiveBarSettings));

// ── Corner rotation (position_rotate) ──────────────────────────────────────
const rotateStartTime = performance.now();

function getEffectiveSettings() {
    if (!settings.position_rotate) return settings;
    const intervalMs = Math.max(1, settings.position_rotate_interval || 10) * 1000;
    const elapsed = performance.now() - rotateStartTime;
    const idx = Math.floor(elapsed / intervalMs) % ROTATE_CORNERS.length;
    return { ...settings, clock_position: ROTATE_CORNERS[idx] };
}

function drawFrame() {
    ensureCanvasSize();
    const W = canvas.width;
    const H = canvas.height;
    ctx.clearRect(0, 0, W, H);

    const effSettings = getEffectiveSettings();
    renderClockFrame(ctx, W, H, effSettings);

    // Brightness: overlay a dimming layer (doesn't touch physical backlight)
    const brightness = settings.brightness !== undefined ? settings.brightness : 100;
    if (brightness < 100) {
        ctx.fillStyle = `rgba(0,0,0,${(100 - brightness) / 100})`;
        ctx.fillRect(0, 0, W, H);
    }

    drawDebugOverlay();
    if (settings.show_fps || debugForced) drawFpsCounter();
}

// ── FPS counter (debug) ─────────────────────────────────────────────────
let fpsFrames = 0;
let fpsLastTime = performance.now();
let fpsValue = 0;

let debugForced = false;
let lastStatus = { video: null, width: null, height: null };

async function pollDebugStatus() {
    if (!(settings.show_fps || debugForced)) return;
    try {
        const res = await fetch("/api/status");
        const data = await res.json();
        lastStatus = {
            video: data.video || "(no video)",
            width: data.width || null,
            height: data.height || null,
        };
    } catch (err) {
        lastStatus = { video: "mpv: unreachable", width: null, height: null };
    }
}
setInterval(pollDebugStatus, 500);

function drawFpsCounter() {
    const resText = lastStatus.width && lastStatus.height
        ? `${lastStatus.width}x${lastStatus.height}`
        : "unknown res";
    const eff = getEffectiveSettings();
    const lines = [
        `PinClock ${systemStatus.version || ""}`,
        `${fpsValue} fps`,
        lastStatus.video || "(no video)",
        `video: ${resText}`,
        `canvas: ${canvas.width}x${canvas.height} (screen: ${getScreenSize().join("x")})`,
        `clock pos: ${eff.clock_position}`,
    ];

    ctx.save();
    ctx.font = "16px monospace";
    ctx.fillStyle = "#3cff78";
    ctx.textAlign = "left";
    ctx.textBaseline = "top";

    const pad = 6;
    const lineHeight = 20;
    const boxW = Math.max(...lines.map((l) => ctx.measureText(l).width)) + pad * 2;
    const boxH = lines.length * lineHeight + pad * 2;
    ctx.fillStyle = "rgba(0,0,0,0.5)";
    ctx.fillRect(4, 4, boxW, boxH);

    ctx.fillStyle = "#3cff78";
    lines.forEach((line, i) => {
        ctx.fillText(line, 4 + pad, 4 + pad + i * lineHeight);
    });
    ctx.restore();
}

function render() {
    fpsFrames++;
    const now = performance.now();
    if (now - fpsLastTime >= 1000) {
        fpsValue = fpsFrames;
        fpsFrames = 0;
        fpsLastTime = now;
    }

    drawFrame();
    requestAnimationFrame(render);
}

// ===============================
// Debug keys (matches original display.py scheme):
//   F8    - toggle persistent debug overlay (fps / filename / resolution)
//   Left  - previous video
//   Right - next video
//   Space - play/pause
// ===============================

let debugOverlayText = "";
let debugOverlayUntil = 0;

function showDebugOverlay(text, durationMs = 2000) {
    debugOverlayText = text;
    debugOverlayUntil = performance.now() + durationMs;
}

function drawDebugOverlay() {
    if (!debugOverlayText || performance.now() > debugOverlayUntil) return;

    ctx.save();
    ctx.font = "24px monospace";
    ctx.textAlign = "center";
    ctx.textBaseline = "bottom";

    const x = canvas.width / 2;
    const y = canvas.height - 24;

    ctx.lineWidth = 4;
    ctx.strokeStyle = "#000000";
    ctx.strokeText(debugOverlayText, x, y);

    ctx.fillStyle = "#00ff66";
    ctx.fillText(debugOverlayText, x, y);
    ctx.restore();
}

let isPaused = false;

async function mpvTransport(cmd) {
    try {
        await fetch("/api/transport", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ cmd }),
        });
        if (cmd === "play") isPaused = false;
        if (cmd === "pause") isPaused = true;
        pollDebugStatus();
    } catch (err) {
        showDebugOverlay("mpv: unreachable");
    }
}

document.addEventListener("keydown", (e) => {
    switch (e.key) {
        case "F8":
            debugForced = !debugForced;
            if (debugForced) pollDebugStatus();
            break;
        case "ArrowRight":
            mpvTransport("next");
            break;
        case "ArrowLeft":
            mpvTransport("prev");
            break;
        case " ":
            mpvTransport(isPaused ? "play" : "pause");
            e.preventDefault();
            break;
    }
});

// Start the render loop now that everything it depends on is declared.
render();
