
// ===============================
// PinClock - Clock / date text helpers
// ===============================

const WEEKDAYS = ["SUNDAY", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"];
const MONTHS = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];

/**
 * Returns:
 *   displayStr - "12:34:56" or "23:34:56" (no AM/PM baked in)
 *   ampm       - "AM"/"PM" or "" for 24h
 *   minuteKey  - stable per-minute key used to trigger transitions
 *   now        - Date object
 */
function getCurrentTime(format) {
    const now = new Date();
    let hour = now.getHours();
    let ampm = "";

    if (format === "12h") {
        ampm = hour < 12 ? "AM" : "PM";
        hour = hour % 12;
        if (hour === 0) hour = 12;
    }

    const hh = String(hour).padStart(2, "0");
    const mm = String(now.getMinutes()).padStart(2, "0");
    const ss = String(now.getSeconds()).padStart(2, "0");

    const displayStr = `${hh}:${mm}:${ss}`;
    const minuteKey = `${hh}:${mm}${ampm}`;

    return { displayStr, ampm, minuteKey, now };
}

function getDateString(now) {
    return `${WEEKDAYS[now.getDay()]}  ${MONTHS[now.getMonth()]} ${now.getDate()}`;
}
