import io
import json
import os
import socket
import subprocess
import sys
import threading
import time

from flask import Flask, jsonify, request, send_from_directory, render_template, send_file
from flask_socketio import SocketIO
from werkzeug.utils import secure_filename

import qrcode

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "app"))
from core import mpv_ipc  # noqa: E402
from core import settings_store as store  # noqa: E402
from core import wifi_manager  # noqa: E402
from core import system_state  # noqa: E402
from core.paths import DATA_DIR  # noqa: E402

# Single source of truth for the version string - the Device tab and the
# on-screen debug overlay (display.js) both fetch this via
# /api/system/status rather than each hardcoding their own copy, so a
# version bump only ever needs to happen in one place.
PINCLOCK_VERSION = "v0.9.1"

app = Flask(__name__, static_folder="app/static", template_folder="app/templates")
app.config["MAX_CONTENT_LENGTH"] = 1024 * 1024 * 1024  # 1 GB max upload
socketio = SocketIO(app, async_mode="eventlet", cors_allowed_origins="*")

# Changes every time Flask (re)starts, used as a cache-busting query string on
# display.html's <script> tags - see note on add_no_cache_headers() below.
ASSET_VERSION = str(int(time.time()))


@app.after_request
def add_no_cache_headers(response):
    """
    The display page runs inside Cog/WebKit as a long-lived kiosk view, which
    can aggressively disk-cache HTML/JS/API responses across restarts and
    even reboots. Since this is a local single-purpose app (not something
    served to the public internet), we just disable caching entirely so a
    code or settings change always takes effect on the next reload.
    """
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response


# -------------------------------------------------------------- pages -----
@app.route("/")
def index():
    return render_template("display.html", v=ASSET_VERSION)


_control_page_loaded = False


@app.route("/control")
def control():
    global _control_page_loaded
    _control_page_loaded = True
    return render_template("control.html")


@app.route("/videos/<path:filename>")
def videos_static(filename):
    """
    Serves a video file for direct browser playback/preview. Checks the
    user directory first, then shipped - NOT relative to the app's own
    root_path (that was this route's original behavior, which broke
    silently once videos moved to DATA_DIR in step 1's path split and
    was never actually exercised by anything in this app since, until
    now with the shipped-videos feature).
    """
    from core.paths import SHIPPED_VIDEOS_DIR
    safe_name = secure_filename(filename)
    if (store.VIDEOS_DIR / safe_name).is_file():
        return send_from_directory(str(store.VIDEOS_DIR), safe_name)
    if (SHIPPED_VIDEOS_DIR / safe_name).is_file():
        return send_from_directory(str(SHIPPED_VIDEOS_DIR), safe_name)
    return jsonify({"error": "not found"}), 404


# ----------------------------------------------------------- settings -----
@app.route("/api/settings", methods=["GET"])
def get_settings():
    return jsonify(store.load_settings())


@app.route("/api/settings", methods=["POST"])
def post_settings():
    data = request.get_json(force=True, silent=True) or {}
    # "playlist" is deliberately excluded here even though it's a
    # DEFAULT_SETTINGS key - it must only ever be mutated through the
    # validated /api/playlist/add and /api/playlist/remove endpoints
    # (which check the video actually exists, dedupe, etc.), never as
    # a raw blob via the generic settings-save path.
    allowed_keys = set(store.DEFAULT_SETTINGS.keys()) - {"playlist"}
    clean = {k: v for k, v in data.items() if k in allowed_keys}
    updated = store.save_settings(clean)

    # Live-apply what we can directly to mpv
    try:
        if "video_volume" in clean:
            mpv_ipc.set_property("volume", clean["video_volume"])
        if "video_loop" in clean:
            mpv_ipc.set_property("loop-playlist", "inf" if clean["video_loop"] else "no")
        if "randomize" in clean:
            _regenerate_and_reload_playlist()
    except mpv_ipc.MpvIPCError:
        pass

    socketio.emit("settings_updated", updated)
    return jsonify(updated)


# ------------------------------------------------------------- videos -----
@app.route("/api/videos", methods=["GET"])
def get_videos():
    """My Videos / Stock tabs - every video available on the device,
    tagged with whether it's currently in the playlist (so the UI can
    show "Add" vs an already-added state)."""
    playlist_keys = {(e["name"], e["source"]) for e in store.get_playlist()}
    out = []
    for v in store.list_videos():
        try:
            size = v["path"].stat().st_size
        except OSError:
            size = 0
        out.append({
            "name": v["name"], "size": size, "source": v["source"],
            "deletable": v["deletable"],
            "in_playlist": (v["name"], v["source"]) in playlist_keys,
        })
    return jsonify(out)


@app.route("/api/videos/upload", methods=["POST"])
def upload_video():
    if "file" not in request.files:
        return jsonify({"error": "no file provided"}), 400
    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "empty filename"}), 400

    filename = secure_filename(file.filename)
    ext = os.path.splitext(filename)[1].lower()
    if ext not in store.ALLOWED_VIDEO_EXT:
        return jsonify({"error": "only .mp4 files are supported"}), 400

    from core.paths import SHIPPED_VIDEOS_DIR
    if (SHIPPED_VIDEOS_DIR / filename).exists():
        return jsonify({
            "error": f"'{filename}' is already a shipped video name - rename your file and try again"
        }), 400

    dest = store.VIDEOS_DIR / filename
    file.save(str(dest))
    store.add_to_playlist(filename, "user")  # uploading always adds it to what's playing

    _regenerate_and_reload_playlist()
    socketio.emit("videos_updated", {})
    socketio.emit("playlist_updated", {})
    return jsonify({"ok": True, "name": filename})


@app.route("/api/videos/<path:name>", methods=["DELETE"])
def delete_video(name):
    """User videos only - shipped videos (source="shipped", see
    settings_store.list_videos) are never deletable through this app,
    the same way they're never editable through the update mechanism
    outside of a real firmware release. A request naming a shipped
    video's filename gets refused rather than silently no-op'd, so the
    control page can show a clear reason rather than a mysterious
    non-deletion."""
    filename = secure_filename(name)
    from core.paths import SHIPPED_VIDEOS_DIR
    if (SHIPPED_VIDEOS_DIR / filename).is_file() and not (store.VIDEOS_DIR / filename).is_file():
        return jsonify({"error": "shipped videos can't be deleted"}), 403

    target = store.VIDEOS_DIR / filename
    if target.exists() and target.is_file():
        target.unlink()
        store.remove_from_playlist(filename, "user")  # can't stay in the playlist once it's gone
        _regenerate_and_reload_playlist()
        socketio.emit("videos_updated", {})
        socketio.emit("playlist_updated", {})
        return jsonify({"ok": True})
    return jsonify({"error": "not found"}), 404


@app.route("/api/videos/play", methods=["POST"])
def play_video():
    """
    Plays the requested video right away, WITHOUT clearing the rest of
    the loaded playlist (unlike this endpoint's earlier "replace"
    behavior). See mpv_ipc.play_now for how - insert-next then an
    explicit playlist-next, rather than a single loadfile flag that
    needs a specific-enough mpv version to work at all.

    Accepts an optional "source" to disambiguate a name that happens to
    exist in both places (see settings_store.list_videos's docstring on
    why name alone isn't always unique) - if omitted, checks user then
    shipped, matching this endpoint's previous behavior.
    """
    data = request.get_json(force=True, silent=True) or {}
    name = data.get("name")
    source = data.get("source")
    if not name:
        return jsonify({"error": "name is required"}), 400
    filename = secure_filename(name)

    from core.paths import SHIPPED_VIDEOS_DIR
    if source == "user":
        target = store.VIDEOS_DIR / filename
    elif source == "shipped":
        target = SHIPPED_VIDEOS_DIR / filename
    else:
        target = store.VIDEOS_DIR / filename
        if not target.exists():
            target = SHIPPED_VIDEOS_DIR / filename

    if not target.exists():
        return jsonify({"error": "not found"}), 404
    try:
        mpv_ipc.play_now(str(target))
        return jsonify({"ok": True})
    except mpv_ipc.MpvIPCError as e:
        return jsonify({"ok": False, "error": str(e)}), 500


# ----------------------------------------------------------- playlist -----
@app.route("/api/playlist", methods=["GET"])
def get_playlist_route():
    """Current Playlist tab - the explicit, curated set of videos that
    actually get played, in play order. See
    settings_store.get_playlist for the self-healing behavior (stale
    entries referencing deleted files are dropped automatically)."""
    playlist = store.get_playlist()
    by_key = {(v["name"], v["source"]): v for v in store.list_videos()}
    out = []
    for e in playlist:
        v = by_key.get((e["name"], e["source"]))
        size = 0
        if v:
            try:
                size = v["path"].stat().st_size
            except OSError:
                pass
        out.append({"name": e["name"], "source": e["source"], "size": size})
    return jsonify(out)


@app.route("/api/playlist/add", methods=["POST"])
def add_to_playlist_route():
    data = request.get_json(force=True, silent=True) or {}
    name = secure_filename(data.get("name") or "")
    source = data.get("source")
    if not name or source not in ("user", "shipped"):
        return jsonify({"error": "name and source ('user' or 'shipped') are required"}), 400
    try:
        playlist = store.add_to_playlist(name, source)
    except ValueError as e:
        return jsonify({"error": str(e)}), 404
    _regenerate_and_reload_playlist()
    socketio.emit("videos_updated", {})
    socketio.emit("playlist_updated", {})
    return jsonify({"ok": True, "playlist": playlist})


@app.route("/api/playlist/remove", methods=["POST"])
def remove_from_playlist_route():
    """Playlist-only removal - the video stays on the device (still
    visible/manageable in My Videos or Stock), it just stops playing.
    See delete_video() for actually removing a user video from the
    device entirely."""
    data = request.get_json(force=True, silent=True) or {}
    name = secure_filename(data.get("name") or "")
    source = data.get("source")
    if not name or source not in ("user", "shipped"):
        return jsonify({"error": "name and source ('user' or 'shipped') are required"}), 400
    playlist = store.remove_from_playlist(name, source)
    _regenerate_and_reload_playlist()
    socketio.emit("videos_updated", {})
    socketio.emit("playlist_updated", {})
    return jsonify({"ok": True, "playlist": playlist})


# ---------------------------------------------------------- transport -----
@app.route("/api/transport", methods=["POST"])
def transport():
    data = request.get_json(force=True, silent=True) or {}
    cmd = data.get("cmd")
    if cmd not in ("play", "pause", "next", "prev"):
        return jsonify({"error": "invalid command"}), 400
    try:
        if cmd == "play":
            mpv_ipc.set_pause(False)
        elif cmd == "pause":
            mpv_ipc.set_pause(True)
        elif cmd == "next":
            mpv_ipc.next_video()
        elif cmd == "prev":
            mpv_ipc.prev_video()
        return jsonify({"ok": True})
    except mpv_ipc.MpvIPCError as e:
        return jsonify({"ok": False, "error": str(e)}), 500


@app.route("/api/status", methods=["GET"])
def status():
    return jsonify(mpv_ipc.get_status())


# ---------------------------------------------------------------- time ----
@app.route("/api/time", methods=["POST"])
def set_time():
    """
    Set the Pi's system clock from the phone.
    Expects JSON: {"iso": "2026-07-08T14:23:00"} (local time, no timezone math)

    Requires a passwordless sudo rule for /bin/date - see setup.sh.
    """
    data = request.get_json(force=True, silent=True) or {}
    iso = data.get("iso")
    if not iso:
        return jsonify({"error": "iso datetime string is required"}), 400

    date_str = iso.replace("T", " ").replace("'", "")
    try:
        result = subprocess.run(
            ["sudo", "/bin/date", "-s", date_str],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode != 0:
            return jsonify({"error": result.stderr.strip() or "failed to set system time"}), 500
        st = system_state.mark_time_valid("manual")
        socketio.emit("system_status", _system_status_payload(st))
        return jsonify({"ok": True, "output": result.stdout.strip()})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ------------------------------------------------------------- wifi ------
def _hostname_url():
    """
    A fixed, DHCP-independent address for reaching the control page once
    connected to a real network - relies on mDNS (avahi-daemon), which is
    already running on this image. This is deliberately preferred over
    trying to display/track the actual DHCP-assigned IP: that changes
    per-network and would need the on-device display to regenerate a QR
    code live, whereas "<hostname>.local" is stable across reboots and
    networks, so it can be shown as a plain static QR code instead.
    """
    host = socket.gethostname()
    return f"http://{host}.local:5000/control"


_qr_cache = {}


def _qr_png_bytes(payload):
    """Small in-memory cache - the handful of payloads this ever
    generates (the hostname URL, essentially) don't change within a
    process lifetime, so there's no reason to re-render the QR every time
    the display polls for it."""
    if payload not in _qr_cache:
        img = qrcode.make(payload)
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        _qr_cache[payload] = buf.getvalue()
    return _qr_cache[payload]


@app.route("/api/wifi/status", methods=["GET"])
def wifi_status():
    return jsonify({
        **wifi_manager.get_status(),
        "remembered_ssid": wifi_manager.get_remembered_ssid(),
        "hostname_url": _hostname_url(),
    })


@app.route("/api/wifi/scan", methods=["GET"])
def wifi_scan():
    rescan = request.args.get("rescan", "1") != "0"
    return jsonify(wifi_manager.scan_networks(rescan=rescan))


@app.route("/api/wifi/connect", methods=["POST"])
def wifi_connect():
    data = request.get_json(force=True, silent=True) or {}
    ssid = (data.get("ssid") or "").strip()
    password = data.get("password") or ""
    try:
        ok, message = wifi_manager.connect(ssid, password)
    except wifi_manager.WifiError as e:
        return jsonify({"ok": False, "error": str(e)}), 500

    status = wifi_manager.get_status()
    socketio.emit("wifi_status", status)
    if not ok:
        return jsonify({"ok": False, "error": message, **status}), 400
    return jsonify({"ok": True, **status})


@app.route("/api/wifi/enabled", methods=["POST"])
def wifi_enabled():
    """
    "WiFi enabled" in the settings UI means: connected to a home network
    (on) vs. disconnected and running the PinClock-Setup hotspot instead
    (off). It intentionally never disables the WiFi radio itself - see
    the big warning in wifi_manager.py's docstring for why (short
    version: doing that once already locked a Pi out of both WiFi and
    SSH until someone re-imaged the SD card).

    The actual network change is scheduled a moment after this responds,
    not run inline - if the caller's own HTTP connection is riding over
    the very WiFi link about to come down (the normal case: someone using
    their phone on the home network to reach /control), doing it inline
    risks the response never making it back before the link drops. This
    way the browser gets its "ok" first and the transition happens
    (briefly) after.
    """
    data = request.get_json(force=True, silent=True) or {}
    enabled = bool(data.get("enabled"))

    def _apply():
        try:
            if enabled:
                ok, message = wifi_manager.reconnect_client()
            else:
                ok, message = wifi_manager.disconnect_to_hotspot()
        except Exception as e:
            # Whatever went wrong, this runs in a detached background
            # thread with no HTTP response left to return it through - if
            # we don't catch it here it just vanishes into the Flask
            # process's stderr and the settings UI never finds out.
            ok, message = False, str(e)
        socketio.emit("wifi_status", {**wifi_manager.get_status(), "last_error": None if ok else message})

    threading.Timer(1.0, _apply).start()
    return jsonify({"ok": True, "pending": True})


@app.route("/api/wifi/forget", methods=["POST"])
def wifi_forget():
    ok, message = wifi_manager.forget()
    status = wifi_manager.get_status()
    socketio.emit("wifi_status", {**status, "last_error": None if ok else message})
    if not ok:
        return jsonify({"ok": False, "error": message, **status}), 500
    return jsonify({"ok": True, **status})


@app.route("/api/qr/settings.png", methods=["GET"])
def qr_settings():
    """A QR code encoding this device's stable mDNS settings URL - see
    _hostname_url(). Shown on the physical display for a window after
    boot once WiFi is connected, so someone can scan their way to the
    control page without needing to know or type an IP address."""
    png = _qr_png_bytes(_hostname_url())
    return send_file(io.BytesIO(png), mimetype="image/png")


# ----------------------------------------------------------- system ------
def _system_status_payload(state=None):
    state = state or system_state.get_state()
    return {
        "time_valid": state["time_valid"],
        "demo_mode": not state["time_valid"],
        "time_source": state["time_source"],
        "control_page_loaded": _control_page_loaded,
        "version": PINCLOCK_VERSION,
    }


@app.route("/api/system/status", methods=["GET"])
def system_status():
    return jsonify(_system_status_payload())


@app.route("/api/system/reboot", methods=["POST"])
def system_reboot():
    """
    Responds first, then reboots a moment later - same reasoning as
    /api/wifi/enabled: if this request is the last thing the browser
    hears from the Pi for a while, better that it actually got the "ok"
    response before the reboot begins tearing things down.
    """
    def _do_reboot():
        subprocess.run(["sudo", "systemctl", "reboot"])

    threading.Timer(1.0, _do_reboot).start()
    return jsonify({"ok": True, "pending": True})


@app.route("/api/system/reset-defaults", methods=["POST"])
def system_reset_defaults():
    """
    Device tab's "Default settings" - display settings back to
    DEFAULT_SETTINGS, WiFi forgotten, time/demo state cleared, then
    reboot so it actually comes up the way a first-time user would see
    it rather than just silently changing state underneath a still-running
    session.
    """
    store.reset_to_defaults()
    wifi_ok, wifi_message = wifi_manager.forget()
    if not wifi_ok:
        # Still proceed with the reboot (the person already confirmed
        # this action, and settings/state are reset regardless) - but
        # this needs to actually be visible somewhere, since by the time
        # anyone could look at a response the reboot may already have
        # happened. See /tmp/pinclock-flask.log.
        print(f"[reset-defaults] WARNING: wifi_manager.forget() reported: {wifi_message}")
    system_state.reset_to_defaults()

    def _do_reboot():
        subprocess.run(["sudo", "systemctl", "reboot"])

    threading.Timer(1.5, _do_reboot).start()
    return jsonify({"ok": True, "pending": True, "wifi_forgotten": wifi_ok, "wifi_message": wifi_message})


# ---------------------------------------------------- firmware update -----
# run_update.py deliberately lives at a fixed path outside any versioned
# release directory (see that script's own docstring for why) - app.py
# must always reference it there directly, never relative to its own
# __file__, since app.py itself is what may be running from inside a
# versioned release directory once the blue-green layout is in use.
RUN_UPDATE_SCRIPT = "/opt/pinclock/updater/run_update.py"
UPDATE_STATUS_FILE = DATA_DIR / "update_status.json"


@app.route("/api/firmware/check", methods=["GET"])
def firmware_check():
    """
    Device tab's "Check for Firmware Update" - read-only, no side
    effects. Runs run_update.py as a separate process rather than
    importing it (see RUN_UPDATE_SCRIPT comment and that script's own
    module docstring) so this stays fully decoupled from the actual
    update/rollback machinery.
    """
    try:
        result = subprocess.run(
            ["/usr/bin/python3", RUN_UPDATE_SCRIPT, "--check"],
            capture_output=True, text=True, timeout=20,
        )
    except (subprocess.SubprocessError, OSError) as e:
        return jsonify({"ok": False, "error": f"could not run update checker: {e}"}), 500

    try:
        payload = json.loads(result.stdout)
    except json.JSONDecodeError:
        return jsonify({"ok": False, "error": result.stderr.strip() or "invalid response from update checker"}), 502

    if "error" in payload:
        return jsonify({"ok": False, "error": payload["error"]}), 502
    return jsonify({"ok": True, **payload})


@app.route("/api/firmware/update", methods=["POST"])
def firmware_update():
    """
    Device tab's "Update Firmware" - fires the update off as a separate
    systemd --user unit (pinclock-update.service) and returns
    immediately. The actual download/verify/stage/swap/restart/
    health-check/rollback sequence - including restarting
    pinclock.service, which this very request handler is running
    inside of - happens entirely outside this request. Poll
    /api/firmware/update-status for progress. See scripts/run_update.py.

    No sudo needed here (unlike /api/system/reboot): pinclock-update.
    service is a *user* unit, same as pinclock.service - this is just
    vfw's own systemd --user instance starting one of its own units,
    not a privileged operation.
    """
    result = subprocess.run(
        ["systemctl", "--user", "start", "pinclock-update.service"],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        return jsonify({
            "ok": False,
            "error": result.stderr.strip() or "failed to start pinclock-update.service",
        }), 500
    return jsonify({"ok": True, "pending": True})


@app.route("/api/firmware/update-status", methods=["GET"])
def firmware_update_status():
    """
    Polled by the control page while an update OR a factory reset is in
    flight - the response includes an "operation" field ("update" vs
    "factory_reset") since both share this same status file (see
    run_update.py's _write_status), so the UI can label progress
    correctly regardless of which one triggered it.

    Reads the status file run_update.py writes as it goes - this can't
    just be a synchronous response to /api/firmware/update or
    /api/system/factory-reset because that request's own Flask process
    gets restarted partway through the sequence it triggers.
    """
    if not UPDATE_STATUS_FILE.exists():
        return jsonify({"state": "idle"})
    try:
        with open(UPDATE_STATUS_FILE, "r") as f:
            return jsonify(json.load(f))
    except (OSError, json.JSONDecodeError):
        return jsonify({"state": "unknown", "message": "could not read update status file"})


@app.route("/api/system/factory-reset", methods=["POST"])
def system_factory_reset():
    """
    Device tab's "Factory Reset" - restores code + labwc config from the
    blessed factory snapshot (see scripts/bless_factory.py), verified
    and health-checked the same way an update is, then resets settings/
    WiFi/state and clears videos, then reboots. See
    scripts/run_update.py's run_factory_reset() for the full sequence.

    Fires as a separate systemd --user unit and returns immediately,
    same reasoning as /api/firmware/update - poll
    /api/firmware/update-status for progress (the "operation" field in
    its response will read "factory_reset").
    """
    result = subprocess.run(
        ["systemctl", "--user", "start", "pinclock-factory-reset.service"],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        return jsonify({
            "ok": False,
            "error": result.stderr.strip() or "failed to start pinclock-factory-reset.service",
        }), 500
    return jsonify({"ok": True, "pending": True})


# ------------------------------------------------------------ helpers -----
def _regenerate_and_reload_playlist():
    """Re-run gen_playlist.py (picks up randomize setting) then hot-reload mpv."""
    script = os.path.join(os.path.dirname(__file__), "scripts", "gen_playlist.py")
    subprocess.run([sys.executable, script], check=False)
    try:
        mpv_ipc.reload_playlist()
    except mpv_ipc.MpvIPCError:
        pass


# ----------------------------------------------------------- socket.io ----
def _status_broadcaster():
    last_status = None
    last_settings = None
    last_system = None
    last_wifi = None
    while True:
        st = mpv_ipc.get_status()
        if st != last_status:
            socketio.emit("status_update", st)
            last_status = st

        cfg = store.load_settings()
        if cfg != last_settings:
            socketio.emit("settings_updated", cfg)
            last_settings = cfg

        # Poll NTP sync state - this is how demo mode clears itself once
        # WiFi comes up and the clock catches an NTP sync, with no action
        # needed from the settings UI.
        sys_state = system_state.poll()
        sys_payload = _system_status_payload(sys_state)
        if sys_payload != last_system:
            socketio.emit("system_status", sys_payload)
            last_system = sys_payload

        wifi_st = wifi_manager.get_status()
        if wifi_st != last_wifi:
            socketio.emit("wifi_status", wifi_st)
            last_wifi = wifi_st

        socketio.sleep(2)


@socketio.on("connect")
def on_connect():
    socketio.emit("settings_updated", store.load_settings())
    socketio.emit("status_update", mpv_ipc.get_status())
    socketio.emit("videos_updated", {})
    socketio.emit("system_status", _system_status_payload())
    socketio.emit("wifi_status", wifi_manager.get_status())


def main():
    system_state.recheck_on_startup()
    socketio.start_background_task(_status_broadcaster)
    socketio.run(app, host="0.0.0.0", port=5000)


if __name__ == "__main__":
    main()
