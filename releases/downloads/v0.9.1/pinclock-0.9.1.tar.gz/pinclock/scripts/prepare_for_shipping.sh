#!/bin/sh
#########################################################
# PinClock - prepare for shipping / imaging
#
# Run this on the Pi (as root, e.g. `sudo sh scripts/prepare_for_shipping.sh`)
# right before you clone the SD card or hand the device to someone else.
# It clears:
#   1. PinClock's own record of your WiFi (config.json, state.json)
#   2. The NetworkManager WiFi connection profile itself (which holds
#      the actual PSK) - found dynamically, not hardcoded, so this works
#      whether the profile is netplan-managed (e.g. "netplan-wlan0-xxxx")
#      or one PinClock's own WiFi tab created (named after the SSID).
#
# What this does NOT do, because it's genuinely device/image-specific and
# risky to script blindly:
#   - Edit netplan's *source* YAML (e.g. /etc/netplan/50-cloud-init.yaml).
#     If your WiFi was set up there rather than through PinClock's own
#     WiFi tab, NetworkManager will just recreate the same
#     "netplan-wlan0-*" profile (with your real SSID/password) again on
#     the next boot, undoing step 2 above. See the printed reminder at
#     the end - you likely want to strip the `wifis:` block from that
#     file entirely and let the new hotspot/WiFi-tab flow handle first
#     boot setup instead.
#   - Regenerate the machine ID / SSH host keys / clear logs. Standard
#     "prepare a golden image" steps, but out of scope for a WiFi-specific
#     cleanup - handle separately if you're distributing this image.
#########################################################

PINCLOCK_DATA_DIR="/home/vfw/pinclock-data"
CONFIG_FILE="$PINCLOCK_DATA_DIR/config.json"
STATE_FILE="$PINCLOCK_DATA_DIR/state.json"

echo "== PinClock: clearing WiFi credentials before shipping =="

# --- 1. NetworkManager profile(s) -----------------------------------------
# Anything of TYPE wifi that isn't our own open setup hotspot is a real
# network profile - delete every one of them, not just the current SSID,
# since old/forgotten ones from earlier testing can carry credentials too.
nmcli -t -f NAME,TYPE connection show 2>/dev/null | while IFS=: read -r name type; do
    if [ "$type" = "wifi" ] && [ "$name" != "PinClock-Setup" ]; then
        echo "Deleting NetworkManager profile: $name"
        nmcli connection delete "$name" >/dev/null 2>&1
    fi
done

# --- 2. PinClock's own bookkeeping -----------------------------------------
if [ -f "$CONFIG_FILE" ]; then
    python3 - "$CONFIG_FILE" <<'PYEOF'
import json, sys
path = sys.argv[1]
with open(path) as f:
    cfg = json.load(f)
cfg["wifi"] = {"configured": False, "ssid": "", "connection_name": ""}
with open(path, "w") as f:
    json.dump(cfg, f, indent=2)
print(f"Cleared wifi section of {path}")
PYEOF
fi

if [ -f "$STATE_FILE" ]; then
    rm -f "$STATE_FILE"
    echo "Removed $STATE_FILE (demo-mode/time state - regenerates fresh on next boot)"
fi

echo
echo "== Done clearing what's safe to automate. =="
echo
echo "IMPORTANT: if your WiFi was originally set up via the Pi's initial"
echo "imaging/setup tool (not PinClock's own WiFi tab), it likely also"
echo "lives in a netplan YAML file, e.g.:"
echo
echo "  grep -rl 'wifis:' /etc/netplan/"
echo
echo "Open whatever file that finds and remove the wifis: block (or just"
echo "the access-points/password lines) before imaging - otherwise"
echo "NetworkManager will recreate the same profile with your real"
echo "credentials on the next boot, undoing the cleanup above. With that"
echo "block removed, a fresh boot will have no saved WiFi at all and will"
echo "fall straight into the PinClock-Setup hotspot, which is exactly the"
echo "flow the next owner should use to set up their own WiFi."
