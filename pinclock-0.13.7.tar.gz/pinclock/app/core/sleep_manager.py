"""
PinClock - sleep mode scheduling.

Pure logic only (no mpv/subprocess/socketio calls here) so it can be
unit-tested directly - see the __main__ self-test block at the bottom,
run via `python3 sleep_manager.py`. app.py owns actually *acting* on
the result (pausing mpv, best-effort HDMI power via wlr-randr,
broadcasting sleep_status) - see _apply_sleep_state() there.

Two modes, both described in settings_store.py's DEFAULT_SETTINGS
comment:
  - "minutes":  one-shot countdown from process start (PROCESS_START_TIME
                below) - NOT a repeating cycle. Once elapsed, stays asleep
                until pinclock.service itself restarts.
  - "schedule": daily sleep_time -> wake_time window, in local time,
                correctly handling a window that does or doesn't cross
                midnight.
"""
import time
from datetime import datetime

# Captured once at import time (i.e. once per pinclock.service start,
# including restarts triggered by a firmware update) - the reference
# point "minutes" mode counts from.
PROCESS_START_TIME = time.time()


def _parse_hhmm(s):
    """'HH:MM' -> minutes since midnight. Returns None if unparseable
    (caller should treat that as "schedule not configured" rather than
    raising, since this runs unattended every poll)."""
    try:
        h, m = s.split(":")
        h, m = int(h), int(m)
        if 0 <= h < 24 and 0 <= m < 60:
            return h * 60 + m
    except (ValueError, AttributeError):
        pass
    return None


def _minutes_mode_asleep(settings, now_ts):
    elapsed_minutes = (now_ts - PROCESS_START_TIME) / 60.0
    threshold = settings.get("sleep_after_minutes", 60)
    try:
        threshold = float(threshold)
    except (TypeError, ValueError):
        return False
    if threshold <= 0:
        return False
    return elapsed_minutes >= threshold


def _schedule_mode_asleep(settings, now_dt):
    sleep_min = _parse_hhmm(settings.get("sleep_time"))
    wake_min = _parse_hhmm(settings.get("wake_time"))
    if sleep_min is None or wake_min is None or sleep_min == wake_min:
        # Degenerate/unconfigured - never asleep rather than guessing.
        return False

    now_min = now_dt.hour * 60 + now_dt.minute

    if sleep_min < wake_min:
        # Same-day window, e.g. sleep 01:00 -> wake 08:00: asleep only
        # between those two times, same calendar day.
        return sleep_min <= now_min < wake_min
    else:
        # Overnight window, e.g. sleep 23:00 -> wake 07:00: asleep from
        # sleep_time through midnight up to wake_time the next day.
        return now_min >= sleep_min or now_min < wake_min


def is_asleep(settings, now=None):
    """settings: the loaded settings dict. now: optional (epoch seconds,
    datetime) override for testing - defaults to the real current time."""
    mode = settings.get("sleep_mode", "off")
    if mode == "minutes":
        now_ts = now if isinstance(now, (int, float)) else time.time()
        return _minutes_mode_asleep(settings, now_ts)
    if mode == "schedule":
        now_dt = now if isinstance(now, datetime) else datetime.now()
        return _schedule_mode_asleep(settings, now_dt)
    return False


if __name__ == "__main__":
    # Quick self-test - not pytest (this project has no test runner set
    # up), just asserts run directly. See TESTING PHILOSOPHY note in the
    # continuation prompt: verify timer/state-machine logic explicitly
    # rather than eyeballing it.
    from datetime import datetime as _dt

    # -- schedule mode: same-day window (the example from the request) --
    s = {"sleep_mode": "schedule", "sleep_time": "01:00", "wake_time": "08:00"}
    assert is_asleep(s, _dt(2026, 1, 1, 0, 59)) is False
    assert is_asleep(s, _dt(2026, 1, 1, 1, 0)) is True
    assert is_asleep(s, _dt(2026, 1, 1, 4, 30)) is True
    assert is_asleep(s, _dt(2026, 1, 1, 7, 59)) is True
    assert is_asleep(s, _dt(2026, 1, 1, 8, 0)) is False
    assert is_asleep(s, _dt(2026, 1, 1, 12, 0)) is False

    # -- schedule mode: overnight window --
    s = {"sleep_mode": "schedule", "sleep_time": "23:00", "wake_time": "07:00"}
    assert is_asleep(s, _dt(2026, 1, 1, 22, 59)) is False
    assert is_asleep(s, _dt(2026, 1, 1, 23, 0)) is True
    assert is_asleep(s, _dt(2026, 1, 2, 0, 0)) is True
    assert is_asleep(s, _dt(2026, 1, 2, 6, 59)) is True
    assert is_asleep(s, _dt(2026, 1, 2, 7, 0)) is False

    # -- schedule mode: degenerate (equal times) never sleeps --
    s = {"sleep_mode": "schedule", "sleep_time": "05:00", "wake_time": "05:00"}
    assert is_asleep(s, _dt(2026, 1, 1, 5, 0)) is False

    # -- schedule mode: bad/missing config never sleeps --
    s = {"sleep_mode": "schedule", "sleep_time": "", "wake_time": "08:00"}
    assert is_asleep(s, _dt(2026, 1, 1, 3, 0)) is False

    # -- minutes mode: one-shot countdown from PROCESS_START_TIME --
    s = {"sleep_mode": "minutes", "sleep_after_minutes": 10}
    assert is_asleep(s, PROCESS_START_TIME + 9 * 60) is False
    assert is_asleep(s, PROCESS_START_TIME + 10 * 60) is True
    assert is_asleep(s, PROCESS_START_TIME + 999 * 60) is True  # stays asleep

    # -- minutes mode: 0/negative threshold treated as "never" --
    s = {"sleep_mode": "minutes", "sleep_after_minutes": 0}
    assert is_asleep(s, PROCESS_START_TIME + 999 * 60) is False

    # -- off mode --
    s = {"sleep_mode": "off", "sleep_after_minutes": 1, "sleep_time": "00:00", "wake_time": "00:01"}
    assert is_asleep(s, PROCESS_START_TIME + 999 * 60) is False

    print("sleep_manager: all self-tests passed")
