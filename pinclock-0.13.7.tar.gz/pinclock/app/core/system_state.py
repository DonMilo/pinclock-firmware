"""
PinClock - system state: time validity / demo mode.

The Pi has no RTC battery, so on a cold boot without network it wakes up
with whatever time fake-hwclock last saved (or the epoch) - not a real
clock. "Demo mode" just means: we don't yet trust the system clock.

We leave demo mode the moment either of these happens:
  - NetworkManager gets us online and systemd-timesyncd reports NTP sync
    (checked via `timedatectl show -p NTPSynchronized`), or
  - the phone-based settings UI POSTs a time to /api/time (see app.py)

State is persisted to state.json purely so a Flask restart doesn't
flip back to "Demo" for no reason if the clock is already known-good;
it is re-derived (not blindly trusted) on every startup via
recheck_on_startup().
"""
import json
import subprocess
import time

from .paths import DATA_DIR

STATE_FILE = DATA_DIR / "state.json"

DEFAULT_STATE = {
    "time_valid": False,
    "time_source": None,  # "ntp" | "manual" | None
    "last_sync": None,    # unix timestamp
}


def _load():
    try:
        with open(STATE_FILE, "r") as f:
            data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        data = {}
    if not isinstance(data, dict):
        data = {}
    merged = dict(DEFAULT_STATE)
    merged.update(data)
    return merged


def _save(state):
    tmp = STATE_FILE.with_suffix(".json.tmp")
    with open(tmp, "w") as f:
        json.dump(state, f, indent=2)
    tmp.replace(STATE_FILE)


def check_ntp_synced() -> bool:
    try:
        result = subprocess.run(
            ["timedatectl", "show", "-p", "NTPSynchronized", "--value"],
            capture_output=True, text=True, timeout=5,
        )
        return result.returncode == 0 and result.stdout.strip() == "yes"
    except Exception:
        return False


def get_state() -> dict:
    return _load()


def mark_time_valid(source: str) -> dict:
    state = _load()
    state["time_valid"] = True
    state["time_source"] = source
    state["last_sync"] = time.time()
    _save(state)
    return state


def mark_time_invalid() -> dict:
    state = _load()
    state["time_valid"] = False
    state["time_source"] = None
    _save(state)
    return state


def reset_to_defaults() -> dict:
    """Used by the Device tab's "Default settings" action - back to
    exactly what a fresh boot with no prior state would look like."""
    _save(dict(DEFAULT_STATE))
    return dict(DEFAULT_STATE)


def recheck_on_startup() -> dict:
    """
    Called once when Flask starts. If NTP has already synced (e.g. wired
    ethernet was up before we even got here), trust it immediately rather
    than showing Demo mode for a few seconds needlessly. Otherwise leave
    time_valid as whatever was last persisted - a previous manual/NTP sync
    still counts unless something actively invalidates it.
    """
    if check_ntp_synced():
        return mark_time_valid("ntp")
    return _load()


def poll() -> dict:
    """Call periodically (e.g. from the socketio background loop)."""
    state = _load()
    if not state["time_valid"] and check_ntp_synced():
        state = mark_time_valid("ntp")
    return state
