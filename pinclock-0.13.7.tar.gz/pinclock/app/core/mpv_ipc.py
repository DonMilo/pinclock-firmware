"""
PinClock - mpv IPC client

Thin wrapper around mpv's JSON IPC unix socket
(https://mpv.io/manual/master/#json-ipc). mpv must be started with
`--input-ipc-server=<SOCKET_PATH>` (see labwc autostart).
"""

import json
import os
import socket

SOCKET_PATH = os.environ.get("PINCLOCK_MPV_SOCKET", "/tmp/mpvsocket")


class MpvIPCError(Exception):
    pass


def _send(command):
    """Send a single JSON IPC command and return mpv's parsed response."""
    if not os.path.exists(SOCKET_PATH):
        raise MpvIPCError(f"mpv socket not found at {SOCKET_PATH}")

    payload = json.dumps({"command": command}) + "\n"

    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as sock:
        sock.settimeout(2.0)
        try:
            sock.connect(SOCKET_PATH)
            sock.sendall(payload.encode("utf-8"))

            # mpv may emit event lines before/interleaved with our reply;
            # read lines until we find one with a "data"/"error" reply.
            buf = b""
            while True:
                chunk = sock.recv(4096)
                if not chunk:
                    break
                buf += chunk
                if b"\n" in buf:
                    for line in buf.split(b"\n"):
                        if not line.strip():
                            continue
                        try:
                            msg = json.loads(line.decode("utf-8"))
                        except json.JSONDecodeError:
                            continue
                        if "error" in msg:
                            return msg
                    buf = b""
        except socket.timeout:
            raise MpvIPCError("mpv IPC timed out")
        except OSError as e:
            raise MpvIPCError(f"mpv IPC connection failed: {e}")

    raise MpvIPCError("mpv IPC returned no response")


def next_video():
    return _send(["playlist-next"])


def prev_video():
    return _send(["playlist-prev"])


def set_property(name, value):
    return _send(["set_property", name, value])


def set_pause(paused):
    return set_property("pause", bool(paused))


def loadfile(path, mode="replace"):
    """
    Load and play a specific file immediately. Raises MpvIPCError if
    mpv rejects the command (e.g. an unsupported mode string on an
    older mpv build) - this used to return whatever mpv sent back
    without checking it, which silently masked failures as apparent
    success (the caller always got a response object, never an
    exception, regardless of whether mpv actually did anything).
    """
    msg = _send(["loadfile", path, mode])
    if msg.get("error") != "success":
        raise MpvIPCError(f"loadfile({path!r}, {mode!r}) failed: {msg}")
    return msg


def play_now(path):
    """
    Plays `path` immediately WITHOUT clearing the rest of the loaded
    playlist - inserts it directly after the current playback
    position, then explicitly commands mpv to jump to it. Two
    separate, long-standing, universally-supported IPC calls
    (loadfile ... insert-next, then playlist-next) rather than relying
    on loadfile's single-shot "insert-next-play" mode flag: that flag
    needs a specific-enough mpv version, and if it's ever unsupported
    the previous approach failed completely silently (see loadfile's
    own docstring). insert-next and playlist-next are both far older,
    more basic commands that are extremely unlikely to ever be missing
    or behave unexpectedly.
    """
    loadfile(path, "insert-next")
    msg = _send(["playlist-next"])
    if msg.get("error") != "success":
        raise MpvIPCError(f"playlist-next (after insert-next) failed: {msg}")
    return msg


def get_property(name):
    """e.g. get_property('filename'), get_property('playlist-pos')"""
    msg = _send(["get_property", name])
    if msg.get("error") != "success":
        raise MpvIPCError(f"get_property({name}) failed: {msg}")
    return msg.get("data")


def current_filename():
    """Return just the filename (no path) of what's currently playing."""
    try:
        return get_property("filename")
    except MpvIPCError:
        return None


def get_status():
    """
    Best-effort snapshot of playback state for the control panel.
    Returns dict matching the shape control.html expects from /api/status.
    """
    try:
        filename = get_property("filename")
        paused = get_property("pause")
        pos = get_property("playlist-pos")
        count = get_property("playlist-count")
        time_pos = get_property("time-pos")
        try:
            width = get_property("width")
            height = get_property("height")
        except MpvIPCError:
            width = height = None
        return {
            "playing": not bool(paused),
            "video": filename,
            "index": pos if pos is not None else 0,
            "count": count if count is not None else 0,
            "time": time_pos,
            "width": width,
            "height": height,
        }
    except MpvIPCError:
        return {
            "playing": False, "video": None, "index": 0, "count": 0,
            "time": None, "width": None, "height": None,
        }


def reload_playlist(playlist_path="/tmp/pinclock-playlist.m3u"):
    """Clear and reload the playlist (used after regenerating it).

    Explicitly sends `stop` before `loadlist ... replace`. The
    "replace" flag is documented to stop playback and swap the list on
    its own, but real-hardware testing showed the CURRENTLY playing
    file kept playing to completion regardless (observed via Clear
    Playlist: it visibly waited for the current video to finish instead
    of cutting immediately) - `stop` is mpv's dedicated "actually stop
    right now" command, so this doesn't rely on `loadlist`'s flag alone
    to do that job.

    See also --idle=yes in autostart's mpv invocation: without it, mpv
    exits entirely once its playlist is empty rather than sitting idle,
    and gets silently respawned a moment later by supervise() - a
    single missing flag that plausibly explained three separate-looking
    symptoms at once: the boot splash logo briefly reappearing (nothing
    painting over it during the respawn gap), the volume resetting to
    mpv's own default of 100 (a fresh process has no memory of the
    IPC-set volume), and this reload not stopping the current video
    reliably (mpv was mid-crash-and-respawn, not just idling).
    """
    _send(["stop"])
    _send(["loadlist", playlist_path, "replace"])
