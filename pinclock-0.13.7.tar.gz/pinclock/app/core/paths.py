"""
PinClock - shared data directory.

Through v0.7.2, settings.json, config.json, state.json, and videos/ all
lived directly inside the app's own directory (pinclock/), each derived
independently as Path(__file__).resolve().parent.parent.parent by
settings_store.py, wifi_manager.py, and system_state.py. That colocation
of app code and user data breaks starting in v0.8.0, which introduces a
release-swap update mechanism (see docs/updates.md): a firmware update
stages a brand new versioned release directory and then repoints
/opt/pinclock/current at it. If settings/WiFi config/videos still lived
inside that versioned directory, every update or factory reset would
strand or wipe them out as a side effect of swapping code - not what
"update the app" or "reset settings" should mean.

DATA_DIR is the fix: a fixed path outside any versioned release
directory, so it survives every future code swap untouched. It only
ever changes via the Device tab's own Default Settings / Factory Reset
actions (which explicitly touch its contents) or a manual purge - never
implicitly as a result of updating code.

IMPORTANT: DATA_DIR must stay on the same filesystem as APP_DIR (both
under /home/vfw on a normal single-partition Pi image) - the migration
below relies on same-filesystem moves being atomic renames rather than
copy+delete, which matters for not corrupting large video files if
power is lost mid-migration.
"""
import json
import shutil
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent.parent.parent  # pinclock/ (versioned app code)
DATA_DIR = Path("/home/vfw/pinclock-data")

# Shipped/demo videos live in a PERSISTENT, non-versioned location -
# deliberately NOT inside APP_DIR/the versioned release tree (an
# earlier version of this design put them there, but that meant every
# update's own release directory carried a full copy of every shipped
# video ever added, and _prune_old_releases keeping the last 3
# releases around for rollback safety meant up to 3x duplication of
# potentially large binary content - a real problem unlike small
# app-code files, where the same duplication costs nothing).
#
# Updates instead bundle new/changed shipped videos in their own
# release tarball under pinclock/shipped-videos/ (still auto-discovered
# by build_release.py, no changes needed there) - but run_update.py
# syncs that content OUT to this persistent directory and strips it
# from the release directory immediately after staging, so the release
# directory that actually sticks around around never carries video
# content at all. See run_update.py's _sync_shipped_videos_and_strip.
#
# Also deliberately never touched by Factory Reset: since the blessed
# factory snapshot never captures this directory (nothing to restore
# from there), a factory reset leaves the accumulated shipped-video set
# exactly as-is - once a video becomes "shipped" (whether from the
# original image or added by a later update), it stays shipped, rather
# than reverting to whatever the original factory image happened to
# include.
SHIPPED_VIDEOS_DIR = Path("/opt/pinclock/shipped-videos")

_LEGACY_ENTRIES = ["settings.json", "config.json", "state.json", "videos"]


def _migrate_legacy_data_dir():
    """
    One-time upgrade path for devices already in the field on v0.7.2 or
    earlier: move settings.json / config.json / state.json / videos/ out
    of APP_DIR and into DATA_DIR.

    Runs at import time (there's no other well-defined "once per upgrade"
    hook in this project's process model) and is cheap to call again
    every subsequent boot: as soon as DATA_DIR exists, this returns
    immediately without touching the filesystem.

    Resumable by design, not just "safe to call twice": if power is lost
    partway through (e.g. mid-move of a large videos/ directory), the
    in-progress work sits in a sibling .migrating directory rather than
    DATA_DIR itself, and the *next* boot picks up wherever the last one
    left off - already-moved entries are detected (dst exists) and
    skipped, remaining ones are moved, and DATA_DIR only comes into
    existence via the final atomic rename once everything is present.
    There is no state where DATA_DIR exists but is only partially
    populated.
    """
    if DATA_DIR.exists():
        return

    tmp_dir = DATA_DIR.with_name(DATA_DIR.name + ".migrating")
    legacy_present = any((APP_DIR / name).exists() for name in _LEGACY_ENTRIES)

    if not legacy_present and not tmp_dir.exists():
        # Fresh install, nothing to migrate - just create an empty DATA_DIR.
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        return

    tmp_dir.mkdir(parents=True, exist_ok=True)

    moved_any = False
    for name in _LEGACY_ENTRIES:
        src = APP_DIR / name
        dst = tmp_dir / name
        if dst.exists():
            continue  # already moved in a previous, interrupted attempt
        if src.exists():
            shutil.move(str(src), str(dst))
            moved_any = True

    tmp_dir.replace(DATA_DIR)  # atomic rename, same filesystem
    if moved_any:
        print(f"[paths] migrated legacy data files from {APP_DIR} to {DATA_DIR}")

    _fixup_migrated_config()


def _fixup_migrated_config():
    """
    A freshly-migrated config.json still has its old videos.path pointing
    at APP_DIR/videos (its pre-v0.8.0 default) - correct it to live under
    DATA_DIR now that videos/ has physically moved there too. Only
    rewrites the value if it still matches the known pre-migration
    default, so a deliberately customized path is left alone.
    """
    config_file = DATA_DIR / "config.json"
    if not config_file.exists():
        return
    try:
        with open(config_file, "r") as f:
            cfg = json.load(f)
    except (json.JSONDecodeError, OSError):
        return

    old_default = str(APP_DIR / "videos")
    videos_cfg = cfg.get("videos") or {}
    if videos_cfg.get("path") == old_default:
        videos_cfg["path"] = str(DATA_DIR / "videos")
        cfg["videos"] = videos_cfg
        tmp = config_file.with_suffix(".json.tmp")
        with open(tmp, "w") as f:
            json.dump(cfg, f, indent=2)
        tmp.replace(config_file)


_migrate_legacy_data_dir()
