"""
PinClock - WiFi management via NetworkManager (nmcli).

Assumes NetworkManager is the active network backend. Works whether
NetworkManager is driving things directly (stock Raspberry Pi OS
Bookworm+) or is itself being configured by netplan (Ubuntu) - in the
netplan case, existing connection profiles are named like
"netplan-wlan0-4242a" rather than after the SSID, so we never assume the
NM connection name equals the SSID; see _active_wifi_ssid() and
connect()/forget() below, which track the real profile name separately.

All state that needs to persist across reboots (whether WiFi has been
configured, the last-known SSID, and the underlying NM profile name)
lives in config.json under the "wifi" key; the actual PSK is never
stored by us - NetworkManager keeps it in its own connection profile
under /etc/NetworkManager/system-connections/, so a lost/corrupted
config.json can't leak or lose credentials we don't otherwise need.

Two nmcli connection profiles matter here:
  - Whatever profile NetworkManager creates/reuses when we call
    `nmcli device wifi connect` (normal client/station mode).
  - HOTSPOT_CON_NAME: an open AP we create on demand so a phone can talk
    to the Pi directly at 10.42.0.1 when no home WiFi is reachable.

IMPORTANT: the WiFi tab's on/off toggle must never call set_radio()
(`nmcli radio wifi off`). That disables the WiFi hardware outright,
taking the setup hotspot down with it, and NetworkManager persists that
"off" state across reboots - so a person turning it off over WiFi
strands themselves with no fallback and no easy recovery (physical
console or an SD-card edit). Use disconnect_to_hotspot() /
reconnect_client() instead, which only ever change which network the
(always-on) radio is associated with.

Every nmcli call goes through a short timeout - this runs in a Flask
request thread and must never hang the settings UI if the WiFi adapter
is in a weird state.
"""
import json
import subprocess
import threading
import time

from .paths import DATA_DIR

CONFIG_FILE = DATA_DIR / "config.json"

WIFI_IFACE = "wlan0"


def _load_hotspot_ssid():
    """
    Per-device hotspot SSID (v0.13.0+), written by
    /opt/pinclock/identity/device_identity.py at boot (before Flask
    starts - see labwc autostart) from the CPU serial. Read once at
    import time here, same as every other module-level constant in this
    file - this module is re-imported fresh on every pinclock.service
    (re)start, which is the same cadence device_identity.py runs at, so
    there's no staleness window in practice.

    Falls back to the old shared "PinClock-Setup" name if the identity
    file is missing (identity script hasn't run yet, failed, or this is
    a dev/sandbox environment without the real boot chain) - degrades to
    pre-v0.13.0 behavior rather than crashing the whole WiFi subsystem
    over it.
    """
    try:
        with open(DATA_DIR / "device_identity.json", "r") as f:
            data = json.load(f)
        ssid = data.get("hotspot_ssid")
        if ssid:
            return ssid
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        pass
    return "PinClock-Setup"


HOTSPOT_SSID = _load_hotspot_ssid()
# The connection profile name and the over-the-air SSID are the same
# string for our own hotspot (unlike a normal client profile - see this
# module's docstring on netplan-managed names) - kept as two separate
# constants anyway since they mean different things to nmcli, and code
# elsewhere already refers to them separately.
HOTSPOT_CON_NAME = HOTSPOT_SSID
HOTSPOT_ADDR = "10.42.0.1/24"

NMCLI_TIMEOUT = 15

# Serializes every nmcli invocation from anywhere in this module. Added
# after a real, reproducible hardware failure: once app.py started
# calling eventlet.monkey_patch() (needed so the app stays responsive
# during nmcli activity - see that file's top-of-file comment), nmcli
# calls could genuinely overlap for the first time - previously,
# blocking calls accidentally serialized everything, which masked
# whatever assumptions NetworkManager/nmcli make about not receiving
# concurrent commands against the same radio. The symptom was directly
# observed: the periodic status broadcaster (app.py's
# _status_broadcaster, firing every 2s) landing mid-flight during
# connect()'s own add/up sequence produced inconsistent, timing-
# dependent failures against the SAME network with the SAME correct
# password - an immediate secrets error on one attempt, a full timeout
# on the next.
#
# This lock restores the "one nmcli call in flight at a time" invariant
# intentionally rather than by accident, without giving up the actual
# benefit of monkey_patch(): callers queued on this lock still block
# only each other, not the rest of the app - unrelated requests (loading
# the settings page, mpv control, anything not touching WiFi) stay
# responsive throughout.
_nmcli_lock = threading.Lock()


class WifiError(Exception):
    pass


def _run(args, timeout=NMCLI_TIMEOUT):
    with _nmcli_lock:
        try:
            result = subprocess.run(
                args, capture_output=True, text=True, timeout=timeout,
            )
            return result
        except FileNotFoundError as e:
            # Was hardcoded to say "nmcli not found" - fine when this was
            # nmcli's only caller, misleading now that kick_hotspot_client()
            # also calls through here for iw. Reference whatever command
            # was actually attempted instead.
            raise WifiError(f"command not found: {args[0]}") from e
        except Exception as e:
            # Deliberately not `except subprocess.TimeoutExpired` here - under
            # app.py's eventlet.monkey_patch() (required for the app to stay
            # responsive during real nmcli activity - see app.py's top-of-file
            # comment), a timed-out subprocess.run() on this exact eventlet
            # version raises a TimeoutExpired that is NOT `is`-identical to
            # the subprocess.TimeoutExpired class visible here, despite
            # sharing the same name and reported module - confirmed via
            # sandbox testing, not a guess. `except subprocess.TimeoutExpired`
            # silently fails to catch it, letting it escape uncaught into
            # whatever called this (in the worst case, permanently killing
            # the status-broadcaster loop in app.py on the very first nmcli
            # timeout). Checking the class NAME instead of catching by class
            # sidesteps the identity mismatch entirely. Anything that isn't
            # actually a timeout still re-raises unchanged, so genuinely
            # unexpected errors aren't silently swallowed.
            if type(e).__name__ == "TimeoutExpired":
                raise WifiError(f"command timed out: {' '.join(args)}") from e
            raise


def _nmcli(*args, timeout=NMCLI_TIMEOUT):
    """
    Runs nmcli via sudo (passwordless, same pattern as /bin/date in
    app.py's /api/time route - see the sudoers snippet in
    sudoers/pinclock-nmcli). Started out relying on polkit rules instead
    (see polkit/50-pinclock-nm.rules), but real-world testing showed that
    covers some NetworkManager actions (radio on/off) but not others
    (adding a connection) without being able to pin down the exact
    action-id mismatch remotely - sudo avoids the guessing game entirely,
    since root bypasses NM's polkit checks altogether.
    """
    result = _run(["sudo", "nmcli", *args], timeout=timeout)
    if result.returncode != 0:
        raise WifiError(result.stderr.strip() or f"nmcli {' '.join(args)} failed")
    return result.stdout


# ------------------------------------------------------------- config -----
def _load_config():
    try:
        with open(CONFIG_FILE, "r") as f:
            data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        data = {}
    if not isinstance(data, dict):
        data = {}
    return data


def _save_config(data):
    tmp = CONFIG_FILE.with_suffix(".json.tmp")
    with open(tmp, "w") as f:
        json.dump(data, f, indent=2)
    tmp.replace(CONFIG_FILE)


def _remember_ssid(ssid, connection_name=None):
    cfg = _load_config()
    cfg.setdefault("wifi", {})
    cfg["wifi"]["configured"] = True
    cfg["wifi"]["ssid"] = ssid
    cfg["wifi"]["connection_name"] = connection_name or ssid
    cfg["wifi"].pop("password", None)  # never persist a plaintext password
    _save_config(cfg)


def get_remembered_ssid():
    cfg = _load_config()
    return (cfg.get("wifi") or {}).get("ssid") or ""


def _get_remembered_connection_name():
    cfg = _load_config()
    wifi_cfg = cfg.get("wifi") or {}
    return wifi_cfg.get("connection_name") or wifi_cfg.get("ssid") or ""


# --------------------------------------------------------------- status ---
def radio_enabled():
    try:
        out = _nmcli("radio", "wifi", timeout=5).strip()
        return out == "enabled"
    except WifiError:
        return False


def _active_wifi_ssid():
    """
    The NM *connection profile name* is not necessarily the SSID - e.g. on
    a netplan-managed system (Ubuntu) it looks like "netplan-wlan0-4242a".
    `nmcli device wifi` always reports the true over-the-air SSID though,
    so use that for anything user-facing.
    """
    try:
        out = _nmcli("-t", "-f", "ACTIVE,SSID", "device", "wifi", timeout=8)
    except WifiError:
        return None
    for line in out.splitlines():
        parts = line.split(":", 1)
        if len(parts) == 2 and parts[0] == "yes":
            return parts[1]
    return None


def get_status():
    """
    Returns:
      {
        "radio_enabled": bool,
        "connected": bool,       # associated with a real AP (not our own hotspot)
        "ssid": str | None,      # currently associated SSID
        "connection_name": str | None,  # underlying NM profile name (may differ from ssid)
        "ip": str | None,
        "hotspot_active": bool,  # our own fallback AP is up
      }
    """
    enabled = radio_enabled()
    status = {
        "radio_enabled": enabled,
        "connected": False,
        "ssid": None,
        "connection_name": None,
        "ip": None,
        "hotspot_active": False,
    }
    if not enabled:
        return status

    try:
        out = _nmcli(
            "-t", "-f", "DEVICE,TYPE,STATE,CONNECTION", "device", "status", timeout=8
        )
    except WifiError:
        return status

    wifi_line = None
    for line in out.splitlines():
        parts = line.split(":")
        if len(parts) >= 4 and parts[0] == WIFI_IFACE and parts[1] == "wifi":
            wifi_line = parts
            break

    if not wifi_line:
        return status

    state, con_name = wifi_line[2], wifi_line[3]

    if con_name == HOTSPOT_CON_NAME and "connected" in state:
        status["hotspot_active"] = True
        status["ip"] = HOTSPOT_ADDR.split("/")[0]
        return status

    if "connected" in state and con_name and con_name != "--":
        status["connected"] = True
        status["connection_name"] = con_name
        status["ssid"] = _active_wifi_ssid() or con_name
        try:
            ip_out = _nmcli(
                "-g", "IP4.ADDRESS", "device", "show", WIFI_IFACE, timeout=5
            ).strip()
            status["ip"] = ip_out.split("/")[0].splitlines()[0] if ip_out else None
        except WifiError:
            pass

    return status


# -------------------------------------------------------------- connect ---
def _up_with_retry(con_name, attempts=3, delay=1.0):
    """
    A freshly-added profile's secrets aren't always immediately visible
    to NetworkManager's settings service by the time `connection up`
    fires right after `connection add` - confirmed directly on hardware:
    the very first activation attempt against a brand-new profile can
    fail with "no secrets: No agent..." even though the password stored
    in that exact profile (same UUID, nothing changed) is correct, and a
    near-immediate retry against that same profile succeeds cleanly.

    A short retry loop rather than a fixed pre-emptive delay before the
    first attempt, since the exact timing isn't guaranteed either way -
    and this still fails at roughly the normal speed if the password
    genuinely is wrong, since a real auth failure repeats identically on
    every retry rather than self-resolving; the only added cost in that
    case is a couple of seconds before the (still correct) failure is
    reported.
    """
    last_error = None
    for attempt in range(attempts):
        try:
            _nmcli("connection", "up", con_name, timeout=30)
            return
        except WifiError as e:
            last_error = e
            if attempt < attempts - 1:
                time.sleep(delay)
    raise last_error


def connect(ssid, password):
    """
    Tear down our setup hotspot (if any) and connect to a real WiFi network.
    Returns (ok: bool, message: str).

    Builds the connection profile explicitly (connection add + up) rather
    than using `nmcli device wifi connect ssid password ...`. That
    shortcut infers the security type (key-mgmt) from the AP's entry in
    NetworkManager's WiFi scan cache - if that entry is stale, missing, or
    the AP just isn't in range of the last scan, it can create a profile
    with a password set but no key-mgmt, which NetworkManager then
    rejects with "802-11-wireless-security.key-mgmt: property is
    missing". Setting key-mgmt explicitly sidesteps that entirely.

    The new profile is built under a distinct working name
    ("<ssid>-pinclock-pending") rather than reusing/deleting any existing
    profile for this ssid up front. This module already treats the NM
    connection-profile name as independent of the ssid anyway (see
    _active_wifi_ssid()'s docstring), so nothing downstream assumes they
    match - the only real change here is WHEN a same-named stale profile
    gets cleaned up: after the new one is confirmed working, never
    before.

    Doing it before was a real, confirmed-on-hardware bug: if the ssid
    being (re)connected to is the SAME network currently providing the
    device's only network path, deleting its profile immediately tore
    that working connection down - and if the new attempt then failed
    (wrong password, timeout, anything), there was nothing left to fall
    back to: no old profile (deleted), no hotspot (never restored,
    teardown_hotspot() only ever runs at the start). Reproduced directly:
    reconnecting to the currently-active network with a wrong password
    left the device with no network path at all, recoverable only by a
    physical reboot - not even SSH worked.

    This project already hit and fixed this exact class of bug once
    before, for disconnect_to_hotspot() (see its docstring: "reconnects
    to the known-good network automatically rather than leaving the
    device on neither network - which is exactly what happened during
    testing before this existed"). connect() just never got the same
    treatment until now - see _recover_after_failed_connect() below,
    which mirrors that same pattern.
    """
    if not ssid:
        return False, "SSID is required"

    prior_status = get_status()
    prior_con_name = prior_status.get("connection_name")
    was_connected = prior_status.get("connected") and not prior_status.get("hotspot_active")

    teardown_hotspot()

    work_con_name = f"{ssid}-pinclock-pending"
    try:
        _nmcli("connection", "delete", work_con_name, timeout=8)
    except WifiError:
        pass  # fine if there wasn't one - e.g. a leftover from an earlier failed attempt

    add_args = [
        "connection", "add",
        "type", "wifi",
        "con-name", work_con_name,
        "ifname", WIFI_IFACE,
        "ssid", ssid,
    ]
    if password:
        # wpa-psk covers WPA/WPA2-Personal, which is what the overwhelming
        # majority of home networks use. A WPA3-only ("sae") network would
        # need a different key-mgmt value here - not handled yet.
        #
        # psk-flags 0 explicitly marks the secret as "stored in the
        # connection file" (NetworkManager's default assumption otherwise
        # can end up treating it as "ask an agent for this each time" -
        # which there is no agent for here - producing "Secrets were
        # required, but not provided" on activation even though a psk
        # value was given at creation time).
        add_args += [
            "wifi-sec.key-mgmt", "wpa-psk",
            "wifi-sec.psk", password,
            "wifi-sec.psk-flags", "0",
        ]

    try:
        _nmcli(*add_args, timeout=15)
        _up_with_retry(work_con_name)
    except WifiError as e:
        # Clean up the half-created/failed new profile - the OLD profile
        # (if any) was never touched, so it's still there for
        # _recover_after_failed_connect() to fall back to.
        try:
            _nmcli("connection", "delete", work_con_name, timeout=8)
        except WifiError:
            pass
        return False, _recover_after_failed_connect(str(e), prior_con_name, was_connected)

    # New connection confirmed working - now it's safe to remove whatever
    # profile this exact ssid had before, if any, rather than
    # accumulating a duplicate. Deliberately targets a profile literally
    # named `ssid` (what a normal prior connect() call would have left
    # behind), NOT prior_con_name in general - prior_con_name could be a
    # different, unrelated network the device simply switched away from,
    # and must not be deleted just because it's no longer active.
    try:
        _nmcli("connection", "delete", ssid, timeout=8)
    except WifiError:
        pass

    status = get_status()
    _remember_ssid(ssid, status.get("connection_name") or work_con_name)
    return True, "connected"


def _recover_after_failed_connect(error_message, prior_con_name, was_connected):
    """
    Never leave the device with no network path at all after a failed
    connect() - reconnect to whatever was working before if possible,
    falling back to the setup hotspot otherwise. See connect()'s
    docstring for the real incident this fixes.
    """
    if prior_con_name and was_connected:
        try:
            _nmcli("connection", "up", prior_con_name, timeout=30)
            return f"{error_message} (reconnected to your previous network)"
        except WifiError:
            pass

    try:
        ensure_hotspot()
        return f"{error_message} (setup hotspot restored so you can try again)"
    except WifiError:
        pass

    return (
        f"{error_message} (could not restore any network connection - "
        f"the device may be unreachable until it's rebooted)"
    )





def set_radio(enabled: bool):
    """
    !! DO NOT wire this to any user-facing API route. !!

    `nmcli radio wifi off` disables the WiFi hardware entirely - which
    also takes down our own setup hotspot, since it needs the same radio.
    Worse, NetworkManager persists that "off" state to disk
    (NetworkManager.state), so it survives a reboot too. If the person
    calling this is themselves connected over WiFi (the normal way to
    reach the settings page), this cuts their own access with no
    fallback - recovering means physical console access or editing the
    SD card's NetworkManager.state by hand. This is exactly what
    happened during testing of an earlier version of this toggle.

    Kept only for interactive debugging over a wired/console session
    where you can see the consequences directly. The WiFi tab's "off"
    behavior is disconnect_to_hotspot() below instead, which keeps the
    radio on and always leaves 10.42.0.1 reachable.
    """
    try:
        _nmcli("radio", "wifi", "on" if enabled else "off", timeout=10)
    except WifiError as e:
        return False, str(e)
    return True, "ok"


def disconnect_to_hotspot():
    """
    What the WiFi tab's toggle actually calls for "off": disconnect from
    whatever home network is active and bring up the PinClock-Setup
    hotspot instead. The radio itself is never disabled, so 10.42.0.1
    should always stay reachable - this is the safe alternative to
    set_radio().

    Returns (ok: bool, message: str). On most single-radio WiFi hardware
    (including the Pi Zero's onboard chip) the radio can be a client OR
    an access point, never both - so bringing the hotspot up necessarily
    means bringing the client connection down first, and there's a real
    chance the hotspot then fails to come up for its own reasons (driver
    limitations, an unset WiFi regulatory/country code blocking AP mode,
    etc). If that happens, this reconnects to the known-good network
    automatically rather than leaving the device on neither network -
    which is exactly what happened during testing before this existed.
    """
    status = get_status()
    con_name = status.get("connection_name")
    was_connected = status.get("connected") and not status.get("hotspot_active")

    if con_name and was_connected:
        try:
            _nmcli("connection", "down", con_name, timeout=15)
        except WifiError:
            pass

    try:
        ensure_hotspot()
    except WifiError as e:
        # Hotspot didn't come up - reconnect to the known-good network
        # rather than stranding the device with nothing active.
        if con_name and was_connected:
            try:
                _nmcli("connection", "up", con_name, timeout=30)
            except WifiError:
                pass
        return False, f"Setup hotspot failed to start ({e}); reconnected to your network instead."

    return True, "ok"


def reconnect_client():
    """
    What the WiFi tab's toggle calls for "on": tear down the setup
    hotspot and reconnect to whatever network was last remembered.

    Real hardware bug fixed here (2026-08): this used to trust
    config.json's stored connection_name literally and call `nmcli
    connection up <that name>` directly. If that exact PROFILE no
    longer exists - e.g. it was recreated under a different name, like
    the manual nmcli-based recovery flow used elsewhere in this project
    (which lands on a profile such as "4242a-manual", unrelated to
    whatever connect() or config.json originally called it) - that call
    just fails outright. Worse: teardown_hotspot() had ALREADY run
    unconditionally by that point, so a failed reconnect left the
    device with NEITHER the hotspot NOR a real network up - confirmed
    on real hardware, where NetworkManager's own autoconnect eventually
    (and non-deterministically - it could just as easily have picked
    the hotspot back up, or picked nothing for a while) settled on the
    right profile purely by luck, not because of anything this function
    actually did.

    Now:
      1. If the exact remembered connection_name doesn't currently
         exist, falls back to searching by SSID instead - the SSID is
         far more likely to still be accurate than a profile's internal
         name, which can silently drift however the connection was
         actually made (this app's own connect() flow vs. a manual
         nmcli command vs. netplan).
      2. On a successful SSID-fallback match, re-saves config.json with
         the CURRENT correct profile name via _remember_ssid() - self-
         heals the stale record so future calls don't need the fallback
         search again.
      3. If nothing at all can be found/brought up, explicitly restores
         the hotspot rather than leaving the outcome to NetworkManager's
         own autoconnect timing - same safety-net pattern
         disconnect_to_hotspot() already uses for ITS failure case, now
         applied here too.

    Returns (ok, message) - ok is True even if there's nothing to
    reconnect to (that's not an error, just nothing to do).
    """
    con_name = _get_remembered_connection_name()
    ssid = get_remembered_ssid()

    try:
        existing = _nmcli("-t", "-f", "NAME", "connection", "show", timeout=8).splitlines()
    except WifiError:
        existing = []

    target = con_name if con_name and con_name in existing else None

    if target is None and ssid:
        # Fall back to matching by SSID - find any wifi profile whose
        # actual over-the-air SSID matches, regardless of what its NM
        # profile name happens to be.
        try:
            out = _nmcli("-t", "-f", "NAME,TYPE", "connection", "show", timeout=8)
        except WifiError:
            out = ""
        for line in out.splitlines():
            parts = line.rsplit(":", 1)
            if len(parts) != 2:
                continue
            name, con_type = parts
            if con_type != "wifi" or name == HOTSPOT_CON_NAME:
                continue
            try:
                actual_ssid = _nmcli("-g", "802-11-wireless.ssid", "connection", "show", name, timeout=5).strip()
            except WifiError:
                continue
            if actual_ssid == ssid:
                target = name
                break
        if target:
            _remember_ssid(ssid, target)  # self-heal the stale record

    if target is None:
        # Genuinely nothing to reconnect to - same "ok, just nothing to
        # do" convention as before. Don't touch the hotspot in this
        # case at all; there was nothing to tear it down FOR.
        return True, "no remembered network found to reconnect to"

    teardown_hotspot()
    try:
        _nmcli("connection", "up", target, timeout=30)
    except WifiError as e:
        # Don't leave the device on NOTHING - restore the hotspot
        # explicitly rather than trusting NetworkManager's own
        # autoconnect to sort it out eventually (confirmed on real
        # hardware: it can, but not promptly or deterministically).
        try:
            ensure_hotspot()
        except WifiError:
            pass
        return False, f"couldn't reconnect to {target}: {e}"

    return True, "ok"


def forget():
    """
    Remove every WiFi connection profile except our own setup hotspot -
    not just whichever one config.json happens to remember.

    That bookkeeping can go stale, or simply never get populated at all:
    a profile created by the Pi's initial imaging tool, or reconnected
    by hand over SSH (`nmcli device wifi connect ...` directly, bypassing
    this app entirely - both of which happened during testing), never
    touches config.json. Relying on it alone meant "Default settings"
    reset our own record but left the actual NetworkManager profile
    completely intact, autoconnect and all - it just reconnected on the
    very next reboot as if nothing had happened. Enumerating NM's actual
    connection list directly (same approach as
    scripts/prepare_for_shipping.sh) doesn't have that blind spot.

    Returns (ok: bool, message: str) - ok is False if *any* profile
    failed to delete, with the specific failures named, rather than
    silently reporting success regardless of what actually happened.
    """
    try:
        out = _nmcli("-t", "-f", "NAME,TYPE", "connection", "show", timeout=10)
    except WifiError as e:
        cfg = _load_config()
        cfg.setdefault("wifi", {})
        cfg["wifi"]["configured"] = False
        cfg["wifi"]["ssid"] = ""
        cfg["wifi"]["connection_name"] = ""
        _save_config(cfg)
        return False, f"couldn't list connections: {e}"

    failures = []
    deleted = []
    for line in out.splitlines():
        # NAME can itself contain ":" (rare, but SSIDs allow it) - TYPE
        # never does, so split from the right to keep NAME intact.
        parts = line.rsplit(":", 1)
        if len(parts) != 2:
            continue
        name, con_type = parts
        if con_type == "wifi" and name != HOTSPOT_CON_NAME:
            try:
                _nmcli("connection", "delete", name, timeout=10)
                deleted.append(name)
            except WifiError as e:
                failures.append(f"{name}: {e}")

    cfg = _load_config()
    cfg.setdefault("wifi", {})
    cfg["wifi"]["configured"] = False
    cfg["wifi"]["ssid"] = ""
    cfg["wifi"]["connection_name"] = ""
    _save_config(cfg)

    if failures:
        return False, "Failed to remove: " + "; ".join(failures)
    if not deleted:
        return True, "no saved networks to forget"
    return True, f"removed {', '.join(deleted)}"


def kick_hotspot_client(client_ip):
    """
    Disconnects ONE specific client (identified by its own IP on the
    10.42.0.0/24 hotspot subnet) from this device's setup hotspot,
    WITHOUT touching the hotspot itself - it keeps running afterward,
    ready for the next device. Used by the settings page's idle-timeout
    and "Disconnect now" button (see app.py's /api/wifi/exit-hotspot) so
    a phone that's done with setup, or just left idle, can fall off the
    hotspot and let its own OS auto-reconnect to its known network.

    This is deliberately NOT built on disconnect_to_hotspot()/
    reconnect_client() (which tear down and rebuild the Pi's OWN network
    state) - an earlier design that used reconnect_client() for this had
    a real stranding risk: on a device with no remembered network yet
    (true first-time setup), reconnect_client() tears the hotspot down
    and has nothing to bring back up, leaving the device on NEITHER
    network with no automatic recovery path - same failure class as the
    old WiFi profile-deletion bug in connect(). Operating at the
    kernel/driver level via `iw ... station del` instead sidesteps that
    entirely: the AP's own state is never touched, so there's nothing to
    strand.

    Uses `iw dev <iface> station del <mac>` (direct nl80211/kernel driver
    command) rather than reaching into whatever's actually managing the
    AP under the hood (hostapd vs. wpa_supplicant's own AP mode varies by
    NetworkManager version/build) - iw operates one layer below either of
    those, so it works regardless of which one NM is actually using here.

    NOT yet confirmed on real hardware whether `iw` is installed on this
    image - untested in sandbox for the same reason `iw`'s actual effect
    on a real associated client can't be simulated there either (no real
    wireless stack in the sandbox). Verify with `which iw` before relying
    on this.

    Returns (ok: bool, message: str). Returns ok=True (nothing to do,
    not an error) if the hotspot isn't even active, or if the client's
    MAC can't be resolved (it may have already disconnected on its own
    by the time this runs) - mirrors reconnect_client()'s "ok even if
    there was nothing to do" convention elsewhere in this file.
    """
    status = get_status()
    if not status.get("hotspot_active"):
        return True, "hotspot not active - nothing to disconnect"

    try:
        neigh_out = _run(["ip", "neighbor", "show", client_ip, "dev", WIFI_IFACE], timeout=5).stdout
    except WifiError as e:
        return True, f"couldn't look up client - assuming already gone ({e})"

    mac = None
    tokens = neigh_out.split()
    if "lladdr" in tokens:
        mac = tokens[tokens.index("lladdr") + 1]

    if not mac:
        return True, "client not found in the neighbor table - likely already disconnected"

    try:
        result = _run(["sudo", "/usr/sbin/iw", "dev", WIFI_IFACE, "station", "del", mac], timeout=10)
    except WifiError as e:
        return False, str(e)

    if result.returncode != 0:
        # Report this as a REAL failure rather than assuming "already
        # gone" - an earlier version of this function swallowed every
        # nonzero return here as a benign no-op, which silently hid
        # genuine problems (iw missing, wrong path, permission denied,
        # wrong interface name) behind a falsely reassuring "success"
        # message - exactly the kind of silent-patch-around this
        # project's testing philosophy warns against. Surfacing the
        # real stderr is what makes a failure like this diagnosable
        # (e.g. "iw: command not found" clearly points at needing
        # `sudo apt install iw`) instead of just mysteriously not
        # working with no trace of why.
        return False, f"iw failed (exit {result.returncode}): {result.stderr.strip() or '(no output)'}"

    return True, "disconnected"


# ---------------------------------------------------------------- scan ---
def scan_networks(rescan=True):
    """
    Returns a deduplicated, signal-sorted list of nearby networks:
      [{"ssid": str, "signal": int, "secure": bool}, ...]

    Hidden networks (blank SSID) are skipped - there's nothing useful to
    show or click on for those; a user with a hidden network still types
    the SSID in by hand, which the form supports either way.

    `rescan=True` asks the WiFi adapter to actively scan first (takes a
    couple seconds); `rescan=False` just reads NetworkManager's existing
    cache, which is instant but can be stale/empty right after boot.
    """
    args = ["-t", "-f", "SSID,SIGNAL,SECURITY", "device", "wifi", "list"]
    if rescan:
        args += ["--rescan", "yes"]

    try:
        out = _nmcli(*args, timeout=20 if rescan else 8)
    except WifiError:
        return []

    best = {}
    for line in out.splitlines():
        # SSID can't contain a literal ":" once nmcli escapes it, but it
        # can be empty (hidden network) - split from the right so a
        # SIGNAL/SECURITY pair we can always trust is intact.
        parts = line.rsplit(":", 2)
        if len(parts) != 3:
            continue
        ssid, signal_str, security = parts
        ssid = ssid.strip()
        if not ssid:
            continue
        try:
            signal = int(signal_str)
        except ValueError:
            signal = 0
        secure = bool(security.strip())

        existing = best.get(ssid)
        if existing is None or signal > existing["signal"]:
            best[ssid] = {"ssid": ssid, "signal": signal, "secure": secure}

    return sorted(best.values(), key=lambda n: n["signal"], reverse=True)


def _system_dnsmasq_conflict():
    """
    True if a separate, systemd-managed 'dnsmasq.service' is currently
    running. NetworkManager's own hotspot-mode DHCP server is a private
    dnsmasq instance it spawns directly (not a systemd unit), so this
    specifically detects the *other*, independent one - which is what
    conflicted with the hotspot during testing (both trying to bind
    10.42.0.1:53/67).
    """
    try:
        result = subprocess.run(
            ["systemctl", "is-active", "dnsmasq"],
            capture_output=True, text=True, timeout=5,
        )
        return result.stdout.strip() == "active"
    except Exception:
        return False


def _hotspot_exists():
    try:
        out = _nmcli("-t", "-f", "NAME", "connection", "show", timeout=8)
    except WifiError:
        return False
    return HOTSPOT_CON_NAME in out.splitlines()


def ensure_hotspot():
    """
    Bring up the PinClock-Setup open AP at 10.42.0.1 so a phone can reach
    the control page directly when no home WiFi is available.

    Always deletes and recreates the profile rather than reusing an
    existing one by that name. A prior version of this function set
    "wifi-sec.key-mgmt none" trying to mean "open network" - which in
    NetworkManager's model actually means WEP, producing a profile that
    then had no WEP key and refused to activate ("password for
    '802-11-wireless-security.wep-key0' not given"). Reusing-if-exists
    meant that broken profile kept getting silently reused across
    restarts even after the bug causing it was fixed, since "does a
    profile named PinClock-Setup exist" was the only check - the fix
    changed what a *newly created* profile looks like, but did nothing
    for one already sitting in NetworkManager's connection store. Always
    recreating avoids that whole class of "stale profile from an earlier
    bug" problem, at the cost of a couple of extra nmcli calls each time
    - this isn't a hot path.
    """
    if _hotspot_exists():
        try:
            _nmcli("connection", "delete", HOTSPOT_CON_NAME, timeout=10)
        except WifiError:
            pass

    _nmcli(
        "connection", "add",
        "type", "wifi",
        "ifname", WIFI_IFACE,
        "con-name", HOTSPOT_CON_NAME,
        "autoconnect", "yes",
        "ssid", HOTSPOT_SSID,
        "mode", "ap",
        "ipv4.method", "shared",
        "ipv4.addresses", HOTSPOT_ADDR,
        timeout=15,
    )
    try:
        _nmcli("connection", "up", HOTSPOT_CON_NAME, timeout=20)
    except WifiError as e:
        # A system-wide dnsmasq.service (distinct from the private
        # instance NetworkManager's own "ipv4.method shared" spawns
        # internally for the hotspot) binding port 53/67 first is a
        # real failure mode that came up during testing: the AP itself
        # comes up fine, WiFi association succeeds, but no DHCP leases
        # are ever handed out, so nothing that joins can reach
        # 10.42.0.1. Surfacing this directly saves re-running the whole
        # SSH/journalctl diagnostic chain if it happens again.
        if _system_dnsmasq_conflict():
            e = WifiError(
                f"{e} Hint: a separate system 'dnsmasq' service is already running and is "
                f"likely blocking the hotspot's own DHCP server from binding 10.42.0.1 - "
                f"if you don't need it for anything else, "
                f"'sudo systemctl disable --now dnsmasq' resolves this."
            )
        raise e


def teardown_hotspot():
    if _hotspot_exists():
        try:
            _nmcli("connection", "down", HOTSPOT_CON_NAME, timeout=10)
        except WifiError:
            pass
