
// ===============================
// PinClock - Title bar + ticker
//
// DOM/CSS only (TrueType text, no dot-matrix, no canvas) - see
// pinclock-ticker-titlebar-design.md. The clock canvas is completely
// untouched by this file; it only sets styles/text on the two fixed
// <div> strips and exposes getBarInsets() so renderer.js can keep the
// clock out of these reserved bands.
// ===============================

// Fixed height band derived from configured font size (not measured at
// runtime) - cheap, static, and avoids reflow-triggering measurement
// code running on every settings change.
const BAR_HEIGHT_MULTIPLIER = 1.6;

function barHeight(fontSize) {
    return Math.round((fontSize || 0) * BAR_HEIGHT_MULTIPLIER);
}

function hexToRgbBars(hex) {
    const h = (hex || "#000000").replace("#", "");
    return [
        parseInt(h.substring(0, 2), 16) || 0,
        parseInt(h.substring(2, 4), 16) || 0,
        parseInt(h.substring(4, 6), 16) || 0,
    ];
}

function rgbaCss(hex, opacityPct) {
    const [r, g, b] = hexToRgbBars(hex);
    const a = Math.max(0, Math.min(100, opacityPct !== undefined ? opacityPct : 100)) / 100;
    return `rgba(${r},${g},${b},${a})`;
}

/**
 * Exclusion-band insets for the clock's positioning logic. Unconditional
 * reserved zones, not something the clock dodges dynamically - the clock
 * simply treats the usable area as `H - top - bottom`.
 */
function getBarInsets(settings) {
    return {
        top: settings.title_enabled ? barHeight(settings.title_font_size) : 0,
        bottom: settings.ticker_enabled ? barHeight(settings.ticker_font_size) : 0,
    };
}

// -------------------------------------------------------------- title ----
function updateTitleBar(settings) {
    const el = document.getElementById("titlebar");
    if (!el) return;

    if (!settings.title_enabled) {
        el.style.display = "none";
        return;
    }

    const h = barHeight(settings.title_font_size);
    el.style.display = "flex";
    el.style.height = h + "px";
    el.style.fontSize = (settings.title_font_size || 28) + "px";
    el.style.color = settings.title_color || "#ffffff";
    el.style.justifyContent =
        settings.title_align === "left" ? "flex-start" :
        settings.title_align === "right" ? "flex-end" : "center";
    el.style.padding = "0 16px";

    el.style.background = settings.title_bg_enabled
        ? rgbaCss(settings.title_bg_color, settings.title_bg_opacity)
        : "transparent";

    if (settings.title_border_enabled) {
        el.style.borderBottom = `${settings.title_border_width || 2}px solid ${settings.title_border_color || "#ffffff"}`;
    } else {
        el.style.borderBottom = "none";
    }

    if (el.textContent !== settings.title_text) {
        el.textContent = settings.title_text || "";
    }
}

// ------------------------------------------------------------- ticker ----
// Track the last-applied "signature" so the scroll animation is only
// rebuilt when something that actually changes its geometry/timing
// changes - not on every settings push (e.g. unrelated clock settings).
let _tickerSignature = null;
let _tickerStyleEl = null;

function tickerSignature(settings, trackWidth) {
    return [
        settings.ticker_text,
        settings.ticker_font_size,
        settings.ticker_speed,
        settings.ticker_direction,
        trackWidth,
    ].join("|");
}

function updateTicker(settings, opts) {
    const track = document.getElementById("ticker-track");
    const content = document.getElementById("ticker-content");
    if (!track || !content) return;

    if (!settings.ticker_enabled) {
        track.style.display = "none";
        _tickerSignature = null;
        return;
    }

    const h = barHeight(settings.ticker_font_size);
    track.style.display = "block";
    track.style.height = h + "px";
    track.style.background = settings.ticker_bg_enabled
        ? rgbaCss(settings.ticker_bg_color, settings.ticker_bg_opacity)
        : "transparent";

    if (settings.ticker_border_enabled) {
        track.style.borderTop = `${settings.ticker_border_width || 2}px solid ${settings.ticker_border_color || "#ffffff"}`;
    } else {
        track.style.borderTop = "none";
    }

    content.style.fontSize = (settings.ticker_font_size || 32) + "px";
    content.style.color = settings.ticker_color || "#ffffff";

    if (content.textContent !== settings.ticker_text) {
        content.textContent = settings.ticker_text || "";
    }

    const trackWidth = track.offsetWidth;
    const sig = tickerSignature(settings, trackWidth);
    // Same dedup either way (once-mode or not): if nothing that affects
    // the actual scroll changed - including the text itself - leave an
    // in-flight animation completely alone. This is what protects a
    // one-shot now-playing scroll from being restarted or converted to
    // a different iteration count by an unrelated applyBarSettings()
    // call (an unrelated settings change, a resize, etc.) arriving
    // mid-scroll - see applyBarSettings()'s comment in display.js for
    // why every call passes the same opts.once consistently while a
    // scroll is active.
    if (sig === _tickerSignature) return;
    _tickerSignature = sig;

    restartTickerAnimation(settings, track, content, trackWidth, opts);
}

// Tracks the one-shot scroll's own listener so a rebuild (e.g. from a
// window resize mid-scroll) removes the stale one first - otherwise an
// interrupted animation (canceled via "animation: none", not completed)
// never fires "animationend" on its own, and each rebuild would pile up
// another listener that fires - all of them - the next time any
// animation on this element does complete.
let _tickerOnceHandler = null;

function restartTickerAnimation(settings, track, content, trackWidth, opts) {
    opts = opts || {};

    // Reset transform before measuring so scrollWidth isn't skewed by an
    // in-flight translation from the previous animation.
    content.style.animation = "none";
    content.style.transform = "translateX(0)";

    const contentWidth = content.scrollWidth;
    const speed = Math.max(1, settings.ticker_speed || 80); // px/sec
    const totalDistance = trackWidth + contentWidth;
    const durationSec = totalDistance / speed;

    const rtl = settings.ticker_direction !== "ltr";
    const startX = rtl ? trackWidth : -contentWidth;
    const endX = rtl ? -contentWidth : trackWidth;

    if (!_tickerStyleEl) {
        _tickerStyleEl = document.createElement("style");
        document.head.appendChild(_tickerStyleEl);
    }
    _tickerStyleEl.textContent = `
      @keyframes ticker-scroll {
        from { transform: translateX(${startX}px); }
        to   { transform: translateX(${endX}px); }
      }
    `;

    // Force reflow so the browser picks up the "animation: none" reset
    // before the new animation is applied.
    void content.offsetWidth;

    if (_tickerOnceHandler) {
        content.removeEventListener("animationend", _tickerOnceHandler);
        _tickerOnceHandler = null;
    }

    if (opts.once) {
        // A single pass, timed to actually finish crossing the screen
        // (not a guessed fixed duration) - see triggerNowPlayingOnTicker()
        // in display.js. "animationend" tells us exactly when that
        // happens, so the revert never fires early (cutting the scroll
        // off) or late (leaving a finished scroll's text hanging).
        content.style.animation = `ticker-scroll ${durationSec}s linear 1`;
        const handler = () => {
            content.removeEventListener("animationend", handler);
            _tickerOnceHandler = null;
            if (opts.onComplete) opts.onComplete();
        };
        _tickerOnceHandler = handler;
        content.addEventListener("animationend", handler);
    } else {
        content.style.animation = `ticker-scroll ${durationSec}s linear infinite`;
    }
}

// Track width (not just text/speed) affects the animation, so re-derive it
// on resize too - debounced, since this only needs to happen occasionally,
// not every frame. Takes the whole update function (not just a settings
// getter) so a resize mid-scroll goes through applyBarSettings() in
// display.js - which is what threads the once-mode opts through
// consistently while a now-playing ticker scroll is active. Calling
// updateTicker() directly here would drop that.
let _barsResizeTimer = null;
function scheduleBarsResize(runUpdate) {
    clearTimeout(_barsResizeTimer);
    _barsResizeTimer = setTimeout(() => {
        _tickerSignature = null; // force rebuild against new track width
        runUpdate();
    }, 200);
}
