
// ===============================
// PinClock - Clock / date text helpers
// ===============================

const WEEKDAYS = ["SUNDAY", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"];
const MONTHS = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];

/**
 * Returns:
 *   displayStr - "12:34:56" or "23:34:56" (no AM/PM baked in), or
 *                "12:34"/"23:34" when showSeconds is false
 *   ampm       - "AM"/"PM" or "" for 24h. Full words - see renderer.js
 *                for how these get sized/positioned (smaller, for the
 *                truetype clock style specifically).
 *   minuteKey  - stable per-minute key used to trigger transitions
 *   now        - Date object
 */
function getCurrentTime(format, showSeconds) {
    const now = new Date();
    let hour = now.getHours();
    let ampm = "";

    if (format === "12h") {
        ampm = hour < 12 ? "AM" : "PM";
        hour = hour % 12;
        if (hour === 0) hour = 12;
    }

    const hh = String(hour).padStart(2, "0");
    const mm = String(now.getMinutes()).padStart(2, "0");
    const ss = String(now.getSeconds()).padStart(2, "0");

    // Default to showing seconds unless explicitly turned off - undefined
    // (old settings.json predating this option, or a stripped-down test
    // settings object) should behave exactly like it always has.
    const displayStr = showSeconds === false ? `${hh}:${mm}` : `${hh}:${mm}:${ss}`;
    // minuteKey is intentionally still second-independent regardless of
    // showSeconds - it drives per-minute transitions, not per-second ones.
    const minuteKey = `${hh}:${mm}${ampm}`;

    return { displayStr, ampm, minuteKey, now };
}

function getDateString(now) {
    return `${WEEKDAYS[now.getDay()]}  ${MONTHS[now.getMonth()]} ${now.getDate()}`;
}
