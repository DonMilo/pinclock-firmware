
// ===============================
// PinClock - Main display loop
// ===============================

// Version string is now sourced from systemStatus.version (fetched from
// /api/system/status) rather than hardcoded here - see PINCLOCK_VERSION
// in app.py for the single source of truth.

const canvas = document.getElementById("display");
const ctx = canvas.getContext("2d");

// -- video filename decoding (Manufacturer_GameName.mp4 -> "Game Name
// (Manufacturer)") -----------------------------------------------------
// Used for the "now playing" title-bar banner below. control.html has
// its own copy for the My Videos/Stock/Playlist lists and the Now
// Playing card - two separate JS execution contexts (this kiosk display
// page vs. the phone/browser control panel), so it's duplicated rather
// than shared, same as SHIPPED_VIDEOS_DIR between gen_playlist.py and
// paths.py elsewhere in this project. Keep the two copies in sync if
// this logic ever changes.
const MANUFACTURER_NAMES = {
    Capcom: "Capcom", DE: "Data East", Gtb: "Gottlieb",
    Sega: "Sega", Stn: "Stern", Wpc: "Williams",
};
function splitWords(s) {
    return s
        .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
        .replace(/([A-Za-z])([0-9])/g, "$1 $2");
}
function decodeVideoName(filename) {
    const base = String(filename || "").replace(/\.[^.]+$/, "");
    const idx = base.indexOf("_");
    if (idx !== -1) {
        const mfgCode = base.slice(0, idx);
        const gameCode = base.slice(idx + 1);
        if (Object.prototype.hasOwnProperty.call(MANUFACTURER_NAMES, mfgCode) && gameCode) {
            return splitWords(gameCode) + " (" + MANUFACTURER_NAMES[mfgCode] + ")";
        }
    }
    return splitWords(base.replace(/_/g, " ")).trim();
}

/**
 * Use the actual viewport size, not screen.width/height - screen reflects
 * the full physical monitor resolution, which is wrong whenever the page
 * isn't truly filling the display (a normal browser window, DevTools docked
 * and shrinking the viewport, etc). That mismatch is what caused bottom
 * positions to render past the visible viewport and get clipped by
 * overflow:hidden, while top positions (near y=0) still appeared fine.
 */
function getScreenSize() {
    return [window.innerWidth, window.innerHeight];
}

function resizeCanvas() {
    const [w, h] = getScreenSize();
    canvas.width = w;
    canvas.height = h;
}
window.addEventListener("resize", resizeCanvas);
resizeCanvas();

// Re-check every frame instead of relying solely on the 'resize' event,
// since some Wayland/WPE kiosk setups may not fire one after startup.
function ensureCanvasSize() {
    const [w, h] = getScreenSize();
    if (canvas.width !== w || canvas.height !== h) {
        canvas.width = w;
        canvas.height = h;
    }
}

// ── Settings (synced from /api/settings + socket.io "settings_updated") ───
const DEFAULT_SETTINGS = {
    clock_style: "dotmatrix",
    dmd_font_style: "5x7",
    clock_position: "top-right",
    clock_size: "medium",
    clock_format: "24h",
    show_date: true,
    show_seconds: true,
    clock_display_mode: "always",
    clock_display_interval: 60,
    dot_color: "#ff6600",
    dot_glow: true,
    dot_gap: 2,
    bg_enabled: false,
    bg_color: "#000000",
    border_enabled: false,
    border_color: "#ffffff",
    border_width: 2,
    position_rotate: false,
    position_rotate_interval: 10,
    effect: "fade",
    effect_speed: "medium",
    brightness: 100,
    show_fps: false,
    show_now_playing: false,
    show_boot_qr: true,
    boot_qr_duration: 15,

    title_enabled: false,
    title_text: "",
    title_font_size: 28,
    title_color: "#ffffff",
    title_align: "center",
    title_bg_enabled: true,
    title_bg_color: "#000000",
    title_bg_opacity: 60,
    title_border_enabled: false,
    title_border_color: "#ffffff",
    title_border_width: 2,

    ticker_enabled: false,
    ticker_text: "",
    ticker_font_size: 32,
    ticker_color: "#ffffff",
    ticker_speed: 80,
    ticker_direction: "rtl",
    ticker_bg_enabled: true,
    ticker_bg_color: "#000000",
    ticker_bg_opacity: 60,
    ticker_border_enabled: false,
    ticker_border_color: "#ffffff",
    ticker_border_width: 2,
};

let settings = { ...DEFAULT_SETTINGS };

// ── Sleep mode (server-authoritative - see app.py's _apply_sleep_state) ────
// The backend decides *whether* to sleep (mpv pause + best-effort HDMI
// power live there, since they need subprocess/IPC access this page
// doesn't have) and just broadcasts the resulting boolean here. This page
// only needs to blank the canvas and hide the title/ticker bars - see
// getEffectiveBarSettings() and drawFrame() below.
let sleepStatus = { asleep: false };

// ── One-shot ticker announcements ────────────────────────────────────────
// Shared mechanism for any message that should scroll across the ticker
// ONCE and then disappear - not loop forever. Used for: the now-playing
// video name, demo mode's "set the time" notice, and the "playlist is
// empty" warning. Previously demo mode/empty-playlist kept the ticker
// looping indefinitely for as long as the underlying condition was true;
// that's deliberately gone now - after one scroll-through, the ticker
// gets out of the way and leaves a clean clock/video view, even though
// the condition itself may persist. style, if given, overrides ticker
// appearance (used for system messages, which need to stay legible
// regardless of the user's own ticker colors); null means "use the
// user's own configured ticker styling" (used for the now-playing name).
let tickerAnnouncementActive = false;
let tickerAnnouncementText = "";
let tickerAnnouncementStyle = null;

function triggerTickerAnnouncement(text, style) {
    tickerAnnouncementText = text;
    tickerAnnouncementStyle = style || null;
    tickerAnnouncementActive = true;
    applyBarSettings();
}

// ── "Now playing" banner (show_now_playing) ─────────────────────────────
// Two delivery modes, chosen once per video transition based on whether
// the ticker is actually in use at that moment:
//   - ticker idle (settings.ticker_enabled false): scroll the name across
//     the ticker strip once via triggerTickerAnnouncement() above, using
//     the user's configured ticker font/color/speed/direction/bg/border.
//   - ticker in active use: fall back to the title bar (as before), so a
//     real configured ticker message never gets interrupted mid-scroll.
// Triggered by the backend's "video_changed" socket event (see the
// socket.on() block below); fires once per actual video transition, not
// on every status poll.
let nowPlayingName = "";
let nowPlayingUntil = 0;
const NOW_PLAYING_DURATION_MS = 4000;

function triggerNowPlayingBanner(name) {
    nowPlayingName = name;
    nowPlayingUntil = performance.now() + NOW_PLAYING_DURATION_MS;
    applyBarSettings();
    // Nothing else re-checks this on a timer (unlike the canvas, the
    // title bar is plain DOM/CSS, not redrawn every frame) - explicitly
    // schedule the revert. Guards against a stale timeout firing early
    // if a second video starts (and pushes nowPlayingUntil further out)
    // before this one's timer would've fired.
    setTimeout(() => {
        if (performance.now() >= nowPlayingUntil) applyBarSettings();
    }, NOW_PLAYING_DURATION_MS + 50);
}

// ── System status (demo mode / time validity / playlist) ────────────────
// "Demo mode" means the Pi doesn't yet trust its system clock (no NTP sync,
// no manual set from the settings UI). While it's on, the title bar stays
// force-overridden to explain that (persistent, not one-shot - it's a
// small, static indicator, not a moving/looping distraction) - the user's
// own title setting is never touched, just visually superseded until a
// valid time is available again. The TICKER side of both demo mode and an
// empty playlist is a one-shot announcement instead (see
// checkSystemStatusTransitions() below) - triggered once on the edge into
// that state, not held persistently.
const DEMO_TICKER_TEXT = "To set the time, go to http://10.42.0.1/control";
const EMPTY_PLAYLIST_TICKER_TEXT = "No videos in the playlist - showing the clock only. Add some from the app's Video tab.";
const SYSTEM_MESSAGE_TICKER_STYLE = () => ({
    ticker_color: "#ffffff",
    ticker_bg_enabled: true,
    ticker_bg_color: "#000000",
    ticker_bg_opacity: 80,
    ticker_border_enabled: false,
    ticker_direction: "rtl",
    ticker_speed: settings.ticker_speed || 80,
});

// ── Persistent hotspot-identity ticker (v0.13.0+, capped v0.13.6+) ──────
// While this device is running its own setup hotspot (unconfigured, or
// WiFi lost), the ticker strip is dedicated to identifying THIS device -
// unlike the one-shot announcements below, this loops rather than
// showing once, since with multiple PinClocks in a room someone might
// glance at any one of their screens at any moment during setup, not
// just right after boot. See getEffectiveBarSettings(), which gives
// this priority over the ticker's normal contents while active.
//
// Capped at HOTSPOT_TICKER_DURATION_MS though, not truly forever - if
// nobody's completed setup within a couple minutes, the message is
// more likely stale/ignorable than actively useful, and a clock stuck
// permanently announcing "set me up" to an empty room isn't a great
// steady state either. Re-arms on every fresh entry into hotspot mode
// (WiFi dropped later, hotspot comes back up) - each occurrence gets
// its own full window, this isn't a once-ever-per-device budget.
const HOTSPOT_TICKER_DURATION_MS = 2 * 60 * 1000;
let hotspotTickerTimer = null;
let hotspotTickerExpired = false;
let wasHotspotActiveForTicker = false;

function updateHotspotTickerTimer() {
    const active = wifiStatus.hotspot_active;
    if (active && !wasHotspotActiveForTicker) {
        // Fresh entry into hotspot mode (edge-triggered, same false ->
        // true reasoning as checkSystemStatusTransitions() below) -
        // (re)start the window.
        hotspotTickerExpired = false;
        clearTimeout(hotspotTickerTimer);
        hotspotTickerTimer = setTimeout(() => {
            hotspotTickerExpired = true;
            applyBarSettings(); // re-render immediately, don't wait for the next unrelated trigger
        }, HOTSPOT_TICKER_DURATION_MS);
    } else if (!active) {
        // Left hotspot mode entirely - clear so a future re-entry starts
        // its own fresh window rather than inheriting this one's timing.
        clearTimeout(hotspotTickerTimer);
        hotspotTickerTimer = null;
        hotspotTickerExpired = false;
    }
    wasHotspotActiveForTicker = active;
}

function hotspotTickerText() {
    const ssid = wifiStatus.hotspot_ssid || "PinClock-Setup";
    const url = (wifiStatus.hostname_url || "").replace(/^https?:\/\//, "") || "10.42.0.1:5000/control";
    return `Set up this clock: join WiFi \u201c${ssid}\u201d, then visit ${url}`;
}

let systemStatus = { demo_mode: false, time_valid: false, playlist_empty: false };
let wasDemoMode = false;
let wasPlaylistEmpty = false;

function checkSystemStatusTransitions() {
    // Edge-triggered (false -> true), same reasoning as checkWifiTransition()
    // below - and since these start false, the very first status fetch
    // after page load treats an already-ongoing condition as a fresh
    // edge too, which is the right call: the page hasn't announced it
    // yet, so it should, once.
    //
    // Both one-shots below are skipped entirely while hotspot_active -
    // the persistent hotspot-identity ticker (see hotspotTickerText()
    // above and getEffectiveBarSettings() below) already owns the ticker
    // strip during setup, and a demo-mode/empty-playlist announcement
    // competing with it would just interrupt it for no benefit (both of
    // those conditions are essentially expected and secondary while the
    // device isn't even on a network yet).
    if (wifiStatus.hotspot_active) {
        wasDemoMode = systemStatus.demo_mode;
        wasPlaylistEmpty = systemStatus.playlist_empty;
        return;
    }

    if (systemStatus.demo_mode && !wasDemoMode) {
        triggerTickerAnnouncement(DEMO_TICKER_TEXT, SYSTEM_MESSAGE_TICKER_STYLE());
    }
    wasDemoMode = systemStatus.demo_mode;

    if (systemStatus.playlist_empty && !wasPlaylistEmpty) {
        triggerTickerAnnouncement(EMPTY_PLAYLIST_TICKER_TEXT, SYSTEM_MESSAGE_TICKER_STYLE());
    }
    wasPlaylistEmpty = systemStatus.playlist_empty;
}

async function loadSystemStatus() {
    try {
        const res = await fetch("/api/system/status");
        systemStatus = await res.json();
    } catch (err) {
        // keep last-known state if unreachable
    }
    checkSystemStatusTransitions();
    applyBarSettings();
    updateSetupOverlay();
}
loadSystemStatus();

// ── Setup overlay (QR codes / instructions for a window after boot) ────────
// Separate from demo mode above - this is about *getting onto a network at
// all*, not about the clock trusting its time. Two independent windows,
// not one shared one:
//   - Not-yet-connected (hotspot QR pair): always shows, capped at
//     SETUP_OVERLAY_WINDOW_MS - this is the only way to actually get
//     onto WiFi in the first place, so it isn't user-configurable.
//   - Already connected (single settings QR): user-configurable via
//     show_boot_qr/boot_qr_duration (WiFi tab, under "Connected to:") -
//     this one's a convenience, not a necessity, so it can be turned off
//     or its duration changed. Defaults to 15s (was a fixed 90s before
//     this became configurable).
const SETUP_OVERLAY_WINDOW_MS = 90 * 1000;
let overlayVisibleUntil = Date.now() + SETUP_OVERLAY_WINDOW_MS;
let connectedOverlayVisibleUntil = 0;
let wifiStatus = { connected: false, hotspot_active: false, remembered_ssid: "", hostname_url: "", hotspot_ssid: "" };
let wasConnected = false;

async function loadWifiStatus() {
    try {
        const res = await fetch("/api/wifi/status");
        wifiStatus = await res.json();
    } catch (err) {
        // keep last-known state if unreachable
    }
    checkWifiTransition();
    updateHotspotTickerTimer();
    updateSetupOverlay();
}
loadWifiStatus();

async function loadSleepStatus() {
    try {
        const res = await fetch("/api/system/sleep-status");
        sleepStatus = await res.json();
    } catch (err) {
        // keep last-known state if unreachable
    }
    applyBarSettings();
    updateSetupOverlay();
}
loadSleepStatus();

function checkWifiTransition() {
    // Boot itself can take a while (up to a minute or more) before this
    // page even loads, let alone before WiFi finishes associating - a
    // fixed window measured from page-load can easily have already
    // expired by the time the connection actually succeeds, meaning the
    // "here's how to reach settings" QR would never actually get shown.
    // Reset the window fresh every time WiFi genuinely just connected
    // (false -> true), so it's tied to the event that actually matters
    // rather than an unrelated page-load timestamp.
    if (wifiStatus.connected && !wasConnected) {
        connectedOverlayVisibleUntil = Date.now() + (settings.boot_qr_duration || 15) * 1000;
    }
    wasConnected = wifiStatus.connected;
}

function updateSetupOverlay() {
    const overlay = document.getElementById("setup-overlay");
    if (sleepStatus.asleep) {
        overlay.style.display = "none";
        return;
    }
    const wifiKnown = wifiStatus.connected || wifiStatus.remembered_ssid || wifiStatus.hotspot_active;

    // Once someone's actually reached /control, the overlay's job is
    // done - no reason to keep it up for the rest of the window just
    // because the timer hasn't run out yet.
    if (systemStatus.control_page_loaded || !wifiKnown) {
        overlay.style.display = "none";
        return;
    }

    if (wifiStatus.connected) {
        if (!settings.show_boot_qr || Date.now() >= connectedOverlayVisibleUntil) {
            overlay.style.display = "none";
            return;
        }
    } else if (Date.now() >= overlayVisibleUntil) {
        overlay.style.display = "none";
        return;
    }

    const qr1 = document.getElementById("setup-qr-1");
    const qr2Block = document.getElementById("setup-qr-2-block");
    const qr1Label = document.getElementById("setup-qr-1-label");
    const qr1Number = document.getElementById("setup-qr-1-number");
    const qr2Number = document.getElementById("setup-qr-2-number");
    const text = document.getElementById("setup-overlay-text");
    const ssidEl = document.getElementById("setup-overlay-ssid");
    const ipEl = document.getElementById("setup-overlay-ip");

    if (wifiStatus.connected) {
        // On a real network - show the way back to settings from here on,
        // since 10.42.0.1 no longer applies once off the hotspot. SSID +
        // raw IP shown directly (not just the .local address) so a wrong
        // network - e.g. an isolated guest WiFi that can't reach the LAN -
        // is obvious at a glance instead of needing a debugging session.
        qr1.src = "/api/qr/settings.png";
        qr1Label.textContent = "Scan for settings";
        qr2Block.style.display = "none";
        // Only one QR here - no scan order to communicate, so no number.
        qr1Number.style.display = "none";
        ssidEl.textContent = "Connected to: " + (wifiStatus.ssid || "");
        text.textContent = wifiStatus.hostname_url || "";
        ipEl.textContent = wifiStatus.ip ? ("IP: " + wifiStatus.ip) : "";
        overlay.style.display = "flex";
    } else {
        // Still on the setup hotspot (or otherwise not connected) - show
        // both the WiFi-join and settings-URL QR codes, same pair as the
        // printed setup card. Two QRs means there's a scan ORDER worth
        // making obvious (join the hotspot first, then reach settings) -
        // hence the big 1/2 numbers, only shown in this branch.
        // wifi-join-qr.png was a static, pre-baked PNG through v0.12.8,
        // encoding the old shared "PinClock-Setup" SSID - now dynamic
        // per device (see /api/qr/wifi-join.png), since
        // wifi_manager.HOTSPOT_SSID is unique per device as of v0.13.0.
        // control-url-qr.png stays a static file and unchanged: it
        // encodes the fixed 10.42.0.1 hotspot gateway address, which is
        // identical for every device's hotspot regardless of SSID.
        qr1.src = "/api/qr/wifi-join.png";
        qr1Label.textContent = "Scan to join WiFi";
        qr1Number.textContent = "1";
        qr1Number.style.display = "block";
        qr2Block.style.display = "flex";
        document.getElementById("setup-qr-2").src = "/static/img/control-url-qr.png";
        document.getElementById("setup-qr-2-label").textContent = "Scan to open settings";
        qr2Number.textContent = "2";
        qr2Number.style.display = "block";
        ssidEl.textContent = "Hotspot: " + (wifiStatus.hotspot_ssid || "PinClock-Setup");
        ipEl.textContent = "";
        text.textContent = "Set up WiFi to keep accurate time automatically";
        overlay.style.display = "flex";
    }
}
// Time-boxed, so re-check on an interval rather than only on data changes -
// it needs to disappear after its window even with no new events at all.
setInterval(updateSetupOverlay, 5000);

function getEffectiveBarSettings() {
    // Sleep takes priority over everything else below - a sleeping
    // device should show nothing at all, not a "Demo" banner or a
    // ticker announcement.
    if (sleepStatus.asleep) {
        return { ...settings, title_enabled: false, ticker_enabled: false };
    }

    // Demo mode's title override, computed as a base to layer on top of -
    // NOT an early return, since the hotspot ticker override just below
    // needs to be able to combine with it (title bar and ticker are
    // different bars, so both can be persistently active at once: "Demo"
    // in the title while the hotspot name loops in the ticker). Demo
    // mode's own TICKER side stays a one-shot announcement, handled
    // further below via tickerAnnouncementActive - but only reachable at
    // all when the hotspot isn't already claiming the ticker (see
    // checkSystemStatusTransitions()).
    let base = settings;
    if (systemStatus.demo_mode) {
        base = {
            ...settings,
            title_enabled: true,
            title_text: "Demo",
            title_align: "center",
            title_color: "#ffffff",
            title_bg_enabled: true,
            title_bg_color: "#000000",
            title_bg_opacity: 80,
            title_border_enabled: false,
        };
    }

    // Persistent hotspot-identity ticker (v0.13.0+, capped v0.13.6+) - see
    // hotspotTickerText() and updateHotspotTickerTimer() above. Takes
    // priority over a one-shot announcement or the user's own ticker
    // (neither is meaningful before the device has even been
    // configured), but only overrides the ticker, so it layers cleanly
    // on top of `base` above (e.g. demo mode's "Demo" title can still be
    // showing at the same time).
    //
    // Minor, self-resolving edge case: if a one-shot announcement
    // (tickerAnnouncementActive) happened to already be mid-scroll the
    // instant hotspot_active flips true, applyBarSettings()'s own
    // once:true/onComplete logic (keyed off tickerAnnouncementActive,
    // not off what content is actually showing) still governs that one
    // pass - it settles into this persistent infinite loop right after,
    // once that flag clears. Not worth the extra plumbing to avoid one
    // possible extra pass.
    if (wifiStatus.hotspot_active && !hotspotTickerExpired) {
        return {
            ...base,
            ...SYSTEM_MESSAGE_TICKER_STYLE(),
            ticker_enabled: true,
            ticker_text: hotspotTickerText(),
        };
    }

    // A one-shot ticker announcement is in flight - the now-playing name,
    // or demo mode/empty-playlist's message triggered on the edge into
    // that state (see checkSystemStatusTransitions() and the
    // video_changed handler below). style is null for the now-playing
    // case (use the user's own ticker styling); non-null for system
    // messages (fixed, legible regardless of the user's own colors).
    if (tickerAnnouncementActive) {
        return {
            ...base,
            ...(tickerAnnouncementStyle || {}),
            ticker_enabled: true,
            ticker_text: tickerAnnouncementText,
        };
    }
    // Title mode: a video changed while the ticker was actually in use
    // at trigger time (see the video_changed handler below) - falls back
    // to the title bar's slot instead of interrupting a real ticker
    // message mid-scroll.
    if (settings.show_now_playing && nowPlayingName && performance.now() < nowPlayingUntil) {
        return { ...base, title_enabled: true, title_text: nowPlayingName };
    }
    return base;
}

async function loadSettings() {
    try {
        const res = await fetch("/api/settings");
        settings = { ...DEFAULT_SETTINGS, ...(await res.json()) };
    } catch (err) {
        // keep defaults if the backend isn't reachable yet
    }
    applyBarSettings();
    updateSetupOverlay();
}
loadSettings();

if (window.io) {
    const socket = io();
    socket.on("settings_updated", (s) => {
        settings = { ...DEFAULT_SETTINGS, ...s };
        applyBarSettings();
        updateSetupOverlay();
    });
    socket.on("system_status", (s) => {
        systemStatus = s;
        checkSystemStatusTransitions();
        applyBarSettings();
        updateSetupOverlay();
    });
    socket.on("wifi_status", (w) => {
        wifiStatus = w;
        checkWifiTransition();
        updateHotspotTickerTimer();
        // v0.13.0+: getEffectiveBarSettings() now reads
        // wifiStatus.hotspot_active for the persistent hotspot-identity
        // ticker - without this, a hotspot-state change would only be
        // reflected in the ticker whenever something else happened to
        // trigger a re-render next, not promptly.
        applyBarSettings();
        updateSetupOverlay();
    });
    socket.on("sleep_status", (s) => {
        sleepStatus = s;
        applyBarSettings();
        updateSetupOverlay();
    });
    socket.on("video_changed", (v) => {
        if (!settings.show_now_playing) return;
        const name = decodeVideoName(v.name);
        // Decided once, at the moment the video changes: if the ticker
        // is genuinely idle right now, scroll the name across it;
        // otherwise (a real ticker message is actively configured and
        // on) fall back to the title bar instead of interrupting it.
        if (settings.ticker_enabled) {
            triggerNowPlayingBanner(name);
        } else {
            triggerTickerAnnouncement(name, null);
        }
    });
}

// Title bar/ticker are DOM/CSS, updated on settings changes - not driven
// by the rAF render loop, since they're static (title) or a CSS
// compositor animation (ticker), not a per-frame canvas redraw.
function applyBarSettings() {
    const effective = getEffectiveBarSettings();
    updateTitleBar(effective);
    // Whenever a one-shot ticker announcement is active, EVERY call to
    // applyBarSettings() (not just the one that triggered it) needs to
    // pass {once:true, onComplete}: this function gets called for
    // reasons that have nothing to do with the scroll (an unrelated
    // settings change from another browser tab, a system_status tick,
    // window resize) while it's mid-flight, and updateTicker()'s own
    // signature check (see bars.js) is what actually protects an
    // in-flight scroll from being restarted or converted into an
    // infinite loop by one of those - but only if opts.once is supplied
    // consistently on every call, not just the first one.
    const tickerOpts = tickerAnnouncementActive
        ? {
            once: true,
            onComplete: () => {
                tickerAnnouncementActive = false;
                tickerAnnouncementText = "";
                tickerAnnouncementStyle = null;
                applyBarSettings();
            },
        }
        : undefined;
    updateTicker(effective, tickerOpts);
}

// The ticker's scroll distance depends on the track's actual pixel width,
// so a viewport resize needs to rebuild its animation too (debounced,
// title bar just needs its width restyled which CSS handles for free).
window.addEventListener("resize", () => scheduleBarsResize(applyBarSettings));

// ── Corner rotation (position_rotate) ──────────────────────────────────────
const rotateStartTime = performance.now();

function getEffectiveSettings() {
    let s = settings;
    if (s.position_rotate) {
        const intervalMs = Math.max(1, s.position_rotate_interval || 10) * 1000;
        const elapsed = performance.now() - rotateStartTime;
        const idx = Math.floor(elapsed / intervalMs) % ROTATE_CORNERS.length;
        s = { ...s, clock_position: ROTATE_CORNERS[idx] };
    }
    // Bar visibility can be temporarily forced independently of the
    // user's stored title_enabled/ticker_enabled (demo mode, sleep, the
    // now-playing banners above) - the clock's reserved-space
    // calculation (getBarInsets() in bars.js, used in renderClockFrame)
    // needs to match what's ACTUALLY on screen right now, not just
    // what's saved in settings, or the clock can render underneath a
    // bar that's only conditionally visible. This also fixes a
    // pre-existing gap where demo mode's forced bars weren't accounted
    // for in the clock's layout even though they were already forced on
    // in getEffectiveBarSettings() for rendering purposes.
    const barEff = getEffectiveBarSettings();
    if (barEff.title_enabled !== s.title_enabled || barEff.ticker_enabled !== s.ticker_enabled) {
        s = { ...s, title_enabled: barEff.title_enabled, ticker_enabled: barEff.ticker_enabled };
    }
    return s;
}

// ── Display Clock (clock_display_mode) ──────────────────────────────────────
// "always"/"never" are static; "interval" cycles the clock visible for a
// fixed reveal window, then hidden for the rest of clock_display_interval
// seconds, repeating - full period is clock_display_interval itself (not
// interval-plus-reveal), so e.g. 60s means "flash on once a minute", not
// "60s hidden, then also visible for a while on top of that". The reveal
// duration itself isn't user-configurable (yet) - flagging that as an
// assumption, easy to expose as its own setting later if wanted.
const CLOCK_REVEAL_DURATION_S = 8;
const clockCycleStartTime = performance.now();

function isClockVisible(s) {
    const mode = s.clock_display_mode || "always";
    if (mode === "never") return false;
    if (mode !== "interval") return true; // "always" (or an unrecognized value - fail open)
    // Guard against a period shorter than the reveal window (shouldn't
    // happen given the control panel's slider min, but degenerate input
    // shouldn't produce a permanently-on or flickering clock either).
    const periodS = Math.max(CLOCK_REVEAL_DURATION_S + 1, s.clock_display_interval || 60);
    const elapsedS = (performance.now() - clockCycleStartTime) / 1000;
    const phase = elapsedS % periodS;
    return phase < CLOCK_REVEAL_DURATION_S;
}

function drawFrame() {
    ensureCanvasSize();
    const W = canvas.width;
    const H = canvas.height;
    ctx.clearRect(0, 0, W, H);

    if (sleepStatus.asleep) {
        // Minimal processing while asleep - solid black, nothing else
        // computed or drawn (no clock layout, no debug overlay, no
        // now-playing banner). mpv is paused and the title/ticker bars
        // are hidden separately - see app.py's _apply_sleep_state() and
        // getEffectiveBarSettings() above.
        ctx.fillStyle = "#000000";
        ctx.fillRect(0, 0, W, H);
        return;
    }

    const effSettings = getEffectiveSettings();
    if (isClockVisible(settings)) {
        renderClockFrame(ctx, W, H, effSettings);
    }

    // Brightness: overlay a dimming layer (doesn't touch physical backlight)
    const brightness = settings.brightness !== undefined ? settings.brightness : 100;
    if (brightness < 100) {
        ctx.fillStyle = `rgba(0,0,0,${(100 - brightness) / 100})`;
        ctx.fillRect(0, 0, W, H);
    }

    drawDebugOverlay();
    if (settings.show_fps || debugForced) drawFpsCounter();
}

// ── FPS counter (debug) ─────────────────────────────────────────────────
let fpsFrames = 0;
let fpsLastTime = performance.now();
let fpsValue = 0;

let debugForced = false;
let lastStatus = { video: null, width: null, height: null };

async function pollDebugStatus() {
    if (!(settings.show_fps || debugForced)) return;
    try {
        const res = await fetch("/api/status");
        const data = await res.json();
        lastStatus = {
            video: data.video || "(no video)",
            width: data.width || null,
            height: data.height || null,
        };
    } catch (err) {
        lastStatus = { video: "mpv: unreachable", width: null, height: null };
    }
}
setInterval(pollDebugStatus, 500);

function drawFpsCounter() {
    const resText = lastStatus.width && lastStatus.height
        ? `${lastStatus.width}x${lastStatus.height}`
        : "unknown res";
    const eff = getEffectiveSettings();
    const lines = [
        `PinClock ${systemStatus.version || ""}`,
        `${fpsValue} fps`,
        lastStatus.video || "(no video)",
        `video: ${resText}`,
        `canvas: ${canvas.width}x${canvas.height} (screen: ${getScreenSize().join("x")})`,
        `clock pos: ${eff.clock_position}`,
    ];

    ctx.save();
    ctx.font = "16px monospace";
    ctx.fillStyle = "#3cff78";
    ctx.textAlign = "left";
    ctx.textBaseline = "top";

    const pad = 6;
    const lineHeight = 20;
    const boxW = Math.max(...lines.map((l) => ctx.measureText(l).width)) + pad * 2;
    const boxH = lines.length * lineHeight + pad * 2;
    ctx.fillStyle = "rgba(0,0,0,0.5)";
    ctx.fillRect(4, 4, boxW, boxH);

    ctx.fillStyle = "#3cff78";
    lines.forEach((line, i) => {
        ctx.fillText(line, 4 + pad, 4 + pad + i * lineHeight);
    });
    ctx.restore();
}

// Redraw throttling: a clock only needs to visibly change once a second,
// so redrawing (clearRect + full re-render + WebKit re-compositing the
// canvas layer) on every single requestAnimationFrame tick - up to 60x/sec
// - was pure wasted GPU/compositor work, all of it landing on the same
// GPU mpv is simultaneously decoding/presenting video through. TARGET_FPS
// is a small margin over 1fps so the seconds digit still feels prompt
// rather than visibly lagging behind the real time.
//
// requestAnimationFrame itself still fires every vsync as before (cheap -
// it's just a callback + timestamp check); only the actual drawFrame()
// call - the expensive part - is gated behind the interval.
//
// The debug overlay (F8 / show_fps) is deliberately exempted from the
// throttle: it exists specifically to diagnose real rendering
// performance, so it should report the actual achievable framerate, not
// the rate we've chosen to throttle down to on purpose.
const TARGET_FPS = 4;
const FRAME_INTERVAL_MS = 1000 / TARGET_FPS;
let lastDrawTime = 0;

function render() {
    const now = performance.now();
    const debugActive = settings.show_fps || debugForced;

    if (debugActive || now - lastDrawTime >= FRAME_INTERVAL_MS) {
        lastDrawTime = now;

        fpsFrames++;
        if (now - fpsLastTime >= 1000) {
            fpsValue = fpsFrames;
            fpsFrames = 0;
            fpsLastTime = now;
        }

        drawFrame();
    }

    requestAnimationFrame(render);
}

// ===============================
// Debug keys (matches original display.py scheme):
//   F8    - toggle persistent debug overlay (fps / filename / resolution)
//   Left  - previous video
//   Right - next video
//   Space - play/pause
// ===============================

let debugOverlayText = "";
let debugOverlayUntil = 0;

function showDebugOverlay(text, durationMs = 2000) {
    debugOverlayText = text;
    debugOverlayUntil = performance.now() + durationMs;
}

function drawDebugOverlay() {
    if (!debugOverlayText || performance.now() > debugOverlayUntil) return;

    ctx.save();
    ctx.font = "24px monospace";
    ctx.textAlign = "center";
    ctx.textBaseline = "bottom";

    const x = canvas.width / 2;
    const y = canvas.height - 24;

    ctx.lineWidth = 4;
    ctx.strokeStyle = "#000000";
    ctx.strokeText(debugOverlayText, x, y);

    ctx.fillStyle = "#00ff66";
    ctx.fillText(debugOverlayText, x, y);
    ctx.restore();
}

let isPaused = false;

async function mpvTransport(cmd) {
    try {
        await fetch("/api/transport", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ cmd }),
        });
        if (cmd === "play") isPaused = false;
        if (cmd === "pause") isPaused = true;
        pollDebugStatus();
    } catch (err) {
        showDebugOverlay("mpv: unreachable");
    }
}

document.addEventListener("keydown", (e) => {
    switch (e.key) {
        case "F8":
            debugForced = !debugForced;
            if (debugForced) pollDebugStatus();
            break;
        case "ArrowRight":
            mpvTransport("next");
            break;
        case "ArrowLeft":
            mpvTransport("prev");
            break;
        case " ":
            mpvTransport(isPaused ? "play" : "pause");
            e.preventDefault();
            break;
    }
});

// Start the render loop now that everything it depends on is declared.
render();
