"""
IMPORTANT: eventlet.monkey_patch() must run before anything else in the
process imports os/socket/subprocess/threading/select - including Flask
and every stdlib module below - or those modules keep their unpatched,
blocking versions and the patch does nothing for them. This is why it's
the literal first thing in this file, ahead of even `import io`.

Why this exists at all: async_mode="eventlet" (below) means Flask-SocketIO
runs everything - every request, every background task - cooperatively on
ONE OS thread via eventlet greenlets. Without monkey_patch(), a blocking
call anywhere (subprocess.run() for nmcli, disk I/O for a video upload)
doesn't yield - it hard-blocks that ONE thread, freezing the entire app
(every route, every socket message) for as long as that call takes. This
was a real, confirmed bug: the periodic wifi status broadcaster
(_status_broadcaster, further down) calls wifi_manager.get_status() every
2 seconds forever, which makes several blocking nmcli calls - during
normal conditions that's sub-second and invisible, but during real WiFi
churn (repeated connect attempts, hotspot teardown/rebuild) those calls
can stretch toward their timeouts, taking the whole settings page down
with them even though the device itself is fine underneath.

Sandbox-tested against the exact eventlet version installed on-device
(0.41.0) before relying on this: confirmed a slow subprocess call in one
greenthread no longer blocks a concurrent greenthread's progress (the
actual bug, now fixed) - but also uncovered a real, separate bug in doing
so: under this eventlet+Python 3.12 combination, the subprocess.TimeoutExpired
raised by a timed-out subprocess.run() is NOT `is`-identical to the
subprocess.TimeoutExpired class visible via `import subprocess` at the
except-clause - same name, same reported module, genuinely different
class object - so `except subprocess.TimeoutExpired` silently fails to
catch it and lets it escape uncaught instead. See the matching fix in
wifi_manager.py's _run() (catches by class NAME rather than identity)
- every nmcli timeout path funnels through that one function, so fixing
it there covers get_status(), connect(), and everything else at once.
"""
import eventlet
eventlet.monkey_patch()

import io
import json
import os
import shutil
import socket
import subprocess
import sys
import threading
import time

from flask import Flask, jsonify, request, send_from_directory, render_template, send_file
from flask_socketio import SocketIO
from werkzeug.utils import secure_filename

import qrcode

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "app"))
from core import mpv_ipc  # noqa: E402
from core import settings_store as store  # noqa: E402
from core import wifi_manager  # noqa: E402
from core import system_state  # noqa: E402
from core import sleep_manager  # noqa: E402
from core.paths import DATA_DIR  # noqa: E402

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "scripts"))
import gen_playlist  # noqa: E402

# Single source of truth for the version string - the Device tab and the
# on-screen debug overlay (display.js) both fetch this via
# /api/system/status rather than each hardcoding their own copy, so a
# version bump only ever needs to happen in one place.
PINCLOCK_VERSION = "v0.13.7"

app = Flask(__name__, static_folder="app/static", template_folder="app/templates")
app.config["MAX_CONTENT_LENGTH"] = 1024 * 1024 * 1024  # 1 GB max upload
socketio = SocketIO(app, async_mode="eventlet", cors_allowed_origins="*")

# Changes every time Flask (re)starts, used as a cache-busting query string on
# display.html's <script> tags - see note on add_no_cache_headers() below.
ASSET_VERSION = str(int(time.time()))

# Guards against two overlapping /api/wifi/connect attempts both mutating
# NetworkManager state at once - see _run_wifi_connect() below.
_wifi_connect_lock = threading.Lock()



@app.after_request
def add_no_cache_headers(response):
    """
    The display page runs inside Cog/WebKit as a long-lived kiosk view, which
    can aggressively disk-cache HTML/JS/API responses across restarts and
    even reboots. Since this is a local single-purpose app (not something
    served to the public internet), we just disable caching entirely so a
    code or settings change always takes effect on the next reload.
    """
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response


# -------------------------------------------------------------- pages -----
@app.route("/")
def index():
    return render_template("display.html", v=ASSET_VERSION)


_control_page_loaded = False

# display.js POSTs to exactly one endpoint on its own (debug-key
# transport controls, e.g. space to pause) - everything else it does is
# read-only polling. Any OTHER POST is, by construction, someone actually
# doing something (saving a setting, adding a video, connecting to WiFi,
# clearing the playlist, etc.) - a much simpler and more robust signal
# than trying to enumerate every passive GET request the display page's
# browser might incidentally make (favicon requests and the like), which
# risks a false positive from something never actually visited by a
# person. Covers e.g. an already-open control.html tab surviving a Flask
# restart, where no fresh GET /control ever happens again but the person
# is still right there using it - the first real action they take now
# clears the setup overlay, not just a reload.
_PASSIVE_POST_ENDPOINTS = {"/api/transport"}


def _is_control_page_action(method, path):
    """Pure decision logic, split out from the request hook below so it
    can be unit-tested directly without a Flask request context - see
    the standalone simulation used to verify this during development."""
    if path.startswith("/socket.io"):
        # both pages' own socket.io connections can POST here (Engine.IO's
        # polling transport, used before/if it upgrades to a real
        # websocket) - never a real "action", just connection upkeep.
        return False
    return method == "POST" and path not in _PASSIVE_POST_ENDPOINTS


@app.before_request
def _mark_control_page_used():
    global _control_page_loaded
    if _control_page_loaded:
        return
    if _is_control_page_action(request.method, request.path):
        _control_page_loaded = True


@app.route("/control")
def control():
    global _control_page_loaded
    _control_page_loaded = True
    return render_template("control.html")


@app.route("/videos/<path:filename>")
def videos_static(filename):
    """
    Serves a video file for direct browser playback/preview. Checks the
    user directory first, then shipped - NOT relative to the app's own
    root_path (that was this route's original behavior, which broke
    silently once videos moved to DATA_DIR in step 1's path split and
    was never actually exercised by anything in this app since, until
    now with the shipped-videos feature).
    """
    from core.paths import SHIPPED_VIDEOS_DIR
    safe_name = secure_filename(filename)
    if (store.VIDEOS_DIR / safe_name).is_file():
        return send_from_directory(str(store.VIDEOS_DIR), safe_name)
    if (SHIPPED_VIDEOS_DIR / safe_name).is_file():
        return send_from_directory(str(SHIPPED_VIDEOS_DIR), safe_name)
    return jsonify({"error": "not found"}), 404


# ----------------------------------------------------------- settings -----
@app.route("/api/settings", methods=["GET"])
def get_settings():
    return jsonify(store.load_settings())


@app.route("/api/settings", methods=["POST"])
def post_settings():
    data = request.get_json(force=True, silent=True) or {}
    # "playlist" is deliberately excluded here even though it's a
    # DEFAULT_SETTINGS key - it must only ever be mutated through the
    # validated /api/playlist/add and /api/playlist/remove endpoints
    # (which check the video actually exists, dedupe, etc.), never as
    # a raw blob via the generic settings-save path.
    allowed_keys = set(store.DEFAULT_SETTINGS.keys()) - {"playlist"}
    clean = {k: v for k, v in data.items() if k in allowed_keys}
    updated = store.save_settings(clean)

    # Live-apply what we can directly to mpv
    try:
        if "video_volume" in clean:
            mpv_ipc.set_property("volume", clean["video_volume"])
        if "randomize" in clean:
            _regenerate_and_reload_playlist()
    except mpv_ipc.MpvIPCError:
        pass

    # A sleep-schedule field changed - re-evaluate immediately rather than
    # waiting up to 2s for the next _status_broadcaster tick, so e.g.
    # flipping sleep_mode to "off" wakes the display right away.
    if {"sleep_mode", "sleep_after_minutes", "sleep_time", "wake_time"} & set(clean.keys()):
        _apply_sleep_state(updated)

    socketio.emit("settings_updated", updated)
    return jsonify(updated)


# ------------------------------------------------------------- videos -----
@app.route("/api/videos", methods=["GET"])
def get_videos():
    """My Videos / Stock tabs - every video available on the device,
    tagged with whether it's currently in the playlist (so the UI can
    show "Add" vs an already-added state)."""
    playlist_keys = {(e["name"], e["source"]) for e in store.get_playlist()}
    out = []
    for v in store.list_videos():
        try:
            size = v["path"].stat().st_size
        except OSError:
            size = 0
        out.append({
            "name": v["name"], "size": size, "source": v["source"],
            "deletable": v["deletable"],
            "in_playlist": (v["name"], v["source"]) in playlist_keys,
        })
    return jsonify(out)


@app.route("/api/videos/upload", methods=["POST"])
def upload_video():
    if "file" not in request.files:
        return jsonify({"error": "no file provided"}), 400
    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "empty filename"}), 400

    filename = secure_filename(file.filename)
    ext = os.path.splitext(filename)[1].lower()
    if ext not in store.ALLOWED_VIDEO_EXT:
        return jsonify({"error": "only .mp4 files are supported"}), 400

    from core.paths import SHIPPED_VIDEOS_DIR
    if (SHIPPED_VIDEOS_DIR / filename).exists():
        return jsonify({
            "error": f"'{filename}' is already a shipped video name - rename your file and try again"
        }), 400

    dest = store.VIDEOS_DIR / filename
    file.save(str(dest))
    store.add_to_playlist(filename, "user")  # uploading always adds it to what's playing

    _regenerate_and_reload_playlist()
    socketio.emit("videos_updated", {})
    socketio.emit("playlist_updated", {})
    return jsonify({"ok": True, "name": filename})


@app.route("/api/videos/<path:name>", methods=["DELETE"])
def delete_video(name):
    """User videos only - shipped videos (source="shipped", see
    settings_store.list_videos) are never deletable through this app,
    the same way they're never editable through the update mechanism
    outside of a real firmware release. A request naming a shipped
    video's filename gets refused rather than silently no-op'd, so the
    control page can show a clear reason rather than a mysterious
    non-deletion."""
    filename = secure_filename(name)
    from core.paths import SHIPPED_VIDEOS_DIR
    if (SHIPPED_VIDEOS_DIR / filename).is_file() and not (store.VIDEOS_DIR / filename).is_file():
        return jsonify({"error": "shipped videos can't be deleted"}), 403

    target = store.VIDEOS_DIR / filename
    if target.exists() and target.is_file():
        target.unlink()
        store.remove_from_playlist(filename, "user")  # can't stay in the playlist once it's gone
        _regenerate_and_reload_playlist()
        socketio.emit("videos_updated", {})
        socketio.emit("playlist_updated", {})
        return jsonify({"ok": True})
    return jsonify({"error": "not found"}), 404


@app.route("/api/videos/play", methods=["POST"])
def play_video():
    """
    Plays the requested video right away, WITHOUT clearing the rest of
    the loaded playlist (unlike this endpoint's earlier "replace"
    behavior). See mpv_ipc.play_now for how - insert-next then an
    explicit playlist-next, rather than a single loadfile flag that
    needs a specific-enough mpv version to work at all.

    Accepts an optional "source" to disambiguate a name that happens to
    exist in both places (see settings_store.list_videos's docstring on
    why name alone isn't always unique) - if omitted, checks user then
    shipped, matching this endpoint's previous behavior.
    """
    data = request.get_json(force=True, silent=True) or {}
    name = data.get("name")
    source = data.get("source")
    if not name:
        return jsonify({"error": "name is required"}), 400
    filename = secure_filename(name)

    from core.paths import SHIPPED_VIDEOS_DIR
    if source == "user":
        target = store.VIDEOS_DIR / filename
    elif source == "shipped":
        target = SHIPPED_VIDEOS_DIR / filename
    else:
        target = store.VIDEOS_DIR / filename
        if not target.exists():
            target = SHIPPED_VIDEOS_DIR / filename

    if not target.exists():
        return jsonify({"error": "not found"}), 404
    try:
        mpv_ipc.play_now(str(target))
        return jsonify({"ok": True})
    except mpv_ipc.MpvIPCError as e:
        return jsonify({"ok": False, "error": str(e)}), 500


# ----------------------------------------------------------- playlist -----
@app.route("/api/playlist", methods=["GET"])
def get_playlist_route():
    """Current Playlist tab - the explicit, curated set of videos that
    actually get played, in play order. See
    settings_store.get_playlist for the self-healing behavior (stale
    entries referencing deleted files are dropped automatically)."""
    playlist = store.get_playlist()
    by_key = {(v["name"], v["source"]): v for v in store.list_videos()}
    out = []
    for e in playlist:
        v = by_key.get((e["name"], e["source"]))
        size = 0
        if v:
            try:
                size = v["path"].stat().st_size
            except OSError:
                pass
        out.append({"name": e["name"], "source": e["source"], "size": size})
    return jsonify(out)


@app.route("/api/playlist/add", methods=["POST"])
def add_to_playlist_route():
    data = request.get_json(force=True, silent=True) or {}
    name = secure_filename(data.get("name") or "")
    source = data.get("source")
    if not name or source not in ("user", "shipped"):
        return jsonify({"error": "name and source ('user' or 'shipped') are required"}), 400
    try:
        playlist = store.add_to_playlist(name, source)
    except ValueError as e:
        return jsonify({"error": str(e)}), 404
    # Start the just-added video immediately (per-second the user tapped
    # "Add") rather than just silently joining the regenerated playlist -
    # a full reload alone doesn't guarantee it plays next, since it could
    # land anywhere in the (possibly shuffled) rebuilt list.
    video_dir = store.VIDEOS_DIR if source == "user" else store.SHIPPED_VIDEOS_DIR
    play_path = str(video_dir / name)
    _regenerate_and_reload_playlist(play_path=play_path)
    socketio.emit("videos_updated", {})
    socketio.emit("playlist_updated", {})
    return jsonify({"ok": True, "playlist": playlist})


@app.route("/api/playlist/remove", methods=["POST"])
def remove_from_playlist_route():
    """Playlist-only removal - the video stays on the device (still
    visible/manageable in My Videos or Stock), it just stops playing.
    See delete_video() for actually removing a user video from the
    device entirely."""
    data = request.get_json(force=True, silent=True) or {}
    name = secure_filename(data.get("name") or "")
    source = data.get("source")
    if not name or source not in ("user", "shipped"):
        return jsonify({"error": "name and source ('user' or 'shipped') are required"}), 400
    playlist = store.remove_from_playlist(name, source)
    _regenerate_and_reload_playlist()
    socketio.emit("videos_updated", {})
    socketio.emit("playlist_updated", {})
    return jsonify({"ok": True, "playlist": playlist})


@app.route("/api/playlist/clear", methods=["POST"])
def clear_playlist_route():
    """Current Playlist subtab's "Clear Playlist" button. Empties the
    playlist entirely - mpv is left with nothing to play (see
    gen_playlist.py, which writes an empty .m3u in that case), so the
    device falls back to showing just the clock. The control panel warns
    about this before calling here (see the confirm() dialog in
    control.html); the ticker's own "playlist is empty" message (see
    _system_status_payload's playlist_empty field, and display.js's
    getEffectiveBarSettings()) covers the on-screen side of the same
    warning for anyone looking at the device itself, not just whoever
    clicked the button."""
    playlist = store.clear_playlist()
    _regenerate_and_reload_playlist()
    socketio.emit("videos_updated", {})
    socketio.emit("playlist_updated", {})
    return jsonify({"ok": True, "playlist": playlist})


@app.route("/api/playlist/add_all", methods=["POST"])
def add_all_to_playlist_route():
    """Stock sub-tab's "Add all to playlist" button. Currently only ever
    called with source="shipped" from the UI, but takes source as a
    parameter (rather than hardcoding it) since add_all_to_playlist()
    itself is source-agnostic."""
    data = request.get_json(force=True, silent=True) or {}
    source = data.get("source")
    if source not in ("user", "shipped"):
        return jsonify({"error": "source ('user' or 'shipped') is required"}), 400
    playlist = store.add_all_to_playlist(source)
    _regenerate_and_reload_playlist()
    socketio.emit("videos_updated", {})
    socketio.emit("playlist_updated", {})
    return jsonify({"ok": True, "playlist": playlist})


# ---------------------------------------------------------- transport -----
@app.route("/api/transport", methods=["POST"])
def transport():
    data = request.get_json(force=True, silent=True) or {}
    cmd = data.get("cmd")
    if cmd not in ("play", "pause", "next", "prev"):
        return jsonify({"error": "invalid command"}), 400
    try:
        if cmd == "play":
            mpv_ipc.set_pause(False)
        elif cmd == "pause":
            mpv_ipc.set_pause(True)
        elif cmd == "next":
            mpv_ipc.next_video()
        elif cmd == "prev":
            mpv_ipc.prev_video()
        return jsonify({"ok": True})
    except mpv_ipc.MpvIPCError as e:
        return jsonify({"ok": False, "error": str(e)}), 500


@app.route("/api/status", methods=["GET"])
def status():
    return jsonify(mpv_ipc.get_status())


# ---------------------------------------------------------------- time ----
@app.route("/api/time", methods=["POST"])
def set_time():
    """
    Set the Pi's system clock from the phone.
    Expects JSON: {"iso": "2026-07-08T14:23:00"} (local time, no timezone math)

    Requires a passwordless sudo rule for /bin/date - see setup.sh.
    """
    data = request.get_json(force=True, silent=True) or {}
    iso = data.get("iso")
    if not iso:
        return jsonify({"error": "iso datetime string is required"}), 400

    date_str = iso.replace("T", " ").replace("'", "")
    try:
        result = subprocess.run(
            ["sudo", "/bin/date", "-s", date_str],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode != 0:
            return jsonify({"error": result.stderr.strip() or "failed to set system time"}), 500
        st = system_state.mark_time_valid("manual")
        socketio.emit("system_status", _system_status_payload(st))
        return jsonify({"ok": True, "output": result.stdout.strip()})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ------------------------------------------------------------- wifi ------
def _hostname_url():
    """
    A fixed, DHCP-independent address for reaching the control page once
    connected to a real network - relies on mDNS (avahi-daemon), which is
    already running on this image. This is deliberately preferred over
    trying to display/track the actual DHCP-assigned IP: that changes
    per-network and would need the on-device display to regenerate a QR
    code live, whereas "<hostname>.local" is stable across reboots and
    networks, so it can be shown as a plain static QR code instead.
    """
    host = socket.gethostname()
    return f"http://{host}.local:5000/control"


_qr_cache = {}


def _qr_png_bytes(payload):
    """Small in-memory cache - the handful of payloads this ever
    generates (the hostname URL, essentially) don't change within a
    process lifetime, so there's no reason to re-render the QR every time
    the display polls for it."""
    if payload not in _qr_cache:
        img = qrcode.make(payload)
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        _qr_cache[payload] = buf.getvalue()
    return _qr_cache[payload]


@app.route("/api/wifi/status", methods=["GET"])
def wifi_status():
    return jsonify({
        **wifi_manager.get_status(),
        "remembered_ssid": wifi_manager.get_remembered_ssid(),
        "hostname_url": _hostname_url(),
        # This device's own setup-hotspot SSID (v0.13.0+, per-device -
        # see wifi_manager.HOTSPOT_SSID) - exposed so control.html can
        # show/confirm the REAL name instead of a hardcoded generic one,
        # which would now be actively wrong on any device past v0.12.8.
        "hotspot_ssid": wifi_manager.HOTSPOT_SSID,
    })


@app.route("/api/wifi/scan", methods=["GET"])
def wifi_scan():
    rescan = request.args.get("rescan", "1") != "0"
    return jsonify(wifi_manager.scan_networks(rescan=rescan))


@app.route("/api/wifi/connect", methods=["POST"])
def wifi_connect():
    """
    Starts the connection attempt in a background thread and returns
    immediately, rather than blocking the request for however long
    wifi_manager.connect() takes (worst case ~45-90s: teardown_hotspot +
    connection delete + connection add + connection up, each with its
    own timeout). A synchronous multi-step nmcli sequence that long is a
    bad foundation for responsive UI feedback regardless of how the
    frontend is built - and on this backend specifically, since
    eventlet's async_mode is used WITHOUT eventlet.monkey_patch() (see
    app.py's docstring/history), a long blocking subprocess call in the
    request thread stalls the entire Flask/SocketIO process, not just
    this one request - every other API route and socket message queues
    up behind it. That's a very plausible explanation for testers
    reporting "stuck on Connecting... forever, no error" - they likely
    gave up watching before nmcli's own worst-case timeout ever
    resolved.

    A plain threading.Thread (not an eventlet greenlet) sidesteps that
    specific problem without requiring the broader, riskier
    monkey_patch() change: a real OS thread runs independently of
    eventlet's single-threaded hub, so it can't block other requests
    the way an unpatched blocking call in the request thread does.

    The actual result is delivered via the "wifi_connect_result" socket
    event once the background thread finishes - see
    _run_wifi_connect() below. _wifi_connect_lock prevents two
    overlapping attempts from both mutating NetworkManager state at
    once (each doing its own teardown/delete/add/up against the same
    profile name would be a real mess).
    """
    data = request.get_json(force=True, silent=True) or {}
    ssid = (data.get("ssid") or "").strip()
    password = data.get("password") or ""

    if not ssid:
        return jsonify({"ok": False, "error": "SSID is required"}), 400

    if not _wifi_connect_lock.acquire(blocking=False):
        return jsonify({"ok": False, "error": "a connection attempt is already in progress"}), 409

    thread = threading.Thread(
        target=_run_wifi_connect, args=(ssid, password), daemon=True,
    )
    thread.start()
    return jsonify({"ok": True, "pending": True})


def _run_wifi_connect(ssid, password):
    """Runs on a background thread, started by wifi_connect() above - see
    that route's docstring for why. Always releases _wifi_connect_lock
    and always emits a "wifi_connect_result" event, even on an
    unexpected exception, so the frontend modal can never be left
    spinning forever no matter what goes wrong here."""
    try:
        try:
            ok, message = wifi_manager.connect(ssid, password)
        except wifi_manager.WifiError as e:
            ok, message = False, str(e)
        except Exception as e:  # noqa: BLE001 - must not leave the UI hanging
            ok, message = False, f"unexpected error: {e}"

        status = wifi_manager.get_status()
        socketio.emit("wifi_status", status)
        socketio.emit("wifi_connect_result", {
            # attempted_ssid identifies which connect() call this result
            # belongs to (for the frontend modal to match against) -
            # deliberately NOT the same field as status's own "ssid",
            # which means "currently connected network" and must stay
            # authoritative: on a failed attempt these two can rightly
            # differ (e.g. still on the old network, or on nothing).
            "ok": ok, "error": None if ok else message,
            "attempted_ssid": ssid, **status,
        })
    finally:
        _wifi_connect_lock.release()


@app.route("/api/wifi/enabled", methods=["POST"])
def wifi_enabled():
    """
    "WiFi enabled" in the settings UI means: connected to a home network
    (on) vs. disconnected and running the PinClock-Setup hotspot instead
    (off). It intentionally never disables the WiFi radio itself - see
    the big warning in wifi_manager.py's docstring for why (short
    version: doing that once already locked a Pi out of both WiFi and
    SSH until someone re-imaged the SD card).

    The actual network change is scheduled a moment after this responds,
    not run inline - if the caller's own HTTP connection is riding over
    the very WiFi link about to come down (the normal case: someone using
    their phone on the home network to reach /control), doing it inline
    risks the response never making it back before the link drops. This
    way the browser gets its "ok" first and the transition happens
    (briefly) after.
    """
    data = request.get_json(force=True, silent=True) or {}
    enabled = bool(data.get("enabled"))

    def _apply():
        try:
            if enabled:
                ok, message = wifi_manager.reconnect_client()
            else:
                ok, message = wifi_manager.disconnect_to_hotspot()
        except Exception as e:
            # Whatever went wrong, this runs in a detached background
            # thread with no HTTP response left to return it through - if
            # we don't catch it here it just vanishes into the Flask
            # process's stderr and the settings UI never finds out.
            ok, message = False, str(e)
        socketio.emit("wifi_status", {**wifi_manager.get_status(), "last_error": None if ok else message})

    threading.Timer(1.0, _apply).start()
    return jsonify({"ok": True, "pending": True})


@app.route("/api/wifi/forget", methods=["POST"])
def wifi_forget():
    ok, message = wifi_manager.forget()
    status = wifi_manager.get_status()
    socketio.emit("wifi_status", {**status, "last_error": None if ok else message})
    if not ok:
        return jsonify({"ok": False, "error": message, **status}), 500
    return jsonify({"ok": True, **status})


@app.route("/api/wifi/exit-hotspot", methods=["POST"])
def wifi_exit_hotspot():
    """
    Disconnects THE CALLER's own device from this Pi's setup hotspot -
    triggered by the settings page's own idle timer (10 min of no
    interaction, see control.html's hotspotIdleTimer) or its
    "Disconnect now" button - so a phone that's done with setup, or just
    left idle, falls off the hotspot and lets its own OS auto-reconnect
    to its known network.

    Deliberately does NOT touch the hotspot itself - it stays up,
    unaffected, ready for the next device. Only drops the ONE client
    making this request, identified by its own source IP - no separate
    session/identity tracking needed, since a client can only ever ask
    to kick itself. See wifi_manager.kick_hotspot_client() for the full
    reasoning, including why this replaced an earlier design built on
    reconnect_client() that had a real device-stranding risk.
    """
    ok, message = wifi_manager.kick_hotspot_client(request.remote_addr)
    return jsonify({"ok": ok, "message": message})


@app.route("/api/qr/settings.png", methods=["GET"])
def qr_settings():
    """A QR code encoding this device's stable mDNS settings URL - see
    _hostname_url(). Shown on the physical display for a window after
    boot once WiFi is connected, so someone can scan their way to the
    control page without needing to know or type an IP address."""
    png = _qr_png_bytes(_hostname_url())
    return send_file(io.BytesIO(png), mimetype="image/png")


@app.route("/api/qr/wifi-join.png", methods=["GET"])
def qr_wifi_join():
    """
    A QR code encoding a direct "join this hotspot" WiFi payload, in the
    standard WIFI:S:<ssid>;T:<auth>;P:<password>;; format phones
    recognize. Dynamic per device as of v0.13.0 (wifi_manager.HOTSPOT_SSID
    is now unique per device, derived from the CPU serial) - this used to
    be a static pre-baked PNG (app/static/img/wifi-join-qr.png,  removed
    this version) encoding the old shared "PinClock-Setup" SSID, which
    would now be silently wrong on every device.

    T:nopass marks it as an open network, matching ensure_hotspot()'s
    actual security config (no P: field needed for an open network).
    """
    payload = f"WIFI:S:{wifi_manager.HOTSPOT_SSID};T:nopass;;"
    png = _qr_png_bytes(payload)
    return send_file(io.BytesIO(png), mimetype="image/png")


# ----------------------------------------------------------- system ------
def _system_status_payload(state=None):
    state = state or system_state.get_state()
    return {
        "time_valid": state["time_valid"],
        "demo_mode": not state["time_valid"],
        "time_source": state["time_source"],
        "control_page_loaded": _control_page_loaded,
        "version": PINCLOCK_VERSION,
        "playlist_empty": len(store.get_playlist()) == 0,
    }


@app.route("/api/system/status", methods=["GET"])
def system_status():
    return jsonify(_system_status_payload())


@app.route("/api/system/storage", methods=["GET"])
def system_storage():
    """My Videos tab's "disk space remaining" line. DATA_DIR is used as
    the statvfs target (not VIDEOS_DIR specifically) since paths.py
    requires DATA_DIR and APP_DIR to share a filesystem anyway - see its
    module docstring - so this reflects the space actually available to
    new uploads regardless of which subdirectory they land in."""
    try:
        usage = shutil.disk_usage(str(DATA_DIR))
        return jsonify({"total": usage.total, "used": usage.used, "free": usage.free})
    except OSError as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/system/sleep-status", methods=["GET"])
def system_sleep_status():
    """Same info as the "sleep_status" socket event, as a plain GET -
    display.html's initial page load uses this (same pattern as
    loadSystemStatus()/loadWifiStatus()) so the page reflects sleep state
    immediately rather than waiting for the socket to connect and the
    backend to emit on_connect()."""
    return jsonify({"asleep": _is_asleep})


@app.route("/api/system/reboot", methods=["POST"])
def system_reboot():
    """
    Responds first, then reboots a moment later - same reasoning as
    /api/wifi/enabled: if this request is the last thing the browser
    hears from the Pi for a while, better that it actually got the "ok"
    response before the reboot begins tearing things down.
    """
    def _do_reboot():
        subprocess.run(["sudo", "systemctl", "reboot"])

    threading.Timer(1.0, _do_reboot).start()
    return jsonify({"ok": True, "pending": True})


@app.route("/api/system/reset-defaults", methods=["POST"])
def system_reset_defaults():
    """
    Device tab's "Default settings" - display settings back to
    DEFAULT_SETTINGS, WiFi forgotten, time/demo state cleared, then
    reboot so it actually comes up the way a first-time user would see
    it rather than just silently changing state underneath a still-running
    session.
    """
    store.reset_to_defaults()
    wifi_ok, wifi_message = wifi_manager.forget()
    if not wifi_ok:
        # Still proceed with the reboot (the person already confirmed
        # this action, and settings/state are reset regardless) - but
        # this needs to actually be visible somewhere, since by the time
        # anyone could look at a response the reboot may already have
        # happened. See /tmp/pinclock-flask.log.
        print(f"[reset-defaults] WARNING: wifi_manager.forget() reported: {wifi_message}")
    system_state.reset_to_defaults()

    def _do_reboot():
        subprocess.run(["sudo", "systemctl", "reboot"])

    threading.Timer(1.5, _do_reboot).start()
    return jsonify({"ok": True, "pending": True, "wifi_forgotten": wifi_ok, "wifi_message": wifi_message})


# ---------------------------------------------------- firmware update -----
# run_update.py deliberately lives at a fixed path outside any versioned
# release directory (see that script's own docstring for why) - app.py
# must always reference it there directly, never relative to its own
# __file__, since app.py itself is what may be running from inside a
# versioned release directory once the blue-green layout is in use.
RUN_UPDATE_SCRIPT = "/opt/pinclock/updater/run_update.py"
UPDATE_STATUS_FILE = DATA_DIR / "update_status.json"


@app.route("/api/firmware/check", methods=["GET"])
def firmware_check():
    """
    Device tab's "Check for Firmware Update" - read-only, no side
    effects. Runs run_update.py as a separate process rather than
    importing it (see RUN_UPDATE_SCRIPT comment and that script's own
    module docstring) so this stays fully decoupled from the actual
    update/rollback machinery.
    """
    try:
        result = subprocess.run(
            ["/usr/bin/python3", RUN_UPDATE_SCRIPT, "--check"],
            capture_output=True, text=True, timeout=20,
        )
    except OSError as e:
        return jsonify({"ok": False, "error": f"could not run update checker: {e}"}), 500
    except Exception as e:
        # Not `except subprocess.SubprocessError` - see the identity-
        # mismatch note in wifi_manager.py's _run(). SubprocessError is
        # TimeoutExpired's own parent class and confirmed to have the
        # exact same problem under eventlet.monkey_patch(), so this
        # checks by name instead for the same reason. Anything that
        # isn't actually a subprocess error still re-raises unchanged.
        if type(e).__name__ in ("SubprocessError", "TimeoutExpired"):
            return jsonify({"ok": False, "error": f"could not run update checker: {e}"}), 500
        raise

    try:
        payload = json.loads(result.stdout)
    except json.JSONDecodeError:
        return jsonify({"ok": False, "error": result.stderr.strip() or "invalid response from update checker"}), 502

    if "error" in payload:
        return jsonify({"ok": False, "error": payload["error"]}), 502
    return jsonify({"ok": True, **payload})


@app.route("/api/firmware/update", methods=["POST"])
def firmware_update():
    """
    Device tab's "Update Firmware" - fires the update off as a separate
    systemd --user unit (pinclock-update.service) and returns
    immediately. The actual download/verify/stage/swap/restart/
    health-check/rollback sequence - including restarting
    pinclock.service, which this very request handler is running
    inside of - happens entirely outside this request. Poll
    /api/firmware/update-status for progress. See scripts/run_update.py.

    --no-block is not optional here, despite this docstring (and the
    original one) having always claimed "returns immediately" - without
    it, `systemctl start` on a Type=oneshot unit blocks until the unit
    finishes running ENTIRELY, since systemd only considers a oneshot
    unit "started" once its ExecStart process exits. That means this
    handler would block for the update's full duration - and partway
    through, run_update.py restarts pinclock.service, killing the very
    worker process that's sitting here blocked waiting for it, severing
    the browser's connection with no response ever sent (surfacing as a
    raw network failure, "couldn't reach the device", even though the
    update itself likely completed successfully in the background
    regardless). --no-block makes systemctl return as soon as the job
    is queued, matching what this was always supposed to do.

    No sudo needed here (unlike /api/system/reboot): pinclock-update.
    service is a *user* unit, same as pinclock.service - this is just
    vfw's own systemd --user instance starting one of its own units,
    not a privileged operation.
    """
    result = subprocess.run(
        ["systemctl", "--user", "start", "--no-block", "pinclock-update.service"],
        capture_output=True, text=True, timeout=10,
    )
    if result.returncode != 0:
        return jsonify({
            "ok": False,
            "error": result.stderr.strip() or "failed to start pinclock-update.service",
        }), 500
    return jsonify({"ok": True, "pending": True})


@app.route("/api/firmware/update-status", methods=["GET"])
def firmware_update_status():
    """
    Polled by the control page while an update OR a factory reset is in
    flight - the response includes an "operation" field ("update" vs
    "factory_reset") since both share this same status file (see
    run_update.py's _write_status), so the UI can label progress
    correctly regardless of which one triggered it.

    Reads the status file run_update.py writes as it goes - this can't
    just be a synchronous response to /api/firmware/update or
    /api/system/factory-reset because that request's own Flask process
    gets restarted partway through the sequence it triggers.
    """
    if not UPDATE_STATUS_FILE.exists():
        return jsonify({"state": "idle"})
    try:
        with open(UPDATE_STATUS_FILE, "r") as f:
            return jsonify(json.load(f))
    except (OSError, json.JSONDecodeError):
        return jsonify({"state": "unknown", "message": "could not read update status file"})


@app.route("/api/system/factory-reset", methods=["POST"])
def system_factory_reset():
    """
    Device tab's "Factory Reset" - restores code + labwc config from the
    blessed factory snapshot (see scripts/bless_factory.py), verified
    and health-checked the same way an update is, then resets settings/
    WiFi/state and clears videos, then reboots. See
    scripts/run_update.py's run_factory_reset() for the full sequence.

    Fires as a separate systemd --user unit and returns immediately,
    same reasoning as /api/firmware/update - poll
    /api/firmware/update-status for progress (the "operation" field in
    its response will read "factory_reset").

    --no-block is required, not optional, for the same reason as
    /api/firmware/update: without it, `systemctl start` on this
    Type=oneshot unit blocks until run_factory_reset() finishes
    entirely, and that process restarts pinclock.service partway
    through - killing the very worker blocked here waiting for it.
    """
    result = subprocess.run(
        ["systemctl", "--user", "start", "--no-block", "pinclock-factory-reset.service"],
        capture_output=True, text=True, timeout=10,
    )
    if result.returncode != 0:
        return jsonify({
            "ok": False,
            "error": result.stderr.strip() or "failed to start pinclock-factory-reset.service",
        }), 500
    return jsonify({"ok": True, "pending": True})


# ------------------------------------------------------------ helpers -----
def _regenerate_and_reload_playlist(play_path=None):
    """Rebuilds the playlist file and hot-reloads mpv.

    Used to shell out to a fresh `python3 scripts/gen_playlist.py`
    subprocess every single call - correct, but spawning a whole new
    Python interpreter on a Pi Zero for something called after every
    single playlist edit (add one video, toggle randomize, etc.) added
    real, user-visible latency (several seconds) before mpv even got the
    reload command - almost certainly what was behind "adding a video
    does nothing for a few seconds". gen_playlist is now imported once
    (see the sys.path/import near the top of this file) and called
    in-process instead; its own docstring notes it's also run standalone
    via autostart at boot - that invocation is untouched, this only
    affects the live-reload path from inside the already-running Flask
    process.

    play_path, if given, is an absolute path to immediately jump
    playback to after reloading (used when a person explicitly taps
    "Add" on one specific video - see add_to_playlist_route() below) -
    a full reload alone doesn't guarantee that video is next, since it
    could land anywhere in the regenerated (and possibly shuffled) list.
    """
    config = gen_playlist.load_config(gen_playlist.CONFIG_PATH)
    settings = gen_playlist.load_settings(gen_playlist.SETTINGS_PATH)
    paths = gen_playlist.build_playlist(config, settings)
    gen_playlist.write_playlist(paths, gen_playlist.PLAYLIST_PATH)
    try:
        mpv_ipc.reload_playlist(gen_playlist.PLAYLIST_PATH)
        if play_path:
            mpv_ipc.play_now(play_path)
    except mpv_ipc.MpvIPCError:
        pass


def _enforce_video_volume(cfg):
    """Keeps mpv's actual volume in sync with settings.json's saved
    video_volume - the single source of truth - by polling and
    correcting any drift, every broadcaster tick (~2s), forever.

    Replaces an earlier one-shot _apply_startup_volume() that only ran
    once, tied to THIS Flask process's own startup: it correctly fixed
    the original bug (mpv defaults to its own internal volume of 100 on
    a fresh process, regardless of settings.json), but only for the
    very first mpv process this Flask process ever talked to. If mpv
    itself gets restarted independently afterward - a crash-respawn, or
    someone manually killing/restarting it (e.g. while testing a manual
    code update, without also restarting pinclock.service) - the new mpv
    process starts back at its own default volume again, and nothing
    ever re-applied the saved value, since the one-shot task had already
    long since finished. Continuous polling catches that regardless of
    *why* mpv's volume drifted, rather than trying to detect every
    possible cause individually - one extra tiny IPC round-trip every
    ~2s to check, and it only actually issues a correction on genuine
    mismatch (harmless no-op otherwise, including while someone's
    actively dragging the volume slider, since post_settings() already
    applies each intermediate value directly and this would just be
    reinforcing the same value moments later).
    """
    try:
        target = cfg.get("video_volume", store.DEFAULT_SETTINGS["video_volume"])
        current = mpv_ipc.get_property("volume")
        # >=1 tolerance, not exact equality - mpv can report volume as a
        # float with tiny rounding noise (e.g. 79.99999) even when
        # nothing meaningful actually changed, which would otherwise
        # cause a pointless correction (and pointless log activity, if
        # this ever gets logging) every single tick forever.
        if current is not None and abs(current - target) >= 1:
            mpv_ipc.set_property("volume", target)
    except mpv_ipc.MpvIPCError:
        pass


# --------------------------------------------------------- sleep mode -----
# Edge-triggered: _apply_sleep_state() only actually touches mpv/the
# display when the desired state *changes* from what it was last time,
# even though _status_broadcaster below calls it on every 2s tick - so
# this isn't re-pausing an already-paused mpv or re-issuing wlr-randr
# every poll.
_is_asleep = False
_wlr_output_name = None  # cached after the first successful `wlr-randr` listing


def _detect_wlr_output():
    """Best-effort: parse the first output name out of a bare `wlr-randr`
    call (no args lists outputs, one per un-indented line, name first).

    UNVERIFIED ON REAL HARDWARE - written against wlr-randr's documented
    output format, not confirmed against this device's actual output name
    (e.g. "HDMI-A-1") or against whether pinclock.service's systemd --user
    context even has WAYLAND_DISPLAY/XDG_RUNTIME_DIR set - those are
    exported in ~/.config/labwc/autostart (see PINCLOCK_MPV_SOCKET etc.
    nearby there), which runs *inside* the compositor session, whereas
    pinclock.service is a separately-managed systemd --user unit that may
    or may not inherit them depending on how the user session/systemd
    are wired together on this image. Needs confirming on real hardware
    (`systemctl --user show-environment` while pinclock.service is
    running would answer it) - flagging rather than guessing further.
    If this returns None, sleep mode still works (mpv pause + canvas
    blank cover the CPU/visual side); it just won't also power off the
    physical HDMI output."""
    global _wlr_output_name
    if _wlr_output_name:
        return _wlr_output_name
    try:
        result = subprocess.run(["wlr-randr"], capture_output=True, text=True, timeout=5)
        if result.returncode != 0:
            return None
        for line in result.stdout.splitlines():
            if line and not line[0].isspace():
                _wlr_output_name = line.split()[0]
                return _wlr_output_name
    except Exception:
        pass
    return None


def _set_display_power(on):
    """Best-effort HDMI power via wlr-randr - see _detect_wlr_output's
    docstring on why this is unverified. Never raises; a failure here
    just means the physical output stays powered while everything else
    about sleep mode (mpv paused, canvas blanked) still applies."""
    name = _detect_wlr_output()
    if not name:
        return
    try:
        subprocess.run(
            ["wlr-randr", "--output", name, "--on" if on else "--off"],
            capture_output=True, timeout=5,
        )
    except Exception:
        pass


def _apply_sleep_state(settings=None):
    """Computes the desired sleep state from settings and, if it changed
    since the last call, applies it: pauses/unpauses mpv (cuts decode
    CPU - the "minimal processing" half of the request), best-effort
    HDMI power, and a socket broadcast so display.js blanks its canvas to
    solid black immediately rather than waiting on the other two (which
    can be slow or silently no-op if wlr-randr isn't cooperating)."""
    global _is_asleep
    settings = settings if settings is not None else store.load_settings()
    desired = sleep_manager.is_asleep(settings)
    if desired == _is_asleep:
        return desired
    _is_asleep = desired
    try:
        mpv_ipc.set_pause(desired)
    except mpv_ipc.MpvIPCError:
        pass
    _set_display_power(not desired)
    socketio.emit("sleep_status", {"asleep": desired})
    return desired


# ----------------------------------------------------------- socket.io ----
def _status_broadcaster():
    last_status = None
    last_settings = None
    last_system = None
    last_wifi = None
    # Tracked separately from last_status - status_update fires on *any*
    # change (including time-pos ticking every couple seconds while
    # playing, so it's noisy), but "a new video started" needs its own
    # edge-triggered event so display.js can show a one-shot "now
    # playing" banner without re-parsing the whole status blob itself
    # or re-showing it every broadcast tick.
    last_video_name = None
    while True:
        st = mpv_ipc.get_status()
        if st != last_status:
            socketio.emit("status_update", st)
            last_status = st

        video_name = st.get("video")
        if video_name != last_video_name:
            last_video_name = video_name
            if video_name:
                socketio.emit("video_changed", {"name": video_name})

        cfg = store.load_settings()
        if cfg != last_settings:
            socketio.emit("settings_updated", cfg)
            last_settings = cfg

        _apply_sleep_state(cfg)
        _enforce_video_volume(cfg)

        # Poll NTP sync state - this is how demo mode clears itself once
        # WiFi comes up and the clock catches an NTP sync, with no action
        # needed from the settings UI.
        sys_state = system_state.poll()
        sys_payload = _system_status_payload(sys_state)
        if sys_payload != last_system:
            socketio.emit("system_status", sys_payload)
            last_system = sys_payload

        wifi_st = wifi_manager.get_status()
        if wifi_st != last_wifi:
            socketio.emit("wifi_status", wifi_st)
            last_wifi = wifi_st

        socketio.sleep(2)


@socketio.on("connect")
def on_connect():
    socketio.emit("settings_updated", store.load_settings())
    socketio.emit("status_update", mpv_ipc.get_status())
    socketio.emit("videos_updated", {})
    socketio.emit("system_status", _system_status_payload())
    socketio.emit("wifi_status", wifi_manager.get_status())
    socketio.emit("sleep_status", {"asleep": _is_asleep})


def main():
    system_state.recheck_on_startup()
    socketio.start_background_task(_status_broadcaster)
    socketio.run(app, host="0.0.0.0", port=5000)


if __name__ == "__main__":
    main()
