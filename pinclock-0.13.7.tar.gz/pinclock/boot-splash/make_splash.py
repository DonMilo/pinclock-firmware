"""
PinClock - boot splash generator.

Produces a static 1920x1080 PNG shown by swaybg the instant the Wayland
session starts, before Flask/mpv/Cog exist - the whole point is showing
*something* branded within a couple seconds of power-on, rather than a
blank screen through the 30s+ startup chain that follows.

Edit COMPANY_NAME below (and swap in a real logo instead of text, if you
have one) and rerun this to regenerate splash.png.
"""
from PIL import Image, ImageDraw, ImageFont

W, H = 1920, 1080

PRODUCT_NAME = "PinClock"
COMPANY_NAME = "YOUR COMPANY NAME"   # <-- edit this
VERSION = "v0.6.0"                  # <-- keep in sync with PINCLOCK_VERSION

BG = (8, 8, 12)
FG_PRIMARY = (255, 255, 255)
FG_SECONDARY = (140, 140, 150)
FG_TERTIARY = (90, 90, 100)
ACCENT = (80, 170, 255)

FONT_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FONT_REGULAR = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"


def load_font(path, size):
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        return ImageFont.load_default()


def center_text(draw, text, font, y, fill):
    bbox = draw.textbbox((0, 0), text, font=font)
    w = bbox[2] - bbox[0]
    draw.text(((W - w) / 2, y), text, font=font, fill=fill)
    return bbox[3] - bbox[1]  # height, for stacking


def build():
    img = Image.new("RGB", (W, H), BG)
    draw = ImageDraw.Draw(img)

    # A simple accent bar above the wordmark - swap for a real logo image
    # here later with img.paste(logo, (x, y), logo) if you have one.
    bar_w, bar_h = 140, 8
    draw.rectangle(
        [(W - bar_w) / 2, 300, (W + bar_w) / 2, 300 + bar_h], fill=ACCENT
    )

    center_text(draw, PRODUCT_NAME, load_font(FONT_BOLD, 220), 360, FG_PRIMARY)
    center_text(draw, COMPANY_NAME, load_font(FONT_REGULAR, 54), 620, FG_SECONDARY)
    center_text(draw, VERSION, load_font(FONT_REGULAR, 36), 960, FG_TERTIARY)

    img.save("splash.png")
    print("wrote splash.png")


if __name__ == "__main__":
    build()
