#!/usr/bin/env python3
"""
PinClock - Playlist Generator

Writes an .m3u playlist for mpv from the explicit, curated playlist
stored in settings.json's "playlist" key - an ORDERED list of
{"name": ..., "source": "user"|"shipped"} entries, maintained by the
control panel's Current Playlist / My Videos / Stock tabs (see app.py's
/api/playlist* endpoints and app/core/settings_store.py's
add_to_playlist/remove_from_playlist). This is NOT "everything in some
folder" - only videos explicitly added to the playlist play; My Videos
and Stock are just browsing/management views over what's available to
add. Order is alphabetical-at-add-time by default (whatever order
entries were appended in); set "randomize": true to shuffle instead.

Called by labwc autostart before mpv is launched, and can also be
called again later (e.g. after a playlist change) followed by an mpv
`playlist-clear` + `loadlist` over IPC to pick up changes live.

Two video sources, resolved independently of settings_store.py's own
import chain since this script runs standalone via autostart, not
through app.py:
  - user videos: config.json's videos.path (normally DATA_DIR/videos)
  - shipped videos: SHIPPED_VIDEOS_DIR below - a fixed, persistent
    location (NOT inside any versioned release - see
    app/core/paths.py's SHIPPED_VIDEOS_DIR for why)
"""

import json
import os
import random
import sys

CONFIG_PATH = os.environ.get(
    "PINCLOCK_CONFIG", "/home/vfw/pinclock-data/config.json"
)
SETTINGS_PATH = os.environ.get(
    "PINCLOCK_SETTINGS", "/home/vfw/pinclock-data/settings.json"
)
PLAYLIST_PATH = os.environ.get(
    "PINCLOCK_PLAYLIST", "/tmp/pinclock-playlist.m3u"
)
# Fixed, persistent location - NOT relative to this script's own
# versioned location (see app/core/paths.py's SHIPPED_VIDEOS_DIR for
# the full reasoning - this must match that module's value exactly,
# though the two are declared independently rather than one importing
# the other, since this script runs standalone via autostart).
SHIPPED_VIDEOS_DIR = os.environ.get(
    "PINCLOCK_SHIPPED_VIDEOS", "/opt/pinclock/shipped-videos"
)


def load_config(path):
    with open(path, "r") as f:
        return json.load(f)


def load_settings(path):
    try:
        with open(path, "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def _source_dir(source, user_videos_dir):
    return user_videos_dir if source == "user" else SHIPPED_VIDEOS_DIR


def build_playlist(config, settings):
    videos_cfg = config.get("videos", {})
    user_videos_dir = videos_cfg.get("path", "/home/vfw/pinclock-data/videos")
    randomize = bool(settings.get("randomize", videos_cfg.get("randomize", False)))
    entries = settings.get("playlist", [])

    files = []
    for entry in entries:
        name = entry.get("name")
        source = entry.get("source")
        if not name or source not in ("user", "shipped"):
            continue
        full_path = os.path.join(_source_dir(source, user_videos_dir), name)
        if os.path.isfile(full_path):
            files.append(full_path)
        else:
            # Stale entry (file removed outside the app, e.g. directly
            # via SSH) - settings_store.get_playlist() self-heals these
            # out of settings.json on next read through the API, but
            # this script runs standalone and shouldn't write back to
            # settings.json itself - just skip it for this playlist.
            print(f"[gen_playlist] skipping missing file: {full_path}", file=sys.stderr)

    if not files:
        print("[gen_playlist] playlist is empty (no videos added yet, or all entries stale)", file=sys.stderr)
        return []

    if randomize:
        random.shuffle(files)

    return files


def write_playlist(paths, out_path):
    with open(out_path, "w") as f:
        for p in paths:
            f.write(p + "\n")


def main():
    config = load_config(CONFIG_PATH)
    settings = load_settings(SETTINGS_PATH)
    paths = build_playlist(config, settings)
    write_playlist(paths, PLAYLIST_PATH)
    print(f"[gen_playlist] wrote {len(paths)} entries to {PLAYLIST_PATH}")


if __name__ == "__main__":
    main()
