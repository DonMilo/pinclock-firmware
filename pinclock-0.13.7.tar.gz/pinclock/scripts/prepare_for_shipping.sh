#!/bin/sh
#########################################################
# PinClock - prepare for shipping / imaging
#
# Run this on the Pi (as root, e.g. `sudo sh scripts/prepare_for_shipping.sh`)
# right before you clone the SD card or hand the device to someone else.
# It clears:
#   1. PinClock's own record of your WiFi (config.json, state.json)
#   2. The NetworkManager WiFi connection profile itself (which holds
#      the actual PSK) - found dynamically, not hardcoded, so this works
#      whether the profile is netplan-managed (e.g. "netplan-wlan0-xxxx")
#      or one PinClock's own WiFi tab created (named after the SSID).
#
# What this does NOT do, because it's genuinely device/image-specific and
# risky to script blindly:
#   - Edit netplan's *source* YAML (e.g. /etc/netplan/50-cloud-init.yaml).
#     If your WiFi was set up there rather than through PinClock's own
#     WiFi tab, NetworkManager will just recreate the same
#     "netplan-wlan0-*" profile (with your real SSID/password) again on
#     the next boot, undoing step 2 above. See the printed reminder at
#     the end - you likely want to strip the `wifis:` block from that
#     file entirely and let the new hotspot/WiFi-tab flow handle first
#     boot setup instead.
#   - Regenerate SSH host keys. Standard "prepare a golden image" step,
#     but out of scope here - handle separately if you're distributing
#     this image.
#
# What THIS script DOES now also handle (added after finding a real,
# live device still carrying the shared machine-id from before this was
# automated - see steps 3 and 4 below):
#   - Clear /etc/machine-id, so every future clone gets its own unique
#     one instead of silently inheriting this device's - the same
#     "cloned image, needs to look different per device" problem
#     device_identity.py already solves for hostname/hotspot SSID, but
#     machine-id doesn't have a live-hardware source to self-correct
#     from (unlike CPU serial) - it genuinely needs to be EMPTY at the
#     moment of capture so systemd's own first-boot detection can
#     regenerate a fresh one on each clone.
#   - Clear the persistent journal (/var/log/journal/) - partly for the
#     same "don't ship this exact device's own history to every clone"
#     reasoning, partly plain privacy (your own testing/WiFi/etc ends up
#     in there once persistent logging is on, per the journald
#     persistence fix - see etc-systemd-journald-conf-d/).
#########################################################

PINCLOCK_DATA_DIR="/home/vfw/pinclock-data"
CONFIG_FILE="$PINCLOCK_DATA_DIR/config.json"
STATE_FILE="$PINCLOCK_DATA_DIR/state.json"
IDENTITY_ENV="$PINCLOCK_DATA_DIR/device_identity.env"

echo "== PinClock: clearing WiFi credentials before shipping =="

# Per-device hotspot name (v0.13.0+, see
# /opt/pinclock/identity/device_identity.py) - falls back to the old
# shared name if this is an older device/image without it yet.
if [ -f "$IDENTITY_ENV" ]; then
    . "$IDENTITY_ENV"
fi
HOTSPOT_NAME="${PINCLOCK_HOTSPOT_SSID:-PinClock-Setup}"

# --- 1. NetworkManager profile(s) -----------------------------------------
# Anything of TYPE wifi that isn't our own open setup hotspot is a real
# network profile - delete every one of them, not just the current SSID,
# since old/forgotten ones from earlier testing can carry credentials too.
nmcli -t -f NAME,TYPE connection show 2>/dev/null | while IFS=: read -r name type; do
    if [ "$type" = "wifi" ] && [ "$name" != "$HOTSPOT_NAME" ]; then
        echo "Deleting NetworkManager profile: $name"
        nmcli connection delete "$name" >/dev/null 2>&1
    fi
done

# --- 2. PinClock's own bookkeeping -----------------------------------------
if [ -f "$CONFIG_FILE" ]; then
    python3 - "$CONFIG_FILE" <<'PYEOF'
import json, sys
path = sys.argv[1]
with open(path) as f:
    cfg = json.load(f)
cfg["wifi"] = {"configured": False, "ssid": "", "connection_name": ""}
with open(path, "w") as f:
    json.dump(cfg, f, indent=2)
print(f"Cleared wifi section of {path}")
PYEOF
fi

if [ -f "$STATE_FILE" ]; then
    rm -f "$STATE_FILE"
    echo "Removed $STATE_FILE (demo-mode/time state - regenerates fresh on next boot)"
fi

# --- 3. machine-id -----------------------------------------------------
# truncate, NOT delete-and-regenerate - the goal is to leave it EMPTY at
# capture time, not to give THIS device a fresh id right now. An empty
# /etc/machine-id is what makes systemd treat the NEXT boot as a genuine
# first boot (ConditionFirstBoot=) and generate a fresh, unique id then -
# on every clone independently, since each one's "next boot" is its own.
# Regenerating immediately here would just bake ONE new (but still
# shared-across-every-clone) id into the image, solving nothing.
echo
echo "Clearing /etc/machine-id (will regenerate fresh on next boot)..."
truncate -s 0 /etc/machine-id

# /var/lib/dbus/machine-id is a symlink to /etc/machine-id on most
# Debian-derived systems (nothing more to do there) - but handle the
# case where it's a real, separate file defensively rather than assume.
if [ -f /var/lib/dbus/machine-id ] && [ ! -L /var/lib/dbus/machine-id ]; then
    truncate -s 0 /var/lib/dbus/machine-id
    echo "Also cleared /var/lib/dbus/machine-id (real file, not a symlink here)"
fi

# --- 4. persistent journal ----------------------------------------------
# The journal directory is literally named after the machine-id being
# cleared above (/var/log/journal/<machine-id>/) - once that id is gone,
# journald creates a fresh directory under whatever id each clone
# generates for itself at first boot regardless, so this isn't strictly
# required for correctness. It's here for a different reason: with
# persistent journal storage on (see etc-systemd-journald-conf-d/), this
# directory accumulates real logs from YOUR OWN testing - WiFi activity,
# hostnames, whatever else - that has no business shipping to a
# customer's device.
if [ -d /var/log/journal ]; then
    echo "Clearing persistent journal logs..."
    rm -rf /var/log/journal/*
fi

echo
echo "== Done clearing what's safe to automate. =="
echo
echo "IMPORTANT: if your WiFi was originally set up via the Pi's initial"
echo "imaging/setup tool (not PinClock's own WiFi tab), it likely also"
echo "lives in a netplan YAML file, e.g.:"
echo
echo "  grep -rl 'wifis:' /etc/netplan/"
echo
echo "Open whatever file that finds and remove the wifis: block (or just"
echo "the access-points/password lines) before imaging - otherwise"
echo "NetworkManager will recreate the same profile with your real"
echo "credentials on the next boot, undoing the cleanup above. With that"
echo "block removed, a fresh boot will have no saved WiFi at all and will"
echo "fall straight into the PinClock-Setup hotspot, which is exactly the"
echo "flow the next owner should use to set up their own WiFi."
echo
echo "======================================================="
echo "  IMPORTANT: power off, do NOT reboot, before imaging"
echo "======================================================="
echo "A reboot would immediately regenerate a machine-id right now, on"
echo "THIS device, before you ever get to cloning it - which just bakes"
echo "a single new (but still shared-across-every-future-clone) id into"
echo "the image, right back where this step started. Once you've checked"
echo "the netplan file above, run:"
echo
echo "  sudo poweroff"
echo
echo "then pull the card and image it from there."
