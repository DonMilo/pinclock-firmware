#!/bin/sh
#########################################################
# PinClock - boot-time network fallback
#
# NetworkManager already auto-connects to any saved WiFi profile on its
# own. This script's only job is the fallback: if we're not online a few
# seconds after boot (no saved network, wrong password, out of range,
# etc.), bring up the "PinClock-Setup" open hotspot at 10.42.0.1 so the
# settings page is still reachable from a phone. Flask/system_state.py
# independently decides demo-mode from whether the clock has a valid
# time - this script only deals with getting *a* network path back up.
#
# Called from labwc autostart, before Flask/mpv/Cog start - see
# .config/labwc/autostart. Idempotent: safe to run every boot.
#########################################################

WAIT_SECONDS=20
POLL_INTERVAL=2
HOTSPOT_ADDR="10.42.0.1/24"
IFACE="wlan0"

# Per-device identity (v0.13.0+) - written by
# /opt/pinclock/identity/device_identity.py, which autostart runs
# synchronously right before this script. Sourcing it directly (rather
# than parsing JSON in POSIX sh) gives PINCLOCK_HOTSPOT_SSID and
# PINCLOCK_DEVICE_HOSTNAME. Falls back to the old shared name if the
# file is missing for any reason (identity script failed, or this is
# running standalone/pre-v0.13.0) - degrades gracefully rather than
# failing the whole fallback flow over it.
IDENTITY_ENV="/home/vfw/pinclock-data/device_identity.env"
if [ -f "$IDENTITY_ENV" ]; then
    . "$IDENTITY_ENV"
fi
HOTSPOT_SSID="${PINCLOCK_HOTSPOT_SSID:-PinClock-Setup}"
HOTSPOT_NAME="$HOTSPOT_SSID"

# Every nmcli call here goes through sudo (passwordless, see
# sudoers/pinclock-nmcli) since this runs as the vfw user, same reasoning
# as app/core/wifi_manager.py: NetworkManager's polkit checks turned out
# to authorize some actions (radio) but not others (connection add)
# without a way to pin down the exact mismatch remotely, so sudo (root
# bypasses NM's polkit checks entirely) is what's actually wired up.

elapsed=0
connected=0
while [ "$elapsed" -lt "$WAIT_SECONDS" ]; do
    state=$(sudo nmcli -t -f DEVICE,STATE device status 2>/dev/null | grep "^${IFACE}:" | cut -d: -f2)
    if [ "$state" = "connected" ]; then
        connected=1
        break
    fi
    sleep "$POLL_INTERVAL"
    elapsed=$((elapsed + POLL_INTERVAL))
done

if [ "$connected" = "1" ]; then
    echo "[network_boot] WiFi connected, no hotspot needed"
    exit 0
fi

echo "[network_boot] no WiFi after ${WAIT_SECONDS}s, bringing up setup hotspot"

if sudo nmcli -t -f NAME connection show | grep -qx "$HOTSPOT_NAME"; then
    sudo nmcli connection delete "$HOTSPOT_NAME" >/dev/null 2>&1
fi

sudo nmcli connection add \
    type wifi \
    ifname "$IFACE" \
    con-name "$HOTSPOT_NAME" \
    autoconnect yes \
    ssid "$HOTSPOT_SSID" \
    mode ap \
    ipv4.method shared \
    ipv4.addresses "$HOTSPOT_ADDR"

sudo nmcli connection up "$HOTSPOT_NAME"
