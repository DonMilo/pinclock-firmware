#!/usr/bin/env python3
"""
PinClock factory-blessing tool.

Run manually, via sudo, ONCE per device (or once per master SD image
at build time for future units) - never automatically, never as part
of an update. Snapshots the CURRENTLY RUNNING code + labwc system
config as the permanent "factory" baseline that scripts/run_update.py's
run_factory_reset() restores to, locked down read-only afterward.

Usage:
    sudo python3 scripts/bless_factory.py

WHY THIS MUST RUN AS ROOT (unlike everything else in this update
mechanism, which deliberately avoids needing new sudo grants):
the whole point of the factory snapshot is that it can't be
accidentally (or maliciously) modified or deleted by the same
unprivileged vfw account that runs the app day to day - that's what
makes "restore to factory" a meaningful safety net rather than just
another mutable copy sitting next to everything else. So this one
script is the deliberate exception: it locks the snapshot down to
root:root ownership, read-only permissions, right after writing it.

WHY THIS DOESN'T LIVE IN run_update.py: blessing is a rare, manually
reviewed, one-time action - the opposite of the automated, unattended
flow run_update.py exists for. Keeping it a separate script makes that
distinction obvious rather than adding a privileged code path to a
script that otherwise deliberately never needs to touch anything as
root.

WHAT GETS SNAPSHOTTED:
  - /opt/pinclock/current (resolved) -> /opt/pinclock-factory/<version>/pinclock/
  - ~/.config/labwc/autostart, ~/.config/labwc/environment
      -> /opt/pinclock-factory/<version>/labwc/{autostart,environment}
  - a release-manifest.json with sha256 of every file, same format
    run_update.py's _verify_release_files already knows how to check -
    so restoring is verified the same way installing an update is.

NOT snapshotted (deliberately): pinclock-data/ (settings/config/state/
videos) - that's user state, not "what it shipped with", and Factory
Reset already wipes it separately via the existing Default Settings
logic rather than restoring it from here.

REFUSES TO OVERWRITE AN EXISTING SNAPSHOT: a device should have exactly
one factory baseline for its whole lifetime (the version it actually
shipped with) - if you need to re-bless (e.g. you got the first one
wrong), remove the existing /opt/pinclock-factory/<version>/ manually
first, deliberately, rather than this script silently clobbering it.
"""
import hashlib
import json
import os
import shutil
import stat
import sys
from pathlib import Path

CURRENT_LINK = Path("/opt/pinclock/current")
FACTORY_ROOT = Path("/opt/pinclock-factory")
LABWC_DIR = Path("/home/vfw/.config/labwc")
OWNER_USER = "root"
OWNER_GROUP = "root"


class BlessError(Exception):
    pass


def _read_version(app_dir):
    app_py = app_dir / "app.py"
    if not app_py.exists():
        raise BlessError(f"{app_py} doesn't exist")
    import re
    m = re.search(r'^PINCLOCK_VERSION\s*=\s*["\'](.+?)["\']', app_py.read_text(), re.MULTILINE)
    if not m:
        raise BlessError(f"couldn't find PINCLOCK_VERSION in {app_py}")
    return m.group(1).lstrip("v")


def _sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _lock_down(path):
    """Read-only, root-owned - see module docstring for why."""
    for root, dirs, files in os.walk(path):
        for d in dirs:
            os.chown(os.path.join(root, d), 0, 0)
            os.chmod(os.path.join(root, d), 0o555)
        for f in files:
            os.chown(os.path.join(root, f), 0, 0)
            os.chmod(os.path.join(root, f), 0o444)
    os.chown(path, 0, 0)
    os.chmod(path, 0o555)


def bless():
    if os.geteuid() != 0:
        raise BlessError("must be run with sudo (see module docstring for why)")

    if not CURRENT_LINK.exists():
        raise BlessError(
            f"{CURRENT_LINK} doesn't exist - this device hasn't been migrated to the "
            f"blue-green layout yet (see scripts/migrate_to_blue_green.py)"
        )

    live_dir = CURRENT_LINK.resolve()
    version = _read_version(live_dir)
    print(f"Blessing currently-running version {version} as the factory baseline...")

    snapshot_dir = FACTORY_ROOT / version
    if snapshot_dir.exists():
        raise BlessError(
            f"{snapshot_dir} already exists - refusing to overwrite an existing factory "
            f"snapshot. If you genuinely need to re-bless, remove it manually first: "
            f"sudo rm -rf {snapshot_dir}"
        )

    snapshot_pinclock = snapshot_dir / "pinclock"
    print(f"Copying {live_dir} -> {snapshot_pinclock}...")
    snapshot_pinclock.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(
        live_dir, snapshot_pinclock,
        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".git"),
    )

    snapshot_labwc = snapshot_dir / "labwc"
    snapshot_labwc.mkdir(parents=True, exist_ok=True)
    for name in ("autostart", "environment"):
        src = LABWC_DIR / name
        if src.exists():
            print(f"Copying {src} -> {snapshot_labwc / name}...")
            shutil.copy2(src, snapshot_labwc / name)
        else:
            print(f"WARNING: {src} doesn't exist - skipping (factory reset will leave this file alone)")

    print("Computing checksums...")
    file_hashes = {}
    for p in snapshot_pinclock.rglob("*"):
        if p.is_file():
            rel = p.relative_to(snapshot_pinclock).as_posix()
            file_hashes[rel] = "sha256:" + _sha256_file(p)

    manifest = {"version": version, "files": file_hashes}
    manifest_path = snapshot_dir / "release-manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2))
    print(f"Wrote {manifest_path} ({len(file_hashes)} files)")

    print("Locking down snapshot as read-only, root-owned...")
    _lock_down(snapshot_dir)

    print()
    print(f"Factory snapshot for version {version} is ready at {snapshot_dir}")
    print("Factory Reset (see run_update.py's run_factory_reset) will restore to this from now on.")


if __name__ == "__main__":
    try:
        bless()
    except BlessError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)
