#!/usr/bin/env python3
"""
PinClock blue-green layout migration - ONE-TIME, run manually on the
device via SSH/console. Not part of any automated update, and not run
by run_update.py - this only ever needs to happen once, to move the
device from its original "one real directory" layout into the
versioned-release layout the update mechanism (see run_update.py)
expects.

BEFORE:
    /home/vfw/pinclock/            <- real directory: app.py, venv/, everything

AFTER:
    /opt/pinclock/releases/<version>/pinclock/   <- the same code, moved here
    /opt/pinclock/current -> releases/<version>/pinclock/
    /opt/pinclock/venv/                            <- venv, moved OUT separately (see below)
    /home/vfw/pinclock -> /opt/pinclock/current    <- compatibility symlink

WHY THE VENV MOVES OUT TOO:
build_release.py deliberately excludes venv/ from release tarballs
(it's a large, environment-specific virtualenv, not source code - see
that script's EXCLUDED_DIR_NAMES). A future release's staged directory,
extracted from a downloaded tarball, will therefore never contain a
venv/ of its own. If pinclock.service's ExecStart pointed at
<release>/venv/bin/python, it would break the instant any update ran.
So the venv gets a fixed, non-versioned home - /opt/pinclock/venv/ -
shared across every release, the same reasoning that put
pinclock-data/ outside the versioned app tree back in step 1.

KNOWN LIMITATION - not solved by this script or by run_update.py yet:
if a future release changes requirements.txt, nothing currently
re-installs the shared venv's dependencies during an update. That's
real follow-up work, not something to quietly paper over here.

WHY /home/vfw/pinclock BECOMES A SYMLINK RATHER THAN REWRITING EVERY
REFERENCE TO IT:
autostart, gen_playlist.py's fallback defaults, and the sudoers install
docs all hardcode /home/vfw/pinclock/... paths. A symlink there means
every one of those keeps working completely unchanged - resolution is
transparent through a symlink chain - so this migration doesn't need
to touch autostart, sudoers, or gen_playlist.py at all.
pinclock.service is the one thing updated to reference
/opt/pinclock/current directly rather than through this compatibility
symlink, since it's what most benefits from naming the real, current
location explicitly (visible in `systemctl status`, etc.)

Idempotent and safe to re-run if interrupted partway: every step
checks whether it's already done before acting, same philosophy as
paths.py's _migrate_legacy_data_dir from step 1.
"""
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

LIVE_APP_DIR = Path("/home/vfw/pinclock")  # the real directory, pre-migration
OPT_PINCLOCK = Path("/opt/pinclock")
RELEASES_DIR = OPT_PINCLOCK / "releases"
CURRENT_LINK = OPT_PINCLOCK / "current"
SHARED_VENV_DIR = OPT_PINCLOCK / "venv"


class MigrationError(Exception):
    pass


def _read_version(app_dir):
    app_py = app_dir / "app.py"
    if not app_py.exists():
        raise MigrationError(f"{app_py} doesn't exist")
    m = re.search(r'^PINCLOCK_VERSION\s*=\s*["\'](.+?)["\']', app_py.read_text(), re.MULTILINE)
    if not m:
        raise MigrationError(f"couldn't find PINCLOCK_VERSION in {app_py}")
    return m.group(1).lstrip("v")


def _atomic_symlink(link_path, target_path):
    tmp_link = link_path.with_name(link_path.name + ".tmp")
    if tmp_link.exists() or tmp_link.is_symlink():
        tmp_link.unlink()
    tmp_link.symlink_to(target_path)
    tmp_link.replace(link_path)  # atomic rename, same filesystem


def migrate():
    if LIVE_APP_DIR.is_symlink():
        print(f"{LIVE_APP_DIR} is already a symlink -> {os.readlink(LIVE_APP_DIR)} - nothing to do.")
        return

    if not LIVE_APP_DIR.is_dir():
        raise MigrationError(f"{LIVE_APP_DIR} doesn't exist or isn't a directory - nothing to migrate")

    if not OPT_PINCLOCK.exists() or not os.access(OPT_PINCLOCK, os.W_OK):
        raise MigrationError(
            f"{OPT_PINCLOCK} doesn't exist or isn't writable by this user. /opt/ is root-owned "
            f"by default, so this is a one-time setup step this script deliberately doesn't do "
            f"for you (it shouldn't need sudo for anything else it does). Run once, then re-run "
            f"this script:\n"
            f"    sudo mkdir -p {OPT_PINCLOCK}\n"
            f"    sudo chown {os.environ.get('USER', 'vfw')}:{os.environ.get('USER', 'vfw')} {OPT_PINCLOCK}"
        )

    version = _read_version(LIVE_APP_DIR)
    print(f"Detected running version: {version}")

    release_dir = RELEASES_DIR / version
    release_app_dir = release_dir / "pinclock"

    print("Stopping pinclock.service before moving its own working directory...")
    subprocess.run(["systemctl", "--user", "stop", "pinclock.service"], check=False)

    # Move the venv out first, into its own fixed, shared location.
    live_venv = LIVE_APP_DIR / "venv"
    if live_venv.exists() and not SHARED_VENV_DIR.exists():
        print(f"Moving {live_venv} -> {SHARED_VENV_DIR} (shared across all future releases)...")
        SHARED_VENV_DIR.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(live_venv), str(SHARED_VENV_DIR))
    elif SHARED_VENV_DIR.exists() and live_venv.exists():
        raise MigrationError(
            f"both {live_venv} and {SHARED_VENV_DIR} exist - refusing to guess which is "
            f"authoritative. This looks like an earlier attempt got partway through; "
            f"compare the two and remove whichever is stale, then re-run."
        )
    elif SHARED_VENV_DIR.exists():
        print(f"{SHARED_VENV_DIR} already exists and {live_venv} is already gone - venv move already done.")

    # Move the (now venv-less) app directory into the versioned release location.
    if release_app_dir.exists():
        raise MigrationError(
            f"{release_app_dir} already exists but {LIVE_APP_DIR} is still a real directory - "
            f"looks like an earlier attempt partially completed. Check both manually before "
            f"re-running (don't want to guess and possibly overwrite one with the other)."
        )
    release_dir.mkdir(parents=True, exist_ok=True)
    print(f"Moving {LIVE_APP_DIR} -> {release_app_dir}...")
    shutil.move(str(LIVE_APP_DIR), str(release_app_dir))

    print(f"Linking {CURRENT_LINK} -> {release_app_dir}...")
    _atomic_symlink(CURRENT_LINK, release_app_dir)

    print(f"Linking {LIVE_APP_DIR} -> {CURRENT_LINK} (compatibility symlink for autostart etc.)...")
    _atomic_symlink(LIVE_APP_DIR, CURRENT_LINK)

    print()
    print("Filesystem migration complete.")
    print("Next: install the updated pinclock.service (WorkingDirectory/ExecStart now point at")
    print("/opt/pinclock/current and /opt/pinclock/venv), then:")
    print("  systemctl --user daemon-reload")
    print("  systemctl --user start pinclock.service")
    print("  curl -sf http://127.0.0.1:5000 && echo OK")


if __name__ == "__main__":
    try:
        migrate()
    except MigrationError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)
