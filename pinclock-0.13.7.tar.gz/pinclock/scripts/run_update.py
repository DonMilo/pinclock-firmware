#!/usr/bin/env python3
"""
PinClock firmware update worker.

Run exclusively by pinclock-update.service (a oneshot systemd --user
unit) - never invoked directly by app.py. Flask only ever fires this
off via `systemctl --user start pinclock-update.service` and returns
immediately (see /api/firmware/update in app.py); this script owns the
actual download -> verify -> stage -> swap -> restart -> health-check
-> rollback sequence, running entirely outside the Flask process it
will end up restarting.

WHY THIS LIVES OUTSIDE /opt/pinclock/releases/<version>/ AND USES ONLY
THE PYTHON STDLIB:

This script is the thing responsible for recovering from a bad release.
If it were itself part of a versioned release (or depended on that
release's venv/dependencies), a botched release could take the updater
down along with the app, with nothing left outside the blast radius to
fix it. So run_update.py:
  - lives at a fixed path, /opt/pinclock/updater/run_update.py, deployed
    and updated separately from (and much more rarely than) app releases
  - uses only stdlib (urllib instead of requests, tarfile, hashlib,
    json) so it never depends on the app's venv or requirements.txt
  - hardcodes its own paths rather than importing core.paths from
    whatever release happens to be current, for the same reason

Progress is written to pinclock-data/update_status.json throughout,
which the control page polls (see /api/firmware/update-status) since
the Flask request that triggered this already returned long before any
of this runs.
"""
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path

DATA_DIR = Path("/home/vfw/pinclock-data")
RELEASES_DIR = Path("/opt/pinclock/releases")
CURRENT_LINK = Path("/opt/pinclock/current")
STATUS_FILE = DATA_DIR / "update_status.json"
LOCK_FILE = Path("/opt/pinclock/updater/.update.lock")

# Where scripts/bless_factory.py snapshots the originally-shipped code +
# system config to. Read-only from run_update.py's perspective - this
# script never writes here, only bless_factory.py (a separate, manually
# run, sudo-gated tool) does.
FACTORY_ROOT = Path("/opt/pinclock-factory")
LABWC_DIR = Path("/home/vfw/.config/labwc")

# Must match app/core/paths.py's SHIPPED_VIDEOS_DIR exactly - declared
# independently rather than one importing the other, since this script
# stays isolated from the app's own code (see module docstring). See
# _sync_shipped_videos_and_strip for why this lives outside any
# versioned release directory.
PERSISTENT_SHIPPED_VIDEOS_DIR = Path("/opt/pinclock/shipped-videos")

# Hosted, developer-controlled manifest. Deliberately not GitHub's own
# "latest release" API - that would mean anything tagged as a release
# is immediately live on every device with no separate gate. Publishing
# a new version means updating this file (a plain commit+push), which
# only happens once a release has actually been built and tested.
UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/DonMilo/pinclock-firmware/main/update-manifest.json"

HEALTHCHECK_URL = "http://127.0.0.1:5000/"
HEALTHCHECK_TIMEOUT_S = 15
HEALTHCHECK_POLL_INTERVAL_S = 1


class UpdateError(Exception):
    """Any failure that should abort the update and (if we'd already
    swapped) trigger a rollback."""


def _now_iso():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _atomic_write_json(path, data):
    """Same pattern as settings_store.atomic_write_json - deliberately
    reimplemented here rather than imported, per this module's own
    "don't depend on the release tree" rule."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(dir=str(path.parent), prefix=".tmp-", suffix=".json")
    try:
        with os.fdopen(fd, "w") as f:
            json.dump(data, f, indent=2)
        os.replace(tmp_path, str(path))
    except BaseException:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


def _write_status(state, from_version=None, to_version=None, message="", operation="update"):
    payload = {
        "operation": operation,
        "state": state,
        "from_version": from_version,
        "to_version": to_version,
        "message": message,
        "updated_at": _now_iso(),
    }
    try:
        _atomic_write_json(STATUS_FILE, payload)
    except OSError as e:
        # Status reporting is best-effort - never let a failure to write
        # the status file itself abort or mask the actual update result.
        print(f"[run_update] WARNING: could not write status file: {e}")
    print(f"[run_update] {state}: {message}")


def _current_version():
    """
    Reads PINCLOCK_VERSION straight from whichever release
    CURRENT_LINK points at right now - a plain file read, NOT a live
    HTTP call to Flask. This used to call Flask's own
    /api/system/status instead, reasoning that reading the file might
    reflect stale source rather than what's actually running - but
    that HTTP call created a real self-deadlock: /api/firmware/check
    runs `subprocess.run(["...", "--check"])` SYNCHRONOUSLY from
    inside a Flask request handler, blocking it until the subprocess
    exits. If that subprocess (this function, via check_for_update())
    then tries to HTTP GET back into that same blocked Flask process,
    the request has nowhere to be serviced from and just hangs until
    timeout - which is exactly what happened in practice (Check for
    Update reporting "current version unknown" every time).

    CURRENT_LINK always points at exactly the release Flask actually
    imported PINCLOCK_VERSION from at startup, so a file read here is
    exactly as accurate as asking Flask live, without the deadlock
    risk. See _current_version_live() for the one place that
    genuinely needs a real, live functional check instead of this.
    """
    if not CURRENT_LINK.exists():
        return None
    app_py = CURRENT_LINK.resolve() / "app.py"
    if not app_py.exists():
        return None
    m = re.search(r'^PINCLOCK_VERSION\s*=\s*["\'](.+?)["\']', app_py.read_text(), re.MULTILINE)
    return m.group(1).lstrip("v") if m else None


def _current_version_live():
    """
    Like _current_version(), but actually asks the running Flask
    process over HTTP instead of reading a file. Used ONLY after a
    restart, to verify the newly-swapped code genuinely came up and is
    serving requests correctly - a real functional check ("is this
    actually working"), not just "what does the symlink point at"
    (which would trivially always match, having already been
    checksum-verified earlier, making it useless as a health signal).

    Safe to call here specifically (unlike from _current_version()'s
    former implementation): nothing is synchronously blocked waiting
    on this call at this point in the flow - the Flask request that
    triggered the update already returned immediately (see
    /api/firmware/update), and this runs from the independent
    pinclock-update.service unit, not from inside a blocked handler.
    """
    try:
        with urllib.request.urlopen(f"{HEALTHCHECK_URL}api/system/status", timeout=5) as resp:
            data = json.loads(resp.read().decode())
            return data.get("version", "").lstrip("v")
    except (urllib.error.URLError, OSError, json.JSONDecodeError, ValueError):
        return None


def _fetch_json(url):
    try:
        with urllib.request.urlopen(url, timeout=15) as resp:
            return json.loads(resp.read().decode())
    except (urllib.error.URLError, OSError) as e:
        raise UpdateError(f"could not fetch {url}: {e}")
    except json.JSONDecodeError as e:
        raise UpdateError(f"{url} did not return valid JSON: {e}")


def _sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _download(url, dest_path):
    try:
        urllib.request.urlretrieve(url, str(dest_path))
    except (urllib.error.URLError, OSError) as e:
        raise UpdateError(f"download failed: {e}")


def check_for_update():
    """Read-only: fetch the hosted manifest, compare to the running
    version, report - no side effects. Used by /api/firmware/check."""
    current = _current_version()
    manifest = _fetch_json(UPDATE_MANIFEST_URL)
    latest = manifest.get("latest", "")
    return {
        "current": current,
        "latest": latest,
        "update_available": bool(current and latest and latest != current),
        "changelog": manifest.get("changelog", ""),
        "url": manifest.get("url"),
        "sha256": manifest.get("sha256"),
    }


def _guard_no_foreign_flask():
    """Belt-and-suspenders check inspired directly by the flask.service
    incident during step 2 of this project: refuse to proceed if
    something other than the pinclock.service-managed process is bound
    to port 5000, since staging a swap underneath a supervisor we don't
    know about is exactly how that incident happened in the first
    place."""
    try:
        out = subprocess.run(
            ["systemctl", "--user", "show", "-p", "MainPID", "--value", "pinclock.service"],
            capture_output=True, text=True, timeout=10,
        )
        managed_pid = out.stdout.strip()
    except (subprocess.SubprocessError, OSError) as e:
        raise UpdateError(f"could not query pinclock.service state: {e}")

    try:
        listeners = subprocess.run(
            ["ss", "-ltnp", "sport", "=", ":5000"],
            capture_output=True, text=True, timeout=10,
        ).stdout
    except (subprocess.SubprocessError, OSError):
        listeners = ""

    if listeners and managed_pid and managed_pid != "0" and f"pid={managed_pid}" not in listeners:
        raise UpdateError(
            "port 5000 appears to be held by a process other than the "
            "pinclock.service-managed one - refusing to proceed. Run "
            "`systemctl --user status pinclock.service` and `sudo ss "
            "-ltnp sport = :5000` to investigate before retrying."
        )


def _acquire_lock():
    LOCK_FILE.parent.mkdir(parents=True, exist_ok=True)
    if LOCK_FILE.exists():
        try:
            pid = int(LOCK_FILE.read_text().strip())
            os.kill(pid, 0)  # raises OSError if not alive
            raise UpdateError(f"an update is already in progress (pid {pid})")
        except (ValueError, ProcessLookupError, PermissionError):
            pass  # stale lock from a crashed previous run - safe to take over
    LOCK_FILE.write_text(str(os.getpid()))


def _release_lock():
    try:
        LOCK_FILE.unlink()
    except FileNotFoundError:
        pass


def _restart_and_healthcheck():
    subprocess.run(["systemctl", "--user", "restart", "pinclock.service"], check=True, timeout=30)
    deadline = time.time() + HEALTHCHECK_TIMEOUT_S
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(HEALTHCHECK_URL, timeout=3) as resp:
                if resp.status == 200:
                    return True
        except (urllib.error.URLError, OSError):
            pass
        time.sleep(HEALTHCHECK_POLL_INTERVAL_S)
    return False


def _rollback(previous_target, to_version, reason, operation="update"):
    _write_status("rolled_back", to_version=to_version, message=f"rolling back: {reason}", operation=operation)
    if previous_target is not None:
        _atomic_symlink(CURRENT_LINK, previous_target)
    healthy = _restart_and_healthcheck()
    if healthy:
        _write_status("rolled_back", to_version=to_version,
                       message=f"rolled back successfully after: {reason}", operation=operation)
    else:
        # This is the scenario the whole design has been trying to keep
        # small: rollback itself didn't come back healthy. Nothing left
        # to automatically try - this needs a human with console access.
        _write_status("failed", to_version=to_version,
                       message=f"UPDATE AND ROLLBACK BOTH FAILED ({reason}) - "
                               f"needs manual intervention, see journalctl --user -u pinclock",
                       operation=operation)


def _atomic_symlink(link_path, target_path):
    tmp_link = link_path.with_name(link_path.name + ".tmp")
    if tmp_link.exists() or tmp_link.is_symlink():
        tmp_link.unlink()
    tmp_link.symlink_to(target_path)
    tmp_link.replace(link_path)  # atomic rename, same filesystem


def _parse_version(v):
    """'0.9.0' -> (0, 9, 0). Deliberately simple (no pre-release/build
    metadata support) - this project's versions are plain X.Y.Z, and a
    strict parser here means an unexpected format fails loudly instead
    of silently comparing wrong."""
    try:
        return tuple(int(p) for p in v.split("."))
    except (ValueError, AttributeError):
        raise UpdateError(f"couldn't parse version string {v!r} as X.Y.Z")


def _check_min_upgrade_from(from_version, release_manifest):
    """A release can declare release-manifest.json's min_upgrade_from
    if it depends on a migration (e.g. step 1's data/code path split)
    having already happened - refuse to jump straight to it from an
    older version that predates that assumption, rather than silently
    staging something that assumes state which isn't there yet."""
    min_from = release_manifest.get("min_upgrade_from")
    if not min_from or not from_version:
        return
    if _parse_version(from_version) < _parse_version(min_from):
        raise UpdateError(
            f"this release requires upgrading from {min_from} or later "
            f"(currently on {from_version}) - upgrade to an intermediate "
            f"version first"
        )


def run_update():
    from_version = _current_version()
    previous_target = CURRENT_LINK.resolve() if CURRENT_LINK.exists() else None

    _acquire_lock()
    try:
        _guard_no_foreign_flask()

        _write_status("checking", from_version=from_version, message="fetching update manifest")
        manifest = _fetch_json(UPDATE_MANIFEST_URL)
        to_version = manifest.get("latest")
        tarball_url = manifest.get("url")
        expected_sha256 = manifest.get("sha256")
        if not (to_version and tarball_url and expected_sha256):
            raise UpdateError("update manifest is missing required fields (latest/url/sha256)")

        if from_version and to_version == from_version:
            _write_status("success", from_version, to_version, message="already up to date")
            return

        with tempfile.TemporaryDirectory(dir=str(RELEASES_DIR.parent)) as tmp:
            tmp = Path(tmp)
            tarball_path = tmp / "release.tar.gz"

            _write_status("downloading", from_version, to_version, message=f"downloading {tarball_url}")
            _download(tarball_url, tarball_path)

            _write_status("verifying", from_version, to_version, message="checking tarball checksum")
            actual_sha256 = _sha256_file(tarball_path)
            if actual_sha256 != expected_sha256:
                raise UpdateError(
                    f"tarball checksum mismatch (expected {expected_sha256}, got {actual_sha256}) "
                    f"- refusing to install, download may be corrupt or tampered with"
                )

            _write_status("staging", from_version, to_version, message="extracting release")
            release_dir = RELEASES_DIR / to_version
            if release_dir.exists():
                shutil.rmtree(release_dir)
            release_dir.mkdir(parents=True)
            with tarfile.open(tarball_path) as tf:
                _safe_extract(tf, release_dir)

            release_manifest_path = release_dir / "release-manifest.json"
            if not release_manifest_path.exists():
                raise UpdateError("staged release is missing release-manifest.json")
            release_manifest = json.loads(release_manifest_path.read_text())

            _check_min_upgrade_from(from_version, release_manifest)

            _write_status("verifying", from_version, to_version, message="checking staged file hashes")
            _verify_release_files(release_dir, release_manifest)

            newly_synced_videos = _sync_shipped_videos_and_strip(release_dir, from_version, to_version)

            _run_post_install_hook(release_dir, release_manifest, from_version, to_version)

        _write_status("restarting", from_version, to_version, message="switching to new release")
        new_target = RELEASES_DIR / to_version / "pinclock"
        _atomic_symlink(CURRENT_LINK, new_target)

        _write_status("healthchecking", from_version, to_version, message="waiting for pinclock.service to come up")
        healthy = _restart_and_healthcheck()
        if not healthy:
            _rollback(previous_target, to_version, "new release failed health check after restart")
            return

        reported = _current_version_live()
        if reported != to_version:
            _rollback(previous_target, to_version,
                      f"new release came up but reports version {reported!r}, expected {to_version!r}")
            return

        if newly_synced_videos:
            _add_new_shipped_videos_to_playlist(newly_synced_videos)

        _write_status("success", from_version, to_version, message=f"updated {from_version} -> {to_version}")
        _prune_old_releases(keep=3)

    except UpdateError as e:
        _write_status("failed", from_version, message=str(e))
        # No swap happened yet in most UpdateError cases (they're mostly
        # raised before _atomic_symlink runs) - but if we get here after
        # the swap, roll back rather than leaving a half-applied state.
        if CURRENT_LINK.exists() and CURRENT_LINK.resolve() != previous_target and previous_target is not None:
            _rollback(previous_target, None, str(e))
    finally:
        _release_lock()


def _safe_extract(tf, dest_dir):
    """tarfile.extractall guard against path traversal (../../etc/passwd
    style entries) in a tarball we've already checksum-verified but
    still shouldn't blindly trust the internal structure of."""
    dest_dir = dest_dir.resolve()
    for member in tf.getmembers():
        member_path = (dest_dir / member.name).resolve()
        if not str(member_path).startswith(str(dest_dir) + os.sep):
            raise UpdateError(f"tarball contains an unsafe path: {member.name}")
    tf.extractall(dest_dir)


def _verify_release_files(release_dir, release_manifest):
    for rel_path, expected_hash in release_manifest.get("files", {}).items():
        full_path = release_dir / "pinclock" / rel_path
        if not full_path.exists():
            raise UpdateError(f"release manifest lists {rel_path} but it wasn't extracted")
        expected = expected_hash.split("sha256:")[-1]
        actual = _sha256_file(full_path)
        if actual != expected:
            raise UpdateError(f"checksum mismatch for {rel_path} in staged release")


POST_INSTALL_HOOK_TIMEOUT_S = 120


def _sync_shipped_videos_and_strip(release_dir, from_version, to_version):
    """
    Copies any videos from the just-staged release's OWN
    pinclock/shipped-videos/ folder into PERSISTENT_SHIPPED_VIDEOS_DIR,
    then deletes that folder from the release directory entirely - so
    the release directory that actually sticks around (kept for
    rollback by _prune_old_releases) never carries video content, only
    the one persistent, non-versioned copy does. See
    app/core/paths.py's SHIPPED_VIDEOS_DIR for the full reasoning on
    why this split exists.

    Idempotent and cumulative, same philosophy as post_install_hook:
    copies a file only if it's missing or its content actually differs
    (by checksum) from what's already in the persistent store - never
    deletes anything from there, so a device that skipped several
    releases still ends up with every video any of the skipped
    releases would have added, and re-running this (e.g. a retried
    update) never re-copies unchanged files.

    Deliberately runs AFTER _verify_release_files, not before: that
    function checksums shipped-videos/ entries the same way as any
    other file in the release manifest, against the copy still sitting
    in the release directory at that point - stripping it first would
    make verification fail with a false "file missing" error.

    Returns the filenames that were genuinely new or changed by this
    call - NOT the full set of shipped videos, and not ones that were
    already present with identical content. run_update() uses this
    list (after the health check passes) to auto-add exactly those
    videos to the live playlist, so a firmware update that adds a new
    shipped video makes it actually play, without also silently
    re-adding something a person had previously and deliberately
    removed from their playlist just because its content happens to be
    unchanged in this release.
    """
    src_dir = release_dir / "pinclock" / "shipped-videos"
    if not src_dir.exists():
        return []

    to_copy = [f for f in src_dir.iterdir() if f.is_file()]
    newly_added = []
    if to_copy:
        _write_status("staging", from_version, to_version,
                       message=f"syncing {len(to_copy)} shipped video(s) to persistent storage")
        PERSISTENT_SHIPPED_VIDEOS_DIR.mkdir(parents=True, exist_ok=True)
        for src_file in to_copy:
            dst_file = PERSISTENT_SHIPPED_VIDEOS_DIR / src_file.name
            if dst_file.exists() and _sha256_file(dst_file) == _sha256_file(src_file):
                continue  # already present with identical content - nothing to do
            shutil.copy2(src_file, dst_file)
            newly_added.append(src_file.name)

    # Strip the now-redundant copy from the release directory regardless
    # of whether anything needed copying above - this release's copy of
    # shipped-videos/ has served its purpose (declaring what should be
    # in the persistent store) and shouldn't stick around duplicating it.
    shutil.rmtree(src_dir)
    return newly_added


def _add_new_shipped_videos_to_playlist(filenames):
    """
    After a successful update, tells the (now live, health-checked)
    Flask process to add each genuinely-new shipped video to the
    playlist - via HTTP, not by importing or directly mutating
    settings.json. Same reasoning as run_factory_reset() calling
    /api/system/reset-defaults over HTTP rather than duplicating that
    logic here: the validated, tested add_to_playlist() codepath
    already exists in the app that's now confirmed running, so this
    reuses it rather than risking a second, drifted implementation of
    the same thing inside this isolated script.

    Best-effort: a failure here is logged but does NOT fail or roll
    back an otherwise-successful update - the new code is verified,
    running, and healthy either way; worst case, the new shipped
    video(s) just need adding manually via the Stock tab.
    """
    for name in filenames:
        try:
            body = json.dumps({"name": name, "source": "shipped"}).encode()
            req = urllib.request.Request(
                f"{HEALTHCHECK_URL}api/playlist/add", method="POST", data=body,
                headers={"Content-Type": "application/json"},
            )
            urllib.request.urlopen(req, timeout=10)
        except (urllib.error.URLError, OSError) as e:
            print(f"[run_update] WARNING: could not auto-add {name!r} to playlist: {e}")


def _run_post_install_hook(release_dir, release_manifest, from_version, to_version):
    """
    Runs release-manifest.json's optional "post_install_hook" (a path,
    relative to the staged pinclock/ directory, to a script bundled in
    the release - e.g. "scripts/post_install.py") for any one-time
    system-level setup a release needs before it starts running:
    creating a directory, adjusting a permission, writing a config file
    it expects to already exist - anything short of requiring new root
    privileges (see the note below on why that's out of scope here).

    RUNS BEFORE THE SYMLINK SWAP, DELIBERATELY: if the hook fails, this
    aborts the whole update exactly like a checksum failure would -
    nothing gets swapped, the previous version keeps running
    uninterrupted, no rollback is needed because nothing changed yet.
    Whatever partial side effects the hook already made before failing
    (e.g. a directory it already created) are expected to be harmless
    debris precisely because of the idempotency requirement below - not
    something that needs its own undo.

    CRITICAL REQUIREMENT FOR ANYONE WRITING ONE OF THESE, laid out here
    because getting this wrong silently reintroduces exactly the
    "device skipped 3 releases" gap this mechanism exists to close:

      A hook MUST be written as "ensure the full set of prerequisites
      THIS version needs are in place", not "apply what changed since
      the previous version". A device updating straight from 0.8.0 to
      0.11.0 only ever runs 0.11.0's hook - 0.9.0's and 0.10.0's hooks
      never execute for that device, because this mechanism does a
      single hop from whatever "current" is straight to "latest", not
      a chain of intermediate steps. If 0.11.0's hook only does its
      own incremental delta (assuming 0.9.0's and 0.10.0's setup
      already happened), a device that skipped straight there ends up
      silently missing whatever those two would have done. Every
      hook's job is therefore to declare and idempotently ensure ALL
      of its version's prerequisites, cumulative back to the start of
      this mechanism's existence, every single time - "mkdir -p"-style
      idempotence, not "mkdir" that fails or double-applies on a
      second run.

    WHY THIS CAN'T GRANT SUDO: giving an automated hook its own root
    access would undo the project's deliberate choice not to add any
    new sudoers entries for the update mechanism. If a future release
    genuinely needs a root-level system change (a new sudoers fragment,
    a package install), that stays a manual, documented, human-reviewed
    step - the same category autostart/cursor-theme/sudoers changes
    already are - not something this hook can do on its own.
    """
    hook_rel_path = release_manifest.get("post_install_hook")
    if not hook_rel_path:
        return

    hook_path = release_dir / "pinclock" / hook_rel_path
    if not hook_path.exists():
        raise UpdateError(f"release manifest specifies post_install_hook {hook_rel_path!r} but it wasn't extracted")

    _write_status("staging", from_version, to_version, message=f"running post-install hook {hook_rel_path}")
    try:
        result = subprocess.run(
            ["/usr/bin/python3", str(hook_path)],
            capture_output=True, text=True, timeout=POST_INSTALL_HOOK_TIMEOUT_S,
        )
    except subprocess.TimeoutExpired:
        raise UpdateError(f"post-install hook {hook_rel_path} timed out after {POST_INSTALL_HOOK_TIMEOUT_S}s")
    except OSError as e:
        raise UpdateError(f"could not run post-install hook {hook_rel_path}: {e}")

    if result.returncode != 0:
        raise UpdateError(
            f"post-install hook {hook_rel_path} failed (exit {result.returncode}): "
            f"{result.stderr.strip() or result.stdout.strip() or 'no output'}"
        )


def _find_factory_snapshot():
    """Locate the single blessed factory snapshot under FACTORY_ROOT (see
    scripts/bless_factory.py). Deliberately refuses to guess if there's
    zero or more than one - a device should have exactly one "what it
    shipped with" baseline, and silently picking one among several (or
    proceeding with none) is exactly the kind of ambiguity this whole
    project has been trying to design out."""
    if not FACTORY_ROOT.exists():
        raise UpdateError(f"{FACTORY_ROOT} doesn't exist - this device has no blessed factory snapshot")
    candidates = [d for d in FACTORY_ROOT.iterdir() if d.is_dir()]
    if len(candidates) == 0:
        raise UpdateError(f"{FACTORY_ROOT} exists but contains no factory snapshot")
    if len(candidates) > 1:
        raise UpdateError(
            f"{FACTORY_ROOT} contains more than one snapshot ({[c.name for c in candidates]}) - "
            f"refusing to guess which is the real factory baseline"
        )
    return candidates[0]


def _restore_labwc_files(factory_dir):
    """Copies the factory-blessed autostart/environment back into
    ~/.config/labwc/ - plain vfw-writable file copies, no sudo needed.
    Best-effort per file (missing individual files in an older snapshot
    format shouldn't block the rest of the reset)."""
    labwc_snapshot = factory_dir / "labwc"
    if not labwc_snapshot.exists():
        return
    LABWC_DIR.mkdir(parents=True, exist_ok=True)
    for name in ("autostart", "environment"):
        src = labwc_snapshot / name
        if src.exists():
            shutil.copy2(src, LABWC_DIR / name)


def _wipe_videos():
    """Factory Reset's one deliberate difference from Default Settings:
    it also clears user-added videos, since "back to how it left the
    factory" means no user media either - Default Settings intentionally
    leaves videos alone (see its own docstring in app.py)."""
    videos_dir = DATA_DIR / "videos"
    if not videos_dir.exists():
        return
    for f in videos_dir.iterdir():
        if f.is_file():
            f.unlink()


def run_factory_reset():
    """
    Device tab's "Factory Reset". Restores the code + labwc system
    config from the blessed factory snapshot (see
    scripts/bless_factory.py), verified by checksum the same way a
    downloaded update is - then, once that's confirmed healthy, resets
    settings/WiFi/state and clears videos, and reboots.

    Deliberately reuses run_update()'s own swap/restart/health-check/
    rollback machinery (same lock, same _atomic_symlink, same
    _restart_and_healthcheck, same _rollback) rather than a parallel
    implementation - a factory restore that fails health-checking is
    exactly as dangerous as a bad update, and deserves the identical
    safety net.

    For the settings/WiFi/state reset itself, this deliberately does
    NOT reimplement that logic here (unlike everything else in this
    script, which stays stdlib-only and independent of the release
    tree) - it calls the already-existing, already-tested
    /api/system/reset-defaults endpoint over HTTP once the restored
    code is confirmed healthy (the same reasoning as
    _current_version_live()'s HTTP call - safe here because nothing is
    synchronously blocked waiting on this factory-reset process). This
    means zero duplicated logic for wifi_manager.forget() specifically,
    which has real edge-case handling worth not maintaining in two
    places (see that function's own docstring). That endpoint also
    schedules its own reboot, which doubles as this whole factory
    reset's final reboot.
    """
    from_version = _current_version()
    previous_target = CURRENT_LINK.resolve() if CURRENT_LINK.exists() else None
    op = "factory_reset"

    _acquire_lock()
    try:
        _guard_no_foreign_flask()

        _write_status("checking", from_version=from_version, message="locating factory snapshot", operation=op)
        factory_dir = _find_factory_snapshot()
        manifest_path = factory_dir / "release-manifest.json"
        if not manifest_path.exists():
            raise UpdateError(f"factory snapshot at {factory_dir} is missing release-manifest.json")
        factory_manifest = json.loads(manifest_path.read_text())
        to_version = factory_manifest.get("version")
        if not to_version:
            raise UpdateError("factory snapshot manifest is missing a version field")

        _write_status("verifying", from_version, to_version, message="checking factory snapshot integrity", operation=op)
        _verify_release_files(factory_dir, factory_manifest)

        _write_status("staging", from_version, to_version, message="restoring factory release", operation=op)
        new_release_dir = RELEASES_DIR / f"{to_version}-factory-{int(time.time())}"
        shutil.copytree(factory_dir / "pinclock", new_release_dir / "pinclock")
        _restore_labwc_files(factory_dir)

        _write_status("restarting", from_version, to_version, message="switching to factory release", operation=op)
        _atomic_symlink(CURRENT_LINK, new_release_dir / "pinclock")

        _write_status("healthchecking", from_version, to_version,
                       message="waiting for pinclock.service to come up", operation=op)
        healthy = _restart_and_healthcheck()
        if not healthy:
            _rollback(previous_target, to_version, "factory release failed health check after restart", operation=op)
            return

        _write_status("wiping_data", from_version, to_version, message="clearing videos", operation=op)
        _wipe_videos()

        _write_status("success", from_version, to_version,
                       message="factory release restored - resetting settings/WiFi and rebooting", operation=op)
        try:
            req = urllib.request.Request(
                f"{HEALTHCHECK_URL}api/system/reset-defaults", method="POST", data=b"{}",
                headers={"Content-Type": "application/json"},
            )
            urllib.request.urlopen(req, timeout=10)
        except (urllib.error.URLError, OSError) as e:
            raise UpdateError(f"factory code restored, but couldn't trigger settings/WiFi reset: {e}")

    except UpdateError as e:
        _write_status("failed", from_version, message=str(e), operation=op)
        if CURRENT_LINK.exists() and previous_target is not None and CURRENT_LINK.resolve() != previous_target:
            _rollback(previous_target, None, str(e), operation=op)
    finally:
        _release_lock()


def _prune_old_releases(keep=3):
    """Keep the last `keep` releases on disk (current + a couple of
    predecessors) so a rollback doesn't require a re-download - but
    don't let /opt fill up indefinitely either."""
    current_target = CURRENT_LINK.resolve() if CURRENT_LINK.exists() else None
    releases = sorted(
        (d for d in RELEASES_DIR.iterdir() if d.is_dir()),
        key=lambda d: d.stat().st_mtime, reverse=True,
    )
    for old in releases[keep:]:
        if current_target and old in current_target.parents:
            continue  # never prune the release currently in use
        shutil.rmtree(old, ignore_errors=True)


if __name__ == "__main__":
    RELEASES_DIR.mkdir(parents=True, exist_ok=True)
    if "--check" in sys.argv:
        # Read-only path used by Flask's GET /api/firmware/check, which
        # runs this via subprocess.run(...) SYNCHRONOUSLY - blocking
        # that request handler until this process exits. That's exactly
        # why check_for_update() -> _current_version() must NOT make an
        # HTTP call back into Flask (an earlier version of this code
        # did, reasoning "fine from a separate process" - true for this
        # process, but irrelevant: the parent Flask handler blocking on
        # subprocess.run() recreates the exact same deadlock one level
        # up, since Flask's event loop has nothing free to service the
        # incoming connection with). See _current_version()'s docstring
        # for the full story.
        try:
            print(json.dumps(check_for_update()))
        except UpdateError as e:
            print(json.dumps({"error": str(e)}))
            sys.exit(1)
        sys.exit(0)

    if "--factory-reset" in sys.argv:
        try:
            run_factory_reset()
        except UpdateError as e:
            _write_status("failed", message=str(e), operation="factory_reset")
            sys.exit(1)
        sys.exit(0)

    try:
        run_update()
    except UpdateError as e:
        # Top-level catch-all in case an UpdateError somehow escapes
        # run_update()'s own handling (e.g. raised by _acquire_lock
        # before the try block's except UpdateError is in scope).
        _write_status("failed", message=str(e))
        sys.exit(1)
