#!/usr/bin/env python3
"""
PinClock release packaging tool.

Run manually by a developer on their own machine - never on the Pi
itself, and never deployed to a device. Produces two things:

  1. pinclock-<version>.tar.gz  - upload this as a GitHub Release asset
  2. update-manifest.json        - commit + push this to the
                                    pinclock-firmware repo's default branch

Nothing here talks to GitHub's API or pushes anything automatically
(by design - see the project's step 3 design discussion): you run this
script, then upload/commit the two outputs yourself.

Usage:
    python3 scripts/build_release.py 0.9.0 \\
        --changelog "Fixes X, adds Y" \\
        [--min-upgrade-from 0.8.0] \\
        [--repo DonMilo/pinclock-firmware] \\
        [--output-dir dist]

The <version> argument must match PINCLOCK_VERSION in app.py (after
stripping a leading "v") - this is deliberate and not just a sanity
check: it forces the version to actually be bumped in the source before
a release can be cut, so there's no way to publish a tarball whose
contents disagree with what the running device will report as its own
version once installed.

WHAT GETS INCLUDED:
Every file under the pinclock/ directory (the same one this script
lives inside), except the exclusions below. Notably, this does NOT
include .config/labwc/autostart or .config/labwc/environment - those
live outside pinclock/ entirely (they're siblings of it, installed to
~/.config/labwc/ on the device, not under the app's own directory) and
so are never part of an automated update by construction. That's
intentional: system-config files stay a manual, reviewed change (see
the project's step 3 scoping discussion) rather than something this
tool can silently overwrite.
"""
import argparse
import fnmatch
import hashlib
import json
import re
import sys
import tarfile
import time
from pathlib import Path

# Directory names skipped entirely, wherever they appear in the tree.
EXCLUDED_DIR_NAMES = {
    ".git", "__pycache__", ".pytest_cache", "venv", "node_modules",
    "logs", "uploads", "converted", "dist",
}
# Filename glob patterns skipped wherever they appear.
EXCLUDED_FILE_PATTERNS = [
    "*.pyc", "*.pyo", ".DS_Store", "*.tmp", ".gitignore",
]


def _sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _discover_files(source_dir):
    """Walk source_dir, returning a sorted list of (relative_posix_path,
    absolute_path) for every file to include. Sorted so the resulting
    tarball and manifest are byte-for-byte reproducible across runs on
    the same input."""
    included = []
    for path in sorted(source_dir.rglob("*")):
        if path.is_dir():
            continue
        rel_parts = path.relative_to(source_dir).parts
        if any(part in EXCLUDED_DIR_NAMES for part in rel_parts[:-1]):
            continue
        if any(fnmatch.fnmatch(path.name, pat) for pat in EXCLUDED_FILE_PATTERNS):
            continue
        included.append((path.relative_to(source_dir).as_posix(), path))
    return included


def _read_app_version(source_dir):
    app_py = source_dir / "app.py"
    if not app_py.exists():
        return None
    m = re.search(r'^PINCLOCK_VERSION\s*=\s*["\'](.+?)["\']', app_py.read_text(), re.MULTILINE)
    return m.group(1).lstrip("v") if m else None


def build_release(version, source_dir, output_dir, repo, changelog, min_upgrade_from, post_install_hook=None):
    app_version = _read_app_version(source_dir)
    if app_version is None:
        print(f"ERROR: couldn't find PINCLOCK_VERSION in {source_dir / 'app.py'}", file=sys.stderr)
        sys.exit(1)
    if app_version != version:
        print(
            f"ERROR: --version {version} doesn't match PINCLOCK_VERSION "
            f"(\"v{app_version}\") in app.py.\n"
            f"Bump PINCLOCK_VERSION in app.py to \"v{version}\" first, so the "
            f"code you're about to package actually reports the version "
            f"you're releasing it as.",
            file=sys.stderr,
        )
        sys.exit(1)

    output_dir.mkdir(parents=True, exist_ok=True)
    tarball_path = output_dir / f"pinclock-{version}.tar.gz"
    manifest_path = output_dir / "update-manifest.json"

    files = _discover_files(source_dir)
    if not files:
        print(f"ERROR: no files discovered under {source_dir} - check the path", file=sys.stderr)
        sys.exit(1)

    print(f"Packaging {len(files)} files from {source_dir}...")
    file_hashes = {}
    for rel_path, abs_path in files:
        file_hashes[rel_path] = "sha256:" + _sha256_file(abs_path)

    release_manifest = {
        "version": version,
        "files": file_hashes,
    }
    if min_upgrade_from:
        release_manifest["min_upgrade_from"] = min_upgrade_from
    if post_install_hook:
        hook_full_path = source_dir / post_install_hook
        if post_install_hook not in file_hashes:
            print(
                f"ERROR: --post-install-hook {post_install_hook} was not found among the "
                f"discovered files under {source_dir} - check the path is relative to "
                f"source_dir and wasn't caught by an exclusion pattern",
                file=sys.stderr,
            )
            sys.exit(1)
        release_manifest["post_install_hook"] = post_install_hook

    release_manifest_bytes = json.dumps(release_manifest, indent=2).encode()

    with tarfile.open(tarball_path, "w:gz") as tf:
        for rel_path, abs_path in files:
            tf.add(abs_path, arcname=f"pinclock/{rel_path}")
        info = tarfile.TarInfo(name="release-manifest.json")
        info.size = len(release_manifest_bytes)
        info.mtime = 0
        tf.addfile(info, __import__("io").BytesIO(release_manifest_bytes))

    tarball_sha256 = _sha256_file(tarball_path)
    release_url = f"https://github.com/{repo}/releases/download/v{version}/pinclock-{version}.tar.gz"

    update_manifest = {
        "latest": version,
        "url": release_url,
        "sha256": tarball_sha256,
        "changelog": changelog or "",
    }
    manifest_path.write_text(json.dumps(update_manifest, indent=2))

    print()
    print(f"Built {tarball_path} ({tarball_path.stat().st_size:,} bytes, sha256 {tarball_sha256})")
    print(f"Wrote {manifest_path}")
    print()
    print("Next steps:")
    print(f"  1. Create a GitHub Release in {repo} tagged exactly:  v{version}")
    print(f"  2. Upload {tarball_path.name} as that release's asset (filename must match exactly)")
    print(f"  3. Confirm the asset URL is exactly:")
    print(f"       {release_url}")
    print(f"     (GitHub derives this from the tag + filename - if either doesn't match, devices")
    print(f"     will get a 404 when they try to download it)")
    print(f"  4. Commit and push {manifest_path.name} to the {repo} default branch")
    print()
    print("Nothing is live on any device until step 4 - devices only ever read")
    print("update-manifest.json from the repo, never GitHub's release list directly.")


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("version", help="Version being released, e.g. 0.9.0 (must match PINCLOCK_VERSION in app.py)")
    parser.add_argument("--changelog", default="", help="Short human-readable changelog shown on the Device tab")
    parser.add_argument("--min-upgrade-from", default=None,
                         help="Refuse to install this release on devices older than this version")
    parser.add_argument("--post-install-hook", default=None,
                         help="Path (relative to source-dir) to a script run before the symlink "
                              "swap, e.g. scripts/post_install.py - see run_update.py's "
                              "_run_post_install_hook docstring for the idempotency requirement "
                              "before writing one of these")
    parser.add_argument("--repo", default="DonMilo/pinclock-firmware",
                         help="GitHub owner/repo releases are published to (default: DonMilo/pinclock-firmware)")
    parser.add_argument("--source-dir", default=None,
                         help="Path to the pinclock/ app directory to package (default: this script's own parent pinclock/ dir)")
    parser.add_argument("--output-dir", default="dist", help="Where to write the tarball + manifest (default: ./dist)")
    args = parser.parse_args()

    source_dir = Path(args.source_dir) if args.source_dir else Path(__file__).resolve().parent.parent
    output_dir = Path(args.output_dir)

    build_release(
        version=args.version,
        source_dir=source_dir,
        output_dir=output_dir,
        repo=args.repo,
        changelog=args.changelog,
        min_upgrade_from=args.min_upgrade_from,
        post_install_hook=args.post_install_hook,
    )


if __name__ == "__main__":
    main()
