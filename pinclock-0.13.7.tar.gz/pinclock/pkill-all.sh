# Stop the mpv/cog supervisor loops FIRST, before killing mpv/cog
# themselves - otherwise a loop that's still alive just respawns its
# child within ~1s of being killed (verified in sandbox testing), and
# this script silently fails to actually stop anything. See supervise()
# in labwc/autostart for the respawn logic these pidfiles belong to.
# The cursor-position loop isn't a respawn guard for anything else, but
# it's the same kind of perpetual background `while true` loop, so it
# gets cleaned up here too rather than left running after everything
# else it was working around is gone.
for f in /tmp/pinclock-mpv-supervisor.pid /tmp/pinclock-cog-supervisor.pid /tmp/pinclock-cursor-loop.pid; do
    if [ -f "$f" ]; then
        kill "$(cat "$f")" 2>/dev/null
        rm -f "$f"
    fi
done

pkill labwc
pkill mpv
pkill cog
pkill -f "pinclock/app.py"

rm -f /tmp/mpvsocket /tmp/pinclock-playlist.m3u
